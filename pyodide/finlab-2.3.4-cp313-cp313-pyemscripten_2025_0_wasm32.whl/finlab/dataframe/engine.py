"""Frames as expressions, computed only at the dates asked for.

Every node answers ``at(when)`` with a numpy matrix of shape (dates, columns), reading only
rows at or before each date. That one rule is what keeps a backtest free of look-ahead, and
what lets ``sim`` ask for a few hundred rows instead of whole tables.

A frame that is still an expression is a real ``FinlabDataFrame`` (``Frame``) with no data yet.
A kernel answers what it can; anything else reaches for ``_mgr``, which computes every date
and turns the object into a plain ``FinlabDataFrame`` for good, so pandas does the rest.
"""

from __future__ import annotations

import operator
import os
from functools import cache, wraps
from inspect import isfunction, signature
from weakref import ReferenceType, ref

import numpy as np
import pandas as pd
from pandas.api.extensions import no_default
from pandas.core.window.ewm import get_center_of_mass

from finlab.core import kernels as _K
from finlab.dataframe import core_index
from finlab.dataframe.core import _OBJECT_INVERT_ERROR
from finlab.dataframe.core import FinlabDataFrame as FDF
from finlab.dataframe.cs import CsAccessor
from finlab.dataframe.parallel import rank_rows as _ranks_of_rows
from finlab.dataframe.sector import SectorAccessor
from finlab.dataframe.weight import WeightAccessor

ENABLED = os.environ.get("FINLAB_ENGINE") == "expression"
_HOW = {"sum": 0, "mean": 1, "var": 2, "std": 3, "min": 4, "max": 5}
_SERIES_PCT_FILL_METHOD = (
    signature(pd.Series.pct_change).parameters["fill_method"].default
)


def _ns(index):
    return pd.DatetimeIndex(index).as_unit("ns").asi8


def _num(a):
    return a.astype(float) if isinstance(a, np.ndarray) and a.dtype == bool else a


def _widened(a):
    """Numbers that can hold NaN: pandas widens whole numbers, and float32 stays."""
    return a.astype(float) if a.dtype.kind in "biu" else a


def _count(n):
    return isinstance(n, (int, np.integer))


def _number(value):
    return isinstance(value, (bool, int, float, np.number, np.bool_))


class _Mask(np.ndarray):
    """A mask held as numbers. Arithmetic on it gives plain numbers, not another mask."""

    def __array_ufunc__(self, ufunc, method, *inputs, **kwargs):
        def plain(value):
            return np.asarray(value) if isinstance(value, _Mask) else value

        if "out" in kwargs:
            kwargs["out"] = tuple(map(plain, kwargs["out"]))
        return getattr(ufunc, method)(*map(plain, inputs), **kwargs)


class _Nullable(_Mask):
    """A nullable mask, 1, 0 or NaN for unknown, as a quarterly mask is before its disclosure."""


class _BoolWithGaps(_Mask):
    """A mask with NaN cells, as ``shift`` or a reindex leaves one: pandas holds it as objects,
    where ``NaN | True`` is NaN and reads as False, unlike a nullable mask."""


def _kleene(op, a, b):
    """Three-valued logic. A plain mask takes unknown as False, as ``_dense_logical_operation`` does."""
    x, y = _num(a), _num(b)
    unknown = np.isnan(x) | np.isnan(y)
    if op is np.logical_and:
        values = (x != 0) & (y != 0)
        unknown &= ~((x == 0) | (y == 0))
    elif op is np.logical_or:
        values = (x != 0) | (y != 0)
        unknown = (
            np.isnan(x) & (y == 0) | np.isnan(y) & (x == 0) | np.isnan(x) & np.isnan(y)
        )
    else:
        values = (x != 0) ^ (y != 0)
    if any(isinstance(side, np.ndarray) and side.dtype == bool for side in (a, b)):
        return values & ~unknown
    out = values.astype(float)
    out[unknown] = np.nan
    return out.view(_Nullable)


_BITWISE = {
    np.logical_and: np.bitwise_and,
    np.logical_or: np.bitwise_or,
    np.logical_xor: np.bitwise_xor,
}


def _logical(op):
    def run(a, b):
        if type(a) is _Nullable or type(b) is _Nullable:
            return _kleene(op, a, b)
        kinds = {np.asarray(a).dtype.kind, np.asarray(b).dtype.kind}
        # Whole numbers combine bit by bit, and next to a mask pandas reads the result as one.
        if kinds - {"b"} and kinds <= {"b", "i", "u"}:
            out = _BITWISE[op](a, b)
            return out != 0 if "b" in kinds else out
        out = op(_bool(a), _bool(b))
        for side in (a, b):
            if type(side) is _BoolWithGaps:
                out &= ~np.isnan(side)
        return out

    return run


def _gapped(out, raw):
    """``out``, numbers read from the mask ``raw``, still a mask of ``raw``'s kind."""
    if type(raw) is _Nullable or type(raw) is _BoolWithGaps:
        return out.view(type(raw))
    return out.view(_BoolWithGaps) if raw.dtype == bool else out


def _flags(a):
    return type(a) is _Nullable or (isinstance(a, np.ndarray) and a.dtype == bool)


def _added(op, logical):
    """Masks add as ``|`` and multiply as ``&`` in pandas; next to a nullable one, unknown stays."""

    def run(a, b):
        if _flags(a) and _flags(b) and _Nullable in (type(a), type(b)):
            unknown = pd.isna(a) | pd.isna(b)
            return np.where(unknown, np.nan, logical(a != 0, b != 0)).view(_Nullable)
        return op(a, b)

    return run


def _compared(op):
    """Comparing an unknown cell is unknown: ``mask != True`` must not hold it before disclosure."""

    def run(a, b):
        out = op(a, b)
        if type(a) is _Nullable or type(b) is _Nullable:
            return np.where(pd.isna(a) | pd.isna(b), np.nan, out).view(_Nullable)
        return out

    return run


def _bool(a):
    if isinstance(a, np.ndarray):
        return a if a.dtype == bool else np.nan_to_num(a) != 0
    return bool(np.nan_to_num(a))


def _nanoseconds(dates):
    """Column-major nanoseconds of a datetime64 matrix, the largest integer for NaT."""
    never = np.iinfo(np.int64).max
    return np.asfortranarray(
        np.where(
            np.isnat(dates), never, dates.astype("datetime64[ns]").astype(np.int64)
        )
    )


def _columns(array):
    """A float64 matrix laid out column by column, as the kernels read it."""
    return np.asfortranarray(array, dtype=np.float64)


def _rows_of(values, rows):
    """``values[rows]``. Tables are stored column by column, so many rows go column by column too."""
    if values.dtype != np.float64 or not values.flags.f_contiguous:
        return values[rows]
    rows = np.asarray(rows, dtype=np.int64)
    out = np.empty((len(rows), values.shape[1]), order="F")
    _K.take(values, rows, out)
    return out


def _every_row(rows, length):
    """Whether ``rows`` is every row of an axis in order."""
    return len(rows) == length and length > 0 and (rows == np.arange(length)).all()


def _take(values, rows):
    if not len(values):
        return np.full((len(rows), values.shape[1]), np.nan)
    out = _rows_of(values, np.maximum(rows, 0))
    missing = rows < 0
    if missing.any():
        if out.dtype == bool:
            out = out.copy()
            out[missing] = False
        else:
            out = out.astype(float) if out.dtype.kind != "f" else out.copy()
            out[missing] = np.nan
    return out.view(type(values)) if isinstance(values, _Mask) else out


# Kept dense results may reach this much; the least recently read go first and are computed again.
_BUDGET = 1 << 30
# Past this share of an axis, reading it whole is as cheap as picking rows out of it.
_MOST_ROWS = 0.7
_LARGE = 1 << 24
_KEPT: list[tuple[ReferenceType[Node], bytes, int]] = []
_spent = [0]


_STOPPED: dict[str, object] = {}


def _unchanged(frame, snapshot):
    """Whether ``frame`` still holds what ``snapshot`` shares with it: a write copies the block."""
    blocks, kept = frame._mgr.blocks, snapshot._mgr.blocks
    return (
        _COPY_ON_WRITE
        and len(blocks) == len(kept)
        and frame.index.is_(snapshot.index)
        and frame.columns.is_(snapshot.columns)
        and all(
            np.may_share_memory(a.values, b.values)
            for a, b in zip(blocks, kept, strict=True)
        )
    )


def _source(frame):
    """The source of a real frame, the same one while it holds the same data."""
    found = frame.__dict__.get("_source")
    if found is None or not _unchanged(frame, found.frame):
        found = frame.__dict__["_source"] = Source(frame)
    return found


def _data_get():
    from finlab import data

    return data.get


def _datekey(frame):
    """The disclosure dates of a quarterly table, and whether its stocks can be presumed delisted."""
    first = frame.index[0]
    fiscal = core_index._fiscal_datekey_table(first)
    if fiscal:
        return _data_get()(f"{fiscal}:key_date"), False
    prefixes = {
        "US-ALL": "us_stock_all",
        "US": "us_stock",
        "JP": "jp_stock",
        "HK": "hk_stock",
        "KR": "kr_stock",
        "UK": "uk_stock",
    }
    market = next((m for p, m in prefixes.items() if p in first), "tw_stock")
    return core_index._fetch_datekey(market, True), market == "tw_stock"


def _quarter(frame):
    """The quarterly node of a real frame, one per frame however many conditions use it.

    None when nothing in it has been disclosed: no dates to answer from, so pandas handles it.
    """
    found = frame.__dict__.get("_quarter")
    key, listed = _datekey(frame)
    if (
        found is None
        or not _unchanged(frame, found.snapshot)
        or not key.equals(found.datekey)
    ):
        found = frame.__dict__["_quarter"] = Quarter(frame, key, listed)
    return found if len(found.axis) else None


def _dated(frame):
    """A quarterly table by date, inside the truncation window as ``index_str_to_date`` keeps it."""
    node = _quarter(frame)
    return None if node is None else core_index._apply_truncation(_wrap(node))


def _forgotten(reference):
    for i, entry in enumerate(_KEPT):
        if entry[0] is reference:
            _spent[0] -= _KEPT.pop(i)[2]
            break


def _spend(nbytes):
    _spent[0] += nbytes
    while _spent[0] > _BUDGET and _KEPT:
        reference, key, size = _KEPT.pop(0)
        _spent[0] -= size
        node = reference()
        if node is not None:
            node.memo.pop(key, None)


class Node:
    """An expression. ``columns`` is None for one value per date."""

    users = 0

    def __init__(self, columns, kids=()):
        self.columns, self.kids = columns, kids
        for kid in kids:
            kid.users += 1
        self.memo = {}
        self.derived = {}
        self._axis = self._ns_axis = None

    @property
    def axis(self):
        if self._axis is None:
            self._axis = self.make_axis()
        return self._axis

    def make_axis(self):
        return self.kids[0].axis

    @property
    def ns(self):
        if self._ns_axis is None:
            self._ns_axis = _ns(self.axis)
        return self._ns_axis

    def rows(self, when):
        return np.searchsorted(self.ns, when, side="right") - 1

    def at(self, when):
        key = when.tobytes()
        found = self.memo.get(key)
        if found is None:
            with np.errstate(all="ignore"):
                found = self.compute(when)
            large = found.nbytes > _LARGE and type(self) is not Source
            # Its one reader keeps the answer: holding this too only pushes out what several share.
            if large and self.users == 1:
                return found
            self.memo[key] = found
            if large:
                _KEPT.append((ref(self, _forgotten), key, found.nbytes))
                _spend(found.nbytes)
        elif found.nbytes > _LARGE:
            for i, entry in enumerate(_KEPT):
                if entry[0]() is self and entry[1] == key:
                    _KEPT.append(_KEPT.pop(i))
                    break
        return found

    def dense(self):
        return self.at(self.ns)


class Source(Node):
    def __init__(self, frame):
        super().__init__(frame.columns)
        self._axis = frame.index
        # A snapshot: later writes to ``frame`` must not reach an expression built on it.
        frame = self.frame = frame.copy(deep=not _COPY_ON_WRITE)
        values = frame.to_numpy()
        if values.dtype == object or not isinstance(values.dtype, np.dtype):
            values = frame.to_numpy(dtype=float, na_value=np.nan)
        # Every width stays as it is: pandas computes in that width.
        self.values = values

    def compute(self, when):
        if len(when) == len(self.ns) and (when == self.ns).all():
            return self.values
        return _take(self.values, self.rows(when))


def _stopped_stocks():
    """Which stocks ``sim`` presumes delisted on each trading day; only those that ever are."""
    close = _data_get()("price:收盤價")
    blocks = (close._node.frame if type(close) is Frame else close)._mgr.blocks
    block = blocks[0].values if blocks else np.empty((0, 0))
    kept = _STOPPED.get("block")
    if (
        kept is None
        or kept.shape != block.shape
        or not np.may_share_memory(kept, block)
    ):
        _STOPPED["block"] = block
        from finlab.backtest.delisting import DELISTING_MIN_TRAILING_BARS
        from finlab.data.indicator import _unpriced_mask

        if len(close) <= DELISTING_MIN_TRAILING_BARS:
            _STOPPED["table"] = (
                _ns(close.index),
                close.columns[:0],
                np.zeros((len(close), 0), dtype=bool),
            )
            return _STOPPED["table"]
        has_price = close.notna().to_numpy()
        missing = len(close) - has_price.argmax(axis=0) - has_price.sum(axis=0)
        gappy = close.columns[
            has_price.any(axis=0) & (missing >= DELISTING_MIN_TRAILING_BARS)
        ]
        unpriced = _unpriced_mask(close[gappy])
        unpriced = unpriced.loc[:, unpriced.any()]
        _STOPPED["table"] = (
            _ns(unpriced.index),
            unpriced.columns,
            unpriced.to_numpy(dtype=bool),
        )
    return _STOPPED["table"]


class Quarter(Node):
    """A quarterly table as of each date: per stock, the newest period with a value disclosed by then.

    Reads only disclosure dates at or before the date, so it cannot look ahead, and it never
    spreads the table onto a daily axis. As ``index_str_to_date`` does, a Taiwan stock that has
    stopped trading drops a value once the next period's filing deadline has passed.
    """

    def __init__(self, frame, key, listed):
        if not frame.index.is_monotonic_increasing:
            frame = frame.sort_index()
        columns = frame.columns.intersection(key.columns).sort_values()
        if columns.name is None:
            columns = columns.rename("symbol")
        super().__init__(columns)
        self.snapshot = frame.copy(deep=False)
        self.datekey = key
        self.flags = not all(
            isinstance(t, np.dtype) and t.kind == "f" for t in frame.dtypes.unique()
        )
        self.unit = np.datetime_data(key.dtypes.iloc[0])[0] if key.shape[1] else "ns"
        disclosed = key.reindex(frame.index)[columns].to_numpy(dtype="datetime64[ns]")
        self.disclosed = _nanoseconds(disclosed)
        self.values = _columns(frame[columns].to_numpy(dtype=float, na_value=np.nan))
        never = np.iinfo(np.int64).max
        self.due = np.full(self.disclosed.shape, never, dtype=np.int64, order="F")
        self.halted = None
        if listed:
            days, stocks, unpriced = _stopped_stocks()
            place = stocks.get_indexer(columns)
            held = np.flatnonzero(place >= 0)
            if len(held):
                self.halted = (days, unpriced[:, place[held]], held)
                following = (
                    _data_get()("etl:financial_statements_deadline")
                    .shift(-1)
                    .reindex(frame.index)
                )
                common = following.median(axis=1).to_numpy(dtype="datetime64[ns]")[
                    :, None
                ]
                own = following.reindex(columns=columns).to_numpy(
                    dtype="datetime64[ns]"
                )
                self.due = _nanoseconds(np.where(np.isnat(own), common, own))

    def make_axis(self):
        never = np.iinfo(np.int64).max
        days = np.unique(self.disclosed[self.disclosed < never])
        if self.halted is None or not len(days):
            return pd.DatetimeIndex(days.astype("datetime64[ns]"), name="date").as_unit(
                self.unit
            )
        # As ``_drop_stopped``: the days a stopped stock loses or regains its value are rows too.
        trading, unpriced, held = self.halted
        every = np.union1d(days, trading[trading > days[0]])
        at = np.searchsorted(trading, every, side="right") - 1
        stale = unpriced[np.maximum(at, 0)] & (at >= 0)[:, None]
        for k, j in enumerate(held):
            seen = np.flatnonzero(
                (self.disclosed[:, j] < never)
                & (self.values[:, j] == self.values[:, j])
            )
            seen = seen[np.argsort(self.disclosed[seen, j], kind="stable")]
            place = np.searchsorted(self.disclosed[seen, j], every, side="right") - 1
            # The newest period disclosed so far, as ``as_of_disclosure`` reads it.
            newest = np.maximum.accumulate(seen)
            due = (
                self.due[newest[np.maximum(place, 0)], j]
                if len(seen)
                else np.full(len(every), never)
            )
            stale[:, k] &= (place >= 0) & (every >= due)
        keep = (
            np.isin(every, days) | np.r_[False, (stale[1:] != stale[:-1]).any(axis=1)]
        )
        return pd.DatetimeIndex(
            every[keep].astype("datetime64[ns]"), name="date"
        ).as_unit(self.unit)

    def compute(self, when):
        when = np.asarray(when, dtype=np.int64)
        unique, inverse = np.unique(when, return_inverse=True)
        out = np.empty((len(unique), len(self.columns)), order="F")
        stopped = None
        if self.halted is not None:
            days, unpriced, held = self.halted
            rows = np.searchsorted(days, unique, side="right") - 1
            stopped = np.zeros(out.shape, dtype=np.uint8, order="F")
            stopped[:, held] = unpriced[np.maximum(rows, 0)] & (rows >= 0)[:, None]
        _K.as_of_disclosure(self.values, self.disclosed, self.due, stopped, unique, out)
        out = out if len(unique) == len(when) else out[inverse]
        return out.view(_Nullable) if self.flags else out


class LineSource(Node):
    def __init__(self, series):
        super().__init__(None)
        self._axis = series.index
        series = self.series = series.copy(deep=not _COPY_ON_WRITE)
        flags = series.dtype == bool
        self.values = (
            series.to_numpy()
            if flags
            else series.to_numpy(dtype=float, na_value=np.nan)
        )[:, None]
        gaps = (
            series.dtype == object
            and pd.api.types.infer_dtype(series, skipna=True) == "boolean"
        )
        nullable = isinstance(series.dtype, pd.BooleanDtype)
        self.kind = _Nullable if nullable else _BoolWithGaps if gaps else None

    def compute(self, when):
        out = _take(self.values, self.rows(when))
        return out.view(self.kind) if self.kind else out


class Row(Node):
    """Each output row depends only on the same input row."""

    def __init__(self, kid, fn, columns="same"):
        super().__init__(kid.columns if isinstance(columns, str) else columns, (kid,))
        self.fn = fn

    def compute(self, when):
        return self.fn(self.kids[0].at(when))


class Binary(Node):
    def __init__(self, left, right, fn):
        if left.columns is None or right.columns is None:
            columns = left.columns if left.columns is not None else right.columns
        elif left.columns is right.columns or left.columns.equals(right.columns):
            columns = left.columns
        else:
            columns = left.columns.intersection(right.columns)
        super().__init__(columns, (left, right))
        self.fn = fn
        self.picks = [
            None
            if kid.columns is None
            or kid.columns is columns
            or kid.columns.equals(columns)
            else kid.columns.get_indexer(columns)
            for kid in (left, right)
        ]

    def make_axis(self):
        a, b = self.kids[0].axis, self.kids[1].axis
        if a is b or a.equals(b):
            return a
        union = a.union(b)
        return union[union >= max(a[0], b[0])]

    def compute(self, when):
        parts = [
            kid.at(when) if pick is None else kid.at(when)[:, pick]
            for kid, pick in zip(self.kids, self.picks, strict=True)
        ]
        return self.fn(*parts)


class Where(Node):
    """``frame.where(cond, other)``: pandas lines ``cond`` up by label, so a date or stock it lacks keeps
    nothing, the frame keeps all its own stocks, and ``mask`` keeps what ``cond`` does not. A FinLab
    ``cond`` carries forward to dates it lacks, as ``_align_date_mask`` does."""

    def __init__(self, kid, cond, other, inverted, carried):
        super().__init__(kid.columns, (kid, cond))
        self.other, self.inverted, self.carried = other, inverted, carried
        self.pick = cond.columns.get_indexer(kid.columns)
        self.found = self.pick >= 0
        self.same = cond.axis is kid.axis or cond.axis.equals(kid.axis)

    def compute(self, when):
        kid, cond = self.kids
        rows = np.maximum(self.rows(when), 0)
        days = self.ns[rows]
        raw = kid.at(days)
        stays_mask = raw.dtype == bool and isinstance(self.other, (bool, np.bool_))
        values = raw if stays_mask else _num(raw)
        keep = np.zeros(values.shape, dtype=bool)
        if self.same:
            exact = np.ones(len(days), dtype=bool)
        else:
            near = np.searchsorted(cond.ns, days, side="right") - 1
            exact = near >= 0
            if not self.carried:
                exact &= cond.ns[np.maximum(near, 0)] == days
        if exact.any():
            flags = cond.at(days[exact])
            present = np.ascontiguousarray(_bool(flags))
            if self.inverted:
                # ``~NA`` is NA, which keeps nothing.
                present = ~present if type(flags) is not _Nullable else flags == 0
            filled = np.zeros((int(exact.sum()), len(self.pick)), dtype=bool)
            filled[:, self.found] = present[:, self.pick[self.found]]
            keep[exact] = filled
        out = np.where(keep, values, self.other)
        missing = self.rows(when) < 0
        if missing.any():
            out = out.astype(float)
            out[missing] = np.nan
        return _gapped(out, raw) if out.dtype != bool else out


class Agg(Node):
    """One value per date from each row. Counting, or summing a mask, gives whole numbers."""

    def __init__(self, kid, fn, whole=False):
        super().__init__(None, (kid,))
        self.fn, self.whole = fn, whole

    def compute(self, when):
        values = self.kids[0].at(when)
        self.whole = self.whole or (values.dtype == bool and self.fn is _SUM)
        out = self.fn(_num(values))[:, None]
        return (
            out.astype(bool)
            if values.dtype == bool and self.fn in (_MAX, _MIN)
            else out
        )


class Reindex(Node):
    """The child as of each date of a new axis: a slice, a reindex with ffill."""

    def __init__(self, kid, axis):
        super().__init__(kid.columns, (kid,))
        self._axis = axis

    def compute(self, when):
        rows = self.rows(when)
        kid = self.kids[0]
        days = self.ns[np.maximum(rows, 0)]
        out = kid.at(days)
        missing = (rows < 0) | (np.searchsorted(kid.ns, days, side="right") == 0)
        if missing.any():
            flags = out.dtype == bool
            out = out.astype(float) if out.dtype.kind in "biu" else out.copy()
            out[missing] = np.nan
            if flags:
                return out.view(_BoolWithGaps)
        return out


def _changed(now, past):
    """A mask's ``diff``: whether it moved, unknown wherever one side is."""
    return np.where(np.isnan(now) | np.isnan(past), np.nan, now != past)


class Lag(Node):
    """``how(x[t], x[t - k])`` on the child's own rows."""

    def __init__(self, kid, k, how):
        super().__init__(kid.columns, (kid,))
        self.k, self.how = k, how

    def _values(self, raw):
        if self.how == "diff" and raw.dtype.kind == "i" and raw.dtype.itemsize <= 2:
            return raw.astype(np.float32)
        return _widened(raw)

    def compute(self, when):
        kid = self.kids[0]
        rows = self.rows(when)
        k = self.k
        if _every_row(rows, len(self.ns)):
            raw = kid.dense()
            now = self._values(raw)
            out = np.full(now.shape, np.nan, dtype=now.dtype, order="F")
            if self.how == "shift":
                out[k:] = now[:-k]
                return _gapped(out, raw)
            if self.how == "diff":
                if _flags(raw):
                    out[k:] = _changed(now[k:], now[:-k])
                    return _gapped(out, raw)
                out[k:] = now[k:] - now[:-k]
            else:
                out[k:] = now[k:] / now[:-k] - 1
            return out
        earlier = rows - k
        raw = kid.at(kid.ns[np.maximum(earlier, 0)])
        past = self._values(raw)
        missing = earlier < 0
        if missing.any():
            past = past.copy()
            past[missing] = np.nan
        if self.how == "shift":
            return _gapped(past, raw)
        now = self._values(kid.at(kid.ns[np.maximum(rows, 0)]))
        if _flags(raw) and self.how == "diff":
            return _gapped(_changed(now, past), raw)
        return now - past if self.how == "diff" else now / past - 1


def _covered(rows, n):
    """The rows the windows of ``n`` ending at ``rows`` read, or None when ``rows`` holds no date.

    Each window lies inside one run of these rows, so the kernel can read them as if
    they were adjacent. The running sums restart at each run, which moves rounding: a
    stock halted through a window gets a true zero deviation, not 1e-15. The runs
    depend on ``rows`` alone, so data after a date cannot change the bits before it.
    """
    ends = rows[rows >= 0] + 1
    if not len(ends):
        return None
    starts = np.maximum(ends - n, 0)
    gaps = starts[1:] > ends[:-1]
    firsts = np.r_[starts[0], starts[1:][gaps]]
    lasts = np.r_[ends[:-1][gaps], ends[-1]]
    return np.concatenate(
        [np.arange(a, b) for a, b in zip(firsts.tolist(), lasts.tolist(), strict=True)]
    )


class Window(Node):
    def __init__(self, kid, n, min_periods, how):
        super().__init__(kid.columns, (kid,))
        self.n, self.how = n, how
        self.min_periods = n if min_periods is None else min_periods

    def compute(self, when):
        rows = np.asarray(self.rows(when), dtype=np.int64)
        if len(rows) > 1 and (rows[1:] < rows[:-1]).any():
            unique, inverse = np.unique(rows, return_inverse=True)
            return self._read(unique)[inverse]
        return self._read(rows)

    def _read(self, rows):
        kid = self.kids[0]
        needed = _covered(rows, self.n)
        length = len(kid.ns)
        if needed is None or len(needed) == length:
            values = kid.dense()
        else:
            # Only how the rows are read: this share must not choose which rows.
            many = len(needed) > _MOST_ROWS * length
            values = _rows_of(kid.dense(), needed) if many else kid.at(kid.ns[needed])
            rows = np.where(rows < 0, -1, np.searchsorted(needed, rows))
        values = _columns(_num(values))
        out = np.empty((len(rows), values.shape[1]), order="F")
        _K.window(values, rows, self.n, self.min_periods, _HOW[self.how], out)
        return out


def _kept_kind(result, source):
    """A mask or whole numbers come back as they went in when no gap forces floats."""
    if isinstance(source, _Mask):
        return result.view(type(source))
    if source.dtype.kind in "biu" and not np.isnan(result).any():
        return result.astype(source.dtype)
    return result


def _whole(result, source):
    """Adding up a mask or whole numbers gives whole numbers."""
    return result.astype(np.int64) if source.dtype.kind in "biu" else result


class Dense(Node):
    """Computed over the child's whole axis, then read as of each date."""

    def __init__(self, kid, fn, kind=None):
        super().__init__(kid.columns, (kid,))
        self.fn, self.kind = fn, kind
        self.full = None

    def compute(self, when):
        if self.full is None:
            values = self.kids[0].dense()
            self.full = self.fn(_num(values))
            if self.kind is not None:
                self.full = self.kind(self.full, values)
        return _take(self.full, self.rows(when))


# ---- kernels ----
def rank_rows(a, pct, ascending):
    a = _columns(_num(a))
    out = np.empty(a.shape, order="F")
    _K.rank_rows(a, pct, ascending, out)
    return out


class Best(Node):
    """The n best of each row; ties go to the earlier column, so extra columns never change a pick."""

    def __init__(self, kid, n, largest):
        super().__init__(kid.columns, (kid,))
        self.n, self.largest = n, largest

    def compute(self, when):
        a = _columns(_num(self.kids[0].at(when)))
        out = np.zeros(a.shape, dtype=np.uint8, order="F")
        if self.n > 0:
            _K.top_n(a, self.n, self.largest, out)
        picked = out.view(bool)
        self._warn_padding(a, picked, when)
        return picked

    def _warn_padding(self, a, picked, when):
        """Slots filled by stocks tied at a row's worst value, picked by column order."""
        n, largest = self.n, self.largest
        if n <= 0 or n >= a.shape[1]:
            return
        worst = (np.fmin if largest else np.fmax).reduce(a, axis=1)
        cut = np.where(picked, a, -np.inf if not largest else np.inf)
        cut = cut.min(axis=1) if largest else cut.max(axis=1)
        tied = (a == worst[:, None]).sum(axis=1)
        full = (~np.isnan(a)).sum(axis=1) > n
        rows = np.flatnonzero(full & (cut == worst))
        if not len(rows):
            return
        need = n - (picked[rows] & (a[rows] != worst[rows, None])).sum(axis=1)
        padding = need < tied[rows]
        rows, need = rows[padding], need[padding]
        if len(rows):
            from finlab.dataframe.core import (
                _TOP_N_PADDING_EXAMPLE_DATES,
                _warn_top_n_padding,
            )

            shown = slice(_TOP_N_PADDING_EXAMPLE_DATES)
            days = pd.DatetimeIndex(when[rows].astype("datetime64[ns]"))
            _warn_top_n_padding(
                n,
                len(rows),
                days[shown],
                need[shown],
                largest=largest,
            )


_RUNNING = ("ffill", "cumsum", "cummax", "cummin")


def running(how):
    def run(a):
        # The kernel adds in doubles: float32 and long whole numbers round their own way.
        if a.dtype not in (np.float64, bool):
            return getattr(pd.DataFrame(a), _RUNNING[how])().to_numpy()
        a = _columns(a)
        out = np.empty(a.shape, order="F")
        _K.running(a, how, out)
        return out

    return run


_ARITHMETIC = {
    "add": _added(operator.add, np.logical_or),
    "sub": lambda a, b: a - b,
    "mul": _added(operator.mul, np.logical_and),
    "truediv": lambda a, b: _num(a) / _num(b),
    "floordiv": lambda a, b: _num(a) // _num(b),
    "mod": lambda a, b: _num(a) % _num(b),
    "pow": lambda a, b: _num(a) ** _num(b),
    "lt": _compared(operator.lt),
    "le": _compared(operator.le),
    "gt": _compared(operator.gt),
    "ge": _compared(operator.ge),
    "eq": _compared(operator.eq),
    "ne": _compared(operator.ne),
    "and": _logical(np.logical_and),
    "or": _logical(np.logical_or),
    "xor": _logical(np.logical_xor),
}


def _SUM(a):
    return np.nansum(a, axis=1)


def _MAX(a):
    return np.fmax.reduce(a, axis=1) if a.shape[1] else np.full(len(a), np.nan)


def _MIN(a):
    return np.fmin.reduce(a, axis=1) if a.shape[1] else np.full(len(a), np.nan)


def _masked(a, keep):
    return _gapped(np.where(_bool(keep), _num(a), np.nan), a)


def _same_axes(left, right):
    return left.axis.equals(right.axis) and (
        left.columns.equals(right.columns)
        if left.columns is not None and right.columns is not None
        else left.columns is right.columns
    )


def _scalar(value):
    return value is None or np.isscalar(value)


def _node(value):
    """The node of a frame-like value, or None when it has to go through pandas."""
    if type(value) in (Frame, Line):
        return value._node
    if isinstance(value, pd.Series):
        return LineSource(value) if _plain_dates(value.index) else None
    if isinstance(value, pd.DataFrame):
        if isinstance(value, FDF) and _by_quarter(value):
            dated = _dated(value)
            return None if dated is None else _node(dated)
        return _source(value) if _plain_dates(value.index) and _numeric(value) else None
    return None


def _by_quarter(frame):
    """A quarterly table of numbers or masks. Whole numbers stay whole in pandas."""
    return (
        len(frame.index)
        and isinstance(frame.index[0], str)
        and "Q" in frame.index[0]
        and frame.columns.is_unique
        and _one_kind(frame)
    )


def _one_kind(frame):
    """All floats or all masks."""
    kinds = {
        "m"
        if pd.api.types.is_bool_dtype(t)
        else t.kind
        if isinstance(t, np.dtype)
        else "?"
        for t in frame.dtypes.unique()
    }
    return kinds <= {"f"} or kinds <= {"m"}


def _numeric(frame):
    """Numbers of one type: pandas computes each column in its own, one matrix cannot."""
    kinds = frame.dtypes.unique()
    return len(kinds) <= 1 and all(
        isinstance(t, np.dtype) and t.kind in "biuf" for t in kinds
    )


def _plain_dates(index):
    return (
        isinstance(index, pd.DatetimeIndex)
        and index.tz is None
        and len(index) > 0
        and index.is_unique
        and index.is_monotonic_increasing
    )


_COPY_ON_WRITE = int(pd.__version__.split(".")[0]) >= 3


def _invert_row_preview(node, raw):
    if hasattr(node, "fill_value") and (
        raw.dtype == object or type(raw) is _BoolWithGaps
    ):
        boolean = isinstance(node.fill_value, (bool, np.bool_))
        return np.empty(raw.shape, dtype=bool if boolean else object)
    return node.fn(_invert_numeric_preview(raw))


def _invert_numeric_preview(raw):
    return np.empty(raw.shape).view(_BoolWithGaps) if raw.dtype == object else raw


def _invert_leaf_preview(node):
    out = np.empty((0, node.values.shape[1]), dtype=node.values.dtype)
    if isinstance(node, Quarter):
        return out.view(_Nullable) if node.flags else out
    return out.view(getattr(node, "kind", None) or np.ndarray)


def _invert_shape(node):
    return (0, 1 if node.columns is None else len(node.columns))


def _invert_agg_preview(node, raw):
    whole = raw.dtype == bool if node.fn is _SUM else node.whole
    if whole:
        return np.empty((0, 1), dtype=np.int64)
    if node.fn in (_MAX, _MIN):
        return np.empty((0, 1), dtype=raw.dtype).view(type(raw))
    return np.empty((0, 1))


def _invert_preview(node):
    """Inspect types only at `~`: no source reads, dates, or persistent type propagation.

    The shift/fill boundary has pandas' object type here only; execution keeps its
    existing numeric masks. Other row operations keep their existing result type.
    """

    @cache
    def preview(node):
        if not node.kids:
            return _invert_leaf_preview(node)
        if isinstance(node, Best):
            return np.empty((0, len(node.columns)), dtype=bool)
        if isinstance(node, Dense) and node.kind is _whole:
            return np.empty(_invert_shape(node), dtype=np.int64)
        if isinstance(node, Binary):
            return node.fn(
                *(
                    _invert_numeric_preview(preview(kid))
                    if pick is None
                    else _invert_numeric_preview(preview(kid))[:, pick]
                    for kid, pick in zip(node.kids, node.picks, strict=True)
                )
            )
        if isinstance(node, (Row, Lag, Dense, Reindex, Periods, Agg)):
            raw = preview(node.kids[0])
            if isinstance(node, Row):
                return _invert_row_preview(node, raw)
            if isinstance(node, Lag):
                return (
                    _gapped(node._values(raw), raw)
                    if node.how in ("shift", "diff")
                    else _num(raw)
                )
            if isinstance(node, Agg):
                return _invert_agg_preview(node, raw)
            return raw
        return np.empty(_invert_shape(node))

    return preview(node)


def _pending(cls, node):
    """An instance with no data yet: pandas' first reach for it fills it."""
    self = object.__new__(cls)
    fields = self.__dict__
    fields["_node"] = node
    fields["_item_cache"] = {}
    fields["_attrs"] = {}
    fields["_flags"] = pd.Flags(self, allows_duplicate_labels=True)
    return self


class _Pending:
    """A pandas object still written as an expression.

    It is a real ``FinlabDataFrame`` or ``Series`` whose data does not exist yet. A kernel
    answers what it can; anything else reaches for ``_mgr``, which computes every date and
    turns this object into the plain pandas class for good, so pandas does the rest.
    """

    @property
    def _mgr(self):
        self._fill()
        return self.__dict__["_mgr"]

    @_mgr.setter
    def _mgr(self, value):
        self.__dict__.pop("_node", None)
        self.__dict__["_mgr"] = value
        self.__class__ = self._filled_class

    def _fill(self):
        fields = self.__dict__
        if "_node" not in fields:
            return
        real = self._compute(fields.pop("_node"))
        fields["_base"] = (
            real  # pandas tracks shared data through a weak reference to it
        )
        fields["_mgr"] = real.copy(deep=not _COPY_ON_WRITE)._mgr
        self.__class__ = self._filled_class

    def _eager(self, name, *args, **kwargs):
        """The plain pandas or FinLab method. It sees plain objects only."""
        for value in (self, *args, *kwargs.values()):
            if isinstance(value, _Pending):
                value._fill()
        method = getattr(type(self), name)
        if isinstance(self, FDF):
            method = getattr(method, "__wrapped__", method)
        return method(self, *args, **kwargs)

    def __reduce_ex__(self, protocol):
        self._fill()
        return self.__reduce_ex__(protocol)

    def _twin(self):
        """The same expression for an accessor: reading ``self`` before it is used cannot undo it."""
        return _wrap(self._node)

    def _op(self, other, name, reverse=False):
        fn = _ARITHMETIC[name]
        node = self._node
        dunder = f"__r{name}__" if reverse else f"__{name}__"
        if _scalar(other):
            call = (lambda a: fn(other, a)) if reverse else (lambda a: fn(a, other))
            return _wrap(Row(node, call))
        # A plain DataFrame on the left aligns by pandas' rules, not ours.
        right = None if reverse and type(other) is pd.DataFrame else _node(other)
        # On the left a line joins labels as pandas does; only a frame takes a line's latest value.
        if right is None or (node.columns is None and not _same_axes(node, right)):
            return self._eager(dunder, other)
        return _wrap(Binary(right, node, fn) if reverse else Binary(node, right, fn))

    def _row(self, fn):
        return _wrap(Row(self._node, fn))

    def _once(self, key, build):
        """The same expression twice is one node: ``close.average(20)`` written three times."""
        derived = self._node.derived
        if key not in derived:
            derived[key] = build()
        return _wrap(derived[key])

    def _dense(self, fn, kind=None):
        return _wrap(Dense(self._node, fn, kind))

    def __invert__(self):
        preview = _invert_preview(self._node)
        if preview.shape[1] and (
            preview.dtype == object or type(preview) is _BoolWithGaps
        ):
            raise TypeError(_OBJECT_INVERT_ERROR)

        def invert(a):
            if type(a) is _Nullable:
                return (1 - a).view(_Nullable)
            if a.dtype.kind in "iu":
                return ~a
            if preview.dtype.kind in "iu":
                return ~a.astype(preview.dtype)
            return ~_bool(a)

        return self._row(invert)

    def __neg__(self):
        return self._row(
            lambda a: (
                (1 - a).view(_Nullable)
                if type(a) is _Nullable
                else ~a
                if a.dtype == bool
                else -a
            )
        )

    def __abs__(self):
        return self._row(np.abs)

    def __array_ufunc__(self, ufunc, method, *inputs, **kwargs):
        if method == "__call__" and len(inputs) == 1 and not kwargs:
            return self._row(lambda a: ufunc(_num(a)))
        for value in inputs:
            if isinstance(value, _Pending):
                value._fill()
        return type(self).__array_ufunc__(self, ufunc, method, *inputs, **kwargs)

    def __len__(self):
        return len(self._node.axis)

    @property
    def index(self):
        return self._node.axis

    @index.setter
    def index(self, value):
        self._fill()
        self.index = value

    def rolling(self, window, min_periods=None, *args, **kwargs):
        if (
            _count(window)
            and window > 0
            and (min_periods is None or 0 <= min_periods <= window)
            and not args
            and not kwargs
        ):
            return _Rolling(self._twin(), int(window), min_periods)
        return self._eager("rolling", window, min_periods, *args, **kwargs)

    def average(self, n):
        if n < 1:
            return self._eager("average", n)
        return self._once(
            ("window", n, int(n / 2), "mean"),
            lambda: Window(self._node, n, int(n / 2), "mean"),
        )

    def shift(self, periods=1, *args, **kwargs):
        if periods == 0 and not args and not kwargs:
            return self.copy()
        if _count(periods) and periods > 0 and not args and not kwargs:
            return self._once(
                ("lag", periods, "shift"), lambda: Lag(self._node, periods, "shift")
            )
        return self._eager("shift", periods, *args, **kwargs)

    def pct_change(self, periods=1, fill_method=no_default, *args, **kwargs):
        if fill_method is no_default:
            fill_method = None if self._filled_class is FDF else _SERIES_PCT_FILL_METHOD
        if (
            _count(periods)
            and periods > 0
            and fill_method is None
            and not args
            and not kwargs
        ):
            return self._once(
                ("lag", periods, "pct"), lambda: Lag(self._node, periods, "pct")
            )
        return self._eager("pct_change", periods, fill_method, *args, **kwargs)

    def diff(self, periods=1, *args, **kwargs):
        if _count(periods) and periods > 0 and not args and not kwargs:
            return self._once(
                ("lag", periods, "diff"), lambda: Lag(self._node, periods, "diff")
            )
        return self._eager("diff", periods, *args, **kwargs)

    def ffill(self, *args, **kwargs):
        if args or kwargs:
            return self._eager("ffill", *args, **kwargs)
        return self._dense(running(0), _kept_kind)

    def cumsum(self, *args, **kwargs):
        if args or kwargs:
            return self._eager("cumsum", *args, **kwargs)
        return self._dense(running(1), _whole)

    def cummax(self, *args, **kwargs):
        if args or kwargs:
            return self._eager("cummax", *args, **kwargs)
        return self._dense(running(2), _kept_kind)

    def cummin(self, *args, **kwargs):
        if args or kwargs:
            return self._eager("cummin", *args, **kwargs)
        return self._dense(running(3), _kept_kind)

    def ewm(self, *args, **kwargs):
        if args:
            return self._eager("ewm", *args, **kwargs)
        return _Ewm(self._twin(), kwargs)

    def notna(self):
        return self._row(lambda a: ~np.isnan(_num(a)))

    notnull = notna

    def isna(self):
        return self._row(lambda a: np.isnan(_num(a)))

    isnull = isna

    def abs(self):
        return self._row(
            lambda a: _kept_kind(np.abs(a), a) if type(a) is _Nullable else np.abs(a)
        )

    def round(self, decimals=0, *args, **kwargs):
        if args or kwargs or not _count(decimals):
            return self._eager("round", decimals, *args, **kwargs)
        return self._row(
            lambda a: (
                a
                if a.dtype == bool
                else _kept_kind(np.round(a, decimals), a)
                if type(a) is _Nullable
                else np.round(a, decimals)
            )
        )

    def copy(self, deep=True):
        return _wrap(self._node)

    def clip(self, lower=None, upper=None, **kwargs):
        if kwargs or not (_scalar(lower) and _scalar(upper)):
            return self._eager("clip", lower, upper, **kwargs)

        def bound(a):
            if lower is None and upper is None:
                return a
            keeps_bool = (lower is None or lower <= 0) and (upper is None or upper >= 1)
            if keeps_bool and _flags(a):
                return a
            return np.clip(_num(a), lower, upper)

        return self._row(bound)

    def astype(self, dtype, *args, **kwargs):
        if args or kwargs:
            return self._eager("astype", dtype, *args, **kwargs)
        if dtype in (float, "float", "float64", bool, "bool"):
            target = bool if dtype in (bool, "bool") else float
            return self._row(
                lambda a: (
                    a == 1
                    if target is bool and type(a) is _Nullable
                    else np.asarray(a).astype(target)
                )
            )
        if dtype in (int, "int", "int64"):
            # A NaN must raise as pandas raises it.
            return self._row(
                lambda a: (
                    a.astype(np.int64)
                    if a.dtype == bool
                    else pd.DataFrame(a).astype(np.int64).to_numpy()
                )
            )
        return self._eager("astype", dtype)

    def replace(self, to_replace=None, value=no_default, **kwargs):
        olds = to_replace if isinstance(to_replace, (list, tuple)) else [to_replace]
        if kwargs or not _number(value) or not all(map(_number, olds)):
            return self._eager("replace", to_replace, value, **kwargs)
        flags = [old for old in olds if isinstance(old, (bool, np.bool_))]
        amounts = np.asarray(
            [old for old in olds if not isinstance(old, (bool, np.bool_))], dtype=float
        )
        gaps = np.isnan(amounts).any()

        def swap(a):
            # pandas never takes a mask's False for the number 0.
            if a.dtype == bool or type(a) is _Nullable:
                if not flags:
                    return a
                out = np.where(np.isin(a, flags), value, a)
                return out.view(_Nullable) if type(a) is _Nullable else out
            found = np.isin(a, amounts)
            return np.where(found | np.isnan(a) if gaps else found, value, a)

        return self._row(swap)

    def resample(self, rule, *args, **kwargs):
        if args:
            return self._eager("resample", rule, *args, **kwargs)
        return _Resample(self._twin(), rule, kwargs)

    def fillna(self, value=None, **kwargs):
        if _scalar(value) and value is not None and not kwargs:

            def fill(a):
                if a.dtype == bool:
                    return a
                if type(a) in (_BoolWithGaps, _Nullable) and isinstance(
                    value, (bool, np.bool_)
                ):
                    return np.where(np.isnan(a), value, a == 1)
                return np.where(np.isnan(a), value, a)

            result = self._row(fill)
            result._node.fill_value = value
            return result
        return self._eager("fillna", value, **kwargs)


class Cross(Node):
    """Each output date depends only on the same input date, by way of pandas: the asked dates run through it."""

    def __init__(self, kid, fn):
        super().__init__(kid.columns, (kid,))
        self.fn = fn

    def compute(self, when):
        rows = self.rows(when)
        unique, inverse = np.unique(np.maximum(rows, 0), return_inverse=True)
        kid = self.kids[0]
        frame = FDF(
            _num(kid.at(self.ns[unique])),
            index=self.axis[unique],
            columns=kid.columns,
            copy=False,
        )
        out = self.fn(frame).to_numpy(dtype=float, na_value=np.nan)[inverse]
        missing = rows < 0
        if missing.any():
            out[missing] = np.nan
        return out


class _BySector:
    """``frame.sector``: stocks group by the classification in force now, not when computed."""

    __slots__ = ("by", "parent")

    def __init__(self, parent, by=None):
        self.parent, self.by = parent, by

    def __call__(self, by):
        return _BySector(self.parent, by)

    def __getattr__(self, name):
        def call(*args, **kwargs):
            by = self.parent._get_column_categories() if self.by is None else self.by
            return _wrap(
                Cross(
                    self.parent._node,
                    lambda frame: getattr(SectorAccessor(frame, by), name)(
                        *args, **kwargs
                    ),
                )
            )

        return call


class _ByDate:
    """An accessor whose every method works date by date, so only the asked dates run."""

    __slots__ = ("make", "parent")

    def __init__(self, parent, make):
        self.parent, self.make = parent, make

    def __call__(self, *args, **kwargs):
        make = self.make
        return _ByDate(self.parent, lambda frame: make(frame)(*args, **kwargs))

    def __getattr__(self, name):
        def call(*args, **kwargs):
            make = self.make
            return _wrap(
                Cross(
                    self.parent._node,
                    lambda frame: getattr(make(frame), name)(*args, **kwargs),
                )
            )

        return call


class _Weights(_ByDate):
    """``frame.weight``: the methods that read one date at a time run at the asked dates."""

    __slots__ = ()

    def __getattr__(self, name):
        if name in ("cap_industry", "by_group"):
            return super().__getattr__(name)
        self.parent._fill()
        return getattr(self.parent.weight, name)


class _Becomes(type):
    """What is an instance of the filled class counts as one of this class too."""

    def __instancecheck__(cls, value):
        return isinstance(value, cls._filled_class)


class Frame(_Pending, FDF, metaclass=_Becomes):
    """A ``FinlabDataFrame`` waiting for its data."""

    _filled_class = FDF

    def _compute(self, node):
        if type(node) is Source:
            return node.frame
        values = node.dense()
        if type(values) is _BoolWithGaps:
            cells = (values == 1).astype(object)
            cells[np.isnan(values)] = np.nan
            values = cells
        if type(values) is _Nullable:
            empty = FDF(index=node.axis, columns=node.columns, copy=False)
            return core_index._nullable_boolean(empty, values == 1, np.isnan(values))
        return FDF(values, index=node.axis, columns=node.columns, copy=False)

    @property
    def columns(self):
        return self._node.columns

    @columns.setter
    def columns(self, value):
        self._fill()
        self.columns = value

    @property
    def shape(self):
        return len(self._node.axis), len(self._node.columns)

    @property
    def ndim(self):
        return 2

    @property
    def sector(self):
        return _BySector(self._twin())

    @property
    def cs(self):
        return _ByDate(self._twin(), CsAccessor)

    @property
    def weight(self):
        return _Weights(self._twin(), WeightAccessor)

    @property
    def loc(self):
        return _Loc(self)

    @property
    def iloc(self):
        return _Iloc(self)

    @property
    def empty(self):
        return not len(self._node.axis) or not len(self._node.columns)

    @property
    def values(self):
        return self.to_numpy()

    @property
    def dtypes(self):
        node = self._node
        if type(node) is Source:
            return node.frame.dtypes
        values = node.at(node.ns[:1])
        return pd.Series(
            pd.BooleanDtype() if type(values) is _Nullable else values.dtype,
            index=node.columns,
        )

    def to_numpy(self, dtype=None, copy=False, na_value=None):
        values = self._node.dense()
        if type(values) in (_Nullable, _BoolWithGaps) or na_value is not None:
            options = {} if na_value is None else {"na_value": na_value}
            return self._eager("to_numpy", dtype=dtype, copy=copy, **options)
        if dtype is not None and values.dtype != dtype:
            return values.astype(dtype)
        if copy or not _COPY_ON_WRITE:
            return values.copy()
        values = values.view()
        values.flags.writeable = False
        return values

    def index_str_to_date(self):
        return self

    def deadline(self):
        return self

    def __getitem__(self, key):
        if type(key) is Frame or isinstance(key, pd.DataFrame):
            return self._mask(key)
        if isinstance(key, np.ndarray) and key.dtype == bool and len(key) == len(self):
            first = int(key.argmax()) if key.any() else len(key)
            if key[first:].all():
                return _wrap(Reindex(self._node, self._node.axis[first:]))
        if (
            isinstance(key, (list, pd.Index))
            and len(key)
            and all(k in self._node.columns for k in key)
        ):
            pick = self._node.columns.get_indexer(key)
            return _wrap(Row(self._node, lambda a: a[:, pick], columns=pd.Index(key)))
        return self._eager("__getitem__", key)

    def __setitem__(self, key, value):
        right = (
            _node(key) if type(key) is Frame or isinstance(key, pd.DataFrame) else None
        )
        if right is not None and _scalar(value) and value is not None:
            self._assign(right, value)
            return
        self._eager("__setitem__", key, value)

    def _assign(self, right, value):
        node = self._node
        if right.axis.equals(node.axis) and right.columns.equals(node.columns):
            self.__dict__["_node"] = Binary(
                node, right, lambda a, c: np.where(_bool(c), value, a)
            )
        else:
            self._fill()
            self[_wrap(right)] = value

    def _mask(self, key):
        right = _node(key)
        if right is None:
            return self._eager("__getitem__", key)
        return _wrap(Binary(self._node, right, _masked))

    def where(self, cond, other=np.nan, **kwargs):
        right = _node(cond)
        if right is None or right.columns is None or kwargs or not _scalar(other):
            return self._eager("where", cond, other, **kwargs)
        return self._where(cond, right, other, False)

    def mask(self, cond, other=np.nan, **kwargs):
        right = _node(cond)
        if right is None or right.columns is None or kwargs or not _scalar(other):
            return self._eager("mask", cond, other, **kwargs)
        return self._where(cond, right, other, True)

    def _where(self, cond, right, other, inverted):
        # As ``_align_date_mask``: a quarterly table stays on its disclosure dates.
        carried = isinstance(cond, FDF) and isinstance(cond.index, pd.DatetimeIndex)
        return _wrap(Where(self._node, right, other, inverted, carried))

    def rank(self, *args, valid=None, **kwargs):
        axis = args[0] if args else kwargs.get("axis", 0)
        options = {k: v for k, v in kwargs.items() if k != "axis"}
        known = not args[1:] and set(options) <= {
            "pct",
            "ascending",
            "method",
            "na_option",
        }
        pct, ascending = options.get("pct", False), options.get("ascending", True)
        method, na_option = (
            options.get("method", "average"),
            options.get("na_option", "keep"),
        )
        if axis in (1, "columns") and known and na_option == "keep":
            if valid is not None:
                right = _node(valid)
                if right is None or right.columns is None:
                    return self._eager("rank", *args, valid=valid, **kwargs)
                return self._where(valid, right, np.nan, False).rank(*args, **kwargs)
            if method == "average":
                return self._once(
                    ("rank", pct, ascending),
                    lambda: Row(self._node, lambda a: rank_rows(a, pct, ascending)),
                )
            return self._row(
                lambda a: _ranks_of_rows(
                    _num(a),
                    method=method,
                    ascending=ascending,
                    pct=pct,
                    na_option="keep",
                )
            )
        return self._eager("rank", *args, valid=valid, **kwargs)

    def is_largest(self, n):
        return _wrap(Best(self._node, n, True))

    def is_smallest(self, n):
        return _wrap(Best(self._node, n, False))

    def sustain(self, nwindow, nsatisfy=None):
        return self.rolling(nwindow).sum() >= (nsatisfy or nwindow)

    def rise(self, n=1):
        return self > self.shift(n)

    def fall(self, n=1):
        return self < self.shift(n)

    def reindex(self, *args, **kwargs):
        target = args[0] if args else kwargs.get("index")
        plain = (len(args) == 1 and set(kwargs) == {"method"}) or (
            not args and set(kwargs) == {"index", "method"}
        )
        if plain and kwargs["method"] == "ffill" and _plain_dates(pd.Index(target)):
            return _wrap(Reindex(self._node, pd.DatetimeIndex(target)))
        return self._eager("reindex", *args, **kwargs)

    def _agg(self, name, axis, fn, kwargs):
        if axis in (1, "columns") and not kwargs:
            return _wrap(Agg(self._node, fn, whole=name == "count"))
        return self._eager(name, axis=axis, **kwargs)

    def sum(self, axis=0, **kwargs):
        return self._agg("sum", axis, _SUM, kwargs)

    def mean(self, axis=0, **kwargs):
        return self._agg("mean", axis, lambda a: np.nanmean(a, axis=1), kwargs)

    def median(self, axis=0, **kwargs):
        return self._agg("median", axis, lambda a: np.nanmedian(a, axis=1), kwargs)

    def std(self, axis=0, **kwargs):
        return self._agg("std", axis, lambda a: np.nanstd(a, axis=1, ddof=1), kwargs)

    def max(self, axis=0, **kwargs):
        return self._agg("max", axis, _MAX, kwargs)

    def min(self, axis=0, **kwargs):
        return self._agg("min", axis, _MIN, kwargs)

    def count(self, axis=0, **kwargs):
        return self._agg(
            "count", axis, lambda a: (~np.isnan(a)).sum(axis=1).astype(float), kwargs
        )

    def quantile(self, q=0.5, axis=0, **kwargs):
        if axis in (1, "columns") and _scalar(q) and not kwargs:
            return _wrap(Agg(self._node, lambda a: np.nanquantile(a, q, axis=1)))
        return self._eager("quantile", q, axis=axis, **kwargs)

    def quantile_row(self, c):
        return self.quantile(c, axis=1)


class Line(_Pending, pd.Series, metaclass=_Becomes):
    """A Series of one value per date, waiting for its data."""

    _filled_class = pd.Series

    def _compute(self, node):
        if type(node) is LineSource:
            return node.series
        values = node.dense()[:, 0]
        if getattr(node, "whole", False):
            values = values.astype(np.int64)
        return pd.Series(values, index=node.axis, copy=False)

    @property
    def shape(self):
        return (len(self._node.axis),)

    @property
    def ndim(self):
        return 1

    @property
    def name(self):
        return None

    @name.setter
    def name(self, value):
        self._fill()
        self.name = value


for _cls, _real_cls in ((Frame, FDF), (Line, pd.Series)):
    _cls.__name__, _cls.__qualname__, _cls.__module__ = (
        _real_cls.__name__,
        _real_cls.__qualname__,
        _real_cls.__module__,
    )


def _wrap(node):
    cls = Line if node.columns is None else Frame
    self = _pending(cls, node)
    if cls is Line:
        self.__dict__["_name"] = None
    return self


def _plain_only(name):
    def method(self, *args, **kwargs):
        return self._eager(name, *args, **kwargs)

    return method


for _name in (
    "hold_until",
    "exit_when",
    "is_entry",
    "is_exit",
    "entry_price",
    "neutralize",
    "neutralize_industry",
    "groupby_category",
    "industry_rank",
    "rebalance",
    "corrwith",
    "align",
):
    if hasattr(FDF, _name):
        setattr(Frame, _name, _plain_only(_name))


def _flex(name):
    def method(self, other, *args, axis=None, **kwargs):
        op = {"div": "truediv"}.get(name, name)
        if not args and not kwargs:
            # These join labels as pandas does, so only equal axes pair up.
            right = None if _scalar(other) else _node(other)
            if axis in (None, "columns", 1):
                if right is None and _scalar(other):
                    return self._op(other, op)
                if right is not None and _same_axes(self._node, right):
                    return self._op(other, op)
            elif (
                axis in (0, "index")
                and right is not None
                and right.columns is None
                and right.axis.equals(self._node.axis)
            ):
                return _wrap(Binary(self._node, right, _ARITHMETIC[op]))
        if axis is not None:
            kwargs["axis"] = axis
        return self._eager(name, other, *args, **kwargs)

    return method


def _install_operators():
    for name in (
        "add",
        "sub",
        "mul",
        "div",
        "truediv",
        "gt",
        "lt",
        "ge",
        "le",
        "eq",
        "ne",
        "pow",
    ):
        setattr(_Pending, name, _flex(name))
    for name in _ARITHMETIC:
        dunder = f"__{name}__"

        def forward(self, other, name=name):
            return self._op(other, name)

        setattr(_Pending, dunder, forward)
        if name not in ("lt", "le", "gt", "ge", "eq", "ne"):

            def reflected(self, other, name=name):
                return self._op(other, name, reverse=True)

            setattr(_Pending, f"__r{name}__", reflected)

            def inplace(self, other, name=name):
                # An alias of this object sees the update, as in pandas.
                result = self._op(other, name)
                if "_node" in result.__dict__ and result.__class__ is self.__class__:
                    self.__dict__["_node"] = result._node
                    return self
                if isinstance(self, _Pending):
                    self._fill()
                self._mgr = result.reindex_like(self)._mgr
                return self

            setattr(_Pending, f"__i{name}__", inplace)


_install_operators()


# Statistics of one table, with no labels to keep.
_ONE_TABLE = frozenset({"median", "skew", "kurt", "quantile", "count", "sem", "rank"})


class _Rolling:
    __slots__ = ("min_periods", "n", "parent")

    def __init__(self, parent, n, min_periods):
        self.parent, self.n, self.min_periods = parent, n, min_periods

    def _window(self, how):
        parent, n, min_periods = self.parent, self.n, self.min_periods
        return parent._once(
            ("window", n, min_periods if min_periods is not None else n, how),
            lambda: Window(parent._node, n, min_periods, how),
        )

    def __getattr__(self, name):
        n, min_periods = self.n, self.min_periods

        def aggregate(*args, **kwargs):
            if name in _HOW and not args and not kwargs:
                return self._window(name)
            if name not in _ONE_TABLE or not all(
                map(_scalar, (*args, *kwargs.values()))
            ):
                rolling = self.parent._eager("rolling", n, min_periods=min_periods)
                return getattr(rolling, name)(*args, **kwargs)

            def run(a):
                rolling = pd.DataFrame(a).rolling(n, min_periods=min_periods)
                return getattr(rolling, name)(*args, **kwargs).to_numpy()

            return self.parent._dense(run)

        return aggregate


class Periods(Node):
    """``resample(...).last()``: each column's last value of each period, known at the period's end."""

    def __init__(self, kid, labels, stops):
        super().__init__(kid.columns, (kid,))
        self._axis = labels
        self.stops = stops
        self.full = None

    def compute(self, when):
        if self.full is None:
            kept = self.kids[0].dense()
            values = _columns(_num(kept))
            self.full = np.empty((len(self.stops), values.shape[1]), order="F")
            _K.last_valid(values, self.stops, self.full)
            self.full = _kept_kind(self.full, kept)
        return _take(self.full, self.rows(when))


class _Resample:
    """``df.resample(rule).last()`` without leaving the expression."""

    __slots__ = ("kwargs", "parent", "rule")

    def __init__(self, parent, rule, kwargs):
        self.parent, self.rule, self.kwargs = parent, rule, kwargs

    def last(self, *args, **kwargs):
        if self.kwargs or args or kwargs:
            resampler = self.parent._eager("resample", self.rule, **self.kwargs)
            return resampler.last(*args, **kwargs)
        axis = self.parent._node.axis
        counts = pd.Series(1, index=axis).resample(self.rule).sum()
        stops = np.cumsum(counts.to_numpy(dtype=np.int64)).astype(np.int64)
        return _wrap(Periods(self.parent._node, counts.index, stops))

    def __getattr__(self, name):
        return getattr(self.parent._eager("resample", self.rule, **self.kwargs), name)


def ewm_mean(com, min_periods, adjust, ignore_na):
    def run(a):
        a = _columns(a)
        out = np.empty(a.shape, order="F")
        _K.ewm_mean(a, com, min_periods, adjust, ignore_na, out)
        return out

    return run


class _Ewm:
    __slots__ = ("kwargs", "parent")

    def __init__(self, parent, kwargs):
        self.parent, self.kwargs = parent, kwargs

    def mean(self, *args, **options):
        if args or options:
            return self.parent._eager("ewm", **self.kwargs).mean(*args, **options)
        k = dict(self.kwargs)
        adjust, ignore_na = k.pop("adjust", True), k.pop("ignore_na", False)
        min_periods = max(int(k.pop("min_periods", 0) or 0), 1)
        com, span, halflife, alpha = (
            k.pop(key, None) for key in ("com", "span", "halflife", "alpha")
        )
        if k or sum(value is not None for value in (com, span, halflife, alpha)) != 1:
            return self.parent._dense(
                lambda a: pd.DataFrame(a).ewm(**self.kwargs).mean().to_numpy()
            )
        return self.parent._dense(
            ewm_mean(
                get_center_of_mass(com, span, halflife, alpha),
                min_periods,
                adjust,
                ignore_na,
            )
        )

    def __getattr__(self, name):
        kwargs = self.kwargs

        def aggregate(*args, **more):
            if name not in ("std", "var") or not all(
                map(_scalar, (*args, *more.values()))
            ):
                return getattr(self.parent._eager("ewm", **kwargs), name)(*args, **more)
            return self.parent._dense(
                lambda a: getattr(pd.DataFrame(a).ewm(**kwargs), name)(
                    *args, **more
                ).to_numpy()
            )

        return aggregate


def _is_mask(key, length):
    return isinstance(key, np.ndarray) and key.dtype == bool and len(key) == length


def _every(key):
    return isinstance(key, slice) and key == slice(None)


class _Loc:
    __slots__ = ("parent",)

    def __init__(self, parent):
        self.parent = parent

    def __call__(self, axis=None):
        self.parent._fill()
        return self.parent.loc(axis=axis)

    def __getitem__(self, key):
        parent = self.parent
        if not isinstance(parent, _Pending):
            return parent.loc[key]
        axis = parent._node.axis
        if isinstance(key, slice) and key.step is None:
            part = axis[axis.slice_indexer(key.start, key.stop)]
            if len(part):
                return _wrap(Reindex(parent._node, part))
        if _is_mask(key, len(axis)) and key.any():
            return _wrap(Reindex(parent._node, axis[key]))
        if isinstance(key, tuple) and len(key) == 2 and _every(key[0]):
            columns = key[1]
            if _is_mask(columns, parent.shape[1]):
                columns = list(parent.columns[columns])
            if isinstance(columns, list):
                return parent[columns]
        parent._fill()
        return parent.loc[key]

    def __setitem__(self, key, value):
        parent = self.parent
        right = (
            _node(key) if type(key) is Frame or isinstance(key, pd.DataFrame) else None
        )
        if (
            isinstance(parent, _Pending)
            and right is not None
            and _scalar(value)
            and value is not None
        ):
            parent._assign(right, value)
            return
        if isinstance(parent, _Pending):
            parent._fill()
        parent.loc[key] = value


class _Iloc:
    """Row slices stay expressions; a single row reads only that row."""

    __slots__ = ("parent",)

    def __init__(self, parent):
        self.parent = parent

    def __call__(self, axis=None):
        if isinstance(self.parent, _Pending):
            self.parent._fill()
        return self.parent.iloc(axis=axis)

    def __getitem__(self, key):
        parent = self.parent
        if not isinstance(parent, _Pending):
            return parent.iloc[key]
        node = parent._node
        if isinstance(key, slice) and key.step is None:
            part = node.axis[key]
            if len(part):
                return _wrap(Reindex(node, part))
        if isinstance(key, (int, np.integer)):
            row = node.axis[key]
            values = node.at(_ns([row]))
            if not isinstance(values, _Mask):
                return pd.Series(values[0], index=node.columns, name=row)
        parent._fill()
        return parent.iloc[key]

    def __setitem__(self, key, value):
        if isinstance(self.parent, _Pending):
            self.parent._fill()
        self.parent.iloc[key] = value


day_numbers = _ns


def pending(frame, quarterly=False):
    """``frame`` as an expression, or None when pandas has to handle it."""
    if not ENABLED:
        return None
    if _plain_dates(frame.index):
        return _wrap(_source(frame)) if _numeric(frame) else None
    return _dated(frame) if quarterly and _by_quarter(frame) else None


def combine(frame, other, op):
    """``frame <op> other`` as an expression, or None when pandas has to align them."""
    if not ENABLED or op.startswith("__i"):
        return None
    if op == "__getitem__" and not isinstance(other, pd.DataFrame):
        return None
    scalar = _scalar(other)
    if not scalar and not isinstance(other, (pd.DataFrame, pd.Series)):
        return None
    if not (_plain_dates(frame.index) or type(other) in (Frame, Line)):
        return None
    left = _node(frame)
    if left is None or (not scalar and _node(other) is None):
        return None
    return getattr(_wrap(left), op)(other)


def _still_pending(name, method):
    """Python binds a method before it reads the arguments, and they can compute ``self``:
    ``frame.fillna(frame.mean())``. Then pandas answers."""

    @wraps(method)
    def run(self, *args, **kwargs):
        if isinstance(self, _Pending):
            return method(self, *args, **kwargs)
        return getattr(self, name)(*args, **kwargs)

    return run


for _owner in (_Pending, Frame, Line):
    for _name, _method in list(vars(_owner).items()):
        if isfunction(_method) and not _name.startswith("_"):
            setattr(_owner, _name, _still_pending(_name, _method))
