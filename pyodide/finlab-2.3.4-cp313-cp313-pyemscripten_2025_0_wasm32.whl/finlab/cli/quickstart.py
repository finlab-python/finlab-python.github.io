"""`python -m finlab quickstart`: run a first backtest and open its report."""

from __future__ import annotations

import importlib
import os
import runpy
import sys
import threading
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import argparse

_SHOW_REPORT = """
html = Path(__file__).with_suffix(".html").resolve()
report.to_html(str(html))
print(f"Report: {html}")
webbrowser.open(html.as_uri())
"""

# The command only writes and runs these files, so what ran is what the user can edit.
SCRIPTS = {
    "tw": (
        "finlab_quickstart.py",
        '''"""FinLab 第一份回測：營收成長最強、股價站上 60 日線的股票，每月換股。

改完條件後執行 python finlab_quickstart.py，就會重新回測並開啟報告。
"""

import webbrowser
from pathlib import Path

from finlab import data
from finlab.backtest import sim

close, revenue = data.gets("price:收盤價", "monthly_revenue:當月營收")

growth = revenue.average(3) / revenue.average(12)
position = growth.is_largest(20) & (close > close.average(60))

report = sim(position, resample="M")

stats = report.get_stats()
print(
    f"年化報酬 {stats['cagr']:.1%}，最大回撤 {stats['max_drawdown']:.1%}，"
    f"夏普 {stats['daily_sharpe']:.2f}（歷史回測，不代表未來績效）"
)
'''
        + _SHOW_REPORT,
    ),
    "us": (
        "finlab_quickstart_us.py",
        '''"""Your first FinLab backtest: 6-month momentum among the 100 most traded US stocks.

Change the rules, then run python finlab_quickstart_us.py to rerun and open the report.
"""

import webbrowser
from pathlib import Path

from finlab import data
from finlab.backtest import sim
from finlab.markets.us import USMarket

data.set_market("us")
adj_close, close, volume = data.gets(
    "us_price:adj_close", "us_price:close", "us_price:volume"
)

most_traded = (close * volume).rolling(60, min_periods=20).mean().is_largest(100)
momentum = adj_close / adj_close.shift(126) - 1
position = momentum[most_traded].is_largest(20)

report = sim(position, resample="M", market=USMarket())

stats = report.get_stats()
print(
    f"CAGR {stats['cagr']:.1%}, max drawdown {stats['max_drawdown']:.1%},"
    f" Sharpe {stats['daily_sharpe']:.2f} (historical backtest, not a forecast)"
)
'''
        + _SHOW_REPORT,
    ),
}


def _ensure_login(market: str) -> None:
    """Log in here so accounts created by this command can be counted."""
    from finlab import auth

    # get_id_token, not get_session: an expired session has to log in again.
    if (
        auth.get_id_token()
        or {"FINLAB_ID_TOKEN", "FINLAB_API_TOKEN"} & os.environ.keys()
    ):
        return
    print(
        "請在瀏覽器用 Google 登入。第一次使用會自動建立免費帳號，含 7 天完整試用，"
        "不用信用卡。\n"
        "Sign in with Google in your browser. First-time users get a free account"
        " with a 7-day full trial, no credit card needed."
    )
    # macOS scans each new binary on first load, up to half a minute after pip install.
    # Let that happen while the user is signing in instead of after.
    threading.Thread(target=importlib.import_module, args=("finlab.backtest",)).start()
    locale = "en" if market == "us" else None
    if not auth.browser_login(source="quickstart", locale=locale):
        sys.exit(1)


def cmd_quickstart(args: argparse.Namespace) -> None:
    from finlab.cli.skill import print_skill_hint

    _ensure_login(args.market)

    name, content = SCRIPTS[args.market]
    script = Path.cwd() / name
    if not script.exists():
        script.write_text(content, encoding="utf-8")

    print("回測中，第一次要下載約 200 MB 資料。 / Running, about 200 MB on first use.")
    runpy.run_path(str(script), run_name="__main__")

    print(f"改這支程式再跑一次 / Edit and rerun: python {name}")
    print_skill_hint()


def register_quickstart_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    parser = subparsers.add_parser(
        "quickstart",
        help="Run a first backtest and open its report",
        description=(
            "Log in if needed, write a strategy script to the current folder, run it"
            " and open the HTML report. An existing script is run as it is."
        ),
    )
    parser.add_argument(
        "--market", choices=sorted(SCRIPTS), default="tw", help="Market (default: tw)"
    )
