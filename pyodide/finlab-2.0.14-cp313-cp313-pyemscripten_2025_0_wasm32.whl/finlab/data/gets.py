"""Batch transport plus ``data.gets()`` wrapper."""

from __future__ import annotations

import logging

from .get import (
    _fetch_many,
)

logger = logging.getLogger(__name__)

__all__ = [
    "gets",
]


# ---------------------------------------------------------------------------
# data.gets() — batch entry point
# ---------------------------------------------------------------------------


def gets(
    *datasets: str,
    force_download: bool = False,
    lazy: bool = False,
) -> tuple:
    """Batch-fetch multiple datasets, returning finalized pandas dataframes.

    Uses a single HTTP round-trip for auth/URL signing, downloads datasets
    in parallel, and finalizes the results through the same processing
    path used by :func:`data.get`.

    Args:
        *datasets: One or more dataset names (e.g. ``'price:收盤價'``).
        force_download: Bypass cache and re-download from cloud.
        lazy: Return lazy computation wrappers after fetching datasets.

    Returns:
        ``tuple[FinlabDataFrame, ...]`` — one per input dataset, same order.
        When ``lazy=True``, returns ``tuple[LazyWide, ...]``.

    Examples:
        >>> from finlab import data
        >>> close, vol = data.gets('price:收盤價', 'price:成交股數')
        >>> position = (close > close.average(20)) & (vol > vol.average(20))
    """
    frames = _fetch_many(list(datasets), force_download, show_progress=True)
    if lazy:
        return tuple(frame.lazy() for frame in frames)
    return frames
