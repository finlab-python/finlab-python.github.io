"""`finlab ai`: ask the FinLab AI assistant from the terminal.

Questions go through the website support API (studio.finlab.finance/support),
so the terminal and the website share one conversation history, one monthly
question quota and the same account rules. Auth uses
finlab.auth.get_id_token(), which refreshes the login automatically.
"""

from __future__ import annotations

import contextlib
import json
import os
import sys
import time
import urllib.error
import urllib.request
import uuid
from typing import IO, TYPE_CHECKING, Any, Final

if TYPE_CHECKING:
    import argparse
    from collections.abc import Iterator

DEFAULT_BASE_URL: Final[str] = "https://studio.finlab.finance"
BASE_URL_ENV: Final[str] = "FINLAB_SUPPORT_BASE_URL"
MESSAGES_PATH: Final[str] = "/api/support/messages"
# The website polls a pending question at the same cadence.
POLL_SECONDS: Final[float] = 5.0
HTTP_TIMEOUT_SECONDS: Final[float] = 30.0
SUBMIT_ATTEMPTS: Final[int] = 3
# Bracketed paste: the terminal wraps each paste in these marks once asked to.
PASTE_MARKS_ON: Final[str] = "\x1b[?2004h"
PASTE_MARKS_OFF: Final[str] = "\x1b[?2004l"
PASTE_START: Final[str] = "\x1b[200~"
PASTE_END: Final[str] = "\x1b[201~"
# Without marks, lines of one paste arrive together; a gap this long ends the burst.
PASTE_WINDOW_SECONDS: Final[float] = 0.05
FINISHED_STATUSES: Final[frozenset[str]] = frozenset({"replied", "failed", "cancelled"})
EXIT_WORDS: Final[frozenset[str]] = frozenset({"exit", "quit"})
# Signing out or being blocked will not change by asking again.
FATAL_STATUSES: Final[frozenset[int]] = frozenset({401, 403})
INTERRUPTED_EXIT_CODE: Final[int] = 130

WAITING_NOTE: Final[str] = (
    "已送出，FinLab 助理處理中，通常需要 1–5 分鐘。按 Ctrl+C 只會停止等候，不會取消提問。"
)
LAST_HINT: Final[str] = "回覆可用 python -m finlab ai --last 查看。"
CHAT_BANNER: Final[str] = (
    "FinLab AI 助理：與網站客服共用對話紀錄與每月提問額度。"
    "輸入問題後按 Enter 送出，可直接貼上多行內容（沒有送出就在空白行再按一次 Enter）。"
    "輸入 exit 離開。"
)


class SupportApiError(Exception):
    """A support API failure carrying the message to show the user."""

    def __init__(self, message: str, status: int) -> None:
        super().__init__(message)
        self.status = status

    @property
    def retryable(self) -> bool:
        """No answer or a transient server error: resending the same question ID is safe."""
        return self.status in {0, 408} or self.status >= 500


def _base_url() -> str:
    return os.environ.get(BASE_URL_ENV, DEFAULT_BASE_URL).rstrip("/")


def _get_token() -> str:
    from finlab.auth import get_id_token

    token = get_id_token()
    if not token:
        raise SupportApiError("尚未登入。請先執行：python -m finlab login", 401)
    return token


def _http_error_message(error: urllib.error.HTTPError) -> str:
    if error.code == 401:
        return "登入已失效。請重新執行：python -m finlab login"
    try:
        message = json.loads(error.read()).get("message")
    except (ValueError, AttributeError):
        message = None
    if isinstance(message, str) and message:
        return message
    return f"客服服務暫時無法回應（HTTP {error.code}）。"


def _request(
    method: str, path: str, payload: dict[str, Any] | None = None, *, auth: bool = True
) -> dict[str, Any]:
    headers = {"Accept": "application/json", "User-Agent": "finlab-cli/1.0"}
    if auth:
        headers["Authorization"] = f"Bearer {_get_token()}"
    data = None
    if payload is not None:
        data = json.dumps(payload).encode()
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(
        f"{_base_url()}{path}", data=data, headers=headers, method=method
    )
    try:
        with urllib.request.urlopen(request, timeout=HTTP_TIMEOUT_SECONDS) as response:
            return json.loads(response.read())
    except urllib.error.HTTPError as error:
        raise SupportApiError(_http_error_message(error), error.code) from None
    except (OSError, ValueError):
        raise SupportApiError("連線中斷，請確認網路後重試。", 0) from None


def submit_question(text: str) -> dict[str, Any]:
    """Queue a question. Retries reuse its ID, which the API deduplicates."""
    payload = {"id": str(uuid.uuid4()), "text": text, "client": "cli"}
    for attempt in range(1, SUBMIT_ATTEMPTS):
        try:
            return _request("POST", MESSAGES_PATH, payload)["message"]
        except SupportApiError as error:
            if not error.retryable:
                raise
        time.sleep(attempt)
    return _request("POST", MESSAGES_PATH, payload)["message"]


def _refresh(message: dict[str, Any]) -> dict[str, Any]:
    # `?id=` reads one message (finlab-python/new_website#206).
    try:
        return _request("GET", f"{MESSAGES_PATH}?id={message['id']}")["message"]
    except SupportApiError as error:
        if error.retryable:
            return message
        raise


def wait_for_answer(message: dict[str, Any], out: IO[str]) -> dict[str, Any]:
    """Print replies as they arrive; return the message once it is finished."""
    shown = 0
    while True:
        replies = message.get("replies") or []
        for reply in replies[shown:]:
            print(f"\n{reply}", file=out, flush=True)
        shown = len(replies)
        if message.get("status") in FINISHED_STATUSES:
            return message
        time.sleep(POLL_SECONDS)
        message = _refresh(message)


def _warn_if_offline() -> None:
    try:
        state = _request("GET", "/api/support/status", auth=False).get("state")
    except SupportApiError:
        return
    if state == "offline":
        print("助理目前離線，提問已保存，恢復後會依序處理。", file=sys.stderr)


def _outcome(message: dict[str, Any]) -> int:
    if message.get("status") == "replied":
        return 0
    print(message.get("error") or "這則提問已取消。", file=sys.stderr)
    return 1


def ask(text: str, out: IO[str]) -> int:
    message = submit_question(text)
    _warn_if_offline()
    print(WAITING_NOTE, file=sys.stderr)
    return _outcome(wait_for_answer(message, out))


def show_last(out: IO[str]) -> int:
    messages = _request("GET", MESSAGES_PATH)["messages"]
    if not messages:
        print("還沒有任何提問紀錄。", file=sys.stderr)
        return 1
    message = messages[0]
    print(f"> {message['text']}", file=out)
    if message.get("status") not in FINISHED_STATUSES:
        print(WAITING_NOTE, file=sys.stderr)
    return _outcome(wait_for_answer(message, out))


@contextlib.contextmanager
def _marked_pastes() -> Iterator[None]:
    """Have the terminal mark pastes, without echoing the marks as ^[[200~."""
    terminal = next((s for s in (sys.stderr, sys.stdout) if s.isatty()), None)
    if sys.platform == "win32" or terminal is None or not sys.stdin.isatty():
        yield
        return
    import termios

    fd = sys.stdin.fileno()
    saved = termios.tcgetattr(fd)
    quiet = [*saved]
    quiet[3] &= ~termios.ECHOCTL
    termios.tcsetattr(fd, termios.TCSANOW, quiet)
    terminal.write(PASTE_MARKS_ON)
    terminal.flush()
    try:
        yield
    finally:
        terminal.write(PASTE_MARKS_OFF)
        terminal.flush()
        termios.tcsetattr(fd, termios.TCSANOW, saved)


def _input_pending() -> bool:
    """Whether more typed or pasted input is already waiting."""
    if sys.platform == "win32":
        import msvcrt

        deadline = time.monotonic() + PASTE_WINDOW_SECONDS
        while time.monotonic() < deadline:
            if msvcrt.kbhit():
                return True
            time.sleep(PASTE_WINDOW_SECONDS / 10)
        return False
    import select

    return bool(select.select([sys.stdin], [], [], PASTE_WINDOW_SECONDS)[0])


def _paste_open(line: str, was_open: bool) -> bool:
    """Whether a paste is still open after this line; its last mark decides."""
    start, end = line.rfind(PASTE_START), line.rfind(PASTE_END)
    return was_open if start == end else start > end


def _read_chat_question() -> str:
    """One question per prompt; a multi-line paste is one question.

    Marked pastes are read until the latest one ends. A terminal withholds a last
    line without a newline until Enter, so that line is still included. Where
    pastes are not marked (Windows consoles, terminals that ignore the request),
    a paste is input already waiting after the first line, and it ends at an
    empty line the user types.
    """
    lines = [input("\n> ")]
    if PASTE_START in lines[0]:
        pasting = _paste_open(lines[0], was_open=False)
        while pasting:
            lines.append(input())
            pasting = _paste_open(lines[-1], was_open=True)
    elif _input_pending():
        while (line := input()) or _input_pending():
            lines.append(line)
    text = "\n".join(lines).replace(PASTE_START, "").replace(PASTE_END, "")
    return text.strip()


@_marked_pastes()
def chat(out: IO[str]) -> int:
    print(CHAT_BANNER, file=sys.stderr)
    while True:
        try:
            question = _read_chat_question()
        except (EOFError, KeyboardInterrupt):
            print(file=sys.stderr)
            return 0
        if question.lower() in EXIT_WORDS:
            return 0
        if not question:
            continue
        try:
            ask(question, out)
        except SupportApiError as error:
            print(error, file=sys.stderr)
            if error.status in FATAL_STATUSES:
                return 1


def _question(words: list[str], stdin: IO[str]) -> str:
    """Join the question words with piped input, e.g. an error log."""
    parts = [" ".join(words)]
    if not stdin.isatty():
        parts.append(stdin.read())
    return "\n\n".join(filter(None, (part.strip() for part in parts)))


def cmd_ai(args: argparse.Namespace) -> None:
    try:
        if args.last:
            code = show_last(sys.stdout)
        else:
            question = _question(args.question, sys.stdin)
            code = ask(question, sys.stdout) if question else chat(sys.stdout)
    except SupportApiError as error:
        print(error, file=sys.stderr)
        if error.status == 409:
            print(f"上一則提問的{LAST_HINT}", file=sys.stderr)
        code = 1
    except KeyboardInterrupt:
        print(f"\n已停止等候。已送出的提問仍會處理，{LAST_HINT}", file=sys.stderr)
        code = INTERRUPTED_EXIT_CODE
    sys.exit(code)


def register_ai_commands(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    parser = subparsers.add_parser(
        "ai",
        help="Ask the FinLab AI assistant",
        description=(
            "Ask the FinLab AI assistant. Shares the conversation history and"
            " monthly question quota with the support chat on"
            " studio.finlab.finance."
        ),
    )
    parser.add_argument(
        "question",
        nargs="*",
        help="Question to ask; piped input is appended. Omit both to start a chat.",
    )
    parser.add_argument(
        "--last",
        action="store_true",
        help="Show the latest question and its answer, waiting if still in progress",
    )
