from __future__ import annotations

import logging

# Get an instance of a logger
logger = logging.getLogger(__name__)


def read_resource_file(package: str, resource: str) -> str:
    try:
        # For Python 3.9 and later
        from importlib.resources import files

        resource_path = files(package) / resource
        return resource_path.read_text(encoding="utf-8")
    except ImportError:
        try:
            # For Python 3.7 and 3.8
            from importlib.resources import path

            with (
                path(package, resource) as resource_path,
                open(resource_path, encoding="utf-8") as file,
            ):
                return file.read()
        except ImportError:
            # Fallback for older Python versions without importlib.resources
            import pkg_resources

            resource_filename = pkg_resources.resource_filename(package, resource)
            with open(resource_filename, encoding="utf-8") as file:
                return file.read()
    raise ImportError("No compatible importlib.resources implementation found.")
