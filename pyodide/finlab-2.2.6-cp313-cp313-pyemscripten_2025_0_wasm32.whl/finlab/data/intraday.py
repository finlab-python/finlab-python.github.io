"""Bounded, manifest-backed TW tick and minute partition downloads."""

from __future__ import annotations

import datetime as dt
import hashlib
import re
import sys
import time
import uuid
from io import BytesIO
from typing import Any

import pandas as pd

import finlab.utils
from finlab.exceptions import DataError

from . import auth, context

_STOCK_SYMBOL = r"[0-9A-Z]{4,10}"
# Futures symbols are PRODUCT_YYYYMM, with W1-W5 for weekly contracts.
_SYMBOL_PATTERNS = {
    "tw_tick": _STOCK_SYMBOL,
    "tw_minute": _STOCK_SYMBOL,
    "tw_futures_minute": r"[0-9A-Z]{1,6}_\d{6}(?:W[1-5])?",
}
FAMILIES = frozenset(_SYMBOL_PATTERNS)
_STOCK_ATTRS = {
    "completeness": "regular_ohlcv_verified",
    "after_hours_validation": "schema_only",
}
_PUBLICATION_ATTRS = {
    "tw_futures_minute": {
        "completeness": "contract_session_volume_verified",
        "after_hours_validation": "contract_session_volume",
        "source": "taifex_csv",
        "source_resolution": "1s",
        "tie_break": "source_file_order",
        "volume_scope": "outright_only",
    }
}
TICK_COLUMNS = (
    "stock_id",
    "trade_date",
    "timestamp",
    "sequence",
    "ts",
    "close",
    "volume",
    "tick_type",
    "bid_price",
    "bid_volume",
    "ask_price",
    "ask_volume",
    "session",
)
BAR_COLUMNS = (
    "stock_id",
    "trade_date",
    "timestamp",
    "session",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "tick_count",
    "vwap",
)


def is_intraday(dataset: str) -> bool:
    return isinstance(dataset, str) and dataset.split(":", 1)[0] in FAMILIES


def _date(value: Any) -> str:
    if value is None:
        raise ValueError("Intraday data requires both start and end dates")
    stamp = pd.Timestamp(value)
    if pd.isna(stamp) or stamp.tzinfo is not None or stamp != stamp.normalize():
        raise ValueError("Use date-only start/end in Asia/Taipei (YYYY-MM-DD)")
    return stamp.strftime("%Y-%m-%d")


def _post(query: dict[str, Any]) -> dict[str, Any]:
    result = auth.post_signing_request("intraday", query, "Intraday")
    if "error" in result:
        detail = result.get("missing_dates") or result.get("available_through") or ""
        raise DataError(
            f"{result.get('code', 'intraday_error')}: {result['error']} {detail}".strip()
        )
    if result.get("schema_version") != 1 or result.get("dataset") != query["dataset"]:
        raise DataError("Unsupported intraday response schema or dataset")
    context._default_context._role = result.get("role")
    return result


def _download(part: dict[str, Any]) -> bytes:
    problem = "unknown error"
    for attempt in range(2):
        if attempt:
            time.sleep(1)
        try:
            if "pyodide" in sys.modules:
                raw = auth._pyodide_get_bytes(part["url"])
            else:
                response = finlab.utils.requests.get(part["url"], timeout=120)
                if response.status_code != 200:
                    problem = f"HTTP {response.status_code}"
                    continue
                raw = response.content
        except Exception as exc:  # noqa: BLE001 - Never expose signed URLs in transport errors.
            problem = auth._signed_download_error(exc).problem
            continue
        if (
            len(raw) == part["size"]
            and hashlib.sha256(raw).hexdigest() == part["sha256"]
        ):
            return raw
        problem = "size or checksum mismatch"
    # Raised outside any handler so the transport error, whose message may
    # contain the signed URL, is not kept as __context__.
    raise DataError(
        f"Intraday partition download failed ({problem}); retry data.get()"
    ) from None


def _empty(family: str) -> pd.DataFrame:
    columns = TICK_COLUMNS if family == "tw_tick" else BAR_COLUMNS
    frame = pd.DataFrame({c: pd.Series(dtype="object") for c in columns})
    frame["timestamp"] = pd.Series(dtype="datetime64[ns, Asia/Taipei]")
    for c in ("volume", "sequence", "ts", "tick_count"):
        if c in frame:
            frame[c] = frame[c].astype("int64")
    for c in ("open", "high", "low", "close", "vwap", "bid_price", "ask_price"):
        if c in frame:
            frame[c] = frame[c].astype("float64")
    if family == "tw_tick":
        frame["tick_type"] = frame.tick_type.astype("int8")
        for c in ("bid_volume", "ask_volume"):
            frame[c] = frame[c].astype("Int64")
    return frame


def _validate(
    frame: pd.DataFrame, part: dict[str, Any], symbol: str, family: str
) -> None:
    expected = TICK_COLUMNS if family == "tw_tick" else BAR_COLUMNS
    if tuple(frame.columns) != expected or len(frame) != part["rows"]:
        raise DataError("Intraday partition schema or row count mismatch")
    if str(frame.timestamp.dt.tz) != "Asia/Taipei":
        raise DataError("Intraday partition timezone mismatch")
    if not (
        frame.stock_id.eq(symbol).all() and frame.trade_date.eq(part["date"]).all()
    ):
        raise DataError("Intraday partition identity mismatch")
    dates = frame.timestamp.dt.strftime("%Y-%m-%d")
    valid_dates = (
        dates.le(part["date"])
        if family == "tw_futures_minute"
        else dates.eq(part["date"])
    )
    if not valid_dates.all():
        raise DataError("Intraday partition date mismatch")


def _parse_range(dataset: str, start: Any, end: Any) -> tuple[str, str, str, str]:
    family, _, symbol = dataset.partition(":")
    pattern = _SYMBOL_PATTERNS.get(family)
    if pattern is None or not re.fullmatch(pattern, symbol):
        raise ValueError(
            "Expected a stock intraday symbol or tw_futures_minute:PRODUCT_YYYYMM"
        )
    first, last = _date(start), _date(end)
    if not 0 <= (dt.date.fromisoformat(last) - dt.date.fromisoformat(first)).days < 31:
        raise ValueError("Request between 1 and 31 calendar days")
    return family, symbol, first, last


def _verify_signed_partition(
    actual: dict[str, Any] | None, part: dict[str, Any]
) -> dict[str, Any]:
    if actual is None or any(
        actual.get(k) != part[k]
        for k in ("key", "generation", "sha256", "size", "rows")
    ):
        raise DataError("Publication changed during download; retry data.get()")
    return actual


def get_intraday(
    dataset: str,
    *,
    start: Any,
    end: Any,
    force_download: bool,
    save_to_storage: bool,
    lazy: bool,
    progress: str,
    progress_callback: Any,
) -> pd.DataFrame:
    family, symbol, first, last = _parse_range(dataset, start, end)
    if lazy or progress != "silent" or progress_callback is not None:
        raise ValueError(
            "Intraday data currently supports eager, silent data.get() only"
        )
    ctx = context._default_context
    if ctx.use_local_data_only:
        raise ValueError(
            "Intraday data requires a live publication manifest; local-only mode is unsupported"
        )
    force_download = force_download or ctx.force_cloud_download
    query = {"dataset": dataset, "start": first, "end": last}
    manifest = _post({**query, "mode": "manifest"})
    frames, needed = {}, []
    partitions = manifest["partitions"]
    cache = ctx._storage
    for part in partitions:
        if part["status"] == "no_trades":
            continue
        if part.get("status") != "ready":
            raise DataError("Intraday partition is not ready")
        identity = hashlib.sha256(
            f"{part['key']}:{part['generation']}:{part['sha256']}".encode()
        ).hexdigest()[:24]
        key = f"_intraday_v1_{family}_{symbol}_{part['date']}_{identity}"
        cached = (
            cache.get_dataframe(key) if save_to_storage and not force_download else None
        )
        if cached is not None:
            _validate(cached, part, symbol, family)
            frames[part["date"]] = cached
        else:
            needed.append((part, key))
    for offset in range(0, len(needed), 5):
        batch = needed[offset : offset + 5]
        signed = _post(
            {
                **query,
                "mode": "download",
                "request_id": uuid.uuid4().hex,
                "partitions": [
                    {"date": p["date"], "generation": p["generation"]} for p, _ in batch
                ],
            }
        )
        by_date = {p["date"]: p for p in signed["partitions"]}
        for part, key in batch:
            actual = by_date.get(part["date"])
            actual = _verify_signed_partition(actual, part)
            frame = pd.read_parquet(BytesIO(_download(actual)))
            _validate(frame, part, symbol, family)
            if save_to_storage:
                cache.set_dataframe(key, frame)
            frames[part["date"]] = frame
    result = (
        pd.concat([frames[d] for d in sorted(frames)], ignore_index=True)
        if frames
        else _empty(family)
    )
    result = result.sort_values(
        ["timestamp", "sequence"] if family == "tw_tick" else ["timestamp"],
        kind="stable",
    ).reset_index(drop=True)
    result.attrs = {
        "schema_version": 1,
        "dataset": dataset,
        "timezone": "Asia/Taipei",
        "volume_unit": manifest["volume_unit"],
        "closed_dates": manifest["closed_dates"],
        "no_trade_dates": [p["date"] for p in partitions if p["status"] == "no_trades"],
        "price_adjustment": "none",
        **_PUBLICATION_ATTRS.get(family, _STOCK_ATTRS),
    }
    return result
