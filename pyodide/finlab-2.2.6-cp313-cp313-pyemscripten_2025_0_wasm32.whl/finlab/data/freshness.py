"""Data freshness: ``is_tradable()``, ``next_future_expiry()``, ``suggested_tradable_time()``."""

from __future__ import annotations

import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from finlab.market import Market

from .context import _default_context

__all__ = [
    "is_tradable",
    "next_future_expiry",
    "suggested_tradable_time",
]


# ---------------------------------------------------------------------------
# Expiry dict
# ---------------------------------------------------------------------------


def _get_expiry_dict() -> dict[str, datetime.datetime]:
    """Next scheduled refresh of each dataset loaded via get(), as published
    for the version read.

    Only loaded datasets count, so unrelated cached data doesn't affect
    suggested_tradable_time() / is_tradable(). A dataset whose expiry was
    unknown is due since it was loaded.
    """
    ctx = _default_context
    return {
        name: datetime.datetime.fromtimestamp(record[1], datetime.timezone.utc)
        for name in ctx._loaded_datasets
        if (record := ctx._loaded_versions.get(name)) is not None
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def next_future_expiry() -> datetime.datetime | None:
    """Next future expiry time among cached datasets (UTC).

    Returns only expiry times in the future, skipping already expired data.

    Returns:
        datetime in UTC representing the next future expiry, or None if
        no future expiries exist or no data is available.
    """
    now = datetime.datetime.now(tz=datetime.timezone.utc)
    return min((e for e in _get_expiry_dict().values() if e > now), default=None)


def suggested_tradable_time(market: Market | None = None) -> datetime.datetime | None:
    """Latest required scheduled source check, not a guaranteed arrival time.

    Returns None if readiness is unknown or every required slot has passed.
    Rerun the strategy after the scheduled check and confirm readiness again.
    """
    from .readiness import readiness

    result = readiness(market)
    now = datetime.datetime.now(datetime.timezone.utc)
    slots = [
        datetime.datetime.fromisoformat(source["required_refresh_at"])
        for item in result["datasets"].values()
        for source in item.get("sources", [])
        if source.get("pending")
    ]
    future = [slot for slot in slots if slot > now]
    return max(future) if future else None


def _without_publication_schedule(result: dict) -> bool:
    """Whether readiness() had no schedule to judge against: an unsupported
    market or no trading calendar. Missing evidence for a dataset is not this.
    """
    reason = result.get("reason")
    return reason == "unsupported_market" or (
        reason == "readiness_unavailable"
        and result.get("error_type") == "CalendarUnavailable"
    )


def is_tradable(market: Market | None = None) -> bool:
    """Whether loaded data completed its final scheduled refresh before next open.

    Daily TW data is judged by publication evidence, not expiry; use
    data.readiness() for the reason. Markets without publication evidence and
    runs without a trading calendar fall back to the published expiry.
    """
    from .readiness import readiness

    result = readiness(market)
    if _without_publication_schedule(result):
        return _expiry_is_tradable(market)
    return result["final_ready"]


def _expiry_is_tradable(market: Market | None) -> bool:
    """True when no loaded dataset has expired or refreshes again before the open."""
    from finlab.markets.tw import TWMarket

    if market is None:
        market = TWMarket()

    expiry_dict = _get_expiry_dict()
    if not expiry_dict:
        return False

    now = datetime.datetime.now(tz=datetime.timezone.utc)
    tz = market.tzinfo() or datetime.timezone(datetime.timedelta(hours=8))
    open_hour, open_minute = market.market_open_time()
    now_local = now.astimezone(tz)
    today_open_local = now_local.replace(
        hour=open_hour, minute=open_minute, second=0, microsecond=0
    )
    today_open_utc = today_open_local.astimezone(datetime.timezone.utc)
    market_opened_today = now_local >= today_open_local

    for expiry in expiry_dict.values():
        if now >= expiry:
            return False
        if (not market_opened_today) and expiry <= today_open_utc:
            return False
    return True
