from __future__ import annotations

import datetime
import errno
import functools
import gzip
import itertools
import json
import logging
import os
import pickle
import shutil
import sys

__all__ = ["CacheStorage", "FileStorage", "LocalDataReadError"]
from contextlib import contextmanager
from typing import IO, TYPE_CHECKING, Any, ClassVar, cast

if TYPE_CHECKING:
    from collections.abc import Callable, Generator

import pandas as pd
import pyarrow as pa
from pandas.compat import pickle_compat

import finlab.utils
from finlab.data import feather_io
from finlab.data.recent_merge import stream_merge_recent_feather

logger = logging.getLogger(__name__)


class _HashMismatchError(Exception):
    """A merged cache does not hash to the published table."""


class LocalDataReadError(RuntimeError):
    """Raised when an existing local dataframe cache cannot be read."""

    def __init__(self, name: str, file_path: str) -> None:
        super().__init__(f"Failed to read local cache for {name}: {file_path}")
        self.name = name
        self.file_path = file_path


fcntl: Any | None
try:
    import fcntl
except ImportError:
    fcntl = None

msvcrt: Any | None
try:
    import msvcrt
except ImportError:
    msvcrt = None


class _LegacyNDArrayBackedUnpickler(pickle_compat.Unpickler):
    _NO_VALUE: ClassVar[object] = object()

    def __init__(self, *args: object, normalize_state: Any, **kwargs: object) -> None:
        self._normalize_state = normalize_state
        super().__init__(*args, **kwargs)

    def find_class(self, module: str, name: str) -> object:
        obj = super().find_class(module, name)
        if module == "pandas._libs.arrays" and name == "__pyx_unpickle_NDArrayBacked":

            def compat_unpickle(
                klass: type,
                checksum: int,
                state: object,
            ) -> object:
                return obj(klass, checksum, self._normalize_state(state))

            return compat_unpickle
        return obj

    def load_build(self) -> None:
        state = self._normalize_state(self.stack.pop())
        inst = self.stack[-1]
        setstate = getattr(inst, "__setstate__", self._NO_VALUE)
        if setstate is not self._NO_VALUE:
            cast("Any", setstate)(state)
            return

        slotstate = None
        if isinstance(state, tuple) and len(state) == 2:
            state, slotstate = state
        if state:
            inst_dict = inst.__dict__
            intern = sys.intern
            for key, value in state.items():
                if type(key) is str:
                    inst_dict[intern(key)] = value
                else:
                    inst_dict[key] = value
        if slotstate:
            for key, value in slotstate.items():
                setattr(inst, key, value)


_LegacyNDArrayBackedUnpickler.dispatch = pickle_compat.Unpickler.dispatch.copy()
_LegacyNDArrayBackedUnpickler.dispatch[pickle.BUILD[0]] = (
    _LegacyNDArrayBackedUnpickler.load_build
)


# Shared by every CacheStorage, so versions never collide across instances.
_WRITE_IDS = itertools.count()
# Re-dating is optional, so these just keep the old date. Unlike
# get._UNWRITABLE_CACHE_ERRNOS this includes EACCES and EPERM: utime with
# explicit times needs to own the file, not only to be able to write it.
_UNDATABLE_CACHE_ERRNOS = frozenset({errno.EROFS, errno.EACCES, errno.EPERM})


def _known_expiry(
    storage: CacheStorage | FileStorage, name: str
) -> datetime.datetime | None:
    record = storage._published_expiries.get(name)
    if record is None or record[0] != storage.cache_version(name):
        return None
    return datetime.datetime.fromtimestamp(record[1], tz=datetime.timezone.utc)


class CacheStorage:
    _publications: dict

    def __init__(self) -> None:
        """將歷史資料儲存於快取中

        Examples:
            欲切換成以檔案方式儲存，可以用以下之方式：

            ``` py
            from finlab import data
            data.set_storage(data.CacheStorage())
            close = data.get('price:收盤價')
            ```

            可以直接調閱快取資料：

            ``` py
            close = data._storage._cache['price:收盤價']
            ```
        """

        self._cache: dict[str, pd.DataFrame] = {}
        self._published_expiries: dict[str, tuple[object, int]] = {}
        self._cache_time: dict[str, datetime.datetime] = {}
        self._writes: dict[str, int] = {}

    @staticmethod
    def now() -> datetime.datetime:
        return datetime.datetime.now(tz=datetime.timezone.utc)

    def set_dataframe(
        self, name: str, df: pd.DataFrame, revision: datetime.datetime | None = None
    ) -> None:
        self._cache[name] = df
        self.set_revision(name, revision or self.now())

    def set_revision(self, name: str, revision: datetime.datetime) -> None:
        """Date the cached frame at *revision*."""
        self._cache_time[name] = revision
        self._writes[name] = next(_WRITE_IDS)

    def get_time_created(self, name: str) -> datetime.datetime | None:
        if name not in self._cache or name not in self._cache_time:
            return None

        return self._cache_time[name]

    def get_time_expired(self, name: str) -> datetime.datetime | None:
        """Return the published expiry known for the cached version read, if any."""
        return _known_expiry(self, name)

    def cache_version(self, name: str) -> int | None:
        """Identifies the cached frame; changes on every write, even at the same revision."""
        return self._writes.get(name) if name in self._cache else None

    def get_dataframe(
        self, name: str, use_cache: bool | None = None
    ) -> pd.DataFrame | None:
        # not exists
        if name not in self._cache or name not in self._cache_time:
            return None

        return self._cache[name]

    def read_dataframe_date_range(
        self, name: str, start: pd.Timestamp | None, end: pd.Timestamp | None
    ) -> pd.DataFrame | None:
        """Return in-cache rows with ``date`` in ``[start, end]`` (both inclusive).

        The whole frame already lives in memory here, so there is no memory win
        over a full read; the filter is applied for API parity with
        :class:`FileStorage`.
        """
        df = self.get_dataframe(name)
        if df is None:
            return None
        return feather_io.filter_frame_date_range(df, start, end)

    def clear(self) -> None:
        """Remove all in-memory data and timestamp metadata."""
        self._cache.clear()
        self._cache_time.clear()
        self._writes.clear()
        self._published_expiries.clear()

    def release_memory(self) -> None:
        """Release cached data in RAM; with no disk copy, this clears everything."""
        self.clear()


class FileStorage:
    _publications: dict
    _FEATHER_SUFFIX: ClassVar[str] = ".feather"
    _LEGACY_PICKLE_SUFFIX: ClassVar[str] = ".pickle"
    _DATA_FILE_SUFFIXES: ClassVar[tuple[str, ...]] = (
        _FEATHER_SUFFIX,
        _LEGACY_PICKLE_SUFFIX,
    )
    _GZIP_MAGIC: ClassVar[bytes] = b"\x1f\x8b"

    def __init__(self, path: str | None = None, use_cache: bool = True) -> None:
        """將歷史資料儲存於檔案中

        Args:
              path (str): 資料儲存的路徑
              use_cache (bool): 是否額外使用快取，將資料複製一份到記憶體中。

        Examples:
            欲切換成以檔案方式儲存，可以用以下之方式：

            ``` py
            from finlab import data
            data.set_storage(data.FileStorage())
            close = data.get('price:收盤價')
            ```

            可以在本地端的 `./finlab_db/price#收盤價.feather` 中，看到下載的資料，
            可以使用 `pandas.read_feather` 調閱歷史資料：
            ``` py
            import pandas as pd
            close = pd.read_feather('finlab_db/price#收盤價.feather')
            ```
        """
        if path is None:
            path = finlab.utils.get_tmp_dir()

        self._path: str = path
        self._cache: dict[str, pd.DataFrame] = {}
        self._published_expiries: dict[str, tuple[object, int]] = {}
        self.use_cache: bool = use_cache
        # Identity of the bytes last read or written for each dataset.
        self._loaded_from: dict[str, tuple[int, int, int]] = {}

        if not os.path.isdir(path):
            os.mkdir(path)

    @staticmethod
    def _file_identity(file_path: str) -> tuple[int, int, int]:
        """Changes whenever the file is replaced, even by one dated the same:
        mtimes are published revisions, not write times."""
        stat = os.stat(file_path)
        return stat.st_ino, stat.st_mtime_ns, stat.st_size

    @staticmethod
    def _lock_path(file_path: str) -> str:
        return file_path + ".lock"

    def _data_file_path(self, name: str, suffix: str) -> str:
        return os.path.join(self._path, name.replace(":", "#") + suffix)

    def _existing_data_file_path(self, name: str) -> str | None:
        existing = [
            p
            for p in (self._data_file_path(name, s) for s in self._DATA_FILE_SUFFIXES)
            if os.path.isfile(p)
        ]
        if not existing:
            return None
        # An older finlab writing legacy .pickle alongside our .feather (or a
        # failed legacy cleanup) leaves both files behind and causes stale reads.
        # Keep only the freshest write so the next read can't lose ground.
        if len(existing) > 1:
            existing.sort(key=os.path.getmtime, reverse=True)
            for stale in existing[1:]:
                try:
                    os.remove(stale)
                except OSError:
                    logger.warning("failed to remove stale data file: %s", stale)
        return existing[0]

    @classmethod
    def _is_legacy_pickle_data_file(cls, file_path: str) -> bool:
        return file_path.endswith(cls._LEGACY_PICKLE_SUFFIX)

    @staticmethod
    def _wrap_local_read_error(name: str, file_path: str, read_fn: Any) -> Any:
        try:
            return read_fn()
        except LocalDataReadError:
            raise
        except Exception as exc:
            raise LocalDataReadError(name, file_path) from exc

    @classmethod
    def _read_legacy_pickle_dataframe(cls, file_path: str) -> pd.DataFrame:
        """Read a legacy FileStorage dataframe cache.

        Older FileStorage versions wrote pandas pickles, sometimes gzip-compressed,
        while keeping the `.pickle` suffix. Keep all data-pickle compatibility here
        so new storage paths stay feather-only.
        """
        with open(file_path, "rb") as f:
            is_gzip = f.read(len(cls._GZIP_MAGIC)) == cls._GZIP_MAGIC

        compression = "gzip" if is_gzip else None
        try:
            df = pd.read_pickle(file_path, compression=compression)
        except NotImplementedError as exc:
            df = cls._read_legacy_pickle_dataframe_with_ndarray_compat(
                file_path,
                compression=compression,
                original_error=exc,
            )
        if not isinstance(df, pd.DataFrame):
            raise TypeError(f"Legacy pickle cache is not a DataFrame: {file_path}")
        return df

    @classmethod
    def _read_legacy_pickle_dataframe_with_ndarray_compat(
        cls,
        file_path: str,
        *,
        compression: str | None,
        original_error: NotImplementedError,
    ) -> pd.DataFrame:
        """Retry old pandas pickles with legacy datetime/timedelta backing state.

        Some legacy pandas pickles store NDArrayBacked datetime/timedelta state
        as ``(dtype, values)``. Pandas 2.3 on Pyodide Python 3.13 expects the
        newer three-part state and rejects the old tuple during unpickle.
        Normalize only this narrow state format while reading legacy caches.
        """
        try:
            opener = gzip.open if compression == "gzip" else open
            with opener(file_path, "rb") as f:
                return _LegacyNDArrayBackedUnpickler(
                    f,
                    normalize_state=cls._normalize_legacy_ndarray_backed_state,
                ).load()
        except Exception as exc:
            raise original_error from exc

    @staticmethod
    def _normalize_legacy_ndarray_backed_state(state: object) -> object:
        if not isinstance(state, tuple) or len(state) not in (2, 3):
            return state

        dtype = state[0]
        values = state[1]
        if getattr(dtype, "kind", None) not in ("M", "m"):
            return state
        if getattr(values, "ndim", None) != 2 or 1 not in values.shape:
            return state

        if len(state) == 2:
            return (dtype, values, {})
        return state

    def get_dataframe_row_count(self, name: str) -> int | None:
        """Return the local dataframe row count."""
        file_path = self._existing_data_file_path(name)
        if file_path is None:
            return None

        def read_row_count() -> int | None:
            with self._file_lock(file_path, exclusive=False):
                if not os.path.isfile(file_path):
                    return None
                if self._is_legacy_pickle_data_file(file_path):
                    return len(self._read_legacy_pickle_dataframe(file_path))
                return self._read_feather_row_count(file_path)

        return self._wrap_local_read_error(name, file_path, read_row_count)

    def get_dataframe_index(self, name: str) -> pd.Index | None:
        """Return the local dataframe index."""
        file_path = self._existing_data_file_path(name)
        if file_path is None:
            return None

        def read_index() -> pd.Index | None:
            with self._file_lock(file_path, exclusive=False):
                if not os.path.isfile(file_path):
                    return None
                if self._is_legacy_pickle_data_file(file_path):
                    df = self._read_legacy_pickle_dataframe(file_path)
                    return self._index_from_dataframe(name, df)
                return self._read_feather_index(file_path, dataset=name)

        return self._wrap_local_read_error(name, file_path, read_index)

    @staticmethod
    def _read_feather_row_count(file_path: str) -> int:
        with pa.memory_map(file_path, "r") as source:
            reader = pa.ipc.open_file(source)
            return sum(
                reader.get_batch(i).num_rows for i in range(reader.num_record_batches)
            )

    @staticmethod
    def _read_pandas_feather_metadata(schema: pa.Schema) -> dict[str, Any]:
        raw = (schema.metadata or {}).get(b"pandas")
        if raw is None:
            return {}
        return json.loads(raw.decode())

    @staticmethod
    def _range_index_from_metadata(
        index_columns: list[object],
    ) -> pd.RangeIndex | None:
        if len(index_columns) != 1 or not isinstance(index_columns[0], dict):
            return None
        metadata = index_columns[0]
        if metadata.get("kind") != "range":
            return None
        return pd.RangeIndex(
            start=int(metadata.get("start", 0)),
            stop=int(metadata.get("stop", 0)),
            step=int(metadata.get("step", 1)),
            name=metadata.get("name"),
        )

    @staticmethod
    def _raw_index_columns(dataset: str, column_names: list[str]) -> list[str]:
        if ":" not in dataset:
            return []
        id_col = next(
            (column for column in ("symbol", "stock_id") if column in column_names),
            None,
        )
        if id_col is not None and "date" in column_names:
            return [id_col, "date"]
        if "date" in column_names:
            return ["date"]
        if id_col is not None:
            return [id_col]
        return []

    @classmethod
    def _index_from_dataframe(cls, dataset: str, df: pd.DataFrame) -> pd.Index:
        column_names = [column for column in df.columns if isinstance(column, str)]
        raw_index_columns = cls._raw_index_columns(dataset, column_names)
        if raw_index_columns:
            return df.set_index(raw_index_columns).index
        return df.index

    @classmethod
    def _read_feather_index(cls, file_path: str, *, dataset: str) -> pd.Index:
        with pa.memory_map(file_path, "r") as source:
            reader = pa.ipc.open_file(source)
            schema = reader.schema
            column_names = schema.names
            pandas_metadata = cls._read_pandas_feather_metadata(schema)

        index_columns = pandas_metadata.get("index_columns", [])
        if not isinstance(index_columns, list):
            index_columns = []

        range_index = cls._range_index_from_metadata(index_columns)
        stored_index_columns = [
            column
            for column in index_columns
            if isinstance(column, str) and column in column_names
        ]
        if stored_index_columns:
            return feather_io.read_frame_from_path(
                file_path, stored_index_columns
            ).index

        raw_index_columns = cls._raw_index_columns(dataset, column_names)
        if raw_index_columns:
            frame = feather_io.read_frame_from_path(file_path, raw_index_columns)
            return frame.set_index(raw_index_columns).index

        if range_index is not None:
            return range_index
        return pd.RangeIndex(cls._read_feather_row_count(file_path))

    def _remove_data_file(self, name: str, suffix: str) -> None:
        file_path = self._data_file_path(name, suffix)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)
        except OSError:
            logger.warning(f"failed to remove stale data file: {file_path}")

    @staticmethod
    def _acquire_lock(lock_file: IO[bytes], exclusive: bool) -> None:
        if fcntl is not None:
            mode = fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH
            fcntl.flock(lock_file.fileno(), mode)
            return
        if msvcrt is not None:
            # Lock 1 byte for coarse cross-process synchronization.
            mode = msvcrt.LK_LOCK if exclusive else msvcrt.LK_RLCK
            lock_file.seek(0)
            msvcrt.locking(lock_file.fileno(), mode, 1)
            return

    @staticmethod
    def _release_lock(lock_file: IO[bytes]) -> None:
        if fcntl is not None:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
            return
        if msvcrt is not None:
            lock_file.seek(0)
            msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
            return

    @contextmanager
    def _file_lock(
        self, target_file_path: str, exclusive: bool
    ) -> Generator[None, None, None]:
        lock_path = self._lock_path(target_file_path)
        with open(lock_path, "a+b") as lock_file:
            self._acquire_lock(lock_file, exclusive=exclusive)
            try:
                yield
            finally:
                self._release_lock(lock_file)

    def _read_dataframe_with_shared_lock(
        self, file_path: str
    ) -> tuple[Any, tuple[int, int, int] | None]:
        with self._file_lock(file_path, exclusive=False):
            if not os.path.isfile(file_path):
                return None, None
            if self._is_legacy_pickle_data_file(file_path):
                ret = self._read_legacy_pickle_dataframe(file_path)
            else:
                ret = feather_io.read_frame_from_path(file_path)
            return ret, self._file_identity(file_path)

    def _record_data_file_write(self, name: str) -> None:
        self._cache.pop(name, None)
        self._loaded_from[name] = self._file_identity(
            self._data_file_path(name, self._FEATHER_SUFFIX)
        )
        self._remove_data_file(name, self._LEGACY_PICKLE_SUFFIX)

    def set_dataframe(
        self, name: str, df: pd.DataFrame, revision: datetime.datetime | None = None
    ) -> None:
        self._persist_feather(
            name, functools.partial(feather_io.write_frame, df), revision=revision
        )

    def has_feather_cache(self, name: str) -> bool:
        """Return whether ``name`` has a Feather (non-legacy) cache on disk."""
        file_path = self._existing_data_file_path(name)
        return file_path is not None and not self._is_legacy_pickle_data_file(file_path)

    def merge_recent_delta(
        self,
        name: str,
        short_df: pd.DataFrame,
        expected_hash: str,
        revision: datetime.datetime | None = None,
    ) -> bool:
        """Apply a ``.recent`` delta to the cached Feather via a streaming merge.

        The stored table is walked one Arrow record batch at a time, so peak
        memory is ~= one batch + the delta instead of the three full-table
        copies the in-memory merge materialises. Returns ``False`` (leaving the
        existing cache untouched) when the streamed hash does not match
        ``expected_hash``, so the caller can fall back to a full download. The
        replacement is atomic (``os.replace``).
        """
        file_path = self._existing_data_file_path(name)
        if file_path is None or self._is_legacy_pickle_data_file(file_path):
            return False

        def write_merged(tmp_path: str) -> None:
            if not stream_merge_recent_feather(
                file_path, tmp_path, short_df, expected_hash
            ):
                raise _HashMismatchError

        with self._file_lock(file_path, exclusive=True):
            if not os.path.isfile(file_path):
                return False
            try:
                finlab.utils.atomic_replace(file_path, write_merged, revision)
            except _HashMismatchError:
                return False
            self._record_data_file_write(name)
        return True

    def set_dataframe_bytes(
        self,
        name: str,
        payload: bytes,
        revision: datetime.datetime | None = None,
    ) -> None:
        """Persist a feather payload verbatim, skipping pandas re-encoding."""

        def write_payload(tmp_path: str) -> None:
            with open(tmp_path, "wb") as f:
                f.write(payload)

        self._persist_feather(name, write_payload, revision=revision)

    def _persist_feather(
        self,
        name: str,
        write_fn: Callable[[str], Any],
        revision: datetime.datetime | None = None,
    ) -> None:
        file_path = self._data_file_path(name, ".feather")
        with self._file_lock(file_path, exclusive=True):
            try:
                finlab.utils.atomic_replace(file_path, write_fn, revision)
            except OSError as e:
                error_msg = f"{name} save dataframe fail. Path: {file_path}. Error: {e}"
                logger.warning(error_msg)
                print(f"Warning: {error_msg}")
                print(
                    "Please check disk permission, available space, or filename encoding issues."
                )
                raise

            if not os.path.isfile(file_path):
                error_msg = (
                    f"{name} save dataframe fail - file not created at {file_path}"
                )
                logger.warning(error_msg)
                print(f"Warning: {error_msg}")
                raise FileNotFoundError(error_msg)

            self._record_data_file_write(name)

    def get_time_created(self, name: str) -> datetime.datetime | None:
        """The cache's revision: its file mtime, stamped by the last download."""
        file_path = self._existing_data_file_path(name)
        if file_path is None:
            return None

        return datetime.datetime.fromtimestamp(
            os.path.getmtime(file_path), tz=datetime.timezone.utc
        )

    def get_time_expired(self, name: str) -> datetime.datetime | None:
        """Return the published expiry known for the cached version read, if any."""
        return _known_expiry(self, name)

    def cache_version(self, name: str) -> tuple[int, int, int] | None:
        """Identifies the bytes this storage last read or wrote, even across
        replacements dated the same revision; else the file on disk."""
        if name in self._loaded_from:
            return self._loaded_from[name]
        file_path = self._existing_data_file_path(name)
        return None if file_path is None else self._file_identity(file_path)

    def set_revision(self, name: str, revision: datetime.datetime) -> None:
        """Re-date the cache file at a revision whose bytes it already holds.

        A file another process replaced since this one was loaded keeps its date.
        Read-only caches keep their existing date; these bytes remain usable.
        """
        file_path = self._existing_data_file_path(name)
        if file_path is None:
            return
        try:
            with self._file_lock(file_path, exclusive=True):
                loaded_from = self._loaded_from.get(name)
                if loaded_from is not None and loaded_from != self._file_identity(
                    file_path
                ):
                    return
                os.utime(file_path, (revision.timestamp(), revision.timestamp()))
                if loaded_from is not None:
                    self._loaded_from[name] = self._file_identity(file_path)
        except OSError as exc:
            if exc.errno not in _UNDATABLE_CACHE_ERRNOS:
                raise
            logger.debug("Cannot update revision for read-only cache: %s", name)

    def get_dataframe(
        self, name: str, use_cache: bool | None = None
    ) -> pd.DataFrame | None:
        should_use_cache = self.use_cache if use_cache is None else use_cache
        file_path = self._existing_data_file_path(name)

        # If we have a cached version, check whether another process replaced the file
        if should_use_cache and name in self._cache:
            if file_path is None:
                return None
            if self._file_identity(file_path) != self._loaded_from[name]:
                logger.debug(f"{name} file on disk changed, reloading from disk")
                del self._cache[name]
            else:
                # Cache is still valid
                return self._cache[name]

        if file_path is None:
            return None

        # Load from disk under shared lock to avoid partially-read files during writes.
        ret, loaded_from = self._wrap_local_read_error(
            name,
            file_path,
            lambda: self._read_dataframe_with_shared_lock(file_path),
        )
        if ret is None:
            return None
        if loaded_from is None:
            raise RuntimeError(f"Missing identity for loaded cache file: {file_path}")
        self._loaded_from[name] = loaded_from
        if should_use_cache:
            self._cache[name] = ret
        return ret

    def read_dataframe_date_range(
        self, name: str, start: pd.Timestamp | None, end: pd.Timestamp | None
    ) -> pd.DataFrame | None:
        """Read on-disk rows with ``date`` in ``[start, end]`` (both inclusive).

        The date bounds are pushed down to the Arrow layer for Feather V2 caches,
        so only in-range rows are decoded and the full table is never
        materialised. Legacy pickle caches have no columnar pushdown, so they are
        read fully and then filtered. Bypasses the in-memory ``_cache`` on purpose
        so a slice read never pins the whole table in memory.
        """
        file_path = self._existing_data_file_path(name)
        if file_path is None:
            return None

        def read_range() -> pd.DataFrame | None:
            with self._file_lock(file_path, exclusive=False):
                if not os.path.isfile(file_path):
                    return None
                if self._is_legacy_pickle_data_file(file_path):
                    df = self._read_legacy_pickle_dataframe(file_path)
                    return feather_io.filter_frame_date_range(df, start, end)
                return feather_io.read_frame_date_range(file_path, start, end)

        try:
            return self._wrap_local_read_error(name, file_path, read_range)
        except LocalDataReadError as exc:
            # A missing 'date' column is an API/usage error, not a corrupt cache;
            # surface it to the caller unchanged instead of as a read failure.
            if isinstance(exc.__cause__, feather_io.DateColumnMissingError):
                raise exc.__cause__ from None
            raise

    def release_memory(self) -> None:
        """Release the in-memory DataFrame cache, keeping files and their revisions."""
        self._cache.clear()

    def clear(self) -> None:
        self._published_expiries.clear()
        folder_path = self._path
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except OSError as e:
                print(f"Failed to delete {file_path}. Reason: {e}")

    def diagnose(self, dataset: str | None = None) -> None:
        """診斷本地儲存狀態

        Args:
            dataset (str, optional): 指定要檢查的資料集名稱，例如 'price:收盤價'。如果不指定，則列出所有本地資料。

        Examples:
            ``` py
            from finlab import data
            data._storage.diagnose()  # 列出所有本地資料
            data._storage.diagnose('price:收盤價')  # 檢查特定資料集
            ```
        """
        print(f"Storage path: {self._path}")
        print(f"Path exists: {os.path.isdir(self._path)}")

        if dataset:
            file_path = self._existing_data_file_path(dataset)
            expected_file = self._data_file_path(dataset, ".feather")
            print(f"\nDataset: {dataset}")
            print(f"Expected file: {expected_file}")
            print(f"File exists: {file_path is not None}")
            if file_path is not None:
                print(f"Actual file: {file_path}")
                size_mb = os.path.getsize(file_path) / (1024 * 1024)
                mtime = datetime.datetime.fromtimestamp(os.path.getmtime(file_path))
                print(f"File size: {size_mb:.2f} MB")
                print(f"Last modified: {mtime}")
            if dataset in self._cache:
                print(f"In memory cache: Yes ({len(self._cache[dataset])} rows)")
            else:
                print("In memory cache: No")
        else:
            print("\nLocal data files:")
            data_files = [
                f
                for f in os.listdir(self._path)
                if f.endswith(self._DATA_FILE_SUFFIXES)
            ]
            if not data_files:
                print("  (No data files found)")
            for f in sorted(data_files)[:20]:  # Show first 20 files
                file_path = os.path.join(self._path, f)
                size_mb = os.path.getsize(file_path) / (1024 * 1024)
                dataset_name = (
                    f.replace("#", ":")
                    .removesuffix(self._FEATHER_SUFFIX)
                    .removesuffix(self._LEGACY_PICKLE_SUFFIX)
                )
                print(f"  {dataset_name}: {size_mb:.2f} MB")
            if len(data_files) > 20:
                print(f"  ... and {len(data_files) - 20} more files")
            print(f"\nTotal: {len(data_files)} data files")
