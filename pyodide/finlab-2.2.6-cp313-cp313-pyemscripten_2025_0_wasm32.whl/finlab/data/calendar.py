"""Small public fdata calendar; parsed once, refreshed at most every three hours."""

from __future__ import annotations

import datetime as dt
import threading
import time

from finlab.session_calendar import UTC, CalendarUnavailable, SessionCalendar

from .auth import get_public_json

CALENDAR_URL = "https://r2.finlab.finance/market-calendar/tw/v1/latest.json"
# Holidays are announced a year ahead and a cached snapshot stays usable while
# it lists future sessions, so a few refreshes a day are enough.
REFRESH_SECONDS = 3 * 60 * 60
# After a failed download: retry soon when nothing is cached, but keep using a
# cached snapshot for a while instead of blocking every caller on the network.
RETRY_WITHOUT_SNAPSHOT_SECONDS = 30
RETRY_WITH_SNAPSHOT_SECONDS = 5 * 60
_snapshot: SessionCalendar | None = None
_refresh_at = 0.0
_lock = threading.RLock()


def get_calendar(
    market: str = "tw", *, refresh: bool = False, now: dt.datetime | None = None
) -> SessionCalendar:
    """Get announced TW trading dates, including future holidays.

    No price data, login, or download quota is needed. A snapshot past its
    expires_at stays usable while it lists future sessions; unannounced years
    raise CalendarUnavailable instead of guessing weekdays. ``now`` allows
    deterministic evaluation with an explicitly injected snapshot.
    """
    global _snapshot, _refresh_at
    if market not in {"tw", "tw_stock"}:
        raise CalendarUnavailable("Only the TW calendar is currently published")
    now = now or dt.datetime.now(UTC)
    with _lock:
        if not refresh and _snapshot is None and time.monotonic() < _refresh_at:
            raise CalendarUnavailable("TW calendar retry is temporarily deferred")
        if refresh or _snapshot is None or time.monotonic() >= _refresh_at:
            try:
                candidate = SessionCalendar(get_public_json(CALENDAR_URL))
                candidate.require_usable(now)
                # A CDN may still serve an older copy than the cached one.
                if _snapshot is None or candidate.checked_at >= _snapshot.checked_at:
                    _snapshot = candidate
                _refresh_at = time.monotonic() + REFRESH_SECONDS
            except Exception as exc:
                if _snapshot is None:
                    _refresh_at = time.monotonic() + RETRY_WITHOUT_SNAPSHOT_SECONDS
                    raise CalendarUnavailable(
                        "TW calendar could not be downloaded"
                    ) from exc
                _refresh_at = time.monotonic() + RETRY_WITH_SNAPSHOT_SECONDS
        _snapshot.require_usable(now)
        return _snapshot
