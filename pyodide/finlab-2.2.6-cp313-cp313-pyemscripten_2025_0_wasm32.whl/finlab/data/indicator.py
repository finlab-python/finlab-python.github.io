"""Technical indicator computation: ``data.indicator()``."""

from __future__ import annotations

import contextlib
import json
import logging
import sys
from functools import reduce
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from typing import Protocol

    class _TalibAbstract(Protocol):
        input_names: dict[str, str | list[str]]


import numpy as np
import pandas as pd

import finlab.dataframe
import finlab.utils
from finlab import config

logger = logging.getLogger(__name__)

__all__ = [
    "get_strategies",
    "indicator",
]


# ---------------------------------------------------------------------------
# Indicator
# ---------------------------------------------------------------------------


def get_input_args(attr: _TalibAbstract) -> list[str]:
    input_names = attr.input_names
    refine_input_names: list[str] = []
    for key, val in input_names.items():
        if "price" in key:
            if isinstance(val, list):
                refine_input_names += val
            elif isinstance(val, str):
                refine_input_names.append(val)

    return refine_input_names


_MISSING_PACKAGE_MESSAGE = (
    "data.indicator() needs a technical-indicator package: TA-Lib or pandas_ta "
    "(either one).\n"
    "  pip install TA-Lib      # upper-case names, e.g. data.indicator('RSI')\n"
    "  pip install pandas-ta   # lower-case names, e.g. data.indicator('supertrend')\n"
    "Restart the Python kernel after installing.\n"
    "data.indicator() 需要技術指標套件 TA-Lib 或 pandas_ta（擇一安裝），"
    "安裝後請重新啟動 Python kernel。"
)

_MISSING_PACKAGE_MESSAGE_BROWSER = (
    "data.indicator() needs TA-Lib, which is not loaded in this browser Python "
    "(Pyodide) session, and pip cannot install it here.\n"
    "FinLab Studio preloads TA-Lib: reload the page to restart the runtime, then "
    "use TA-Lib names such as data.indicator('RSI'). pandas_ta is not preloaded "
    "in Studio.\n"
    "瀏覽器版 Python 無法用 pip 安裝 TA-Lib。FinLab Studio 已預載 TA-Lib，"
    "請重新整理頁面後，使用 TA-Lib 指標名稱（例如 'RSI'）。"
)


def _talib_indicator(indname: str) -> tuple[Any, bool]:
    """Return (TA-Lib function or None, whether TA-Lib is installed)."""
    try:
        from talib import abstract
    except ImportError:
        return None, False
    if getattr(abstract, indname, None) is None:
        return None, True
    # Module-level functions keep the arguments of a failed call; use a fresh one.
    return cast("Any", abstract).Function(indname), True


def _pandas_ta_indicator(indname: str) -> tuple[Any, bool]:
    """Return (pandas_ta wrapper or None, whether pandas_ta is installed)."""
    try:
        import pandas_ta  # noqa: F401
    except ImportError:
        return None, False
    if not hasattr(pd.DataFrame().ta, indname):
        return None, True

    def _pandas_ta_wrapper(df: pd.DataFrame, **kwargs: Any) -> pd.DataFrame:
        return getattr(df.ta, indname)(**kwargs)

    return _pandas_ta_wrapper, True


def _unknown_indicator_message(
    indname: str, has_talib: bool, has_pandas_ta: bool
) -> str:
    installed = [
        name
        for name, present in (("TA-Lib", has_talib), ("pandas_ta", has_pandas_ta))
        if present
    ]
    message = f"Indicator {indname!r} is not provided by {' or '.join(installed)}."
    upper, lower = indname.upper(), indname.lower()
    if has_talib and upper != indname and _talib_indicator(upper)[0] is not None:
        message += f" Did you mean {upper!r}?"
    elif (
        has_pandas_ta
        and lower != indname
        and _pandas_ta_indicator(lower)[0] is not None
    ):
        message += f" Did you mean {lower!r}?"
    return (
        message + " TA-Lib names are upper-case (e.g. 'RSI', 'STOCH'); "
        "pandas_ta names are lower-case (e.g. 'supertrend')."
    )


def _detect_indicator_package(indname: str) -> tuple[str, Any]:
    """Find *indname* in TA-Lib first, then pandas_ta.

    Raises:
        ImportError: Neither package is installed; says what to install.
        ValueError: The installed packages do not provide *indname*.
    """
    talib_fn, has_talib = _talib_indicator(indname)
    if talib_fn is not None:
        return "talib", talib_fn

    pandas_ta_fn, has_pandas_ta = _pandas_ta_indicator(indname)
    if pandas_ta_fn is not None:
        return "pandas_ta", pandas_ta_fn

    if not (has_talib or has_pandas_ta):
        in_browser = sys.platform == "emscripten"
        raise ImportError(
            _MISSING_PACKAGE_MESSAGE_BROWSER if in_browser else _MISSING_PACKAGE_MESSAGE
        )
    raise ValueError(_unknown_indicator_message(indname, has_talib, has_pandas_ta))


def _check_talib_kwargs(
    indname: str, attr: Any, kwargs: dict[str, Any], *, strict: bool = False
) -> None:
    """Reject keywords a TA-Lib function would silently ignore.

    TA-Lib's abstract API drops unknown keywords without an error, so a typo
    such as ``timperiod`` or ``adjusted=True`` would run with the defaults.
    """
    if strict and (selectors := sorted(set(kwargs) & set(attr.input_names))):
        raise ValueError(
            f"`data.indicator({indname!r}, strict=True)` does not support TA-Lib "
            f"input selectors: {', '.join(selectors)}. "
            "Use the indicator's default price inputs."
        )
    accepted = set(attr.parameters) | set(attr.input_names)
    unknown = sorted(set(kwargs) - accepted)
    if not unknown:
        return
    message = (
        f"`data.indicator({indname!r})` got {', '.join(unknown)}, which TA-Lib "
        f"{indname} does not use; its parameters are: "
        f"{', '.join(attr.parameters) or '(none)'}."
    )
    if any(name.startswith("adj") for name in unknown):
        message += " Use `adjust_price=True` to calculate with adjusted prices."
    raise ValueError(message)


def _align_price_shapes(
    close: pd.DataFrame,
    open_: pd.DataFrame,
    high: pd.DataFrame,
    low: pd.DataFrame,
    volume: pd.DataFrame,
    indname: str,
    market: Any,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Intersect index/columns when OHLCV shapes differ."""
    dfs = [close, open_, high, low, volume]
    if all(close.shape == df.shape for df in dfs[1:]):
        return close, open_, high, low, volume

    latest_date = min(df.index[-1] for df in dfs)
    logger.warning(
        f"indicator: {indname} market: {market} has different end date, "
        f"cut to {latest_date}. This is due to server updating data. "
        "If you want to get the latest data, please try again 3 minutes later."
    )
    common_idx = reduce(lambda a, b: a.intersection(b), [df.index for df in dfs])
    common_cols = reduce(lambda a, b: a.intersection(b), [df.columns for df in dfs])

    return tuple(df.loc[common_idx, common_cols] for df in dfs)  # type: ignore[return-value]


def _compute_stock_indicator(
    package: str,
    attr: Any,
    indname: str,
    prices: dict[str, pd.Series],
    kwargs: dict[str, Any],
) -> dict[Any, Any]:
    """Run the indicator for one stock and normalize the output to a dict."""
    if package == "pandas_ta":
        result = attr(pd.DataFrame(prices), **kwargs)
    elif package == "talib":
        abstract_input = get_input_args(attr)

        if indname == "OBV":
            abstract_input = ["close", "volume"]
        if indname == "BETA":
            abstract_input = ["high", "low"]
        if isinstance(abstract_input, str):
            abstract_input = [abstract_input]
        result = attr(*[prices[k] for k in abstract_input], **kwargs)
    else:
        raise RuntimeError("Cannot determine technical package from indname")

    if isinstance(result, list):
        result = dict(enumerate(result))
    if isinstance(result, np.ndarray):
        result = {0: result}
    if isinstance(result, pd.Series):
        result = {0: result.values}
    if isinstance(result, pd.DataFrame):
        result = {i: series.values for i, series in result.items()}

    return result


def indicator(
    indname: str,
    adjust_price: bool = False,
    resample: str = "D",
    *,
    strict: bool = False,
    **kwargs: Any,
) -> pd.DataFrame | tuple[pd.DataFrame, ...]:
    """支援 Talib 和 pandas_ta 上百種技術指標，計算 2000 檔股票、10年的所有資訊。

    在使用這個函式前，需要安裝計算技術指標的 Packages

    * [Ta-Lib](https://github.com/mrjbq7/ta-lib)
    * [Pandas-ta](https://github.com/twopirllc/pandas-ta)

    Args:
        indname (str): 指標名稱，
            以 TA-Lib 舉例，例如 SMA, STOCH, RSI 等，可以參考 [talib 文件](https://mrjbq7.github.io/ta-lib/doc_index.html)。

            以 Pandas-ta 舉例，例如 supertrend, ssf 等，可以參考 [Pandas-ta 文件](https://twopirllc.github.io/pandas-ta/#indicators-by-category)。
        adjust_price (bool): 是否使用還原股價計算。
        resample (str): 技術指標價格週期，ex: `D` 代表日線, `W` 代表週線, `M` 代表月線。
        market (str): 市場選擇，ex: `TW_STOCK` 代表台股, `US_STOCK` 代表美股。
        strict (bool): 預設 False。True 時只接受 TA-Lib 的數值參數名稱，
            拒絕輸入價格 selector；pandas_ta 尚不支援，會拋出 NotImplementedError。
            例如 `data.indicator('RSI', strict=True, timeperiod=14)`。
            只檢查名稱，不保證參數在每種設定下都影響結果；參數值由 TA-Lib 檢查。
            無股票或全 NaN 時不執行指標計算。
        **kwargs (dict): 技術指標的參數設定，TA-Lib 中的 RSI 為例，調整項為計算週期 `timeperiod=14`。
    建議使用者可以先參考以下範例，並且搭配 talib官方文件，就可以掌握製作技術指標的方法了。
    """
    if "adj" in kwargs:
        adjust_price = kwargs.pop("adj")

    unsupported_price_kwargs = {
        "adj_open",
        "adj_high",
        "adj_low",
        "adj_close",
        "adj_volume",
    }.intersection(kwargs)
    if unsupported_price_kwargs:
        names = ", ".join(sorted(unsupported_price_kwargs))
        raise ValueError(
            f"`data.indicator()` does not accept {names}; "
            "use `adjust_price=True` to calculate indicators with adjusted prices."
        )

    if not isinstance(adjust_price, bool):
        usage_str = f"data.indicator({indname}, adjust_price={adjust_price}, resample={resample}, **kwargs)"
        example_str = 'k, d = data.indicator("STOCH", adjust_price=True, resample="D", fastk_period=9, slowk_period=3, slowd_period=3)'
        raise ValueError(
            f"`adjust_price` must be a bool, e.g. `True`, `False`. Usage: {usage_str}, Example: {example_str}"
        )

    package, attr = _detect_indicator_package(indname)
    if package == "talib":
        _check_talib_kwargs(
            indname,
            attr,
            {k: v for k, v in kwargs.items() if k != "market"},
            strict=strict,
        )
    elif strict:
        raise NotImplementedError(
            "`data.indicator(strict=True)` only supports TA-Lib keyword "
            "validation; pandas_ta kwargs are not verified."
        )

    if "market" in kwargs:
        market_name = kwargs.pop("market")
        from finlab.markets import get_market_by_name

        config.set_market(get_market_by_name(market_name.lower()))

    market = config.get_market()

    close = market.get_price("close", adj=adjust_price)
    open_ = market.get_price("open", adj=adjust_price)
    high = market.get_price("high", adj=adjust_price)
    low = market.get_price("low", adj=adjust_price)
    volume = market.get_price("volume", adj=adjust_price)

    close, open_, high, low, volume = _align_price_shapes(
        close, open_, high, low, volume, indname, market
    )

    if resample.upper() != "D":
        close = close.resample(resample).last()
        open_ = open_.resample(resample).first()
        high = high.resample(resample).max()
        low = low.resample(resample).min()
        volume = volume.resample(resample).sum()

    dfs: dict[str, dict[str, Any]] = {}
    default_output_columns: list[str] | None = None
    for key in close.columns:
        prices = {
            "open": open_[key].ffill(),
            "high": high[key].ffill(),
            "low": low[key].ffill(),
            "close": close[key].ffill(),
            "volume": volume[key].ffill(),
        }

        if prices["close"].iloc[-1] != prices["close"].iloc[-1]:
            continue

        s = _compute_stock_indicator(package, attr, indname, prices, kwargs)

        if default_output_columns is None:
            default_output_columns = list(s)

        for colname, series in s.items():
            dfs.setdefault(colname, {})[key] = series

    newdic: dict[str, pd.DataFrame] = {}
    for key, df in dfs.items():
        newdic[key] = pd.DataFrame(df, index=close.index)

    if default_output_columns is None:
        return finlab.dataframe.FinlabDataFrame(pd.DataFrame(index=close.index))

    ret = [newdic[n] for n in default_output_columns]
    ret = [d.apply(lambda s: pd.to_numeric(s, errors="coerce")) for d in ret]

    if len(ret) == 1:
        return finlab.dataframe.FinlabDataFrame(ret[0])

    return tuple([finlab.dataframe.FinlabDataFrame(df) for df in ret])


indicator_dynamic = cast("Any", indicator)
indicator_dynamic.us_stock = lambda *args, **kwargs: indicator(
    *args, **{**kwargs, "market": "US_STOCK"}
)
indicator_dynamic.tw_stock = lambda *args, **kwargs: indicator(
    *args, **{**kwargs, "market": "TW_STOCK"}
)


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------


def get_strategies(api_token: str | None = None) -> dict[str, Any] | str:
    """取得已上傳量化平台的策略回傳資料。

    可取得自己策略儀表板上的數據，例如每個策略的報酬率曲線、報酬率統計、夏普率、近期部位、近期換股日...，
    這些數據可以用來進行多策略彙整的應用喔！


    Args:
        api_token (str): 若未帶入finlab模組的api_token，會自動跳出[GUI](https://ai.finlab.tw/api_token/)頁面，
                         複製網頁內的api_token貼至輸入欄位即可。
    Returns:
        (dict): strategies data
    Response detail:

        ``` py
        {
          strategy1:{
            'asset_type': '',
            'drawdown_details': {
               '2015-06-04': {
                 'End': '2015-11-03',
                 'Length': 152,
                 'drawdown': -0.19879090089478024
                 },
                 ...
              },
            'fee_ratio': 0.000475,
            'last_trading_date': '2022-06-10',
            'last_updated': 'Sun, 03 Jul 2022 12:02:27 GMT',
            'ndays_return': {
              '1': -0.01132480035770611,
              '10': -0.0014737286933147464,
              '20': -0.06658015749110646,
              '5': -0.002292995729485159,
              '60': -0.010108700314771735
              },
            'next_trading_date': '2022-06-10',
            'positions': {
              '1413 宏洲': {
                'entry_date': '2022-05-10',
                'entry_price': 10.05,
                'exit_date': '',
                'next_weight': 0.1,
                'return': -0.010945273631840613,
                'status': '買進',
                'weight': 0.1479332345384493
                },
              'last_updated': 'Sun, 03 Jul 2022 12:02:27 GMT',
              'next_trading_date': '2022-06-10',
              'trade_at': 'open',
              'update_date': '2022-06-10'
              },
            'return_table': {
              '2014': {
                'Apr': 0.0,
                'Aug': 0.06315180932606546,
                'Dec': 0.0537589857541485,
                'Feb': 0.0,
                'Jan': 0.0,
                'Jul': 0.02937490104459939,
                'Jun': 0.01367930162104769,
                'Mar': 0.0,
                'May': 0.0,
                'Nov': -0.0014734320286596825,
                'Oct': -0.045082529665408266,
                'Sep': 0.04630906972509852,
                'YTD': 0.16626214846456966
                },
                ...
              },
            'returns': {
              'time': [
                '2014-06-10',
                '2014-06-11',
                '2014-06-12',
                ...
                ],
              'value': [
                100,
                99.9,
                100.2,
                ...
                ]
              },
            'stats': {
              'avg_down_month': -0.03304015302646822,
              'avg_drawdown': -0.0238021414698247,
              'avg_drawdown_days': 19.77952755905512,
              'avg_up_month': 0.05293384465715908,
              'cagr': 0.33236021285588846,
              'calmar': 1.65261094975066,
              'daily_kurt': 4.008888367138843,
              'daily_mean': 0.3090784769257415,
              'daily_sharpe': 1.747909002374217,
              'daily_skew': -0.6966018726321078,
              'daily_sortino': 2.8300677082214034,
              ...
              },
            'tax_ratio': 0.003,
            'trade_at': 'open',
            'update_date': '2022-06-10'
            },
          strategy2:{...},
          ...}
        ```
    """
    token_type = "api_token"
    if api_token is None:
        token_result = finlab.get_token()
        if isinstance(token_result, tuple):
            api_token, token_type = token_result
        else:
            api_token = token_result

    request_args: dict[str, str] = {}
    if token_type == "id_token":
        request_args["id_token"] = api_token
    else:
        request_args["api_token"] = api_token

    url = "https://asia-east2-fdata-299302.cloudfunctions.net/auth_get_strategies"
    response = finlab.utils.requests.get(url, request_args, timeout=300)
    status_code = response.status_code
    if status_code in {400, 401}:
        logger.error(
            "The authentication code is wrong or the account is not existed. "
            "Please input right authentication code or register account."
        )
        return {}
    with contextlib.suppress(json.JSONDecodeError, ValueError):
        return json.loads(response.text)

    return response.text
