"""Historical versions of a dataset: the object generations the server still retains.

Every publication of a dataset replaces its cloud object. The server deletes
a replaced generation once it has been replaced for 30 days and 10 newer ones
exist. The rule took effect on 2026-09-26; whatever the server still retains,
including older versions, can be listed (markets whose storage kept no old
versions start with the current one only).
``versions()`` lists what is retained, and
``data.get(..., as_of=...)`` / ``data.get(..., version=...)`` download one
generation exactly. A generation never changes, so its local copy never expires.
"""

from __future__ import annotations

import base64
import datetime
import hashlib
import uuid
import warnings
from typing import TYPE_CHECKING, Any, TypeVar

import numpy as np
import pandas as pd
import pyarrow as pa

from finlab.exceptions import DataError

from . import auth, context, feather_io
from .market import _get_bucket_for_dataset, _resolve_dataset
from .missing import equivalent_key_alias, redirect_warning_message

if TYPE_CHECKING:
    from collections.abc import Callable

__all__ = ["get_version", "select_version", "versions"]

_T = TypeVar("_T")

# Naive ``as_of`` values are read in Taiwan time for every market, like the
# publication schedules (``schedule_timezone``) the server reports.
AS_OF_TIMEZONE = "Asia/Taipei"
# pandas reads these as the local clock, which is not Taiwan time abroad.
_RELATIVE_TIMES = frozenset({"now", "today"})
# GCS generations are positive int64.
_MAX_GENERATION = 2**63 - 1
SCHEMA_VERSION = 1
_CACHE_PREFIX = "_version_v1_"
_TIME_COLUMNS = ("time_created", "time_replaced")
# Error codes meaning "no such object (or generation) under this name".
_NOT_FOUND_CODES = frozenset({"not_found", "version_not_found"})
# Tables whose published vintages fdata keeps permanently as their own datasets;
# the short-lived object history must not stand in for them.
_PERMANENT_VINTAGES = {
    "financial_statement": (
        "data.get('financial_statement_versions') lists the permanent vintages; "
        "fetch one with data.get(<its dataset column>)"
    ),
}


class _NotFound(DataError):
    """The server has no object (or no such generation) under the requested name."""


def _post(query: dict[str, Any]) -> dict[str, Any]:
    result = auth.post_signing_request("versions", query, "Dataset version")
    if "error" in result:
        code = result.get("code", "version_error")
        msg = f"{code}: {result['error']}"
        raise (_NotFound if code in _NOT_FOUND_CODES else DataError)(msg)
    if (
        result.get("schema_version") != SCHEMA_VERSION
        or result.get("blob_name") != query["blob_name"]
    ):
        msg = "Unsupported dataset version response schema or dataset"
        raise DataError(msg)
    return result


def _object(dataset: str) -> dict[str, str]:
    return {
        "bucket_name": _get_bucket_for_dataset(dataset),
        "blob_name": auth._dataset_to_blob(dataset),
    }


def _refuse_permanent_vintages(dataset: str) -> None:
    hint = _PERMANENT_VINTAGES.get(dataset.split(":", maxsplit=1)[0])
    if hint is not None:
        msg = f"{dataset} keeps permanent vintages: {hint}"
        raise ValueError(msg)


def _following_alias(dataset: str, action: Callable[[str], _T]) -> tuple[str, _T]:
    """``(dataset used, action(dataset))``, retrying once on a published equivalent key."""
    try:
        return dataset, action(dataset)
    except _NotFound:
        key_alias = equivalent_key_alias(dataset)
        if key_alias is None:
            raise
    warnings.warn(redirect_warning_message(key_alias), UserWarning, stacklevel=4)
    _refuse_permanent_vintages(key_alias.target)
    return key_alias.target, action(key_alias.target)


def _list(dataset: str) -> pd.DataFrame:
    result = _post({**_object(dataset), "mode": "list"})
    frame = pd.DataFrame(
        result["versions"],
        columns=["generation", *_TIME_COLUMNS, "size", "hash"],
    )
    for column in _TIME_COLUMNS:
        frame[column] = pd.to_datetime(frame[column], utc=True, format="ISO8601")
    frame.attrs["retention"] = result.get("retention")
    return frame


def versions(dataset: str) -> pd.DataFrame:
    """List the retained versions of ``dataset``, oldest first.

    Columns: ``generation`` (pass to ``data.get(version=...)``),
    ``time_created`` / ``time_replaced`` (UTC; the version was the published
    one in between, ``NaT`` = still published), ``size`` (bytes), ``hash``.
    Requires a paid data plan.
    """
    resolved = _resolve_dataset(dataset)
    _refuse_permanent_vintages(resolved)
    return _following_alias(resolved, _list)[1]


def _as_of_timestamp(as_of: Any) -> pd.Timestamp:
    if not isinstance(as_of, (str, datetime.date, np.datetime64)) or (
        isinstance(as_of, str) and as_of.strip().lower() in _RELATIVE_TIMES
    ):
        msg = f"as_of must be a date/time string or datetime, got {as_of!r}"
        raise ValueError(msg)
    stamp = pd.Timestamp(as_of)
    if pd.isna(stamp):
        msg = f"as_of is not a time: {as_of!r}"
        raise ValueError(msg)
    if stamp.tzinfo is None:
        stamp = stamp.tz_localize(AS_OF_TIMEZONE)
    return stamp


def select_version(listed: pd.DataFrame, as_of: Any) -> str:
    """Generation that was published at ``as_of`` (naive = Asia/Taipei; a bare date = 00:00)."""
    stamp = _as_of_timestamp(as_of)
    live = (listed["time_created"] <= stamp) & (
        listed["time_replaced"].isna() | (stamp < listed["time_replaced"])
    )
    if not live.any():
        earliest = listed["time_created"].min()
        msg = (
            f"No retained version was published at {stamp.isoformat()}; "
            f"the earliest retained version was published at {earliest}"
        )
        raise DataError(msg)
    return str(listed.loc[live, "generation"].iloc[-1])


def _canonical_generation(version: str | int) -> str:
    """``version`` as the server spells generations: ASCII digits, no leading zero."""
    text = str(version)
    if not (text.isascii() and text.isdigit()) or not 0 < int(text) <= _MAX_GENERATION:
        msg = f"version must be a generation from data.versions(), got {version!r}"
        raise ValueError(msg)
    return str(int(text))


def _verify(raw: bytes, signed: dict[str, Any], label: str) -> None:
    """Refuse bytes that differ from the signed generation in size or MD5."""
    md5 = signed.get("md5_hash")
    digest = base64.b64encode(hashlib.md5(raw).digest()).decode()
    if len(raw) != signed["size"] or (md5 is not None and digest != md5):
        msg = f"Download of {label} is incomplete or corrupted; retry data.get()"
        raise DataError(msg)


def _download(dataset: str, generation: str) -> bytes:
    signed = _post(
        {
            **_object(dataset),
            "mode": "download",
            "generation": generation,
            "request_id": uuid.uuid4().hex,
        }
    )
    if signed.get("generation") != generation:
        msg = "Server signed a different version than requested"
        raise DataError(msg)
    error: DataError
    try:
        raw = auth._download_feather_bytes(signed["url"], auth._DEFAULT_HEADERS)
    except auth.SignedDownloadError as exc:
        error = exc.for_dataset(f"{dataset} version {generation}")
    except Exception as exc:  # noqa: BLE001 - Never expose signed URLs in transport errors.
        msg = (
            f"Download of {dataset} version {generation} failed "
            f"({type(exc).__name__}); retry data.get()"
        )
        error = DataError(msg)
    else:
        _verify(raw, signed, f"{dataset} version {generation}")
        return raw
    # Raised outside the handler so the original error is not kept as __context__.
    raise error from None


def get_version(
    dataset: str,
    *,
    as_of: Any,
    version: str | int | None,
    force_download: bool,
    save_to_storage: bool,
) -> tuple[str, pd.DataFrame]:
    """``(resolved dataset, raw frame)`` of one retained version of ``dataset``."""
    if (as_of is None) == (version is None):
        msg = "Pass exactly one of as_of and version"
        raise ValueError(msg)
    ctx = context._default_context
    if ctx.use_local_data_only:
        msg = "Historical versions are listed by the server; local-only mode is unsupported"
        raise ValueError(msg)
    resolved = _resolve_dataset(dataset)
    _refuse_permanent_vintages(resolved)
    if version is None:
        resolved, listed = _following_alias(resolved, _list)
        generation = select_version(listed, as_of)
    else:
        generation = _canonical_generation(version)
    storage = ctx._storage
    force = force_download or ctx.force_cloud_download

    def fetch(name: str) -> pd.DataFrame:
        key = f"{_CACHE_PREFIX}{name}_{generation}"
        cached = storage.get_dataframe(key) if save_to_storage and not force else None
        if cached is not None:
            return cached
        frame = feather_io.read_frame(pa.py_buffer(_download(name, generation)))
        if save_to_storage:
            storage.set_dataframe(key, frame)
        return frame

    return _following_alias(resolved, fetch)
