"""Taiwan single-stock futures specifications for the stage-one lot engine."""

from __future__ import annotations

import math
from collections.abc import Mapping
from typing import TYPE_CHECKING, ClassVar, Literal

from finlab.market import Market

if TYPE_CHECKING:
    import pandas as pd

_DEFAULT_TAX_RATIO = 2e-5


class TWStockFuturesMarket(Market):
    """Backtest integer futures lots using adjusted underlying stock prices.

    Stage one treats each adjusted stock price as a futures price. It ignores
    basis, expiry/roll gaps and costs, contract adjustments, margin calls and
    forced liquidation. Stock IDs do not imply historical futures eligibility.
    The caller must select eligible stocks and supply their margin assumptions.

    Args:
        contract: ``standard`` (2,000 shares) or ``mini`` (100 shares).
        initial_capital: Initial equity in NTD, greater than zero.
        leverage: Target gross notional / equity, applied on rebalances only.
        fee_per_lot: REQUIRED broker commission in NTD per lot per side.
            There is no default rate: brokers negotiate different commissions.
        tax_ratio: Tax on notional on BOTH sides, default ``2e-5``.
        margin_ratio: Assumed initial margin / notional, either one ratio or
            a mapping keyed by stock ID. The default 0.135 is an assumption,
            not a historical margin schedule or a maintenance margin rate.
    """

    backtest_engine: ClassVar[str] = "futures_lots"
    supports_stock_execution: ClassVar[bool] = False

    def __init__(
        self,
        *,
        contract: Literal["standard", "mini"] = "standard",
        initial_capital: float = 1_000_000,
        leverage: float = 1,
        fee_per_lot: float | None = None,
        tax_ratio: float = _DEFAULT_TAX_RATIO,
        margin_ratio: float | Mapping[str, float] = 0.135,
    ) -> None:
        if fee_per_lot is None:
            raise ValueError(
                "fee_per_lot is required: supply your own broker's per-lot, "
                "per-side commission in NTD; broker rates differ "
                "（請填自己券商的每口單邊手續費，各券商費率不同）。"
            )
        if contract not in ("standard", "mini"):
            raise ValueError("contract must be 'standard' or 'mini'")
        self.contract = contract
        self.contract_multiplier = 2_000 if contract == "standard" else 100
        self.initial_capital = self._number(
            "initial_capital", initial_capital, positive=True
        )
        self.leverage = self._number("leverage", leverage, positive=True)
        self.fee_per_lot = self._number("fee_per_lot", fee_per_lot)
        self.tax_ratio = self._number("tax_ratio", tax_ratio)
        if self.tax_ratio >= 1:
            raise ValueError("tax_ratio must be less than 1")
        if isinstance(margin_ratio, Mapping):
            if not margin_ratio:
                raise ValueError("margin_ratio mapping must not be empty")
            self.margin_ratio: float | dict[str, float] = {
                str(symbol): self._margin(value)
                for symbol, value in margin_ratio.items()
            }
        else:
            self.margin_ratio = self._margin(margin_ratio)

    @staticmethod
    def _number(name: str, value: float, *, positive: bool = False) -> float:
        number = float(value)
        if not math.isfinite(number) or number < 0 or (positive and number == 0):
            raise ValueError(
                f'{name} must be finite and {"positive" if positive else "nonnegative"}'
            )
        return number

    @classmethod
    def _margin(cls, value: float) -> float:
        ratio = cls._number("margin_ratio", value, positive=True)
        if ratio > 1:
            raise ValueError("margin_ratio must be at most 1")
        return ratio

    def margin_ratios(self, symbols: list[str]) -> list[float]:
        if isinstance(self.margin_ratio, dict):
            missing = set(symbols) - self.margin_ratio.keys()
            if missing:
                raise ValueError(f"margin_ratio missing stock IDs: {sorted(missing)}")
            return [self.margin_ratio[symbol] for symbol in symbols]
        return [self.margin_ratio] * len(symbols)

    @staticmethod
    def get_name() -> str:
        return "tw_stock_futures"

    @staticmethod
    def get_board_lot_size() -> int:
        raise NotImplementedError(
            "Stage-one futures markets cannot be used for live stock execution; "
            "use contract_multiplier for backtest lots"
        )

    def market_close_at_timestamp(
        self, timestamp: pd.Timestamp | None = None
    ) -> pd.Timestamp:
        # Position.from_report asks for this before it reads report.execution.
        # Reject here before the inherited method can load stock prices.
        raise NotImplementedError(
            "Stage-one futures markets cannot be used for live stock execution"
        )

    @staticmethod
    def default_fee_ratio() -> float:
        raise NotImplementedError("Use fee_per_lot with the futures lot engine")

    @staticmethod
    def default_tax_ratio() -> float:
        return _DEFAULT_TAX_RATIO

    def get_price(
        self, trade_at_price: str | pd.Series | pd.DataFrame, adj: bool = True
    ) -> pd.DataFrame:
        """Use adjusted underlying prices, never the near-month futures series."""
        from finlab.markets.tw import TWMarket

        return TWMarket().get_price(trade_at_price, adj=True)
