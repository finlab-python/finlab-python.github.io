from __future__ import annotations

import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import datetime
    from collections.abc import Callable

    import pandas as pd

import requests
import urllib3

import finlab

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Get an instance of a logger
logger = logging.getLogger(__name__)

# Serverless runtimes whose home is read-only or discarded, so the data cache
# goes to the temporary directory: Google Cloud Functions, Cloud Run services
# and jobs, and AWS Lambda.
_SERVERLESS_ENV_VARS = (
    "FUNCTION_TARGET",
    "K_SERVICE",
    "CLOUD_RUN_JOB",
    "AWS_LAMBDA_FUNCTION_NAME",
)
_home_fallback_warned: bool = False


def running_serverless() -> bool:
    return any(os.environ.get(name) for name in _SERVERLESS_ENV_VARS)


def read_resource_file(package: str, resource: str) -> str:
    try:
        # For Python 3.9 and later
        from importlib.resources import files

        resource_path = files(package) / resource
        return resource_path.read_text(encoding="utf-8")
    except ImportError:
        try:
            # For Python 3.7 and 3.8
            from importlib.resources import path

            with (
                path(package, resource) as resource_path,
                open(resource_path, encoding="utf-8") as file,
            ):
                return file.read()
        except ImportError:
            # Fallback for older Python versions without importlib.resources
            import pkg_resources

            resource_filename = pkg_resources.resource_filename(package, resource)
            with open(resource_filename, encoding="utf-8") as file:
                return file.read()


def get_tmp_dir() -> str:
    # Check if running in Google Colab
    if "COLAB_GPU" in os.environ:
        # Try to use Google Drive as the tmp directory
        try:
            # Mount Google Drive
            if os.path.exists("/content/drive/"):
                default_path = "/content/drive/My Drive/Colab_tmp/finlab_db"
                logger.info(
                    "Google Drive is mounted. Using Google Drive as data directory."
                )
            else:
                default_path = "/content/finlab_db"
                logger.info(
                    "Tip: Link to Google Drive as data storage so that "
                    "you can access the data without downloading it again."
                )

            # Custom tmp dir inside Google Drive
            google_drive_tmp_dir = Path(default_path)
            google_drive_tmp_dir.mkdir(parents=True, exist_ok=True)

            return str(google_drive_tmp_dir)

        except ImportError:
            print(
                "Google Drive is not mounted. Please mount Google Drive to use as tmp directory."
            )
            raise

    serverless = running_serverless()
    if not serverless:
        try:
            home_subdir = Path.home() / "finlab_db"
            home_subdir.mkdir(parents=True, exist_ok=True)
            if os.access(home_subdir, os.W_OK):
                return str(home_subdir)
        except (OSError, RuntimeError, KeyError):  # read-only or unknown home
            pass
    # Only now: a host with a writable home needs no usable temporary directory.
    tmp_subdir = Path(tempfile.gettempdir()) / "finlab_db"
    global _home_fallback_warned
    if not serverless and not _home_fallback_warned:
        _home_fallback_warned = True
        logger.warning("Home directory is not writable; caching data in %s", tmp_subdir)
    tmp_subdir.mkdir(parents=True, exist_ok=True)
    return str(tmp_subdir)


def atomic_replace(
    file_path: str,
    write_fn: Callable[[str], Any],
    mtime: datetime.datetime | None = None,
) -> None:
    """Replace *file_path* with what *write_fn* writes to a temporary file beside it.

    *mtime* dates the result; a data file is dated at its published revision.
    """
    tmp_path = None
    try:
        fd, tmp_path = tempfile.mkstemp(
            prefix=os.path.basename(file_path) + ".",
            suffix=".tmp",
            dir=os.path.dirname(file_path),
        )
        os.close(fd)
        write_fn(tmp_path)
        if mtime is not None:
            os.utime(tmp_path, (mtime.timestamp(), mtime.timestamp()))
        os.replace(tmp_path, file_path)
    finally:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                logger.warning(f"failed to remove tmp file: {tmp_path}", exc_info=True)


def get_latest_version(package_name: str) -> str:
    url = f"https://pypi.org/pypi/{package_name}/json"
    try:
        response = requests.get(url)
        data = response.json()
        return data["info"]["version"]
    except (requests.RequestException, KeyError, ValueError):
        return "?"


def check_version_function_factory() -> Callable[[], None]:
    """Check finlab package version is the latest or not

    if the package version is out of date, info user to update.

    Returns
        None

    """
    if "pyodide" in sys.modules:
        return lambda: None

    latest_package_version: str | None = None

    def ret() -> None:
        nonlocal latest_package_version

        if latest_package_version is None:
            latest_package_version = get_latest_version("finlab")

            if latest_package_version not in (finlab.__version__, "?"):
                logger.warning(
                    f'Your version is {finlab.__version__}, please install a newer version.\nUse "pip install finlab=={latest_package_version}" to update the latest version.'
                )

    return ret


def global_object_getter_setter_factory() -> tuple[
    Callable[[str], object | None], Callable[[str, object], None]
]:
    _finlab_global_objects: dict[str, object] = {}

    def get_global(name: str) -> object | None:
        nonlocal _finlab_global_objects
        if name in _finlab_global_objects:
            return _finlab_global_objects[name]
        return None

    def set_global(name: str, obj: object) -> None:
        nonlocal _finlab_global_objects
        _finlab_global_objects[name] = obj
        if "pyodide" in sys.modules and "js" in sys.modules:
            import js
            from pyodide import ffi

            if hasattr(js, "_pyodide_execution_id"):
                js.postMessage(
                    ffi.to_js(
                        {
                            "content": obj,
                            "finish": False,
                            "type": name,
                            "id": js._pyodide_execution_id,
                        }
                    )
                )

    return get_global, set_global


def notify_progress(
    snippet_id: str | int, position: pd.DataFrame, progress: float
) -> None:
    """notify progress of the backtest (only work in pyodide)"""

    if "pyodide" in sys.modules and "js" in sys.modules:
        import js
        from pyodide import ffi

        if hasattr(js, "_pyodide_execution_id"):
            content = {
                "nstocks": (position != 0).sum(axis=1).mean(),
                "timestamp": snippet_id,
                "progress": progress,
            }

            js.postMessage(
                ffi.to_js(
                    {
                        "content": content,
                        "finish": False,
                        "type": "backtest-progress",
                        "id": js._pyodide_execution_id,
                    }
                )
            )


get_global: Callable[[str], object | None]
set_global: Callable[[str, object], None]
get_global, set_global = global_object_getter_setter_factory()
check_version: Callable[[], None] = check_version_function_factory()
