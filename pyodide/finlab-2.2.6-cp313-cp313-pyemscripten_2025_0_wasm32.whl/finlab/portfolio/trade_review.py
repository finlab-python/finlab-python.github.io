"""實盤覆盤：用真實成交、除權息與資金流重建帳戶淨值、報酬率與報表。

Real-trade review: rebuild the account's holdings, cash, NAV, cash-flow
adjusted returns and a FinLab ``Report`` from actual fills.

兩種口徑 / Two modes:

- 帳戶模式（給 ``initial_cash``）：淨值 = 現金 + 持股市值，只有入金、出金算外部資金流。
- 持股模式（``initial_cash=None``）：只看投入股票的資金，買進金額視為當日開盤前投入、
  賣出淨額與股利視為當日收盤後取出。台股交割戶是銀行帳戶、API 查不到入出金時用這個口徑。

日報酬 ``r = (淨值 + 當日流出) / (前日淨值 + 當日流入) - 1``，串接為時間加權報酬率。
"""

from __future__ import annotations

import math
from collections import defaultdict, deque
from dataclasses import dataclass
from functools import cached_property
from typing import TYPE_CHECKING, Any

import pandas as pd

from finlab.market import Market

if TYPE_CHECKING:
    from collections.abc import Iterable

    from finlab.core.report import Report

__all__ = ["TradeReview", "normalize_fills", "tw_corporate_actions"]

EXTERNAL_FLOWS = {"deposit", "withdrawal"}
_EPS = 1e-6
_NO_CASH_NOTE = (
    "API 沒有入出金與歷史餘額，以持股模式計算（買進視為投入、賣出與股利視為取出）"
)
_AUTO_DIVIDEND_NOTE = "API 沒有股利入帳紀錄，除權息依 FinLab 公告資料自動計算"


def _day(values: Any) -> pd.DatetimeIndex:
    index = pd.DatetimeIndex(pd.to_datetime(values, format="mixed"))
    if index.tz is not None:
        index = index.tz_localize(None)
    return index.normalize()


def _action(value: Any) -> str:
    text = str(getattr(value, "name", value)).split(".")[-1].upper()
    if text in ("BUY", "B", "買"):
        return "buy"
    if text in ("SELL", "S", "賣"):
        return "sell"
    raise ValueError(f"無法辨識的買賣方向 Unknown action: {value!r}")


def normalize_fills(fills: Any) -> pd.DataFrame:
    """把成交整理成標準格式：每筆（含部分）成交一列。

    必要欄位 ``time, stock_id, action, quantity, price``，數量以「股」為單位；
    ``fee``、``tax`` 為該筆實際金額（不是費率），缺少時當作 0。
    ``action`` 接受 ``buy``／``sell``、``B``／``S``、``Action.BUY`` 等寫法。
    """
    df = pd.DataFrame(fills).copy()
    missing = {"time", "stock_id", "action", "quantity", "price"} - set(df.columns)
    if missing:
        raise ValueError(f"成交缺少欄位 Fills missing columns: {sorted(missing)}")
    df["time"] = pd.to_datetime(df["time"], format="mixed")
    df["day"] = _day(df["time"])
    df["stock_id"] = df["stock_id"].astype(str)
    df["action"] = df["action"].map(_action)
    for col in ("quantity", "price", "fee", "tax"):
        df[col] = pd.to_numeric(df[col]).fillna(0.0).astype(float) if col in df else 0.0
    if (df["quantity"] <= 0).any():
        raise ValueError("成交數量必須大於 0 Fill quantity must be positive")
    # 同一天先處理買進再處理賣出（現股當沖先賣後買不會被當成超賣）；當日估值不受順序影響
    order = (df["action"] == "sell").astype(int)
    return (
        df.assign(_o=order)
        .sort_values(["day", "_o", "time"], kind="mergesort")
        .drop(columns="_o")
        .reset_index(drop=True)
    )


def _normalize_events(events: Any, required: set[str], date_col: str) -> pd.DataFrame:
    if events is None or len(events) == 0:
        return pd.DataFrame(columns=[*sorted(required), "day"])
    df = pd.DataFrame(events).copy()
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"缺少欄位 Missing columns: {sorted(missing)}")
    df["day"] = _day(df[date_col])
    return df.sort_values("day", kind="mergesort").reset_index(drop=True)


@dataclass
class _Lot:
    day: pd.Timestamp
    shares: float
    cost: float
    income: float = 0.0


class TradeReview:
    """以真實成交重建的帳戶覆盤結果。

    Args:
        fills: 成交，見 :func:`normalize_fills`。
        prices: 未還原收盤價，index 為日期、columns 為代號；用來每日估值。
        start: 覆盤起始日，預設為第一筆成交日。
        end: 覆盤結束日，預設為價格最後一天。
        initial_holdings: 起始日開盤前的庫存股數 ``{代號: 股數}``，以前一個交易日收盤價估值。
        initial_cash: 起始現金；``None`` 表示持股模式（見模組說明）。
        cash_events: 現金事件，欄位 ``time, amount, type``，``amount`` 正數為入帳；
            ``type`` 為 ``deposit``／``withdrawal`` 時算外部資金流，其餘（``dividend``、
            ``interest``、``fee``…）算損益。
        corporate_actions: 除權息與分割，欄位 ``stock_id, date, cash, ratio``：除權息
            交易日每股配發 ``cash`` 元，持股變成 ``ratio`` 倍（配股、分割、反分割）。
        market: 用於報表的 benchmark 與名稱，預設為 FinLab 預設市場。
        limitations: 資料來源的限制說明，會一併放進 ``review.limitations``。
    """

    def __init__(
        self,
        fills: Any,
        prices: pd.DataFrame,
        *,
        start: Any = None,
        end: Any = None,
        initial_holdings: dict[str, float] | None = None,
        initial_cash: float | None = None,
        cash_events: Any = None,
        corporate_actions: Any = None,
        market: Market | None = None,
        limitations: list[str] | tuple[str, ...] = (),
    ) -> None:
        self.fills = normalize_fills(fills)
        self.cash_events = _normalize_events(
            cash_events, {"time", "amount", "type"}, "time"
        )
        self.corporate_actions = _normalize_events(
            corporate_actions, {"stock_id", "date"}, "date"
        )
        self.initial_holdings = {
            str(k): float(v) for k, v in (initial_holdings or {}).items() if v
        }
        self.initial_cash = initial_cash
        self.market = market
        self.limitations = list(limitations)

        prices = prices.copy()
        prices.index = _day(prices.index)
        prices.columns = prices.columns.astype(str)
        prices = prices[~prices.index.duplicated(keep="last")].sort_index()

        first = self.fills["day"].min() if len(self.fills) else prices.index[-1]
        self.start = _day([start])[0] if start is not None else first
        self.end = _day([end])[0] if end is not None else prices.index[-1]
        if len(self.fills) and self.fills["day"].min() < self.start:
            raise ValueError("有成交早於 start；請把那些成交算進 initial_holdings")

        symbols = sorted(set(self.fills["stock_id"]) | set(self.initial_holdings))
        prices = prices.reindex(columns=symbols)
        days = prices.index[(prices.index >= self.start) & (prices.index <= self.end)]
        events = pd.DatetimeIndex(
            pd.concat([self.fills["day"], self.cash_events["day"]]).unique()
        )
        days = days.union(events)
        self._days = days[(days >= self.start) & (days <= self.end)]
        self._close = prices.reindex(prices.index.union(self._days)).ffill()
        before = self._close[self._close.index < self.start]
        self._base_day = (
            before.index[-1] if len(before) else self.start - pd.Timedelta(days=1)
        )
        self._base_price = (
            before.iloc[-1] if len(before) else self._close.loc[self.start]
        )
        self._run()

    @classmethod
    def from_account(
        cls,
        account: Any,
        start: Any,
        *,
        prices: pd.DataFrame | None = None,
        initial_cash: float | None = None,
        cash_events: Any = None,
        corporate_actions: Any = "auto",
        fee_ratio: float | None = None,
        **broker_kwargs: Any,
    ) -> TradeReview:
        """從已登入的 ``finlab.online`` 券商帳戶抓成交，覆盤 ``start`` 到今天。

        起始庫存由券商目前庫存倒推（扣回期間成交與配股、分割）。券商 API 有完整入出金
        時用帳戶模式；沒有時用持股模式，也可以自己給 ``initial_cash`` 與 ``cash_events``。

        Args:
            account: 已登入的券商帳戶，例如 ``SinopacAccount()``。
            start: 覆盤起始日。
            prices: 估值用的未還原收盤價，預設取帳戶市場的收盤價。
            initial_cash: 起始現金；給了就用帳戶模式，需要同時給完整的 ``cash_events``。
            cash_events: 補充的現金事件（入出金等），見 :class:`TradeReview`。
            corporate_actions: ``"auto"`` 用 FinLab 台股除權息資料，或自行傳入 DataFrame。
            fee_ratio: 券商 API 沒有逐筆費用時估算用的手續費率（含折讓），預設為帳戶市場的
                ``default_fee_ratio()``。
            **broker_kwargs: 個別券商的參數，例如幣安的 ``symbols``（已出清的幣別）。
        """
        from finlab.portfolio.broker_history import fetch_history

        start = _day([start])[0]
        hist = fetch_history(account, start, fee_ratio=fee_ratio, **broker_kwargs)
        market, prices = _valuation(account, hist.prices, prices)
        fills = normalize_fills(hist.fills)
        fills = fills[fills["day"] >= start]
        symbols = sorted(set(fills["stock_id"]) | set(hist.holdings))
        today = pd.Timestamp.today().normalize()
        prices = prices.reindex(columns=symbols)

        limitations = list(dict.fromkeys(hist.limitations))
        if hist.cash is None:
            limitations.append(_NO_CASH_NOTE)
        if isinstance(corporate_actions, str) and corporate_actions == "auto":
            if market.get_name() == "tw_stock":
                corporate_actions = tw_corporate_actions(symbols, start, today)
                if hist.dividends:
                    corporate_actions = corporate_actions.assign(cash=0.0)
                else:
                    limitations.append(_AUTO_DIVIDEND_NOTE)
            else:
                corporate_actions = None
                if not hist.dividends:
                    limitations.append(
                        "非台股市場不自動計算除權息，請自行傳入 corporate_actions"
                    )

        actions = _normalize_events(corporate_actions, {"stock_id", "date"}, "date")
        holdings = _rewind(hist.holdings, fills, actions)
        parts = [
            pd.DataFrame(e)
            for e in (hist.cash_events, cash_events)
            if e is not None and len(e)
        ]
        events = pd.concat(parts, ignore_index=True) if parts else None
        if initial_cash is None and hist.cash is not None:
            gross = fills["quantity"] * fills["price"]
            trade_cash = gross.where(fills["action"] == "sell", -gross)
            initial_cash = hist.cash - float(
                (trade_cash - fills["fee"] - fills["tax"]).sum()
            )
            if events is not None:
                initial_cash -= float(pd.to_numeric(events["amount"]).sum())

        review = cls(
            fills,
            prices,
            start=start,
            end=today,
            initial_holdings=holdings,
            initial_cash=initial_cash,
            cash_events=events,
            corporate_actions=actions,
            market=market,
            limitations=limitations,
        )
        last = (
            review.holdings.iloc[-1] if len(review.holdings) else pd.Series(dtype=float)
        )
        for sid in sorted(set(last[last > _EPS].index) | set(hist.holdings)):
            rebuilt = float(last.get(sid, 0.0))
            broker = float(hist.holdings.get(sid, 0.0))
            if abs(rebuilt - broker) > _EPS:
                review.limitations.append(
                    f"{sid} 重建庫存 {rebuilt:g} 股，券商目前 {broker:g} 股"
                )
        return review

    # ------------------------------------------------------------------ ledger
    def _run(self) -> None:
        account_mode = self.initial_cash is not None
        self._held: dict[str, float] = defaultdict(float, self.initial_holdings)
        self._lots: dict[str, deque[_Lot]] = defaultdict(deque)
        self._closed: list[tuple] = []
        for sid, shares in self.initial_holdings.items():
            self._lots[sid].append(
                _Lot(self.start, shares, shares * self._base_price[sid])
            )
        cash = float(self.initial_cash or 0.0)
        nav_prev = self.base_nav = cash + sum(
            s * self._base_price[sid] for sid, s in self._held.items()
        )
        if not account_mode and self.cash_events["type"].isin(EXTERNAL_FLOWS).any():
            self.limitations.append("持股模式不計入出金；要算帳戶淨值請給 initial_cash")

        fills = _by_day(self.fills)
        flows = _by_day(self.cash_events)
        actions = _by_day(self.corporate_actions)
        rows, holdings = [], []
        for day in self._days:
            income = self._apply_actions(actions.get(day, ()))
            trade_in, trade_out, charges = self._apply_fills(fills.get(day, ()), day)
            ext_in, ext_out, other = self._apply_flows(flows.get(day, ()))
            income += other
            if account_mode:
                # 帳戶模式只有入出金是外部資金流，買賣只是現金與持股互換
                cash += trade_out - trade_in + ext_in - ext_out + income
                inflow, outflow = ext_in, ext_out
            else:
                inflow, outflow = trade_in, trade_out + income
            positions = pd.Series(self._held, dtype=float)
            positions = positions[positions.abs() > _EPS]
            price = self._close.loc[day].reindex(positions.index)
            # 任一持股缺價就整天無法估值，不把缺價的持股當成 0
            mv = (
                float((positions * price).sum())
                if price.notna().all()
                else float("nan")
            )
            nav = cash + mv
            denom = nav_prev + inflow
            ret = (nav + outflow) / denom - 1 if denom > _EPS else 0.0
            rows.append((day, cash, mv, nav, inflow, outflow, income, charges, ret))
            holdings.append(positions.rename(day))
            nav_prev = nav

        self.daily = pd.DataFrame(
            rows,
            columns=[
                "date",
                "cash",
                "market_value",
                "nav",
                "inflow",
                "outflow",
                "income",
                "fees_and_tax",
                "return",
            ],
        ).set_index("date")
        net_flow = (self.daily["inflow"] - self.daily["outflow"]).cumsum()
        self.daily["pnl"] = self.daily["nav"] - self.base_nav - net_flow
        self.holdings = pd.DataFrame(holdings).reindex(self._days).fillna(0.0)
        self.holdings.columns = self.holdings.columns.astype(str)
        missing = self.daily.index[self.daily["nav"].isna()]
        if len(missing):
            self.limitations.append(
                f"{len(missing)} 天有持股缺收盤價，淨值無法計算（首日 {missing[0].date()}）"
            )
        self.trades = pd.DataFrame(
            self._closed + self._open_rows(),
            columns=[
                "stock_id",
                "entry_date",
                "exit_date",
                "shares",
                "entry_price",
                "exit_price",
                "income",
                "return",
            ],
        ).astype({"entry_date": "datetime64[ns]", "exit_date": "datetime64[ns]"})

    def _apply_actions(self, group: Iterable[Any]) -> float:
        """除權息：回傳現金股利，並依倍率調整持股與每批成本對應的股數。"""
        income = 0.0
        for a in group:
            sid = str(a.stock_id)
            shares = self._held.get(sid, 0.0)
            if shares <= 0:
                continue
            cash_ps = float(getattr(a, "cash", 0.0) or 0.0)
            income += shares * cash_ps
            for lot in self._lots[sid]:
                lot.income += lot.shares * cash_ps
            ratio = float(getattr(a, "ratio", 1.0) or 1.0)
            if ratio != 1.0:
                new = math.floor(shares * ratio + _EPS)
                for lot in self._lots[sid]:
                    lot.shares *= new / shares
                self._held[sid] = new
        return income

    def _apply_fills(
        self, group: Iterable[Any], day: pd.Timestamp
    ) -> tuple[float, float, float]:
        """成交：回傳（買進總付、賣出淨收、費稅）。"""
        paid = received = charges = 0.0
        for f in group:
            gross, cost = f.quantity * f.price, f.fee + f.tax
            charges += cost
            if f.action == "buy":
                self._held[f.stock_id] += f.quantity
                self._lots[f.stock_id].append(_Lot(day, f.quantity, gross + cost))
                paid += gross + cost
                continue
            if f.quantity > self._held[f.stock_id] + _EPS:
                raise ValueError(
                    f"{day.date()} {f.stock_id} 賣出 {f.quantity:g} 股超過庫存 "
                    f"{self._held[f.stock_id]:g} 股；請補上起始庫存或缺漏的買進成交"
                )
            self._held[f.stock_id] -= f.quantity
            self._closed += self._close_lots(self._lots[f.stock_id], f, day)
            received += gross - cost
        return paid, received, charges

    def _apply_flows(self, group: Iterable[Any]) -> tuple[float, float, float]:
        """現金事件：回傳（入金、出金、其他損益）；有代號的股利依股數分給各批持股。"""
        ext_in = ext_out = other = 0.0
        for e in group:
            if e.type in EXTERNAL_FLOWS:
                ext_in += max(e.amount, 0.0)
                ext_out += max(-e.amount, 0.0)
                continue
            other += e.amount
            lots = self._lots.get(str(getattr(e, "stock_id", "")), ())
            total = sum(lot.shares for lot in lots)
            for lot in lots:
                lot.income += e.amount * lot.shares / total
        return ext_in, ext_out, other

    def _open_rows(self) -> list[tuple]:
        last = self._days[-1] if len(self._days) else self.end
        rows = []
        for sid, queue in self._lots.items():
            px = (
                self._close.loc[last, sid]
                if last in self._close.index
                else float("nan")
            )
            rows += [
                _trade_row(sid, lot, None, px * lot.shares, px)
                for lot in queue
                if lot.shares > _EPS
            ]
        return rows

    @staticmethod
    def _close_lots(queue: deque[_Lot], fill: Any, day: pd.Timestamp) -> list[tuple]:
        rows, left = [], fill.quantity
        charge_ps = (fill.fee + fill.tax) / fill.quantity
        while left > _EPS and queue:
            lot = queue[0]
            take = min(left, lot.shares)
            frac = take / lot.shares
            part = _Lot(lot.day, take, lot.cost * frac, lot.income * frac)
            rows.append(
                _trade_row(
                    fill.stock_id,
                    part,
                    day,
                    take * (fill.price - charge_ps),
                    fill.price,
                )
            )
            lot.shares -= take
            lot.cost -= part.cost
            lot.income -= part.income
            left -= take
            if lot.shares <= _EPS:
                queue.popleft()
        return rows

    # ----------------------------------------------------------------- outputs
    @property
    def returns(self) -> pd.Series:
        """排除入出金影響的每日報酬率（時間加權）。"""
        return self.daily["return"]

    @property
    def creturn(self) -> pd.Series:
        """累積報酬指數；第一點是起始日前一個交易日的 1，保留第一天的損益。"""
        growth = (1 + self.daily["return"]).cumprod()
        return pd.concat([pd.Series([1.0], index=[self._base_day]), growth])

    @property
    def weights(self) -> pd.DataFrame:
        """每日收盤的實際持股權重（占淨值）。"""
        mv = self.holdings * self._close.reindex(
            index=self._days, columns=self.holdings.columns
        )
        return mv.div(self.daily["nav"], axis=0).fillna(0.0)

    def summary(self) -> pd.Series:
        """期間損益摘要：起訖淨值、外部淨投入、費稅、股利與損益。"""
        d = self.daily
        return pd.Series(
            {
                "start": self.start,
                "end": d.index[-1] if len(d) else self.end,
                "base_nav": self.base_nav,
                "end_nav": d["nav"].iloc[-1] if len(d) else self.base_nav,
                "net_inflow": float((d["inflow"] - d["outflow"]).sum()),
                "income": float(d["income"].sum()),
                "fees_and_tax": float(d["fees_and_tax"].sum()),
                "pnl": float(d["pnl"].iloc[-1]) if len(d) else 0.0,
                "time_weighted_return": float(self.creturn.iloc[-1] - 1)
                if len(d)
                else 0.0,
            }
        )

    def compare(self, target: pd.DataFrame, kind: str = "shares") -> pd.DataFrame:
        """實際部位與策略目標的差異。

        Args:
            target: index 為日期、columns 為代號的目標股數（``kind="shares"``）或權重
                （``kind="weight"``）。每個目標日只和「該日收盤時」的實際部位比，不用之後的成交。
        Returns:
            DataFrame: ``date, stock_id, target, actual, diff``，略過兩邊都是 0 的列。
        """
        if kind not in ("shares", "weight"):
            raise ValueError("kind 只能是 'shares' 或 'weight'")
        actual = self.holdings if kind == "shares" else self.weights
        target = target.copy()
        target.index = _day(target.index)
        target.columns = target.columns.astype(str)
        days = target.index[
            (target.index >= self._days[0]) & (target.index <= self._days[-1])
        ]
        cols = target.columns.union(actual.columns)
        act = (
            actual.reindex(actual.index.union(days))
            .ffill()
            .reindex(index=days, columns=cols)
        )
        tgt = target.reindex(index=days, columns=cols)
        out = pd.DataFrame(
            {
                "target": tgt.fillna(0.0).stack(),
                "actual": act.fillna(0.0).stack(),
            }
        )
        out["diff"] = out["actual"] - out["target"]
        out = out[(out["target"].abs() > _EPS) | (out["actual"].abs() > _EPS)]
        return out.rename_axis(["date", "stock_id"]).reset_index()

    def _excursions(self, market: Market, exits: pd.Series) -> pd.DataFrame:
        try:
            adj = market.get_price("close", adj=True)
            adj = adj.set_axis(_day(adj.index)).reindex(columns=self._close.columns)
        except Exception:  # noqa: BLE001 - 自訂市場可能沒有還原價，改用估值價格
            adj = self._close
        adj = adj[~adj.index.duplicated(keep="last")].ffill()
        rows = [
            _excursion(adj.loc[a:b, sid])
            for sid, a, b in zip(
                self.trades["stock_id"], self.trades["entry_date"], exits, strict=True
            )
        ]
        return pd.DataFrame(
            rows,
            index=self.trades.index,
            columns=["mae", "gmfe", "bmfe", "mdd", "pdays"],
        )

    @cached_property
    def report(self) -> Report:
        """FinLab ``Report``：淨值曲線用時間加權報酬，交易明細為 FIFO 配對的實際成交。"""
        from finlab.config import get_default_market
        from finlab.core.report import Report

        if self.daily["nav"].isna().any():
            raise ValueError(
                "有持股缺收盤價，無法產生報表；請補 prices 或看 review.limitations"
            )
        market = self.market or get_default_market()
        weights = self.weights
        report = Report(
            creturn=self.creturn,
            position=weights,
            fee_ratio=0.0,
            tax_ratio=0.0,
            trade_at="close",
            next_trading_date=self._days[-1],
            market=market,
        )
        names = market.get_asset_id_to_name()

        def label(sid: str) -> str:
            return f"{sid} {names[sid]}" if sid in names else sid

        t = self.trades
        nav = self.daily["nav"]
        # 未平倉的部位以最後一天當出場日計算持有天數與 MAE／MFE
        exits = pd.DatetimeIndex(t["exit_date"].fillna(self._days[-1]))
        report.trades = pd.DataFrame(
            {
                "stock_id": t["stock_id"],
                "symbol": t["stock_id"].map(label),
                "name": t["stock_id"].map(names).fillna(""),
                "entry_date": t["entry_date"],
                "exit_date": t["exit_date"],
                "entry_sig_date": t["entry_date"],
                "exit_sig_date": t["exit_date"],
                "position": t["shares"]
                * t["entry_price"]
                / t["entry_date"].map(nav).replace(0, float("nan")),
                "period": self._days.searchsorted(exits, "right")
                - self._days.searchsorted(pd.DatetimeIndex(t["entry_date"]), "right"),
                "return": t["return"],
                "trade_price@entry_date": t["entry_price"],
                "trade_price@exit_date": t["exit_price"],
                "shares": t["shares"],
            }
        ).rename_axis("trade_index")
        report.trades = report.trades.join(self._excursions(market, exits))
        report.mae_mfe = pd.concat(
            {"exit": report.trades[["mae", "gmfe", "bmfe", "mdd", "pdays", "return"]]},
            axis=1,
        )
        last = weights.iloc[-1] if len(weights) else pd.Series(dtype=float)
        last = last[last != 0].rename(self._days[-1])
        report.weights = last.set_axis(last.index.map(label))
        report.next_weights = pd.Series(dtype="float64", name=self._days[-1])
        report.actions = pd.Series(dtype=object)
        report.resample = None
        report.trail_stop_activation = None
        report.data_readiness = None
        report.planned_rebalance_date = None
        if len(report.trades):
            report.calculate_current_trades()
        return report


class _PriceMarket(Market):
    """FinLab 沒有資料的市場（例如加密貨幣），用券商給的收盤價估值。"""

    def __init__(self, prices: pd.DataFrame) -> None:
        self._prices = prices

    def get_price(self, trade_at_price: Any, adj: bool = True) -> pd.DataFrame:
        return self._prices


def _valuation(
    account: Any, broker_prices: pd.DataFrame | None, prices: pd.DataFrame | None
) -> tuple[Market, pd.DataFrame]:
    """估值用的市場與未還原收盤價：券商有給價格（FinLab 沒有的市場）時優先用。"""
    if broker_prices is not None:
        prices = broker_prices if prices is None else prices
        return _PriceMarket(prices), prices
    market = account.get_market()
    if prices is None:
        prices = market.get_price("close", adj=False)
    return market, prices


def _rewind(
    current: dict[str, float], fills: pd.DataFrame, actions: pd.DataFrame
) -> dict[str, float]:
    """由目前庫存倒推起始庫存：逆序扣回成交，再除回配股與分割倍率。"""
    held: dict[str, float] = defaultdict(float, current)
    events = [(f.day, 1, f) for f in fills.itertuples()]
    events += [(a.day, 0, a) for a in actions.itertuples()]
    for _, kind, e in sorted(events, key=lambda x: (x[0], x[1]), reverse=True):
        sid = str(e.stock_id)
        if kind == 1:
            held[sid] += -e.quantity if e.action == "buy" else e.quantity
        elif float(getattr(e, "ratio", 1.0) or 1.0) != 1.0:
            held[sid] = round(held[sid] / float(e.ratio))
    return {sid: q for sid, q in held.items() if q > _EPS}


def _by_day(df: pd.DataFrame) -> dict[pd.Timestamp, list[Any]]:
    """依日期分組成逐筆紀錄，帳本迴圈不必每天重跑 ``itertuples``。"""
    return {day: list(g.itertuples()) for day, g in df.groupby("day")}


def _excursion(path: pd.Series) -> tuple[float, ...]:
    """持有期間（進場日收盤到出場日）的 MAE／MFE，算法同回測報表。"""
    path = path.dropna()
    if len(path) < 2:
        return (0.0, 0.0, 0.0, 0.0, 0.0)
    ret = path / path.iloc[0] - 1
    low = int(ret.to_numpy().argmin())
    equity = 1 + ret
    return (
        min(ret.min(), 0.0),
        max(ret.max(), 0.0),
        max(ret.iloc[: low + 1].max(), 0.0),
        float((equity / equity.cummax() - 1).min()),
        float((ret > 0).sum()),
    )


def _trade_row(
    sid: str,
    lot: _Lot,
    exit_day: Any,
    exit_value: float,
    exit_price: float,
) -> tuple:
    ret = (exit_value + lot.income) / lot.cost - 1 if lot.cost > 0 else float("nan")
    return (
        sid,
        lot.day,
        exit_day,
        lot.shares,
        lot.cost / lot.shares,
        exit_price,
        lot.income,
        ret,
    )


def tw_corporate_actions(stock_ids: list[str], start: Any, end: Any) -> pd.DataFrame:
    """台股除權息與 ETF 分割事件（每股現金股利、配股與分割倍率）。

    - 上市櫃公司：``dividend_announcement`` 的現金股利、配股（元/股 ÷ 面額）與除權息交易日。
    - ETF：交易所除權息結果表的息值（ETF 只配息）。
    - ETF 分割／反分割：``etf_split``，在恢復買賣日套用。

    減資、面額變更沒有每股退還現金與換股比例的完整資料，不在此列；遇到時請手動補進
    ``corporate_actions``。
    """
    from finlab import data

    ids = {str(s) for s in stock_ids}
    lo, hi = _day([start])[0], _day([end])[0]
    rows = []

    ann = data.get("dividend_announcement")
    ann = ann[ann["stock_id"].astype(str).isin(ids)]
    face = pd.to_numeric(
        ann["普通股每股面額"].astype(str).str.extract(r"([\d.]+)")[0], errors="coerce"
    ).fillna(10.0)
    cash = ann["盈餘分配之股東現金股利(元/股)"].fillna(0) + ann[
        "法定盈餘公積、資本公積發放之現金(元/股)"
    ].fillna(0)
    stock = ann["盈餘轉增資配股(元/股)"].fillna(0) + ann[
        "法定盈餘公積、資本公積轉增資配股(元/股)"
    ].fillna(0)
    for sid, day, c in zip(
        ann["stock_id"].astype(str), ann["除息交易日"], cash, strict=True
    ):
        if pd.notna(day) and c > 0:
            rows.append((sid, day, float(c), 1.0))
    for sid, day, s, f in zip(
        ann["stock_id"].astype(str), ann["除權交易日"], stock, face, strict=True
    ):
        if pd.notna(day) and s > 0:
            rows.append((sid, day, 0.0, 1.0 + float(s) / float(f)))

    etf_ids = {s for s in ids if s.startswith("00")}
    if not etf_ids:
        return _corporate_frame(rows, lo, hi)

    company = set(ann["stock_id"].astype(str))
    for table in ("dividend_tse:權值+息值", "dividend_otc:息值"):
        values = data.get(table)
        kinds = data.get(table.split(":")[0] + ":權息")
        etf = [s for s in values.columns.astype(str) if s in etf_ids - company]
        for sid in etf:
            v = values[sid].where(kinds[sid] == "息").dropna()
            rows += [(sid, day, float(x), 1.0) for day, x in v.items() if x > 0]

    kind = data.get("etf_split:分割(反分割)")
    ratio = data.get("etf_split:分割(反分割)比率")
    resume = data.get("etf_split:恢復買賣日期")
    for sid in [s for s in ratio.columns.astype(str) if s in ids]:
        for day, r in ratio[sid].dropna().items():
            r = float(r) if kind.at[day, sid] == "分割" else 1.0 / float(r)
            rows.append(
                (
                    sid,
                    resume.at[day, sid] if pd.notna(resume.at[day, sid]) else day,
                    0.0,
                    r,
                )
            )

    return _corporate_frame(rows, lo, hi)


def _corporate_frame(
    rows: list[tuple], lo: pd.Timestamp, hi: pd.Timestamp
) -> pd.DataFrame:
    out = pd.DataFrame(rows, columns=["stock_id", "date", "cash", "ratio"])
    out["date"] = _day(out["date"])
    out = out[(out["date"] >= lo) & (out["date"] <= hi)]
    return out.sort_values(["date", "stock_id"]).reset_index(drop=True)
