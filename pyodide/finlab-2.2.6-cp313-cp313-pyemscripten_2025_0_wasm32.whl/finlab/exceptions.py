"""Finlab exception hierarchy."""

from __future__ import annotations

import json
from typing import Any

import requests

__all__ = [
    "AuthError",
    "BacktestError",
    "BrokerError",
    "ConfigError",
    "DataError",
    "DatasetNotFoundError",
    "FinlabError",
    "LoginError",
    "PortfolioError",
    "SignedDownloadError",
]


class FinlabError(Exception):
    """Base exception for all finlab errors."""


class DataError(FinlabError):
    """Data fetching, caching, or transformation failures."""


class DatasetNotFoundError(DataError, RuntimeError):
    """``data.get()`` asked for a dataset key that does not exist.

    Subclasses ``RuntimeError`` because missing datasets used to raise a bare
    ``RuntimeError``; existing ``except RuntimeError`` handlers keep working.
    """

    def __init__(
        self, dataset: str, message: str, suggestions: tuple[str, ...] = ()
    ) -> None:
        super().__init__(message)
        self.dataset = dataset
        self.suggestions = suggestions


class SignedDownloadError(DataError, requests.RequestException):
    """Downloading a signed data URL, or signing it, failed.

    A signed URL downloads paid data until it expires, and users paste
    tracebacks into public channels, so neither the message nor any attribute
    contains the URL.

    Attributes:
        dataset: Dataset being downloaded, or ``None`` when unknown.
        status: HTTP status of the failed download, or ``None`` when the
            request never got a response.
        kind: Stable failure category for code to branch on: ``"http"``,
            ``"timeout"``, ``"connection"``, ``"ssl"``, ``"redirects"``,
            ``"browser"``, ``"invalid_reply"`` or ``"other"``.
        problem: Human-readable description of the failure.
        advice: What the user can do about it.

    Subclasses ``requests.RequestException`` (and so ``OSError``) because
    these failures used to raise ``requests`` errors. The instance is also an
    instance of the specific ``requests`` class the failure used to raise,
    such as ``requests.HTTPError`` or ``requests.ConnectionError``, so
    existing ``except`` clauses keep working. ``request`` is always ``None``;
    ``response`` is ``None`` unless ``status`` is set, and then only carries
    ``status_code``.

    Unlike ``requests`` errors, the constructor takes ``problem`` and
    ``advice`` instead of a message and accepts no ``request``/``response``,
    so ``type(e)(str(e))`` or ``type(e)(*e.args)`` cannot rebuild the error.
    ``pickle``, ``copy`` and ``deepcopy`` do.
    """

    def __init__(
        self,
        problem: str,
        advice: str,
        *,
        status: int | None = None,
        dataset: str | None = None,
        kind: str = "other",
    ) -> None:
        self.problem = problem
        self.advice = advice
        self.status = status
        self.dataset = dataset
        self.kind = kind
        # Called directly: requests.JSONDecodeError.__init__ needs the reply
        # text, which SignedDownloadJSONDecodeError must not keep.
        requests.RequestException.__init__(
            self, self._render(), response=_status_only_response(status)
        )

    def _render(self) -> str:
        return f"Download of {self.dataset or 'data'} failed ({self.problem}). {self.advice}"

    def for_dataset(self, dataset: str) -> SignedDownloadError:
        """Name *dataset* in the message; returns ``self`` for ``raise``."""
        if self.dataset is None:
            self.dataset = dataset
            self.args = (self._render(),)
        return self

    def __reduce__(self) -> tuple[Any, ...]:
        # Exceptions pickle through ``args``, which cannot rebuild the fields.
        # Rebuild from them so multiprocessing can return the error to the
        # parent process; ``response`` is rebuilt from ``status``.
        extra = {
            key: value
            for key, value in self.__dict__.items()
            if key not in _REBUILT_FIELDS
        }
        return (
            _rebuild_signed_download_error,
            (
                type(self),
                self.problem,
                self.advice,
                self.status,
                self.dataset,
                self.kind,
            ),
            extra or None,
        )


_REBUILT_FIELDS = frozenset(
    {"problem", "advice", "status", "dataset", "kind", "request", "response"}
)


def _status_only_response(status: int | None) -> requests.Response | None:
    """A ``Response`` with only ``status_code``, for ``e.response.status_code``."""
    if status is None:
        return None
    response = requests.Response()
    response.status_code = status
    response._content = b""
    return response


def _rebuild_signed_download_error(
    cls: type[SignedDownloadError],
    problem: str,
    advice: str,
    status: int | None,
    dataset: str | None,
    kind: str,
) -> SignedDownloadError:
    return cls(problem, advice, status=status, dataset=dataset, kind=kind)


# One subclass per ``requests`` error a signed download used to raise, so
# ``except requests.<Error>`` written for the old error still catches it.
class SignedDownloadHTTPError(SignedDownloadError, requests.HTTPError):
    """HTTP error status; used to be ``requests.HTTPError``."""


class SignedDownloadConnectionError(SignedDownloadError, requests.ConnectionError):
    """Used to be ``requests.ConnectionError``."""


class SignedDownloadProxyError(SignedDownloadError, requests.exceptions.ProxyError):
    """Used to be ``requests.exceptions.ProxyError``."""


class SignedDownloadSSLError(SignedDownloadError, requests.exceptions.SSLError):
    """Used to be ``requests.exceptions.SSLError``."""


class SignedDownloadTimeout(SignedDownloadError, requests.Timeout):
    """Used to be ``requests.Timeout``."""


class SignedDownloadConnectTimeout(SignedDownloadError, requests.ConnectTimeout):
    """Used to be ``requests.ConnectTimeout``."""


class SignedDownloadReadTimeout(SignedDownloadError, requests.ReadTimeout):
    """Used to be ``requests.ReadTimeout``."""


class SignedDownloadTooManyRedirects(SignedDownloadError, requests.TooManyRedirects):
    """Used to be ``requests.TooManyRedirects``."""


class SignedDownloadChunkedEncodingError(
    SignedDownloadError, requests.exceptions.ChunkedEncodingError
):
    """Used to be ``requests.exceptions.ChunkedEncodingError``."""


class SignedDownloadContentDecodingError(
    SignedDownloadError, requests.exceptions.ContentDecodingError
):
    """Used to be ``requests.exceptions.ContentDecodingError``."""


# requests < 2.27 has no JSONDecodeError and raised the standard library's
# json.JSONDecodeError (or simplejson's) for a malformed reply; pyproject.toml
# sets no lower bound on requests, so fall back instead of failing the import.
_RequestsJSONDecodeError: type[ValueError] = getattr(
    requests.exceptions, "JSONDecodeError", json.JSONDecodeError
)


class SignedDownloadJSONDecodeError(SignedDownloadError, _RequestsJSONDecodeError):  # type: ignore[misc, valid-type]
    """The signing endpoint sent a malformed reply.

    Used to be ``requests.exceptions.JSONDecodeError`` (``json.JSONDecodeError``
    in Pyodide and with requests < 2.27), whose ``doc`` held the whole reply
    with every signed URL. Here ``doc`` is empty.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # json.JSONDecodeError attributes, without the reply text.
        self.msg = self.problem
        self.doc = ""
        self.pos = 0
        self.lineno = 1
        self.colno = 1


_REBUILT_FIELDS |= {"msg", "doc", "pos", "lineno", "colno"}


class BacktestError(FinlabError):
    """Invalid backtest config or simulation failures."""


class BrokerError(FinlabError):
    """Broker connection, order submission, or execution failures."""


class AuthError(FinlabError):
    """Authentication or authorization failures."""


class LoginError(AuthError, RuntimeError):
    """Interactive login did not complete (cancelled, rejected or timed out).

    Subclasses ``RuntimeError`` so callers that already catch login failures
    from ``finlab.get_token()`` keep working.
    """


class PortfolioError(FinlabError):
    """Portfolio construction or rebalancing failures."""


class ConfigError(FinlabError):
    """Invalid configuration or missing required settings."""
