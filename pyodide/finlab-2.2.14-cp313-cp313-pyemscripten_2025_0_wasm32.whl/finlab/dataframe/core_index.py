"""Index conversion mixin for FinlabDataFrame.

Handles conversion between string-format financial indices (e.g. '2022-Q1',
'2022-M01') and datetime indices, including business-day alignment and
disclosure-date lookups.
"""

from __future__ import annotations

import datetime
from typing import TYPE_CHECKING, Literal

import numpy as np
import pandas as pd

from finlab.compat import CANONICAL_NAME

if TYPE_CHECKING:
    from collections.abc import Iterable

    from finlab.dataframe.core import FinlabDataFrame


class IndexConversionMixin:
    """Methods for converting FinlabDataFrame indices between str and datetime."""

    def index_str_to_date(self: FinlabDataFrame) -> FinlabDataFrame:  # type: ignore[misc]
        """財務月季報索引格式轉換

        將以下資料的索引轉換成datetime格式:

        財務季報 (ex:2022-Q1) 從文字格式轉為財報電子檔資料上傳日。

        通常使用情境為對不同週期的dataframe做reindex，常用於以公告截止日作為訊號產生日。

        Returns:
          (pd.DataFrame): data

        Examples:
            ```py
            data.get('financial_statement:現金及約當現金').index_str_to_date()
            ```
        """
        if len(self.index) == 0 or not isinstance(self.index[0], str):
            return self

        if self.index[0].find("M") != -1:
            return self._index_str_to_date_month()
        if self.index[0].find("Q") != -1:
            return _route_season_market(self)

        return self

    @staticmethod
    def to_business_day(
        date: Iterable[datetime.date | pd.Timestamp],
        close: pd.DataFrame | None = None,
    ) -> np.ndarray:
        def skip_weekend(d: datetime.date) -> datetime.date:
            add_days = {5: 2, 6: 1}
            wd = d.weekday()
            if wd in add_days:
                d += datetime.timedelta(days=add_days[wd])
            return d

        if close is None:
            from finlab import data

            close = data.get("price:收盤價")

        return (
            pd.Series(date)
            .apply(
                lambda d: (
                    d
                    if d in close.index
                    else skip_weekend(d)
                    if d < close.index[0] or d > close.index[-1]
                    else close.loc[d:].index[0]
                )
            )
            .values
        )

    def _index_date_to_str_month(self: FinlabDataFrame) -> FinlabDataFrame:  # type: ignore[misc]
        from finlab.dataframe.core import FinlabDataFrame as FDF

        if len(self.index) == 0 or not isinstance(self.index[0], pd.Timestamp):
            return self

        index = (self.index - datetime.timedelta(days=30)).strftime("%Y-M%m")
        return FDF(self.values, index=index, columns=self.columns)

    def _index_str_to_date_month(self: FinlabDataFrame) -> FinlabDataFrame:  # type: ignore[misc]
        return self

    def _index_to_business_day(self: FinlabDataFrame) -> FinlabDataFrame:  # type: ignore[misc]
        from finlab.dataframe.core import FinlabDataFrame as FDF

        index = self.to_business_day(self.index)
        ret = FDF(self.values, index=index, columns=self.columns)
        ret.index.name = "date"
        return ret

    def _index_date_to_str_season(  # type: ignore[misc]
        self: FinlabDataFrame, postfix: str = ""
    ) -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame as FDF

        if len(self.index) == 0 or not isinstance(self.index[0], pd.Timestamp):
            return self

        if not isinstance(self.index, pd.DatetimeIndex):
            raise TypeError("Index must be a pd.DatetimeIndex")

        year = self.index.year.copy()
        if postfix:
            q = self.index.strftime("%m").astype(int).map({3: 1, 6: 2, 9: 3, 12: 4})
        else:
            q = (
                self.index.strftime("%m")
                .astype(int)
                .map({5: 1, 8: 2, 9: 2, 10: 3, 11: 3, 3: 4, 4: 4})
            )
            year -= q == 4
        index = year.astype(str) + f"{postfix}-Q" + q.astype(str)
        return FDF(self.values, index=index, columns=self.columns)

    def deadline(self: FinlabDataFrame) -> FinlabDataFrame:  # type: ignore[misc]
        """財務索引轉換成公告截止日

        將財務季報 (ex:2022Q1) 從文字格式轉為公告截止日的datetime格式，
        通常使用情境為對不同週期的dataframe做reindex，常用於以公告截止日作為訊號產生日。
        Returns:
          (pd.DataFrame): data
        Examples:
            ```py
            data.get('financial_statement:現金及約當現金').deadline()
            data.get('monthly_revenue:當月營收').deadline()
            ```
        """
        if len(self.index) == 0 or not isinstance(self.index[0], str):
            return self

        if self.index[0].find("M") != -1:
            return self._index_str_to_date_month()
        if self.index[0].find("Q") != -1:
            return self._index_str_to_date_season(detail=False)

        raise ValueError(
            "Cannot apply deadline to dataframe. "
            "Index is not compatible. "
            "Index should be 2013-Q1 or 2013-M1."
        )

    def _index_str_to_date_season(  # type: ignore[misc]
        self: FinlabDataFrame,
        detail: bool = True,
        market: Literal[
            "hk_stock",
            "jp_stock",
            "kr_stock",
            "tw_stock",
            "uk_stock",
            "us_stock",
            "us_stock_all",
        ] = "tw_stock",
    ) -> FinlabDataFrame:
        from finlab import data
        from finlab.dataframe.core import FinlabDataFrame as FDF

        # Fiscal tables publish no deadlines; use their own disclosure dates.
        if fiscal_table := _fiscal_datekey_table(self.index[0]):
            datekey = data.get(f"{fiscal_table}:key_date")
            detail = True
        else:
            datekey = _fetch_datekey(market, detail)

        intersect_cols = self.columns.intersection(datekey.columns)
        values = self[intersect_cols]
        # All-boolean masks pivot and ffill as one float block, unknown as NaN.
        dense = _dense_boolean(values)
        all_boolean = dense is not None
        # In mixed frames, pivoting staggered disclosure dates adds missing cells,
        # which turns bool columns into object; `~` on those yields -2/-1. Cast
        # them to nullable boolean so pre-disclosure cells stay unknown.
        boolean_dtypes = (
            {}
            if all_boolean
            else dict.fromkeys(
                values.select_dtypes(["bool", "boolean"]).columns, "boolean"
            )
        )
        disclosure_dates = datekey.reindex(self.index)[intersect_cols].unstack()

        # Default the axis name locally; writing it to self.columns would rename
        # the caller's frame.
        col_name = (
            self.columns.name if self.columns.name is not None else CANONICAL_NAME
        )
        unstacked = (values if dense is None else dense).unstack()

        if unstacked.shape != disclosure_dates.shape:
            shared_idx = unstacked.index.intersection(disclosure_dates.index)
            unstacked = unstacked.reindex(shared_idx)
            disclosure_dates = disclosure_dates.reindex(shared_idx)

        ret = pd.DataFrame(
            {
                "value": unstacked.values,
                "disclosures": disclosure_dates.values,
            },
            unstacked.index,
        )
        ret.index.names = [col_name, "date"]

        ret = (
            ret.reset_index()
            .pipe(_latest_period_only, col_name)
            # A period without a disclosure date has no known availability; drop it
            # before ffill, otherwise its NaT row sorts first and leaks backward.
            .pipe(lambda df: df.loc[df["disclosures"].notna()])
            .pivot(index="disclosures", columns=col_name, values="value")
            # Keep symbols whose periods all lack a disclosure date, as all-NaN columns.
            .reindex(columns=intersect_cols.sort_values().rename(col_name))
            # astype({}) still copies every column; skip it for numeric frames.
            .pipe(lambda df: df.astype(boolean_dtypes) if boolean_dtypes else df)
            .pipe(_safe_ffill)
            # Public masks remain nullable: ~unknown must still be unknown.
            .pipe(lambda df: _dense_to_nullable(df) if all_boolean else df)
            .pipe(FDF)
            .rename_axis("date")
        )

        if not detail:
            ret.index = self.to_business_day(ret.index)

        return _apply_truncation(ret)


def _fiscal_datekey_table(idx0: str) -> str | None:
    """Return the fiscal table whose label postfix *idx0* carries, if any."""
    from finlab.data.transform import FISCAL_TABLE_POSTFIX

    return next(
        (t for t, postfix in FISCAL_TABLE_POSTFIX.items() if postfix in idx0),
        None,
    )


def _route_season_market(df: FinlabDataFrame) -> FinlabDataFrame:
    """Dispatch index_str_to_date to the correct market for Q-format indices."""
    idx0 = df.index[0]
    market_prefixes: dict[
        str,
        Literal[
            "hk_stock",
            "jp_stock",
            "kr_stock",
            "uk_stock",
            "us_stock",
            "us_stock_all",
        ],
    ] = {
        "US-ALL": "us_stock_all",
        "US": "us_stock",
        "JP": "jp_stock",
        "HK": "hk_stock",
        "KR": "kr_stock",
        "UK": "uk_stock",
    }
    for prefix, market in market_prefixes.items():
        if idx0.find(prefix) != -1:
            return df._index_str_to_date_season(market=market)
    return df._index_str_to_date_season()


def _fetch_datekey(
    market: str,
    detail: bool,
) -> pd.DataFrame:
    """Fetch the disclosure-date or deadline DataFrame for the given market."""
    from finlab import data

    if market == "tw_stock":
        if detail:
            return data.get("etl:financial_statements_disclosure_dates").copy()
        return data.get("etl:financial_statements_deadline").copy()

    if market == "us_stock_all":
        return data.get("us_fundamental_all:datekey").copy()

    if market in ("us_stock", "jp_stock", "hk_stock", "kr_stock", "uk_stock"):
        region = market.split("_", maxsplit=1)[0]
        return data.get(f"{region}_income_statement:key_date").copy()

    raise ValueError(
        f"Unsupported market: {market}. "
        "Supported markets are 'tw_stock', 'us_stock', 'us_stock_all', "
        "'jp_stock', 'hk_stock', 'kr_stock', 'uk_stock'."
    )


def _labelled_like(data: pd.DataFrame, values: np.ndarray) -> pd.DataFrame:
    """Wrap a freshly built 2-D array in ``data``'s labels without copying it."""
    return data._constructor(
        values, index=data.index, columns=data.columns, copy=False
    ).__finalize__(data)


def _dense_boolean(data: pd.DataFrame) -> pd.DataFrame | None:
    """Represent homogeneous masks as one float block, with NaN for unknown."""
    dtypes = data.dtypes
    if not len(data.columns) or not (
        all(dtype == np.dtype(bool) for dtype in dtypes)
        or all(isinstance(dtype, pd.BooleanDtype) for dtype in dtypes)
    ):
        return None
    return _labelled_like(data, data.to_numpy(dtype=float, na_value=np.nan))


def _nullable_boolean(
    data: pd.DataFrame, values: np.ndarray, unknown: np.ndarray
) -> pd.DataFrame:
    """Nullable boolean frame from 2-D arrays, ~7x faster than ``astype``."""
    values, unknown = np.asfortranarray(values), np.asfortranarray(unknown)
    result = data._constructor(
        {
            i: pd.arrays.BooleanArray(values[:, i], unknown[:, i])
            for i in range(values.shape[1])
        },
        index=data.index,
    ).__finalize__(data)
    result.columns = data.columns  # Positional keys keep duplicate labels intact.
    return result


def _dense_to_nullable(data: pd.DataFrame) -> pd.DataFrame:
    """Inverse of ``_dense_boolean``: 1.0/0.0/NaN become True/False/NA."""
    x = data.to_numpy()
    return _nullable_boolean(data, x == 1, np.isnan(x))


def fill_unknown_boolean(
    data: pd.DataFrame | pd.Series,
) -> pd.DataFrame | pd.Series:
    """Turn nullable boolean columns into plain bool, reading unknown as False.

    Quarterly masks are unknown (``pd.NA``) before a company's first disclosure.
    numpy consumers such as ``np.where`` or ``.values.astype(float)`` cannot
    convert ``pd.NA``. Other dtypes are returned untouched.
    """
    if isinstance(data, pd.Series):
        if isinstance(data.dtype, pd.BooleanDtype):
            return data.fillna(False).astype(bool)
        return data

    nullable = [
        col for col, dtype in data.dtypes.items() if isinstance(dtype, pd.BooleanDtype)
    ]
    if not nullable:
        return data
    if len(nullable) == data.shape[1]:
        # Construct one dense block rather than retaining one block per symbol.
        return _labelled_like(data, data.to_numpy(dtype=bool, na_value=False))
    return data.fillna(dict.fromkeys(nullable, False)).astype(
        dict.fromkeys(nullable, bool)
    )


def _safe_ffill(df: pd.DataFrame) -> pd.DataFrame:
    """Forward-fill without touching deprecated pandas 3+ future options."""
    pandas_major = int(pd.__version__.split(".", maxsplit=1)[0])
    future_options = getattr(pd.options, "future", None) if pandas_major < 3 else None
    if (
        future_options is not None
        and getattr(future_options, "no_silent_downcasting", None) is not None
    ):
        with pd.option_context("future.no_silent_downcasting", True):
            return df.ffill()
    return df.ffill()


def _apply_truncation(ret: pd.DataFrame) -> pd.DataFrame:
    """Apply truncation window if configured in finlab.data."""
    try:
        from finlab import data as finlab_data
    except ImportError:
        return ret

    t_start = getattr(finlab_data, "truncate_start", None)
    t_end = getattr(finlab_data, "truncate_end", None)
    if t_start is None and t_end is None:
        return ret

    start_ts = pd.to_datetime(t_start) if t_start is not None else None
    end_ts = pd.to_datetime(t_end) if t_end is not None else None

    if start_ts is not None and end_ts is not None:
        return ret.loc[(ret.index >= start_ts) & (ret.index <= end_ts)]
    if start_ts is not None:
        return ret.loc[ret.index >= start_ts]
    return ret.loc[ret.index <= end_ts]


def _latest_period_only(rows: pd.DataFrame, col_name: str) -> pd.DataFrame:
    """Per symbol and disclosure date keep one row, never older than a period already public.

    A late-filed older period (or several periods filed on one day) must not replace
    a newer period. Such stale rows keep their date (the output index is unchanged)
    but lose their value, so the newer period is carried forward instead.
    """
    period = pd.Series(pd.factorize(rows["date"], sort=True)[0], index=rows.index)
    order = rows.assign(_period=period).sort_values(
        [col_name, "disclosures", "_period"]
    )
    known = order["disclosures"].notna()
    # Only a period that actually carries a value counts as public.
    published = known & order["value"].notna()
    newest = (
        order["_period"].where(published).groupby(order[col_name], sort=False).cummax()
    )
    stale = known & (order["_period"] < newest)
    order["value"] = order["value"].mask(stale)
    # On a shared date keep the newest period that has a value, if any.
    order["_valued"] = order["value"].notna()
    order = order.sort_values([col_name, "disclosures", "_valued", "_period"])
    return order.drop_duplicates(["disclosures", col_name], keep="last").drop(
        columns=["_period", "_valued"]
    )
