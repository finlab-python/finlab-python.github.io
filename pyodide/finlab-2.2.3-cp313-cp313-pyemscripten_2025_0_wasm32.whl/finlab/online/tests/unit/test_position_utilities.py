"""Unit tests for Position utility behaviors."""

from __future__ import annotations

import datetime
import sys
import types
import warnings
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pandas as pd
import pytest

from finlab.online.enums import OrderCondition
from finlab.online.order_executor import Position
from finlab.online.position import ZeroShareAllocationWarning


def test_position_json_roundtrip(tmp_path: Path) -> None:
    pos = Position({"2330": 1})
    json_path = tmp_path / "position.json"

    pos.to_json(str(json_path))
    pos2 = Position.from_json(str(json_path))

    assert pos.position[0] == pos2.position[0]


def test_position_arithmetic_and_conditions() -> None:
    pos = Position({"2330": 1}) + Position({"2330": 1, "1101": 1})
    for order in pos.position:
        if order["stock_id"] == "2330":
            assert order["quantity"] == 2
        if order["stock_id"] == "1101":
            assert order["quantity"] == 1

    pos = Position.from_list(pos.to_list())
    for order in pos.position:
        if order["stock_id"] == "2330":
            assert order["quantity"] == 2
        if order["stock_id"] == "1101":
            assert order["quantity"] == 1

    pos = Position({"2330": Decimal("1.1")})
    pos = Position.from_list(pos.to_list())
    assert pos.position[0]["quantity"] == Decimal("1.1")

    pos = Position({"2330": 2}) - Position({"2330": 1, "1101": 1})
    for order in pos.position:
        if order["stock_id"] == "2330":
            assert order["quantity"] == 1
        if order["stock_id"] == "1101":
            assert order["quantity"] == -1

    pos = Position({"2330": 2}, day_trading_long=True)
    pos.fall_back_cash()
    assert pos.position[0]["stock_id"] == "2330"
    assert pos.position[0]["quantity"] == 2
    assert pos.position[0]["order_condition"] == OrderCondition.CASH

    pos = Position({"2330": 2}, margin_trading=True)
    assert pos.position[0]["order_condition"] == OrderCondition.MARGIN_TRADING

    pos = Position({"2330": -2}, margin_trading=True)
    assert pos.position[0]["order_condition"] == OrderCondition.CASH

    pos = Position({"2330": -2}, short_selling=True)
    assert pos.position[0]["order_condition"] == OrderCondition.SHORT_SELLING

    pos = Position({"2330": 2}, short_selling=True)
    assert pos.position[0]["order_condition"] == OrderCondition.CASH

    pos = Position.from_list(
        [{"stock_id": "2330", "quantity": 2, "order_condition": OrderCondition.CASH}]
    )
    pos2 = Position.from_dict(
        [{"stock_id": "2330", "quantity": 2, "order_condition": OrderCondition.CASH}]
    )
    assert pos.position[0] == pos2.position[0]


def test_position_from_weight() -> None:
    position = Position.from_weight(
        {"1101": 0.5, "2330": 0.5},
        fund=1_000_000,
        price={"1101": 50, "2330": 100},
    )
    expected = Position.from_list(
        [
            {
                "stock_id": "1101",
                "quantity": 10,
                "order_condition": OrderCondition.CASH,
            },
            {"stock_id": "2330", "quantity": 5, "order_condition": OrderCondition.CASH},
        ]
    )
    assert len((position - expected).position) == 0

    position = Position.from_weight(
        {"1101": 0.5, "2330": 0.5},
        fund=1_000_000,
        price={"1101": 30, "2330": 60},
        odd_lot=True,
        board_lot_size=100,
    )
    expected = Position.from_list(
        [
            {
                "stock_id": "1101",
                "quantity": Decimal("166.66"),
                "order_condition": OrderCondition.CASH,
            },
            {
                "stock_id": "2330",
                "quantity": Decimal("83.33"),
                "order_condition": OrderCondition.CASH,
            },
        ]
    )
    assert len((position - expected).position) == 0

    position = Position.from_weight(
        {"1101": -0.5, "2330": 0.5},
        fund=1_000_000,
        price={"1101": 30, "2330": 60},
        odd_lot=True,
        board_lot_size=100,
        short_selling=True,
    )
    expected = Position.from_list(
        [
            {
                "stock_id": "1101",
                "quantity": Decimal("-166.66"),
                "order_condition": OrderCondition.SHORT_SELLING,
            },
            {
                "stock_id": "2330",
                "quantity": Decimal("83.33"),
                "order_condition": OrderCondition.CASH,
            },
        ]
    )
    assert len((position - expected).position) == 0

    try:
        Position.from_weight(
            {"1101": 0.5, "2330": 0.5},
            fund=1_000_000,
            price={"1101": 30, "2330": 60},
            odd_lot=True,
            board_lot_size=30,
            margin_trading=True,
        )
        raise AssertionError
    except Exception:
        assert True


def _quantities(position: Position) -> dict[str, float]:
    return {p["stock_id"]: float(p["quantity"]) for p in position.to_list()}


def test_from_weight_warns_when_no_stock_affords_one_lot() -> None:
    with pytest.warns(ZeroShareAllocationWarning) as record:
        position = Position.from_weight(
            {"1101": 0.5, "2330": 0.5},
            fund=30_000,
            price={"1101": 40, "2330": 900},
            board_lot_size=1000,
        )

    message = str(record[0].message)
    assert "2 of 2" in message
    assert "2330 (one lot 900,000 vs allocated 15,000)" in message
    assert "no orders will be placed" in message
    assert "odd_lot=True" in message
    assert not any(_quantities(position).values())


def test_from_weight_warns_only_for_unaffordable_stocks() -> None:
    with pytest.warns(ZeroShareAllocationWarning) as record:
        position = Position.from_weight(
            {"1101": 0.5, "2330": 0.5},
            fund=200_000,
            price={"1101": 40, "2330": 900},
            board_lot_size=1000,
        )

    message = str(record[0].message)
    assert "1 of 2" in message
    assert "2330" in message and "1101" not in message
    assert "no orders will be placed" not in message
    assert _quantities(position) == {"1101": 2.0}


def test_from_weight_zero_share_warning_caps_examples() -> None:
    weights = {f"{1000 + i}": 0.2 for i in range(5)}
    price = dict.fromkeys(weights, 100)

    with pytest.warns(ZeroShareAllocationWarning) as record:
        Position.from_weight(weights, fund=50_000, price=price, board_lot_size=1000)

    message = str(record[0].message)
    assert "5 of 5" in message
    assert message.count("one lot") == 3


@pytest.mark.parametrize(
    ("fund", "odd_lot"),
    [(2_000_000, False), (30_000, True)],
    ids=["whole_lots_affordable", "odd_lot"],
)
def test_from_weight_no_zero_share_warning(fund: int, odd_lot: bool) -> None:
    with warnings.catch_warnings():
        warnings.simplefilter("error", ZeroShareAllocationWarning)
        Position.from_weight(
            {"1101": 0.5, "2330": 0.5},
            fund=fund,
            price={"1101": 40, "2330": 900},
            board_lot_size=1000,
            odd_lot=odd_lot,
        )


class _ReportMarket:
    def market_close_at_timestamp(self, timestamp):
        if isinstance(timestamp, pd.Timestamp):
            timestamp = timestamp.to_pydatetime()
        if timestamp.tzinfo is None:
            return timestamp.replace(tzinfo=datetime.timezone.utc)
        return timestamp.astimezone(datetime.timezone.utc)

    def get_board_lot_size(self):
        return 1000


def test_position_from_report_does_not_use_future_next_weights_after_stop_event() -> (
    None
):
    now = datetime.datetime.now(datetime.timezone.utc)
    weights = pd.Series([1.0], index=["2330"], name=now - datetime.timedelta(days=30))
    next_weights = pd.Series(
        [1.0], index=["1101"], name=now + datetime.timedelta(days=7)
    )
    report = SimpleNamespace(
        weights=weights,
        next_weights=next_weights,
        actions=pd.Series(["sl"], index=["2330"], dtype=object),
        next_trading_date=now - datetime.timedelta(days=1),
        market=_ReportMarket(),
    )

    cloud_report_module = types.ModuleType("finlab.portfolio.cloud_report")
    cloud_report_module.CloudReport = type("CloudReport", (), {})
    portfolio_module = types.ModuleType("finlab.portfolio")
    portfolio_module.cloud_report = cloud_report_module

    with patch.dict(
        sys.modules,
        {
            "finlab.portfolio": portfolio_module,
            "finlab.portfolio.cloud_report": cloud_report_module,
        },
    ):
        position = Position.from_report(
            report,
            fund=1_000_000,
            price={"2330": 100, "1101": 50},
            odd_lot=True,
        )

    assert position.position == []


def test_position_from_report_keeps_current_weights_not_stopped() -> None:
    now = datetime.datetime.now(datetime.timezone.utc)
    weights = pd.Series(
        [0.25, 0.25, 0.25, 0.25],
        index=["9905 大華", "2897 王道銀行", "2916 滿心", "8433 弘帆"],
        name=now - datetime.timedelta(days=30),
    )
    next_weights = pd.Series(
        [0.25, 0.25, 0.25, 0.25],
        index=["1342", "2248", "2432", "2637"],
        name=now + datetime.timedelta(days=7),
    )
    report = SimpleNamespace(
        weights=weights,
        next_weights=next_weights,
        actions=pd.Series(
            ["sl_", "sl_", "sl"],
            index=["4442 竣邦-KY", "2851 中再保", "2916 滿心"],
            dtype=object,
        ),
        next_trading_date=now - datetime.timedelta(days=1),
        market=_ReportMarket(),
    )

    cloud_report_module = types.ModuleType("finlab.portfolio.cloud_report")
    cloud_report_module.CloudReport = type("CloudReport", (), {})
    portfolio_module = types.ModuleType("finlab.portfolio")
    portfolio_module.cloud_report = cloud_report_module

    with patch.dict(
        sys.modules,
        {
            "finlab.portfolio": portfolio_module,
            "finlab.portfolio.cloud_report": cloud_report_module,
        },
    ):
        position = Position.from_report(
            report,
            fund=1_000_000,
            price={"9905": 21.3, "2897": 10.15, "2916": 46.0, "8433": 57.5},
            odd_lot=True,
        )

    assert {p["stock_id"] for p in position.position} == {"9905", "2897", "8433"}


def test_custom_allocation_controls_position_quantity() -> None:
    allocator = Mock(return_value=({"2330": 7001}, 0))
    pos = Position.from_weight(
        {"2330": 1.0},
        fund=1_000_000,
        price={"2330": 100},
        allocation=allocator,
        odd_lot=True,
    )
    allocator.assert_called_once()
    weights, prices, fund = allocator.call_args.args
    assert weights.to_dict() == {"2330": 1.0}
    assert prices.to_dict() == {"2330": 100_000}
    assert fund == 1_000_000_000
    assert pos.position[0]["quantity"] == Decimal("7.001")


def test_from_report_forwards_custom_allocation() -> None:
    weights = pd.Series({"2330": 1.0}, name=pd.Timestamp("2024-01-01", tz="UTC"))
    report = SimpleNamespace(
        weights=weights,
        next_weights=weights.copy(),
        actions=pd.Series(dtype=object),
        next_trading_date=pd.Timestamp("2100-01-01", tz="UTC"),
        market=_ReportMarket(),
    )
    allocator = Mock(return_value=({"2330": 7}, 0))
    position = Position.from_report(
        report, fund=1_000_000, price={"2330": 100}, allocation=allocator
    )
    allocator.assert_called_once()
    assert allocator.call_args.args[0].to_dict() == {"2330": 1.0}
    assert position.position[0]["quantity"] == Decimal("7")
