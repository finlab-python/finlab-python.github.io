"""``finlab.online`` now loads the separate open-source package finlab-online.

Every old import path keeps working: ``finlab.online`` and each module under it
(``finlab.online.order_executor``, ``finlab.online.sinopac_account``,
``finlab.online.core.position`` ...) is the same module object as its
``finlab_online`` counterpart, so ``isinstance`` checks and monkeypatching agree.
"""

from __future__ import annotations

import importlib
import importlib.util
import sys
from importlib.machinery import ModuleSpec
from typing import TYPE_CHECKING

from finlab.trial_notice import _english, _once

if TYPE_CHECKING:
    from types import ModuleType

_ALIAS = "finlab.online"
_TARGET = "finlab_online"


def _missing_message() -> str:
    if _english():
        return (
            "FinLab order execution lives in the separate open-source package "
            "finlab-online. Install it with `pip install finlab-online`; "
            "existing code works unchanged."
        )
    return (
        "finlab 的下單功能在獨立的開源套件 finlab-online。"
        "請先執行 pip install finlab-online，現有程式不用改。"
    )


def _show_move_notice() -> None:
    """Tell ordering users, once per machine, before finlab stops installing it."""
    if not _once("finlab-online-moved"):
        return
    if _english():
        print(
            "Note: FinLab order execution has moved to the separate open-source "
            "package finlab-online; existing code keeps working. Installing finlab "
            "still installs it for now. In about two weeks, new finlab releases will "
            "stop installing it, so add `pip install finlab-online` when you set up "
            "a new environment (for example Colab, Docker or a new virtualenv)."
        )
    else:
        print(
            "提醒：finlab 的下單功能已移到獨立的開源套件 finlab-online，現有程式不用改。"
            "目前安裝 finlab 會一併裝好它；約兩週後的新版 finlab 不再自動安裝，"
            "在新環境（例如 Colab、Docker、新的虛擬環境）請先執行 pip install finlab-online。"
        )


class _AliasFinder:
    """Load ``finlab.online.X`` as the already-importable ``finlab_online.X``."""

    def find_spec(
        self,
        fullname: str,
        path: object = None,
        target: object = None,
    ) -> ModuleSpec | None:
        if not fullname.startswith(_ALIAS + "."):
            return None
        real = _TARGET + fullname[len(_ALIAS) :]
        if importlib.util.find_spec(real) is None:
            return None
        return ModuleSpec(fullname, self, loader_state=real)

    def create_module(self, spec: ModuleSpec) -> ModuleType:
        module = importlib.import_module(spec.loader_state)
        spec.loader_state = module.__spec__
        return module

    def exec_module(self, module: ModuleType) -> None:
        # The import system stamped the alias spec on the real module; put its own back.
        module.__spec__ = module.__spec__.loader_state


try:
    _impl = importlib.import_module(_TARGET)
except ModuleNotFoundError as error:
    if error.name != _TARGET:
        raise
    raise ModuleNotFoundError(_missing_message(), name=_TARGET) from None

if not any(type(finder).__name__ == "_AliasFinder" for finder in sys.meta_path):
    # Ahead of the path finder, which would otherwise load a second copy of each file.
    sys.meta_path.insert(0, _AliasFinder())
_show_move_notice()
sys.modules[_ALIAS] = _impl
