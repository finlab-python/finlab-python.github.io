"""DataFrame processing: index normalisation, stock-column cleanup, truncation."""

from __future__ import annotations

import warnings
from typing import Any, Final

import numpy as np
import pandas as pd

import finlab.dataframe

from .context import _default_context

__all__ = [
    "process_data",
]

# ---------------------------------------------------------------------------
# Index helpers
# ---------------------------------------------------------------------------


def has_index_name(df: pd.DataFrame, name: str) -> bool:
    """Check if the DataFrame has a specific index name (single or MultiIndex)."""
    if df.index.name == name:
        return True
    return bool(isinstance(df.index, pd.MultiIndex) and name in df.index.names)


# Suffix of TW tables that carry the latest corrected values under the original
# key_date, alongside a ``revised_at`` item. They share the index shape of the
# locked (first-published) table with the same base name.
_TW_REVISED_TABLE_SUFFIX: Final = "_revised"
# Item of a revised table: when the row was last corrected, NaT if never.
_REVISED_AT_ITEM: Final = "revised_at"

# These are issuer fiscal coordinates, not calendar quarters. The source name
# stays in the label so arithmetic/copies still route to their own datekeys.
FISCAL_TABLE_POSTFIX: Final = {
    "us_income_statement_fiscal": "-US-FISCAL-IS",
    "us_balance_sheet_fiscal": "-US-FISCAL-BS",
    "us_cash_flow_fiscal": "-US-FISCAL-CF",
}

_TW_REVISABLE_TABLE_INDEX_TRANSFORMERS: Final[dict[str, Any]] = {
    "monthly_revenue": lambda df: df._index_to_business_day(),
    "rotc_monthly_revenue": lambda df: df._index_to_business_day(),
    "financial_statement": lambda df: df._index_date_to_str_season(),
}

_TW_REVISED_TABLE_INDEX_TRANSFORMERS: Final[dict[str, Any]] = {
    f"{table}{_TW_REVISED_TABLE_SUFFIX}": transformer
    for table, transformer in _TW_REVISABLE_TABLE_INDEX_TRANSFORMERS.items()
}

# Table index transformations for special data types
TABLE_INDEX_TRANSFORMERS: Final[dict[str, Any]] = {
    **{
        table: lambda df, postfix=postfix: df._index_date_to_str_season(postfix)
        for table, postfix in FISCAL_TABLE_POSTFIX.items()
    },
    **_TW_REVISABLE_TABLE_INDEX_TRANSFORMERS,
    **_TW_REVISED_TABLE_INDEX_TRANSFORMERS,
    "fundamental_features": lambda df: df._index_date_to_str_season(),
    "us_fundamental": lambda df: df._index_date_to_str_season("-US"),
    "us_fundamental_ART": lambda df: df._index_date_to_str_season("-US"),
    "us_fundamental_all": lambda df: df._index_date_to_str_season("-US-ALL"),
    "us_fundamental_all_ART": lambda df: df._index_date_to_str_season("-US-ALL"),
    **{
        f"{r}_{t}": lambda df, postfix=f"-{r.upper()}": df._index_date_to_str_season(  # noqa: B008
            postfix
        )
        for r in ("us", "jp", "hk", "kr", "uk")
        for t in ("income_statement", "balance_sheet", "cash_flow")
    },
}

# PMI/NMI tables whose dates are aligned to the next trading day.
_TRADING_DAY_ALIGNED_TABLES: Final[frozenset[str]] = frozenset(
    {"tw_total_pmi", "tw_total_nmi", "tw_industry_nmi", "tw_industry_pmi"}
)

# Tables whose dates move to the next business day once the index is converted.
_BUSINESS_DAY_TABLES: Final[frozenset[str]] = frozenset(
    f"{table}{suffix}"
    for table in ("monthly_revenue", "rotc_monthly_revenue")
    for suffix in ("", _TW_REVISED_TABLE_SUFFIX)
)

# Tables whose processed dates can be later than their raw ``date``, so a raw
# date before a start bound can still land inside it.
DATE_SHIFTED_TABLES: Final[frozenset[str]] = (
    _TRADING_DAY_ALIGNED_TABLES | _BUSINESS_DAY_TABLES
)

_TW_QUARTERLY_TABLES: Final[frozenset[str]] = frozenset(
    {
        "financial_statement",
        f"financial_statement{_TW_REVISED_TABLE_SUFFIX}",
        "fundamental_features",
    }
)


def _should_mask_quarterly(table_name: str, effective_truncate_end: str | None) -> bool:
    """Check if TW quarterly disclosure-date masking should be applied."""
    return table_name in _TW_QUARTERLY_TABLES and effective_truncate_end is not None


def _is_revised_table(table_name: str) -> bool:
    """Check if *table_name* is a TW revised table."""
    return table_name in _TW_REVISED_TABLE_INDEX_TRANSFORMERS


# ---------------------------------------------------------------------------
# Column / index normalisation
# ---------------------------------------------------------------------------


def _set_dataframe_index(df: pd.DataFrame, rebuilt: bool = False) -> pd.DataFrame:
    """Set appropriate index based on available columns.

    *rebuilt*: the index transformer rebuilds the frame from ``.values``, so its
    block structure here does not reach the caller.
    """
    from finlab.compat import CANONICAL_NAME, LEGACY_NAME, validate_no_dual_columns

    # Accept either 'symbol' or 'stock_id'
    id_col = next((c for c in (CANONICAL_NAME, LEGACY_NAME) if c in df.columns), None)

    if id_col is not None and "date" in df.columns:
        df = df.set_index([id_col, "date"])
    elif "date" in df.columns:
        dates = df["date"]
        if (
            rebuilt
            and isinstance(dates.dtype, np.dtype)
            and (df.dtypes == dates.dtype).all()
        ):
            # A table of dates keeps them in one block with its values, which
            # set_index would split into one block per column only to be rebuilt.
            df = df.drop(columns="date").set_axis(pd.Index(dates))
        else:
            df = df.set_index("date")
    elif id_col is not None:
        df = df.set_index(id_col)

    # Normalize index name from 'stock_id' -> 'symbol'
    if isinstance(df.index, pd.MultiIndex):
        new_names = [CANONICAL_NAME if n == LEGACY_NAME else n for n in df.index.names]
        df.index.names = new_names
    elif df.index.name == LEGACY_NAME:
        df.index.name = CANONICAL_NAME

    validate_no_dual_columns(df)
    return df


def _normalize_stock_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Remove stock names from columns and combine duplicate stock histories."""
    if not (df.columns.str.find(" ") != -1).all():
        return df

    df.columns = df.columns.str.split(" ").str[0]

    if not pd.api.types.is_numeric_dtype(df.values):
        return df.fillna(np.nan).transpose().groupby(level=0).last().transpose()
    # Only a stock listed under two names has anything to average.
    twice = df.columns.duplicated(keep=False)
    if not twice.any():
        return df.sort_index(axis=1).astype(float)
    merged = df.loc[:, twice].transpose().groupby(level=0).mean().transpose()
    return pd.concat([df.loc[:, ~twice].astype(float), merged], axis=1).sort_index(
        axis=1
    )


# ---------------------------------------------------------------------------
# Truncation
# ---------------------------------------------------------------------------


def _apply_truncate_if_any(
    df: pd.DataFrame, skip_end: bool = False, skip_start: bool = False
) -> pd.DataFrame:
    """Truncate DataFrame to context date range if DatetimeIndex."""
    ctx = _default_context
    if isinstance(df.index, pd.DatetimeIndex):
        start = None if skip_start else ctx.truncate_start
        end = None if skip_end else ctx.truncate_end
        return df.loc[slice(start, end)]
    return df


def _mask_undisclosed_quarterly(
    df: pd.DataFrame, truncate_end_str: str, *, missing_is_value: bool = False
) -> pd.DataFrame:
    """NaN out cells where stock had not disclosed at truncate_end. Drop empty rows.

    A row is empty when all its cells are NaN, or, with *missing_is_value*
    (NaN is a disclosed value such as a never-corrected ``revised_at``), when
    no stock had disclosed it.
    """
    from .get import get

    disclosure_dates = get("etl:financial_statements_disclosure_dates")
    end_ts = pd.Timestamp(truncate_end_str)

    common_cols = df.columns.intersection(disclosure_dates.columns)
    if common_cols.empty:
        return df

    aligned = disclosure_dates.reindex(index=df.index, columns=common_cols)

    # True where stock disclosed AFTER cutoff -> should be NaN
    # NaT comparison returns False -> NaT cells are kept (no info = assume disclosed)
    undisclosed = aligned > end_ts

    result = df.copy()
    result.loc[:, common_cols] = df[common_cols].where(~undisclosed)
    empty = undisclosed.all(axis=1) if missing_is_value else result.isna().all(axis=1)
    return finlab.dataframe.FinlabDataFrame(result.loc[~empty])


def _cap_future_revisions(df: pd.DataFrame, truncate_end_str: str) -> pd.DataFrame:
    """Cap ``revised_at`` stamps later than truncate_end at truncate_end.

    The values themselves stay the latest corrections and cannot be rolled back,
    so such cells must still read as revised (not NaT): a ``revised_at.isna()``
    filter then drops them exactly as it does on the full history, while the
    actual future revision date stays hidden.
    """
    truncate_end = pd.Timestamp(truncate_end_str)
    return df.mask(df > truncate_end, truncate_end)


def _warn_revised_values_not_rolled_back(dataset: str, truncate_end_str: str) -> None:
    """Warn that truncation cannot restore the values known before a correction."""
    from .get import _stacklevel_outside

    warnings.warn(
        f"{dataset}: truncate_end={truncate_end_str} cannot restore values known "
        "then; they are still the latest corrections (revised_at caps later "
        "revisions at truncate_end). Use the locked table (without '_revised') "
        "for point-in-time backtests.",
        UserWarning,
        stacklevel=_stacklevel_outside(),
    )


# ---------------------------------------------------------------------------
# process_data -- main processing entry point
# ---------------------------------------------------------------------------


def _plain_categories(df: pd.DataFrame) -> pd.DataFrame:
    """Arrow-backed categories cost a pyarrow ``take`` every time pandas reads the column."""
    for name, dtype in df.dtypes.items():
        if isinstance(dtype, pd.CategoricalDtype):
            column = df[name].cat
            df[name] = pd.Categorical.from_codes(
                column.codes,
                pd.Index(column.categories, dtype=object),
                ordered=column.ordered,
            )
    return df


def process_data(dataset: str, df: pd.DataFrame) -> pd.DataFrame:
    """Process raw data into standardized format."""
    table_name = dataset.split(":", maxsplit=1)[0]
    # Index transformers rebuild a non-empty wide table from its values.
    rebuilt = ":" in dataset and len(df) > 0 and table_name in TABLE_INDEX_TRANSFORMERS
    df = _set_dataframe_index(df, rebuilt)

    # Special case (to align with tutorial)
    if dataset == "broker_transactions":
        df = df.reset_index().set_index("date")

    if ":" in dataset:
        df.columns.name = "symbol"
    else:
        # Table format
        df = df.reset_index()
        if "stock_id" in df.columns and "symbol" not in df.columns:
            df = df.rename(columns={"stock_id": "symbol"})
        # Backward compat: add 'stock_id' alias column for table format
        if "symbol" in df.columns and "stock_id" not in df.columns:
            df["stock_id"] = df["symbol"]

    if not has_index_name(df, "date"):
        return _plain_categories(df)

    # Align PMI/NMI data to trading dates
    if table_name in _TRADING_DAY_ALIGNED_TABLES and isinstance(
        df.index[0], pd.Timestamp
    ):
        from .calendar import _price_calendar
        from .get import get

        trading = _price_calendar()
        close = get("price:收盤價") if trading is None else pd.DataFrame(index=trading)
        df.index = df.index.map(
            lambda d: (
                d
                if len(close.loc[d:]) == 0 or d < close.index[0]
                else close.loc[d:].index[0]
            )
        )

    df = _normalize_stock_columns(df)
    df = finlab.dataframe.FinlabDataFrame(df)

    effective_truncate_end = _default_context.truncate_end
    needs_quarterly_masking = _should_mask_quarterly(table_name, effective_truncate_end)

    if table_name not in FISCAL_TABLE_POSTFIX:
        # Rows moved to the next business day may land after truncate_start.
        df = _apply_truncate_if_any(
            df,
            skip_end=needs_quarterly_masking,
            skip_start=table_name in _BUSINESS_DAY_TABLES,
        )

    # Apply table-specific index transformations
    if table_name in TABLE_INDEX_TRANSFORMERS:
        df = TABLE_INDEX_TRANSFORMERS[table_name](df)
        # Moving dates to the next business day can pass truncate_end.
        df = _apply_truncate_if_any(df, skip_end=needs_quarterly_masking)

    df = _mask_fiscal_range(dataset, df)
    if effective_truncate_end is None:
        return df
    return _mask_after_truncate_end(
        dataset, df, effective_truncate_end, quarterly=needs_quarterly_masking
    )


def _mask_fiscal_range(dataset: str, df: pd.DataFrame) -> pd.DataFrame:
    """Apply fiscal bounds to disclosure dates, retaining the date lookup itself."""
    from finlab import data

    start, end = _default_context.truncate_start, _default_context.truncate_end
    table, _, item = dataset.partition(":")
    if (
        table not in FISCAL_TABLE_POSTFIX
        or item == "key_date"
        or (start is None and end is None)
    ):
        return df
    dates = data.get(f"{table}:key_date").reindex(index=df.index, columns=df.columns)
    disclosed = dates.notna()
    if start is not None:
        disclosed &= dates.ge(pd.Timestamp(start))
    if end is not None:
        disclosed &= dates.le(pd.Timestamp(end))
    rows = disclosed.any(axis=1)
    return finlab.dataframe.FinlabDataFrame(df.loc[rows].where(disclosed.loc[rows]))


def _mask_after_truncate_end(
    dataset: str, df: pd.DataFrame, truncate_end_str: str, *, quarterly: bool
) -> pd.DataFrame:
    """Hide what was not yet known at truncate_end, once the index is converted."""
    table_name, _, item = dataset.partition(":")
    is_revised_at = _is_revised_table(table_name) and item == _REVISED_AT_ITEM
    # For TW quarterly tables: disclosure-date-aware masking after string index conversion
    if quarterly:
        df = _mask_undisclosed_quarterly(
            df, truncate_end_str, missing_is_value=is_revised_at
        )
    if is_revised_at:
        df = _cap_future_revisions(df, truncate_end_str)
    elif _is_revised_table(table_name):
        _warn_revised_values_not_rolled_back(dataset, truncate_end_str)
    return df
