"""Delisted holdings: assets announced for delisting or whose prices end early.

A held asset with no price for the rest of the data can never be traded
again. Left alone, the engine freezes its value at the last price, re-buys it
at every rebalance and reports its trades with a NaN return. This module finds
the bar on which each such asset has to be sold instead:

- With an exchange delisting notice (``Market.get_delisting_notices``), the
  first priced bar after the announcement, which is when the market knows.
- Without one, the last priced bar, if the prices end early enough to rule
  out a trading halt.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from finlab.core import delisting_core

if TYPE_CHECKING:
    import pandas as pd

# Trailing bars without a price before an asset without a notice counts as
# delisted. A shorter gap at the end of the data may be a trading halt that has
# not resumed yet.
DELISTING_MIN_TRAILING_BARS = 20

# Engine marker for an asset that is not delisted.
NOT_DELISTED = -1


def find_delisting_bars(
    price: pd.DataFrame, columns: pd.Index, notices: pd.DataFrame
) -> np.ndarray:
    """Return, per column, the price row on which a delisted asset is sold.

    ``len(price)`` means the notice came after the last priced row, so only
    rebalances after the data drop the asset. Assets that are not delisted,
    including ones halted and later resumed, get ``NOT_DELISTED``.
    """
    values = price.to_numpy(dtype=float)
    column_indices = price.columns.get_indexer(columns)
    last_row = len(price) - 1
    last_priced = delisting_core.last_priced(values, column_indices)
    ever_priced = last_priced >= 0
    # Keep argmax's all-False convention when matching notices for unpriced assets.
    last_priced[~ever_priced] = last_row
    prices_ended = ever_priced & (last_priced <= last_row - DELISTING_MIN_TRAILING_BARS)
    bars = np.where(prices_ended, last_priced, NOT_DELISTED).astype(np.int64)
    if notices.empty:
        return bars

    noticed, announced_bars, delisted_in_data = _notices_by_column(
        price.index, columns, notices, ever_priced, last_priced
    )
    for column, announced_bar, delisted in zip(
        noticed, announced_bars, delisted_in_data, strict=True
    ):
        if announced_bar <= last_priced[column]:
            bars[column] = delisting_core.first_priced(
                values, column_indices[column], announced_bar
            )
        elif delisted:
            bars[column] = last_priced[column]
        else:
            bars[column] = len(price)
    return bars


def _notices_by_column(
    index: pd.DatetimeIndex,
    columns: pd.Index,
    notices: pd.DataFrame,
    ever_priced: np.ndarray,
    last_priced: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Match each column to the notice of the delisting that ended its prices.

    A notice applies when the asset last traded before its delisting date, so
    notices for an earlier listing under a reused symbol, or for a transfer to
    another board, are ignored. Returns the matched columns, the first price
    row after each announcement, and whether the delisting falls in the data.
    """
    column_of = columns.get_indexer(notices.index)
    known = column_of >= 0
    column_of = column_of[known]
    delisted = notices["delisted"].to_numpy()[known]
    applies = ever_priced[column_of] & (index[last_priced[column_of]] < delisted)

    order = np.argsort(delisted[applies], kind="stable")
    matched, first = np.unique(column_of[applies][order], return_index=True)
    announced = notices["announced"].to_numpy()[known][applies][order][first]
    delisted = delisted[applies][order][first]
    return (
        matched,
        index.searchsorted(announced, side="right"),
        delisted <= index[-1],
    )


def exclude_delisted_holdings(
    position: pd.DataFrame,
    price: pd.DataFrame,
    notices: pd.DataFrame,
    *,
    rebalance_on_delisting: bool,
) -> tuple[pd.DataFrame, np.ndarray]:
    """Zero delisted assets from rebalances that execute on or after their sale.

    A signal executes on the first price row after its date. With
    ``rebalance_on_delisting`` (``resample=None``, where every position change
    rebalances), a row is added so the portfolio rebalances on the sale day, as
    if the signal had turned off the day before. Otherwise the engine sells the
    asset on that day and its cash waits for the next rebalance.

    Returns the position and the engine's per-column sale rows.
    """
    delisting_bars = find_delisting_bars(price, position.columns, notices)
    delisted = np.flatnonzero(delisting_bars != NOT_DELISTED)
    if len(delisted) == 0:
        return position, delisting_bars

    bars = delisting_bars[delisted]
    held_at_delisting, held_after = _holdings_around_delisting(
        position, price, delisted, bars
    )
    affected = held_at_delisting | held_after
    if not affected.any():
        return position, delisting_bars

    position = position.astype(float)
    if rebalance_on_delisting:
        signal_dates = price.index[bars[held_at_delisting & (bars > 0)] - 1]
        position = position.reindex(position.index.union(signal_dates), method="ffill")

    execution_bars = price.index.searchsorted(position.index, side="right")
    unexecutable = execution_bars[:, None] >= bars[None, :]
    position.iloc[:, delisted] = position.iloc[:, delisted].mask(unexecutable, 0.0)

    return position, delisting_bars


def _holdings_around_delisting(
    position: pd.DataFrame, price: pd.DataFrame, columns: np.ndarray, bars: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Whether each column is weighted on its sale row, and on any row after."""
    execution_bars = price.index.searchsorted(position.index, side="right")
    weights = position.iloc[:, columns].astype(float).fillna(0).to_numpy()
    rows_in_effect = execution_bars.searchsorted(bars, side="right") - 1
    held_at_bar = (rows_in_effect >= 0) & (
        weights[rows_in_effect, np.arange(len(bars))] != 0
    )
    held_after = ((execution_bars[:, None] > bars[None, :]) & (weights != 0)).any(
        axis=0
    )
    return held_at_bar, held_after
