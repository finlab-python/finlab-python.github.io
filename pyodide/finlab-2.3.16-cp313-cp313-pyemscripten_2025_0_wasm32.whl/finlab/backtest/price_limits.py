"""Daily one-price limit locks for Taiwan ordinary shares."""

import numpy as np
import pandas as pd

from finlab import data
from finlab.market import Market

# Official limits in these tables replace the computed band on event days.
_EVENT_TABLES = (
    "dividend_tse",
    "dividend_otc",
    "capital_reduction_tse",
    "capital_reduction_otc",
    "par_value_change_tse",
    "par_value_change_otc",
)


def execution_locks(
    market: Market, price: pd.DataFrame, columns: pd.Index
) -> np.ndarray:
    """Return +1 for blocked buys, -1 for blocked sells, zero otherwise."""
    close = pd.DataFrame(market.get_price("close", adj=False)).reindex(columns=columns)
    reference = close.shift().to_numpy()
    adjusted = pd.DataFrame(market.get_price("close", adj=True)).reindex_like(close)
    factor = adjusted / close
    regular = np.isclose(factor, factor.shift(), rtol=1e-8, atol=0)
    rate = np.where(close.index < pd.Timestamp("2015-06-01"), 0.07, 0.10)[:, None]
    quoted = close.notna()
    # Exclude funds, warrants, and the initial five quoted sessions.
    flat = quoted & (quoted.cumsum().shift(fill_value=0) >= 5)
    flat.loc[:, ~columns.astype(str).str.fullmatch(r"[1-9]\d{3}")] = False
    for field in ("open", "high", "low"):
        raw = pd.DataFrame(market.get_price(field, adj=False)).reindex_like(close)
        flat &= np.isclose(raw, close, rtol=0, atol=1e-8)
    items = ((1, "漲停價格"), (-1, "跌停價格"))
    names = [f"{table}:{item}" for _, item in items for table in _EVENT_TABLES]
    events = dict(zip(names, data.gets(*names, progress="silent"), strict=True))
    locks = np.zeros(close.shape, dtype=np.int8)
    for direction, item in items:
        value = reference * (1 + direction * rate)
        tick = np.select(
            [value < 10, value < 50, value < 100, value < 500, value < 1000],
            [0.01, 0.05, 0.1, 0.5, 1],
            default=5,
        )
        # The exchange permits at least one cent, with a one-cent price floor.
        if direction == 1:
            limit = np.floor(np.round(value / tick, 8)) * tick
            limit = np.maximum(limit, reference + 0.01)
        else:
            limit = np.ceil(np.round(value / tick, 8)) * tick
            limit = np.maximum(0.01, np.minimum(limit, reference - 0.01))
        limit = np.where(regular, limit, np.nan)
        for table in _EVENT_TABLES:
            official = pd.DataFrame(events[f"{table}:{item}"])
            rows = close.index.get_indexer(official.index)
            cols = columns.get_indexer(official.columns)
            values = official.to_numpy(dtype=float)
            r, c = np.nonzero((values > 0) & (rows >= 0)[:, None] & (cols >= 0))
            limit[rows[r], cols[c]] = values[r, c]
        locks[flat & np.isclose(close, limit, rtol=0, atol=1e-8)] = direction
    return (
        pd.DataFrame(locks, index=close.index, columns=columns)
        .reindex(price.index, fill_value=0)
        .to_numpy(dtype=np.int8)
    )
