from __future__ import annotations

from typing import TYPE_CHECKING, Any

__all__ = [
    "align_to_feature",
    "daytrading_percentage",
    "excess_over_mean",
    "excess_over_median",
    "maximum_adverse_excursion",
    "maximum_favorable_excursion",
    "return_percentage",
]

if TYPE_CHECKING:
    import pandas as pd

from finlab import config
from finlab.ml.utils import resampler


def align_to_feature(index: pd.Index, df: pd.DataFrame) -> pd.Series:
    ret: pd.Series = df.unstack().swaplevel(0, 1).reindex(index)
    ret.index = ret.index.set_names(["datetime", "instrument"])
    return ret


def daytrading_percentage(
    index: pd.Index,
    resample: str | None = "D",
    **kwargs: Any,
) -> pd.Series:
    """Calculate the percentage change of market prices over a given period.

    Args:
        index (pd.Index): A multi-level index of datetime and instrument.
        resample (str | None): The resample frequency for the output data. Defaults to "D".
        **kwargs: Additional arguments to be passed to the resampler function.

    Returns:
        pd.Series: A pd.Series containing the percentage change of stock prices.

    """

    market = config.get_market()
    if market is None:
        raise ValueError("Market is not configured. Set it via finlab.config.")

    adj_close = market.get_price("close", adj=True).shift(-1)
    adj_open = market.get_price("open", adj=True).shift(-1)
    uadj_close = resampler(adj_close, resample, **kwargs)
    uadj_open = resampler(adj_open, resample, **kwargs)

    ret = (uadj_close / uadj_open) - 1
    return align_to_feature(index, ret)


def return_percentage(
    index: pd.Index,
    resample: str | pd.DatetimeIndex | None = None,
    period: int = 1,
    trade_at_price: str = "close",
    bfill: bool = False,
    **kwargs: Any,
) -> pd.Series:
    """Calculate the percentage change of market prices over a given period.

    Args:
        index (pd.Index): A multi-level index of datetime and instrument.
        resample (str | pd.DatetimeIndex | None): The resample frequency or date anchors for the output data. Defaults to None.
        period (int): The number of periods to calculate the percentage change over. Defaults to 1.
            With resample=None, period counts trading days, even for weekly feature
            indexes. For weekly returns, pass the same resample frequency or explicit
            trading-date anchors as the features. 不帶 resample 時 period 是交易日數；
            週頻報酬須與特徵使用相同的重採樣頻率或交易日錨點。
        trade_at_price (str): The price for execution. Defaults to `close`.
        **kwargs: Additional arguments to be passed to the resampler function.

    Returns:
        pd.Series: A pd.Series containing the percentage change of stock prices.

    """

    market = config.get_market()
    if market is None:
        raise ValueError("Market is not configured. Set it via finlab.config.")

    adj = market.get_price(trade_at_price, adj=True).shift(-1)

    if bfill:
        not_listed = adj.notna().cumsum() == 0
        removed = (adj.notna()[::-1].cumsum() == 0)[::-1]
        adj = adj.bfill().where(~not_listed & ~removed)

    uadj = resampler(adj, resample, **kwargs)
    ret = (uadj.shift(-period) / uadj) - 1
    return align_to_feature(index, ret)


def maximum_adverse_excursion(
    index: pd.Index, period: int = 1, trade_at_price: str = "close"
) -> pd.Series:
    """Calculate the minimum forward return relative to the next row's entry price.

    For a signal at market-price row s, entry is the adjusted price at s+1.
    The window covers s+2 through s+period+1 (inclusive), using only
    trade_at_price: min(window) / entry - 1. The entry row is excluded, so
    the result can be positive; it is neither clipped at zero nor a
    peak-to-trough drawdown. Selecting open does not use intraday lows.

    A label becomes known only when the price at s+period+1 is available.
    Missing entry prices, missing window prices and incomplete future
    windows produce NaN. Complete windows at the start need no warm-up.
    These are future training targets, not features available at signal time.

    Args:
        index (pd.Index): A MultiIndex of datetime and instrument, including
            a single instrument if desired.
        period (int): Number of market-price rows in the forward window,
            normally trading days, regardless of feature frequency. Defaults to 1.
        trade_at_price (str): Adjusted price field used for both entry and
            window prices. Defaults to `close`. Prices come from the Market
            configured via finlab.config.set_market, including custom Markets.

    Returns:
        pd.Series: Forward minimum returns aligned to index, with index names
            datetime and instrument.

    """

    market = config.get_market()
    if market is None:
        raise ValueError("Market is not configured. Set it via finlab.config.")
    adj = market.get_price(trade_at_price, adj=True).shift(-1)
    ret = adj.rolling(period).min().shift(-period) / adj - 1
    ret = ret.reindex(index.levels[0], method="ffill")
    return align_to_feature(index, ret)


def maximum_favorable_excursion(
    index: pd.Index, period: int = 1, trade_at_price: str = "close"
) -> pd.Series:
    """Calculate the maximum favorable excursion of market prices over a given period.

    Args:
        index (pd.Index): A multi-level index of datetime and instrument.
        period (int): The number of periods to calculate the percentage change over. Defaults to 1.
        trade_at_price (str): The price for execution. Defaults to `close`.

    Returns:
        pd.Series: A pd.Series containing the maximum favorable excursion.

    """

    market = config.get_market()
    if market is None:
        raise ValueError("Market is not configured. Set it via finlab.config.")
    adj = market.get_price(trade_at_price, adj=True).shift(-1)
    ret = adj.shift(-period).rolling(period).max() / adj - 1
    ret = ret.reindex(index.levels[0], method="ffill")
    return align_to_feature(index, ret)


def excess_over_median(
    index: pd.Index,
    resample: str | None = None,
    period: int = 1,
    trade_at_price: str = "close",
    **kwargs: Any,
) -> pd.Series:
    """Calculate the excess over median of market prices over a given period.

    Args:
        index (pd.Index): A multi-level index of datetime and instrument.
        resample (str | None): The resample frequency for the output data. Defaults to None.
        period (int): The number of periods to calculate the percentage change over. Defaults to 1.
        trade_at_price (str): The price for execution. Defaults to `close`.
        **kwargs: Additional arguments to be passed to the resampler function.

    Returns:
        pd.Series: A pd.Series containing the percentage change of stock prices.

    """

    market = config.get_market()
    adj = market.get_price(trade_at_price, adj=True).shift(-1)
    uadj = resampler(adj, resample, **kwargs)
    ret = (uadj.shift(-period) / uadj) - 1
    ret = ret.subtract(ret.median(axis=1), axis=0)
    return align_to_feature(index, ret)


def excess_over_mean(
    index: pd.Index,
    resample: str | None = None,
    period: int = 1,
    trade_at_price: str = "close",
    **kwargs: Any,
) -> pd.Series:
    """Calculate the excess over mean of market prices over a given period.

    Args:
        index (pd.Index): A multi-level index of datetime and instrument.
        resample (str | None): The resample frequency for the output data. Defaults to None.
        period (int): The number of periods to calculate the percentage change over. Defaults to 1.
        trade_at_price (str): The price for execution. Defaults to `close`.
        **kwargs: Additional arguments to be passed to the resampler function.

    Returns:
        pd.Series: A pd.Series containing the percentage change of stock prices.

    """
    market = config.get_market()
    adj = market.get_price(trade_at_price, adj=True).shift(-1)
    uadj = resampler(adj, resample, **kwargs)
    ret = (uadj.shift(-period) / uadj) - 1
    ret = ret.subtract(ret.mean(axis=1), axis=0)
    return align_to_feature(index, ret)
