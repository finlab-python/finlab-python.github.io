from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .cloud_report import CloudReport, create_report_from_cloud
from .custom_report import create_custom_report, create_multi_asset_report
from .portfolio import Portfolio
from .trade_review import TradeReview

if TYPE_CHECKING:
    from .portfolio_sync_manager import PortfolioSyncManager

__all__: list[str] = [
    "CloudReport",
    "Portfolio",
    "PortfolioSyncManager",
    "TradeReview",
    "create_custom_report",
    "create_multi_asset_report",
    "create_report_from_cloud",
]


def __getattr__(name: str) -> Any:
    # Only syncing needs the separate order package, so reports import without it.
    if name == "PortfolioSyncManager":
        from .portfolio_sync_manager import PortfolioSyncManager

        return PortfolioSyncManager
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
