"""Expression nodes and tree helpers for lazy wide DataFrame evaluation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

    import pandas as pd

_NEEDS_HISTORY = 1


class Node:
    """Base of the expression tree."""


@dataclass
class SourceNode(Node):
    data: pd.DataFrame


@dataclass
class StorageSourceNode(Node):
    dataset: str
    storage: object
    loader: Callable[[], pd.DataFrame]
    index_loader: Callable[[], pd.Index] | None


@dataclass
class ScalarNode(Node):
    value: object


@dataclass
class UnaryNode(Node):
    child: Node
    method: str
    args: tuple[object, ...]
    kwargs: dict[str, object]
    lookback: int = 0


@dataclass
class ReindexNode(Node):
    child: Node
    args: tuple[object, ...]
    kwargs: dict[str, object]


@dataclass
class RollingNode(Node):
    child: Node
    window: int
    rolling_kwargs: dict[str, object]
    method: str
    method_args: tuple[object, ...]
    method_kwargs: dict[str, object]


@dataclass
class BinaryNode(Node):
    left: Node
    right: Node
    op: str


@dataclass
class GetitemNode(Node):
    child: Node
    key: object


def _nodes_in_value(value: object) -> list[Node]:
    if isinstance(value, Node):
        return [value]

    lazy_node = getattr(value, "_node", None)
    if isinstance(lazy_node, Node):
        return [lazy_node]

    if isinstance(value, dict):
        nodes: list[Node] = []
        for item in value.values():
            nodes.extend(_nodes_in_value(item))
        return nodes

    if isinstance(value, (tuple, list, set, frozenset)):
        nodes = []
        for item in value:
            nodes.extend(_nodes_in_value(item))
        return nodes

    return []


def _children(node: Node) -> list[Node]:
    """Return the child nodes of *node*."""
    if isinstance(node, UnaryNode):
        return [node.child, *_nodes_in_value(node.args), *_nodes_in_value(node.kwargs)]
    if isinstance(node, ReindexNode):
        return [node.child, *_nodes_in_value(node.args), *_nodes_in_value(node.kwargs)]
    if isinstance(node, RollingNode):
        return [
            node.child,
            *_nodes_in_value(node.rolling_kwargs),
            *_nodes_in_value(node.method_args),
            *_nodes_in_value(node.method_kwargs),
        ]
    if isinstance(node, BinaryNode):
        return [node.left, node.right]
    if isinstance(node, GetitemNode):
        kids = [node.child]
        if isinstance(node.key, Node):
            kids.append(node.key)
        return kids
    return []


def _walk_tree(node: Node, visitor: Callable[[Node], object]) -> None:
    """Depth-first traversal calling ``visitor(node)`` at each node."""
    visitor(node)
    for child in _children(node):
        _walk_tree(child, visitor)


SourceLike = SourceNode | StorageSourceNode


def _source_data(source: SourceLike, cache: dict | None = None) -> pd.DataFrame:
    """Return source dataframe, loading storage-backed sources per execution."""
    if isinstance(source, SourceNode):
        return source.data

    cache_key = ("__source_data__", id(source))
    if cache is not None and cache_key in cache:
        return cache[cache_key]

    data = source.loader()
    if cache is not None:
        cache[cache_key] = data
    return data


def _source_index(source: SourceLike, cache: dict | None = None) -> pd.Index:
    """Return source index without materializing storage-backed data."""
    if isinstance(source, SourceNode):
        return source.data.index

    data_key = ("__source_data__", id(source))
    if cache is not None and data_key in cache:
        return cache[data_key].index

    index_key = ("__source_index__", id(source))
    if cache is not None and index_key in cache:
        return cache[index_key]

    if source.index_loader is None:
        return _source_data(source, cache).index

    index = source.index_loader()
    if cache is not None:
        cache[index_key] = index
    return index


def _source_identity(source: SourceLike) -> int:
    if isinstance(source, SourceNode):
        return id(source.data)
    return id(source)


def _collect_sources(node: Node) -> list[SourceLike]:
    """Return all SourceNode instances in the tree, in walk order."""
    sources: list[SourceLike] = []
    _walk_tree(
        node,
        lambda n: (
            sources.append(n)
            if isinstance(n, (SourceNode, StorageSourceNode))
            else None
        ),
    )
    return sources


def _collect_full_index(node: Node, cache: dict | None = None) -> pd.Index:
    """Return the union of all source indexes in the tree.

    String-indexed sources are excluded when DatetimeIndex sources exist.
    String-only trees return their native index so callers can execute and
    convert the result after pandas operations preserve native semantics.
    """
    dt_indices: list[pd.Index] = []
    str_indices: list[pd.Index] = []
    from finlab.dataframe.core_index import _fiscal_datekey_table

    sources = _collect_sources(node)
    indexes = [_source_index(source, cache) for source in sources]
    freqs = [_index_str_frequency(index) for index in indexes]
    formats = {freq for freq in freqs if freq}
    # Two label formats have no shared labels, only dates.
    to_dates = len(formats) > 1 or (
        None in freqs and any(map(_fiscal_datekey_table, formats))
    )
    for source, index, freq in zip(sources, indexes, freqs, strict=True):
        if freq is None:
            dt_indices.append(index)
        elif to_dates:
            from finlab.dataframe.core import FinlabDataFrame, _on_dates

            source_df = FinlabDataFrame(_source_data(source, cache))
            dt_indices.append(_on_dates(source_df).index)
        else:
            str_indices.append(index)

    indices = dt_indices or str_indices
    if not indices:
        raise ValueError("No SourceNode found in the tree")
    result = indices[0]
    for idx in indices[1:]:
        result = result.union(idx)
    return result


def _str_freq(node: Node, cache: dict | None = None) -> str | None:
    """Return the string index frequency when all sources share it."""
    freqs = {
        _index_str_frequency(_source_index(source, cache))
        for source in _collect_sources(node)
    }
    if None in freqs or len(freqs) != 1:
        return None
    return freqs.pop()


def _index_str_frequency(index: pd.Index) -> str | None:
    """The label format (``'-Q'``, ``'-US-Q'``, ``'-M'``), None for dates."""
    from finlab.dataframe.core import _row_axis

    axis = _row_axis(index)
    return None if axis == "dates" else axis


def _unique_source(node: Node, cache: dict | None = None) -> SourceLike | None:
    """Return the source if the subtree has exactly one data identity."""
    sources = _collect_sources(node)
    if not sources:
        return None
    first = sources[0]
    first_identity = _source_identity(first)
    return (
        first
        if all(_source_identity(source) == first_identity for source in sources)
        else None
    )
