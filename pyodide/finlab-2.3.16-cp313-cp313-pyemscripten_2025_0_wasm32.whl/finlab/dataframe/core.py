"""Pandas-backed ``FinlabDataFrame`` frontend.

``FinlabDataFrame`` owns the pandas semantics and convenience APIs used by the
documented dataframe SDK.
"""

from __future__ import annotations

import functools
import inspect
import logging
import re
import sys
import warnings
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, cast

__all__ = ["FinlabDataFrame", "PandasLeftOperandWarning", "TopNPaddingWarning"]

if TYPE_CHECKING:
    from collections.abc import Callable

    from finlab.dataframe.cs import CsAccessor
    from finlab.dataframe.lazy import LazyWide
    from finlab.dataframe.sector import SectorAccessor
    from finlab.dataframe.weight import WeightAccessor

import numpy as np
import pandas as pd
from pandas._libs.ops_dispatch import maybe_dispatch_ufunc_to_dunder_op

from finlab.dataframe.core_index import (
    IndexConversionMixin,
    _dense_boolean,
    _labelled_like,
    _nullable_boolean,
    fill_unknown_boolean,
)
from finlab.dataframe.core_industry import IndustryMixin
from finlab.dataframe.core_neutralize import NeutralizeMixin
from finlab.dataframe.core_signals import SignalMixin
from finlab.dataframe.parallel import parallelize_rolling, rank_rows
from finlab.dataframe.profiling import profile_alignment_call
from finlab.threads import for_each_range

logger = logging.getLogger(__name__)

_OBJECT_INVERT_ERROR = (
    "`~` cannot be used on object columns: it produces -1/-2 and logical "
    "conditions can be silently ignored. Use df.shift(1, fill_value=False), "
    "df.fillna(False), or (df == True) before applying `~`."
)


class LookaheadWarning(UserWarning):
    """警告：偵測到可能的 look-ahead bias。"""


class PandasLeftOperandWarning(UserWarning):
    """``pd_df <op> finlab_df`` aligned with pandas, not FinlabDataFrame, rules.

    Filter it by class, e.g.
    ``warnings.simplefilter("ignore", PandasLeftOperandWarning)``.
    """


class TopNPaddingWarning(UserWarning):
    """``is_largest``/``is_smallest`` filled N with stocks tied at the row floor.

    Filter it by class, e.g.
    ``warnings.simplefilter("ignore", TopNPaddingWarning)``.
    """


_TOP_N_PADDING_EXAMPLE_DATES = 3


_LOGICAL_OPS = frozenset(
    {"__and__", "__or__", "__xor__", "__iand__", "__ior__", "__ixor__"}
)


def _is_plain_bool(data: object) -> bool:
    return isinstance(data, pd.DataFrame) and bool(
        (data.dtypes == np.dtype(bool)).all()
    )


def _dense_logical_operation(
    self: pd.DataFrame, other: pd.DataFrame, op: str
) -> pd.DataFrame | None:
    self_plain, other_plain = _is_plain_bool(self), _is_plain_bool(other)
    if (
        self_plain
        and other_plain
        and not (_has_quarter_str_index(self) or _has_quarter_str_index(other))
    ):
        return None
    left, right = _dense_boolean(self), _dense_boolean(other)
    if left is None or right is None:
        return None
    left, right = FinlabDataFrame.reshape(left, right)
    if not (left.index.equals(right.index) and left.columns.equals(right.columns)):
        return None  # Leave pandas' union alignment on non-date grids unchanged.
    x, y = left.to_numpy(), right.to_numpy()
    unknown = np.isnan(x) | np.isnan(y)
    if op == "__and__":
        values = (x == 1) & (y == 1)
        unknown &= ~((x == 0) | (y == 0))
    elif op == "__or__":
        values = (x == 1) | (y == 1)
        unknown &= ~values
    else:
        values = (x == 1) ^ (y == 1)

    # A plain-bool result reads unknown as False, unless that plain-bool operand
    # was quarterly: converting it to disclosure dates made it nullable.
    if any(
        plain and not (_has_quarter_str_index(source) and _is_date_index(aligned.index))
        for plain, source, aligned in (
            (self_plain, self, left),
            (other_plain, other, right),
        )
    ):
        return _labelled_like(left, values & ~unknown)
    return _nullable_boolean(left, values, unknown)


def _dense_getitem(self: pd.DataFrame, other: pd.DataFrame) -> pd.DataFrame | None:
    if _is_plain_bool(other) and not _has_quarter_str_index(other):
        return None
    dense_mask = _dense_boolean(other)
    if dense_mask is None:
        return None
    df1, df2 = FinlabDataFrame.reshape(self, dense_mask)
    return pd.DataFrame.__getitem__(df1, pd.DataFrame.__eq__(df2, 1))


def _apply_frame_operation(
    self: pd.DataFrame,
    other: pd.DataFrame | pd.Series,
    op: str,
    pandas_method: Callable[..., pd.DataFrame],
) -> pd.DataFrame:
    if type(self) is FinlabDataFrame and not self.attrs:
        from finlab.dataframe.engine import combine

        combined = combine(self, other, op)
        if combined is not None:
            return combined
    if not isinstance(other, (pd.DataFrame, pd.Series)):
        # Scalars, labels and slices have nothing to align with.
        return pandas_method(self, other)
    # Nullable and quarterly masks align as one dense block, not one per symbol.
    dense_result = None
    if isinstance(other, pd.DataFrame):
        # Inplace methods must update aliases; pandas calls our forward op.
        if op in {"__and__", "__or__", "__xor__"}:
            dense_result = _dense_logical_operation(self, other, op)
        elif op == "__getitem__":
            dense_result = _dense_getitem(self, other)
    if dense_result is not None:
        return dense_result
    df1, df2 = self.reshape(self, other)
    result = pandas_method(df1, df2)
    # A plain bool mask combined with a quarterly mask stays
    # plain bool, as it did when quarterly masks were object.
    if op in _LOGICAL_OPS and (_is_plain_bool(df1) or _is_plain_bool(df2)):
        return fill_unknown_boolean(result)
    return result


def _deferred(
    quarterly: Callable[..., bool] | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Run a method on an expression, so only the dates asked for are computed.

    A frame the engine cannot hold keeps the method's own body, and so does an
    in-place call, which has to change this very object. ``quarterly`` tells
    whether a call also holds for a quarterly frame read at its disclosure dates.
    """

    def wrap(method: Callable[..., Any]) -> Callable[..., Any]:
        name = method.__name__

        @functools.wraps(method)
        def deferred(self: pd.DataFrame, *args: Any, **kwargs: Any) -> Any:
            if (
                type(self) is FinlabDataFrame
                and not kwargs.get("inplace")
                and not self.attrs
            ):
                from finlab.dataframe.engine import pending

                by_quarter = quarterly is not None and quarterly(*args, **kwargs)
                frame = pending(self, quarterly=by_quarter)
                if frame is not None:
                    return getattr(frame, name)(*args, **kwargs)
            return method(self, *args, **kwargs)

        return deferred

    return wrap


def _any_call(*_args: object, **_kwargs: object) -> bool:
    return True


def _across_stocks(*args: object, **kwargs: object) -> bool:
    axis = args[0] if args else kwargs.get("axis", 0)
    return axis in (1, "columns") and kwargs.get("valid") is None


def _has_quarter_mask(df: object) -> bool:
    return getattr(df, "_quarter_mask", None) is not None


def _still_hidden(excluded: pd.DataFrame, frame: pd.DataFrame) -> pd.DataFrame:
    """The cells of ``excluded`` that ``frame`` still holds as missing."""
    aligned = excluded.reindex(
        index=frame.index, columns=frame.columns, fill_value=False
    )
    return aligned & pd.DataFrame(frame).isna()


def _quarter_exclusions(df: pd.DataFrame) -> pd.DataFrame:
    excluded = getattr(df, "_quarter_mask", None)
    if excluded is None:
        return pd.DataFrame(False, index=df.index, columns=df.columns)
    return _still_hidden(excluded, df)


def _remember_quarter_mask(
    result: pd.DataFrame, excluded: pd.DataFrame
) -> pd.DataFrame:
    if isinstance(result, FinlabDataFrame) and _has_quarter_str_index(result):
        excluded = _still_hidden(excluded, result)
        result._quarter_mask = excluded if excluded.to_numpy().any() else None
    return result


def _carry_quarter_mask(
    self: pd.DataFrame, other: Any, result: pd.DataFrame
) -> pd.DataFrame:
    if not (_has_quarter_mask(self) or _has_quarter_mask(other)) or not (
        isinstance(result, FinlabDataFrame) and _has_quarter_str_index(result)
    ):
        return result
    excluded = _quarter_exclusions(result) | _quarter_exclusions(self)
    if isinstance(other, pd.DataFrame):
        excluded = excluded | _quarter_exclusions(other)
    return _remember_quarter_mask(result, excluded)


def _quarterly_where(
    df: FinlabDataFrame,
    method: Callable[..., Any],
    cond: Any,
    *args: Any,
    **kwargs: Any,
) -> Any:
    """``method`` (pandas ``where`` or ``mask``), remembering the cells it hides."""
    excluded = _quarter_exclusions(df)
    cond = cond(df) if callable(cond) else cond
    keep = method(
        pd.DataFrame(True, index=df.index, columns=df.columns),
        cond,
        False,
        axis=kwargs.get("axis"),
        level=kwargs.get("level"),
    )
    result = method(df, cond, *args, **kwargs)
    _remember_quarter_mask(df if result is None else result, excluded | ~keep)
    return result


def _shift_quarter_mask(method: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(method)
    def shifted(self: pd.DataFrame, *args: Any, **kwargs: Any) -> Any:
        result = method(self, *args, **kwargs)
        if _has_quarter_mask(self):
            excluded = _quarter_exclusions(self)
            options = dict(
                inspect.signature(method).bind(self, *args, **kwargs).arguments
            )
            options.pop("self")
            if options.get("freq") is None:
                options["fill_value"] = False
            return _remember_quarter_mask(result, excluded.shift(**options))
        return result

    return shifted


def _dated_with_mask(
    frame: pd.DataFrame, convert: Callable[[FinlabDataFrame], FinlabDataFrame]
) -> FinlabDataFrame:
    """A masked NaN is a disclosed clearing event, unlike a raw missing value.

    Convert row references so forward fill carries the clearing event too;
    then gather the original values, leaving its NaN in place.
    """
    excluded = _quarter_exclusions(frame)
    observed = pd.DataFrame(frame).notna() | excluded
    positions = np.broadcast_to(np.arange(len(frame))[:, None] + 1, frame.shape)
    pointers = FinlabDataFrame(
        np.where(observed, positions, np.nan), index=frame.index, columns=frame.columns
    )
    dated = convert(pointers)
    references = dated.to_numpy(dtype=float, na_value=np.nan)
    missing = np.isnan(references)
    rows = np.where(missing, 0, references - 1).astype(np.intp)
    source = frame[dated.columns]
    dense = _dense_boolean(source)
    values = (source if dense is None else dense).to_numpy()
    if dense is None and (
        values.dtype.kind == "O"
        or any(not isinstance(t, np.dtype) for t in source.dtypes)
    ):
        gathered = {
            col: source[col].array.take(
                np.where(missing[:, j], -1, rows[:, j]), allow_fill=True
            )
            for j, col in enumerate(dated.columns)
        }
    else:
        if values.dtype.kind in "biu":
            values = values.astype(float)
        gathered = values[rows, np.arange(len(dated.columns))]
        gathered[missing] = (
            np.array("NaT", dtype=gathered.dtype)
            if gathered.dtype.kind in "mM"
            else np.nan
        )
    result = FinlabDataFrame(gathered, index=dated.index, columns=dated.columns)
    if dense is not None:
        from finlab.dataframe.core_index import _dense_to_nullable

        return _dense_to_nullable(result)
    boolean_columns = source.select_dtypes(["bool", "boolean"]).columns
    return (
        result.astype(dict.fromkeys(boolean_columns, "boolean"))
        if len(boolean_columns)
        else result
    )


def reshape_operations(cls: type) -> type:
    # Define a mapping of operations to override to their corresponding pandas method
    methods_to_check = [
        "__getitem__",
        "__add__",
        "__sub__",
        "__mul__",
        "__truediv__",
        "__floordiv__",
        "__mod__",
        "__pow__",
        "__lshift__",
        "__rshift__",
        "__and__",
        "__or__",
        "__xor__",
        "__iadd__",
        "__isub__",
        "__imul__",
        "__itruediv__",
        "__ifloordiv__",
        "__imod__",
        "__ipow__",
        "__ilshift__",
        "__irshift__",
        "__iand__",
        "__ior__",
        "__ixor__",
        "__lt__",
        "__le__",
        "__eq__",
        "__ne__",
        "__gt__",
        "__ge__",
    ]

    # find operation mapping that map str -> function for the function need reshape.

    base_class = pd.DataFrame
    operations_mapping: dict[str, Callable[..., pd.DataFrame]] = {}

    for method_name in methods_to_check:
        if hasattr(base_class, method_name):
            method = getattr(base_class, method_name)
            params = inspect.signature(method).parameters
            can_accept_df = any(
                param.annotation in (pd.DataFrame, inspect._empty)
                for param in params.values()
            )
            if can_accept_df:
                operations_mapping[method_name] = getattr(pd.DataFrame, method_name)

    # replace original function to reshaped function

    for op, pandas_method in operations_mapping.items():
        if hasattr(cls, op):

            def make_wrapped_method(
                op: str, pandas_method: Callable[..., pd.DataFrame]
            ) -> Callable[[pd.DataFrame, pd.DataFrame | pd.Series], pd.DataFrame]:
                def wrapped_method(
                    self: pd.DataFrame, other: pd.DataFrame | pd.Series
                ) -> pd.DataFrame:
                    # pandas-left corrwith also operates on its FinLab right
                    # operand. Keep those internal operations in pandas so
                    # transposed date columns are not treated as date rows.
                    if sys._getframe(1).f_code is pd.DataFrame.corrwith.__code__:
                        plain_other = (
                            pd.DataFrame(other)
                            if isinstance(other, pd.DataFrame)
                            else other
                        )
                        return pandas_method(pd.DataFrame(self), plain_other)
                    if isinstance(other, pd.Series) and op == "__getitem__":
                        return _select_by_series(self, other, pandas_method)

                    result = _apply_frame_operation(self, other, op, pandas_method)
                    return _carry_quarter_mask(self, other, result)

                return wrapped_method

            setattr(cls, op, make_wrapped_method(op, pandas_method))

    return cls


# Reflected op -> forward op. Python calls a subclass's reflected method before
# the base class's forward one, so these run first for ``pd_df <op> finlab_df``.
_REFLECTED_TO_FORWARD = {
    "__radd__": "__add__",
    "__rsub__": "__sub__",
    "__rmul__": "__mul__",
    "__rtruediv__": "__truediv__",
    "__rfloordiv__": "__floordiv__",
    "__rmod__": "__mod__",
    "__rpow__": "__pow__",
    "__rand__": "__and__",
    "__ror__": "__or__",
    "__rxor__": "__xor__",
}

_PANDAS_LEFT_OPERAND_MESSAGE = (
    "A plain pandas DataFrame is on the left of a FinlabDataFrame and their "
    "dates or stocks differ, so pandas alignment was used: no forward fill of "
    "dates, union of stocks, plain DataFrame result. Put the FinlabDataFrame on "
    "the left, or wrap the other side with FinlabDataFrame(df), to align like "
    "FinlabDataFrame.\n"
    "pandas DataFrame 在 FinlabDataFrame 左邊且日期或股票不同，因此用 pandas "
    "規則對齊：日期不向前填補、股票取聯集、結果是一般 DataFrame。"
    "請把 FinlabDataFrame 放在左邊，或用 FinlabDataFrame(df) 包起來。"
)


def warn_on_pandas_left_operand(cls: type) -> type:
    """Warn when ``pd_df <op> finlab_df`` aligns differently than finlab would.

    The result is unchanged: the plain DataFrame's forward op runs exactly as
    it would without these methods (2.0.21 semantics, which templates rely
    on). Only frames whose axes already match skip the warning, since both
    alignments then agree.
    """
    for reflected, forward in _REFLECTED_TO_FORWARD.items():
        setattr(
            cls,
            reflected,
            _make_reflected_method(
                getattr(pd.DataFrame, reflected), getattr(pd.DataFrame, forward)
            ),
        )
    return cls


def _make_reflected_method(
    pandas_reflected: Callable[[pd.DataFrame, object], pd.DataFrame],
    pandas_forward: Callable[[pd.DataFrame, object], pd.DataFrame],
) -> Callable[[pd.DataFrame, object], pd.DataFrame]:
    def reflected_method(self: pd.DataFrame, other: object) -> pd.DataFrame:
        if isinstance(other, FinlabDataFrame):
            # FinLab on both sides, e.g. a frame the expression engine left
            # to pandas: align as FinLab does, keeping ``other`` on the left.
            return getattr(FinlabDataFrame, pandas_forward.__name__)(other, self)
        # Only an exact pd.DataFrame reaches here ahead of its own forward op;
        # scalars, Series and unrelated subclasses keep the pandas path.
        if type(other) is not pd.DataFrame:
            result = pandas_reflected(self, other)
            return _carry_quarter_mask(self, other, result)
        if not (other.index.equals(self.index) and other.columns.equals(self.columns)):
            warnings.warn(
                _PANDAS_LEFT_OPERAND_MESSAGE, PandasLeftOperandWarning, stacklevel=2
            )
        return pandas_forward(other, self)

    return reflected_method


def get_index_str_frequency(df: pd.DataFrame | pd.Series) -> str | None:
    if not hasattr(df, "index"):
        return None

    if len(df.index) == 0:
        return None

    if not isinstance(df.index[0], str):
        return None

    if (df.index.str.find("M") != -1).all():
        return "month"

    if (df.index.str.find("Q") != -1).all():
        return "season"

    return None


def _has_quarter_str_index(df: pd.DataFrame | pd.Series) -> bool:
    """True for a '2013-Q1'-style index; checks the first label before scanning."""
    return (
        len(df.index) > 0
        and isinstance(df.index[0], str)
        and get_index_str_frequency(df) == "season"
    )


def _is_date_index(labels: object) -> bool:
    if isinstance(labels, pd.DatetimeIndex):
        return True
    if labels is None or isinstance(labels, (str, bytes)):
        return False
    try:
        return pd.api.types.is_datetime64_any_dtype(pd.Index(labels))
    except (TypeError, ValueError):
        return False


_MONTH_LABELS_ERROR = (
    "Monthly labels such as 2021-M04 have no disclosure dates, so they cannot "
    "be aligned with dates, quarters or other label formats. Index the frame by "
    "the dates its values became public first: "
    "FinlabDataFrame(pd.DataFrame(df).set_axis(public_dates)).\n"
    "月份字串索引（如 2021-M04）沒有公告日，無法與日期、季度或其他格式對齊。"
    "請先把索引換成資料公開的日期。"
)


_PERIOD_LABEL = re.compile(r"\d{4}-.*([QM])\d+")


def _row_axis(labels: pd.Index) -> str | None:
    """``'dates'``, a label format such as ``'-Q'``, ``'-US-Q'`` or ``'-M'``, or None.

    Each label format has its own disclosure dates, so only frames with the
    same format share label rows. None (stock ids such as 'MSFT', integers)
    aligns as pandas does.
    """
    if isinstance(labels, pd.DatetimeIndex) or (
        len(labels) and isinstance(labels[0], pd.Timestamp)
    ):
        return "dates"
    first = labels[0] if len(labels) else None
    period = _PERIOD_LABEL.fullmatch(first) if isinstance(first, str) else None
    if period and (labels.str.find(period[1]) != -1).all():
        return period[0].strip("0123456789")
    return None


def _on_dates(df: Any) -> Any:
    """A FinLab quarterly frame on its disclosure dates; other frames as they are."""
    if not isinstance(df, FinlabDataFrame):
        return df
    freq = get_index_str_frequency(df)
    if freq == "month":
        raise ValueError(_MONTH_LABELS_ERROR)
    return df.index_str_to_date() if freq == "season" else df


def _row_axes(df1: Any, df2: Any) -> tuple[str | None, str | None]:
    """Both inputs' row axes; an empty frame takes the other's."""
    axis1, axis2 = _row_axis(df1.index), _row_axis(df2.index)
    return (axis1 if len(df1) else axis2), (axis2 if len(df2) else axis1)


def _grid(df1: Any, df2: Any) -> tuple[Any, Any, str | None]:
    """The rows two inputs share, by the one alignment spec (finlab#787).

    =========================================  ==========================================
    inputs                                     rows
    =========================================  ==========================================
    dates and dates                            union from the later first date, each side
                                               carrying its last value forward
    same label format (2021-Q1 and 2021-Q3)    label union; a missing quarter stays missing
    quarterly and dates, or two label formats  quarterly FinLab sides move to disclosure
    (2021-Q1 and 2021-US-Q1)                   dates first, then dates and dates
    FinLab monthly labels and anything else    error: no disclosure dates to move them to
    an empty frame                             the other side's rows
    a plain pandas frame that cannot move      pandas alignment, as with pd.DataFrame(df)
    no row axis (stock ids, e.g. axis=1)       pandas alignment; neither side moves
    =========================================  ==========================================

    Stocks are always the shared ones. ``where`` and ``mask`` keep the frame's
    rows instead; ``_condition`` carries a FinLab condition onto them.
    Returns both inputs and ``'dates'``, ``'labels'`` or None for pandas.
    """
    axis1, axis2 = _row_axes(df1, df2)
    if axis1 != axis2:
        if None in (axis1, axis2):
            return df1, df2, None  # e.g. a Series of stocks: rows stay as they are
        df1, df2 = _on_dates(df1), _on_dates(df2)
        axis1, axis2 = _row_axes(df1, df2)
        if axis1 != axis2:
            return df1, df2, None
    empty = not (len(df1) or len(df2))
    return df1, df2, "labels" if empty or axis1 not in (None, "dates") else axis1


def _dates_from_later_start(a: pd.Index, b: pd.Index) -> pd.Index:
    """Date union, starting where both inputs have begun."""
    if not len(a):
        return b
    if not len(b):
        return a
    union = a.union(b)
    return union[union >= max(a[0], b[0])]


def _condition(
    df: pd.DataFrame, cond: Any, missing: bool, inplace: bool
) -> tuple[Any, Any]:
    """The frame and condition ``df.where(cond)`` runs on, by the spec.

    The result keeps the frame's rows. A quarterly frame moves to disclosure
    dates unless the condition has the same label format (in place it cannot
    move), a quarterly FinLab condition moves to disclosure dates, and a
    FinLab date condition carries its last value forward, never backward, to
    the frame's dates. A plain pandas condition keeps pandas' exact alignment.
    """
    if not isinstance(cond, (pd.DataFrame, pd.Series)):
        return df, cond
    axis = _row_axis(df.index)
    if (
        not inplace
        and axis not in (None, "dates")
        and _row_axis(cond.index) not in (None, axis)
    ):
        return _on_dates(df), cond
    if isinstance(cond, FinlabDataFrame) and isinstance(df.index, pd.DatetimeIndex):
        cond = _on_dates(cond)
        if isinstance(cond.index, pd.DatetimeIndex) and not df.index.equals(cond.index):
            if not cond.index.is_monotonic_increasing:
                cond = cond.sort_index()
            return df, cond.reindex(index=df.index, method="ffill", fill_value=missing)
    return df, cond


_DATE_AXIS = "index"
_STOCK_AXIS = "columns"


def _has_date_axis(df: pd.DataFrame) -> bool:
    """True for a wide frame whose rows are dates or quarter/month strings."""
    return isinstance(df.index, pd.DatetimeIndex) or bool(get_index_str_frequency(df))


def _series_axis(df: pd.DataFrame, s: pd.Series) -> str:
    """Which axis of ``df`` the Series labels: dates (rows) or stocks (columns).

    A date or quarterly/monthly string index labels dates. Otherwise the
    labels must overlap exactly one axis of ``df``; overlapping both or
    neither is ambiguous and raises instead of silently misaligning.
    """
    if isinstance(s.index, pd.DatetimeIndex) or get_index_str_frequency(s):
        return _DATE_AXIS
    col_hit = bool(s.index.isin(df.columns).any())
    row_hit = bool(s.index.isin(df.index).any())
    if col_hit != row_hit:
        return _STOCK_AXIS if col_hit else _DATE_AXIS
    overlap = (
        "both the dates and the stocks"
        if col_hit
        else "neither the dates nor the stocks"
    )
    raise ValueError(
        f"Cannot tell how to align this Series: its index matches {overlap} of "
        "the DataFrame. Pick the axis explicitly, e.g. df.mul(s, axis=0) to "
        "align on dates or df.mul(s, axis=1) to align on stocks (likewise "
        "add/sub/div/gt/lt/eq...).\n"
        "無法判斷 Series 要對齊日期還是股票：請明確指定，例如 "
        "df.mul(s, axis=0) 對齊日期、df.mul(s, axis=1) 對齊股票。"
    )


def _broadcast_over_dates(df: pd.DataFrame, s: pd.Series) -> FinlabDataFrame:
    """Repeat a per-stock Series on every date of ``df``.

    Stocks missing from the Series are False for a boolean Series (so logical
    ops treat them as not selected) and NaN otherwise.
    """
    fill_value = False if pd.api.types.is_bool_dtype(s.dtype) else np.nan
    row = s.reindex(df.columns, fill_value=fill_value).to_numpy()
    return FinlabDataFrame(
        np.broadcast_to(row, df.shape), index=df.index, columns=df.columns
    )


def _as_bool_mask(s: pd.Series) -> pd.Series | None:
    """``s`` as a bool Series when every value is a bool, else ``None``.

    Object-dtype Series holding only bools count too: pandas selects rows
    with them just like with a bool dtype.
    """
    if pd.api.types.is_bool_dtype(s.dtype):
        return s
    return s.astype(bool) if _holds_only_bools(s) else None


def _holds_only_bools(s: pd.Series) -> bool:
    return s.dtype == object and pd.api.types.infer_dtype(s, skipna=False) == "boolean"


def _with_bools_restored(frame: pd.DataFrame) -> pd.DataFrame:
    pure = {label: bool for label, s in frame.items() if _holds_only_bools(s)}
    return frame.astype(pure) if pure else frame


def _select_by_series(
    df: pd.DataFrame,
    s: pd.Series,
    pandas_getitem: Callable[..., pd.DataFrame],
) -> pd.DataFrame:
    """``df[s]`` on a dated frame: a per-stock mask selects columns.

    A per-date mask keeps every date and empties the rows where it is False,
    so ``position[timing]`` goes to cash like ``position & timing``. Label
    Series and frames without a date index (long tables such as
    ``broker_transactions``) keep pandas semantics, so
    ``df[df["stock_id"] == "2330"]`` filters rows.
    """
    mask = _as_bool_mask(s)
    if mask is None or not _has_date_axis(df):
        return pandas_getitem(df, s)
    if _series_axis(df, mask) == _STOCK_AXIS:
        return df.loc[:, mask.reindex(df.columns, fill_value=False).to_numpy()]
    return _empty_masked_dates(df, mask)


def _empty_masked_dates(df: pd.DataFrame, mask: pd.Series) -> pd.DataFrame:
    """Keep the dates of ``df & mask``; rows where ``mask`` is False hold nothing.

    Dates align as in ``df & mask``: a date missing from ``mask`` takes the
    previous mask value. Nothing is False for a boolean frame and 0 for a
    weight frame, which ``sim()`` treats as cash.
    """
    aligned, date_mask = FinlabDataFrame.reshape(df, mask)
    held = date_mask.fillna(False).astype(bool)
    empty = False if all(map(pd.api.types.is_bool_dtype, aligned.dtypes)) else 0
    return aligned.where(held, empty)


def _reindex_row_labels(args: tuple[object, ...], kwargs: dict[str, object]) -> object:
    """Row labels requested by a ``DataFrame.reindex`` call, if any."""
    if "index" in kwargs:
        return kwargs["index"]
    labels = args[0] if args else kwargs.get("labels")
    if kwargs.get("axis") in (None, 0, "index", "rows"):
        return labels
    return None


def _fetch_refined_categories() -> dict[str, str]:
    """Fetch security categories and normalize sector names.

    Returns a dict mapping stock_id -> refined sector name.
    Shared by the FinlabDataFrame accessors that need sector lookups.
    """
    from finlab import data
    from finlab.compat import resolve_id_column

    categories = data.get("security_categories")
    cat = categories.set_index(resolve_id_column(categories)).category.to_dict()
    org_set = set(cat.values())
    valid_names = {o for o in org_set if isinstance(o, str) and o != "nan"}

    refine_cat: dict[str, str] = {}
    for s, c in cat.items():
        if c is None or c == "nan":
            refine_cat[s] = "其他"
        elif c == "電腦及週邊":
            refine_cat[s] = "電腦及週邊設備業"
        elif c[-1] == "業" and c[:-1] in valid_names:
            refine_cat[s] = c[:-1]
        else:
            refine_cat[s] = c
    return refine_cat


@warn_on_pandas_left_operand
@reshape_operations
class FinlabDataFrame(
    IndexConversionMixin,
    SignalMixin,
    NeutralizeMixin,
    IndustryMixin,
    pd.DataFrame,
):
    """回測語法糖
    除了使用熟悉的 Pandas 語法外，我們也提供很多語法糖，讓大家開發程式時，可以用簡易的語法完成複雜的功能，讓開發策略更簡潔！
    我們將所有的語法糖包裹在 `FinlabDataFrame` 中，用起來跟 `pd.DataFrame` 一樣，但是多了很多功能！
    只要使用 `finlab.data.get()` 所獲得的資料，皆為 `FinlabDataFrame` 格式，
    接下來我們就來看看， `FinlabDataFrame` 有哪些好用的語法糖吧！

    當資料日期沒有對齊（例如: 財報 vs 收盤價 vs 月報）時，在使用以下運算符號：
    `+`, `-`, `*`, `/`, `>`, `>=`, `==`, `<`, `<=`, `&`, `|`, `~`，
    不需要先將資料對齊，因為 `FinlabDataFrame` 會自動幫你處理，以下是示意圖。

    <img src="https://i.ibb.co/pQr5yx5/Screen-Shot-2021-10-26-at-5-32-44-AM.png" alt="steps">

    以下是範例：`cond1` 與 `cond2` 分別為「每天」，和「每季」的資料，假如要取交集的時間，可以用以下語法：

    ```py
    from finlab import data
    # 取得 FinlabDataFrame
    close = data.get('price:收盤價')
    roa = data.get('fundamental_features:ROA稅後息前')

    # 運算兩個選股條件交集
    cond1 = close > 37
    cond2 = roa > 0
    cond_1_2 = cond1 & cond2
    ```
    擷取 1101 台泥 的訊號如下圖，可以看到 `cond1` 跟 `cond2` 訊號的頻率雖然不相同，
    但是由於 `cond1` 跟 `cond2` 是 `FinlabDataFrame`，所以可以直接取交集，而不用處理資料頻率對齊的問題。
    <br />
    <img src="https://i.ibb.co/m9chXSQ/imageconds.png" alt="imageconds">

    總結來說，FinlabDataFrame 與一般 dataframe 唯二不同之處：
    1. 多了一些 method，如`df.is_largest()`, `df.sustain()`...等。
    2. 在做四則運算、不等式運算前，會將 df1、df2 的 index 取聯集，column 取交集。

    季報與日資料運算時，季報先轉成各股的公告日；兩份不同來源的季報（例如 `2021-Q1`
    與 `2021-US-Q1`）也各自轉成公告日再對齊。月份字串索引（如 `2021-M04`）沒有公告日，
    只能和同樣格式的資料運算，其他組合會報錯。

    與 `pd.Series` 運算時，依 Series 的 index 判斷對齊方向：日期（或季/月字串）
    index 對齊日期；股票代號 index 對齊股票、套用到每一天（`&` / `|` 缺少的股票視為
    `False`，四則運算為 `NaN`）；兩者皆符合或皆不符合時會報錯，請改用
    `df.mul(s, axis=0)`（日期）或 `df.mul(s, axis=1)`（股票）明確指定。
    日期布林 Series 擇時：`position[cond]` 與 `position & cond` 都保留每個日期，
    False 的日期空手。
    """

    @property
    def _constructor(self) -> type[FinlabDataFrame]:
        return FinlabDataFrame

    _metadata: ClassVar[list[str]] = ["_quarter_mask"]

    def __array_ufunc__(
        self, ufunc: np.ufunc, method: str, *inputs: Any, **kwargs: Any
    ) -> Any:
        if (
            method == "__call__"
            and len(inputs) == 2
            and all(isinstance(value, pd.DataFrame) for value in inputs)
        ):
            # Preserve pandas' dispatch to our arithmetic/comparison methods.
            result = maybe_dispatch_ufunc_to_dunder_op(
                self, ufunc, method, *inputs, **kwargs
            )
            if result is not NotImplemented:
                return result
            implementations = {type(value).__array_ufunc__ for value in inputs}
            if not implementations.issubset(
                {FinlabDataFrame.__array_ufunc__, pd.DataFrame.__array_ufunc__}
            ):
                return super().__array_ufunc__(ufunc, method, *inputs, **kwargs)
            left, right = inputs
            if not (
                left.index.equals(right.index) and left.columns.equals(right.columns)
            ):
                raise ValueError(
                    f"np.{ufunc.__name__} cannot implicitly align DataFrame inputs "
                    "with different dates or stock columns. For date-indexed "
                    "inputs, first use:\n"
                    "import numpy as np\n"
                    "from finlab import FinlabDataFrame\n"
                    "a, b = FinlabDataFrame.reshape(a, b)\n"
                    f"result = np.{ufunc.__name__}(a, b)\n\n"
                    "For monthly/quarterly string indexes, first call "
                    ".index_str_to_date() on each FinlabDataFrame, then use reshape.\n"
                    "For pandas union alignment, explicitly convert both inputs "
                    "with pd.DataFrame(a) and pd.DataFrame(b)."
                )
            if len(implementations) > 1:
                # Avoid circular deferral. NumPy originally chose a subclass
                # before its parent, otherwise the left input's constructor.
                receiver = right if isinstance(right, type(left)) else left
                constructor = receiver._constructor
                inputs = tuple(constructor(value) for value in inputs)
                return pd.DataFrame.__array_ufunc__(
                    inputs[0], ufunc, method, *inputs, **kwargs
                )
        return super().__array_ufunc__(ufunc, method, *inputs, **kwargs)

    def __invert__(self) -> FinlabDataFrame:
        if any(pd.api.types.is_object_dtype(dtype) for dtype in self.dtypes):
            raise TypeError(_OBJECT_INVERT_ERROR)
        return super().__invert__()

    @_deferred()
    def fillna(self, value: Any = None, **kwargs: Any) -> FinlabDataFrame | None:
        """Fill as pandas does, and keep a boolean table boolean when ``value`` is a bool.

        pandas 3 leaves ``bool.shift().fillna(False)`` as object, where ``~``
        gives -1/-2. The value decides, never the later rows: a column turns
        back only if every cell is a bool once filled.
        """
        filled = super().fillna(value, **kwargs)
        if not isinstance(value, (bool, np.bool_)):
            return filled
        if kwargs.get("inplace"):
            self._update_inplace(_with_bools_restored(self))
            return filled
        return _with_bools_restored(filled)

    @property
    def weight(self) -> WeightAccessor:
        from finlab.dataframe.weight import WeightAccessor

        return WeightAccessor(self)

    @property
    def cs(self) -> CsAccessor:
        from finlab.dataframe.cs import CsAccessor
        from finlab.dataframe.engine import pending

        frame = pending(self) if type(self) is FinlabDataFrame else None
        return CsAccessor(self) if frame is None else frame.cs

    @property
    def sector(self) -> SectorAccessor:
        from finlab.dataframe.engine import pending
        from finlab.dataframe.sector import SectorAccessor

        frame = pending(self) if type(self) is FinlabDataFrame else None
        return SectorAccessor(self) if frame is None else frame.sector

    def __setattr__(self, name: str, value: object) -> None:
        if name == "index":
            caller_file = sys._getframe(1).f_code.co_filename
            caller_path = Path(caller_file).resolve()
            pandas_root = Path(pd.__file__).resolve().parent
            finlab_root = Path(__file__).resolve().parents[1]
            is_internal_assignment = caller_path.is_relative_to(
                pandas_root
            ) or caller_path.is_relative_to(finlab_root)
            if not is_internal_assignment:
                raise AttributeError(
                    "\n不要直接覆寫 FinlabDataFrame 的 index！"
                    "\n"
                    "\n原因："
                    "\n  FinlabDataFrame 會保留季報/月報索引的資料時間語意。"
                    "\n  直接覆寫 index 可能把尚未公開的資料提前用在回測中，"
                    "\n  導致未來資料汙染 (lookahead bias)。"
                    "\n"
                    "\n如果你要對齊季報/月報資料，請改用："
                    "\n  df = df.deadline()          # 依財報截止日統一換股（所有股票同日換）"
                    "\n  df = df.index_str_to_date() # 依各股實際財報公布日換股（避免前視偏差）"
                    "\n"
                    "\n如果你確定只是要用 pandas 語意自行處理 index，"
                    "\n請先轉成一般 DataFrame，再自行承擔時間對齊責任："
                    "\n  df = pd.DataFrame(df)"
                    "\n  df.index = pd.to_datetime(df.index)"
                    "\n"
                    "\n範例："
                    "\n  ❌ df.index = pd.to_datetime(df.index)"
                    "\n  ✅ df = df.deadline()"
                    "\n  ✅ df = df.index_str_to_date()"
                    "\n  ✅ df = pd.DataFrame(df); df.index = pd.to_datetime(df.index)"
                    "\nDo not overwrite a FinlabDataFrame index: doing so can introduce lookahead bias. "
                    "For quarterly/monthly data, use df.deadline() for common reporting deadlines "
                    "or df.index_str_to_date() for actual publication dates. "
                    "For pandas index semantics, first use df = pd.DataFrame(df), "
                    "then align dates yourself."
                )
        super().__setattr__(name, value)

    @staticmethod
    @profile_alignment_call
    def reshape(
        df1: pd.DataFrame,
        df2: pd.DataFrame | pd.Series,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        if isinstance(df2, pd.Series) and isinstance(df1, pd.DataFrame):
            if _series_axis(df1, df2) == _STOCK_AXIS:
                return df1, _broadcast_over_dates(df1, df2)
            if get_index_str_frequency(df2):
                # tell user has high chance to use future data
                logger.warning(
                    "Detect pd.Series has season/month index, the chance of using future data is high!\n"
                    "Please convert index from str to date first then perform calculations.\n"
                    "Example: df.quantile(0.3, axis=1) -> df.index_str_to_date().quantile(0.3, axis=1)"
                )
            df2 = _repeat_series(df2, df1.columns)
        if not (isinstance(df1, pd.DataFrame) and isinstance(df2, pd.DataFrame)):
            return df1, df2

        df1, df2, rows = _grid(df1, df2)
        if rows is None or (
            df1.index.equals(df2.index) and df1.columns.equals(df2.columns)
        ):
            return df1, df2
        columns = df1.columns.intersection(df2.columns)
        if rows == "labels":
            # A missing quarter is not the preceding quarter's value.
            index = df1.index.union(df2.index)
            return (
                df1.reindex(index=index, columns=columns),
                df2.reindex(index=index, columns=columns),
            )
        index = _dates_from_later_start(df1.index, df2.index)
        return (
            df1[columns].reindex(index=index, method="ffill" if len(df1) else None),
            df2[columns].reindex(index=index, method="ffill" if len(df2) else None),
        )

    def reindex(self, *args: Any, **kwargs: Any) -> FinlabDataFrame:
        """``pd.DataFrame.reindex`` that understands quarterly string indexes.

        Reindexing a quarterly ('2013-Q1') FinlabDataFrame onto dates first
        converts the quarters to disclosure dates with ``index_str_to_date()``,
        so ``df.reindex(close.index, method='ffill')`` gives each stock's
        latest disclosed value instead of all NaN or a TypeError.
        """
        if _has_quarter_str_index(self) and _is_date_index(
            _reindex_row_labels(args, kwargs)
        ):
            return self.index_str_to_date().reindex(*args, **kwargs)
        return cast("FinlabDataFrame", super().reindex(*args, **kwargs))

    def align(
        self, other: pd.DataFrame | pd.Series, *args: Any, **kwargs: Any
    ) -> tuple[FinlabDataFrame, pd.DataFrame | pd.Series]:
        """``pd.DataFrame.align`` that converts a quarterly side to dates first."""
        left, other, _ = _grid(self, other)
        if left is not self:
            return cast(
                "tuple[FinlabDataFrame, pd.DataFrame | pd.Series]",
                left.align(other, *args, **kwargs),
            )
        return cast(
            "tuple[FinlabDataFrame, pd.DataFrame | pd.Series]",
            super().align(other, *args, **kwargs),
        )

    @_deferred()
    def where(self, cond: Any, *args: Any, **kwargs: Any) -> FinlabDataFrame:
        """``pd.DataFrame.where`` that converts a quarterly frame to dates first.

        With a date-indexed ``cond``, ``roe.where(cond)`` works like
        ``roe.index_str_to_date().where(cond)`` instead of raising
        "putmask: mask and data must be the same size".
        FinlabDataFrame date conditions carry their last observation forward
        to dates missing from the condition, including disclosure timestamps.
        Plain pandas conditions retain pandas' exact-date alignment.
        """
        dated, cond = _condition(
            self, cond, missing=False, inplace=kwargs.get("inplace", False)
        )
        if dated is not self:
            return dated.where(cond, *args, **kwargs)
        if _has_quarter_str_index(self):
            return _quarterly_where(self, pd.DataFrame.where, cond, *args, **kwargs)
        return cast("FinlabDataFrame", super().where(cond, *args, **kwargs))

    @_deferred()
    def mask(self, cond: Any, *args: Any, **kwargs: Any) -> FinlabDataFrame:
        """``pd.DataFrame.mask`` that converts a quarterly frame to dates first."""
        dated, cond = _condition(
            self, cond, missing=True, inplace=kwargs.get("inplace", False)
        )
        if dated is not self:
            return dated.mask(cond, *args, **kwargs)
        if _has_quarter_str_index(self):
            return _quarterly_where(self, pd.DataFrame.mask, cond, *args, **kwargs)
        return cast("FinlabDataFrame", super().mask(cond, *args, **kwargs))

    def corrwith(
        self, other: pd.DataFrame | pd.Series, *args: Any, **kwargs: Any
    ) -> pd.Series:
        """Compute pairwise correlations with pandas alignment and arithmetic."""
        if isinstance(other, pd.DataFrame):
            other = pd.DataFrame(other)
        return pd.DataFrame(self).corrwith(other, *args, **kwargs)

    @_deferred()
    def rolling(self, *args: Any, **kwargs: Any) -> Any:
        """``pd.DataFrame.rolling``; numeric frames compute their columns concurrently."""
        return parallelize_rolling(super().rolling(*args, **kwargs))

    @_deferred()
    def average(self, n: int) -> FinlabDataFrame:
        """取 n 筆移動平均

        若股票在時間窗格內，有 N/2 筆 NaN，則會產生 NaN。
        Args:
          n (positive-int): 設定移動窗格數。
        Returns:
          (pd.DataFrame): data
        Examples:
            股價在均線之上
            ```py
            from finlab import data
            close = data.get('price:收盤價')
            sma = close.average(10)
            cond = close > sma
            ```
            只需要簡單的語法，就可以將其中一部分的訊號繪製出來檢查：
            ```py
            import matplotlib.pyplot as plt

            close.loc['2021', '2330'].plot()
            sma.loc['2021', '2330'].plot()
            cond.loc['2021', '2330'].mul(20).add(500).plot()

            plt.legend(['close', 'sma', 'cond'])
            ```
            <img src="https://i.ibb.co/Mg1P85y/sma.png" alt="sma">
        """
        return self.rolling(n, min_periods=int(n / 2)).mean()

    @_deferred(_any_call)
    def is_largest(self, n: int) -> FinlabDataFrame:
        """取每列前 n 筆大的數值

        若符合 `True` ，反之為 `False` 。用來篩選每天數值最大的股票。

        <img src="https://i.ibb.co/8rh3tbt/is-largest.png" alt="is-largest">
        Args:
          n (positive-int): 設定每列前 n 筆大的數值。
        Returns:
          (pd.DataFrame): data
        Examples:
            每季 ROA 前 10 名的股票
            ```py
            from finlab import data

            roa = data.get('fundamental_features:ROA稅後息前')
            good_stocks = roa.is_largest(10)
            ```

            只在符合條件的股票中排名：用 `score[cond]` 排除不符合的股票，
            不要用 `cond * score`。後者讓不符合的股票分數為 0，符合的股票
            少於 n 檔時會被補進來，並發出 `TopNPaddingWarning`。
            ```py
            top = score[cond].is_largest(10)
            ```
        """
        # Quarterly rows become disclosure dates first, so each date only
        # compares values already public on that date.
        return _top_n(self.index_str_to_date(), n, largest=True)

    @_deferred(_any_call)
    def is_smallest(self, n: int) -> FinlabDataFrame:
        """取每列前 n 筆小的數值

        若符合 `True` ，反之為 `False` 。用來篩選每天數值最小的股票。
        Args:
          n (positive-int): 設定每列前 n 筆小的數值。
        Returns:
          (pd.DataFrame): data
        Examples:
            股價淨值比最小的 10 檔股票
            ```py
            from finlab import data

            pb = data.get('price_earning_ratio:股價淨值比')
            cheap_stocks = pb.is_smallest(10)
            ```

            只在符合條件的股票中排名時用 `pb[cond].is_smallest(10)`。
            每列同為最高值的股票多於剩餘名額、只能依欄位順序挑選時，
            會發出 `TopNPaddingWarning`。
        """
        return _top_n(self.index_str_to_date(), n, largest=False)

    @_deferred(_across_stocks)
    def rank(
        self,
        *args: object,
        valid: pd.DataFrame | pd.Series | None = None,
        **kwargs: object,
    ) -> FinlabDataFrame:
        """Cross-sectional or time-series ranking.

        Args:
            valid (DataFrame or Series of bool, optional):
                只有 valid 為 True 的 cell 才參與排名。
                valid 為 False/NaN 的 cell 在排名前設為 NaN，
                因此不影響 pct=True 的分母。
                常見用法：fillna 後傳入原始 notna() mask，
                避免新上市或歷史不足的股票污染百分位排名。
        """
        # 1) 解析 axis，預設為 0（沿時間軸）
        axis = args[0] if args else kwargs.get("axis", 0)

        # 2) look-ahead 檢查
        if axis in (0, "index"):
            warnings.warn(
                "Unsafe rank: 排名沿時間軸 (axis=0) 可能洩漏未來資料；"
                "請改用 rolling().rank()、expanding().rank()，或 axis=1。 / "
                "Ranking along the time axis (axis=0) may leak future data; "
                "use rolling().rank(), expanding().rank(), or axis=1.",
                LookaheadWarning,
                stacklevel=2,
            )

        # 3) Fast path for axis=1 (cross-sectional) ranking.
        #    Convert quarterly rows to disclosure dates BEFORE ranking so each
        #    date only ranks the values already public on that date.  Ranking
        #    the raw quarter row first would let an early reporter be ranked
        #    against peers' same-quarter values that were not yet disclosed.
        #    The converted frame holds one row per distinct disclosure date,
        #    so only event rows are ranked, not every trading day.
        pct = kwargs.get("pct", False)
        ascending = kwargs.get("ascending", True)
        na_option = kwargs.get("na_option", "keep")

        if axis in (1, "columns") and na_option == "keep":
            masked = self.where(valid) if valid is not None else self
            source = masked.index_str_to_date()

            # Delegate tie handling to pandas.  The previous numpy-argsort fast
            # path assigned ordinal ranks (method="first"), which silently
            # disagreed with pandas' default method="average": tied cells
            # received distinct percentiles (e.g. low-cardinality/discrete
            # factors), so the same tied group had non-zero cross-sectional
            # std instead of 0.
            method = kwargs.get("method", "average")
            # Nullable-boolean cells not yet disclosed become NaN, not False.
            values = source.to_numpy(dtype="float64", na_value=np.nan)
            # Rank the transposed view along axis=0: pandas ranks contiguous
            # columns ~1.6x faster than rows, with identical results.
            ranks = rank_rows(
                values, method=method, ascending=ascending, pct=pct, na_option="keep"
            )
            return FinlabDataFrame(ranks, index=source.index, columns=source.columns)

        # 4) Fallback: full index conversion + pandas rank
        converted = self.index_str_to_date()
        if valid is not None:
            converted = converted.where(valid)
        rank = cast("Callable[..., pd.DataFrame]", pd.DataFrame.rank)
        ranked = rank(converted, *args, **kwargs)
        return FinlabDataFrame(ranked)

    @_deferred()
    def rise(self, n: int = 1) -> FinlabDataFrame:
        """數值上升中

        取是否比前第n筆高，若符合條件的值則為True，反之為False。
        <img src="https://i.ibb.co/Y72bN5v/Screen-Shot-2021-10-26-at-6-43-41-AM.png" alt="Screen-Shot-2021-10-26-at-6-43-41-AM">
        Args:
          n (positive-int): 設定比較前第n筆高。
        Returns:
          (pd.DataFrame): data
        Examples:
            收盤價是否高於10日前股價
            ```py
            from finlab import data
            data.get('price:收盤價').rise(10)
            ```
        """
        return self > self.shift(n)

    @_deferred()
    def fall(self, n: int = 1) -> FinlabDataFrame:
        """數值下降中

        取是否比前第n筆低，若符合條件的值則為True，反之為False。
        <img src="https://i.ibb.co/Y72bN5v/Screen-Shot-2021-10-26-at-6-43-41-AM.png" alt="Screen-Shot-2021-10-26-at-6-43-41-AM">
        Args:
          n (positive-int): 設定比較前第n筆低。
        Returns:
          (pd.DataFrame): data
        Examples:
            收盤價是否低於10日前股價
            ```py
            from finlab import data
            data.get('price:收盤價').fall(10)
            ```
        """
        return self < self.shift(n)

    def rebalance(self, freq: str | pd.Index | list) -> FinlabDataFrame:
        """Downsample to keep only the last observation per period.

        Equivalent to ``self.resample(freq).last()``, except that a period
        labelled before its last row (``'MS'``, ``'QS'``) is dated at that row.

        Args:
            freq: Pandas frequency string, e.g. ``'ME'`` (month-end),
                ``'W'`` (weekly), ``'QE'`` (quarter-end), or explicit dates
                to select with ``reindex``.
        """
        if not isinstance(freq, str):
            return FinlabDataFrame(self.reindex(pd.DatetimeIndex(freq)))
        last = self.resample(freq).last()
        last.index = _resample_labels(self.index, freq)
        return FinlabDataFrame(last)

    @_deferred()
    def pct_change(
        self,
        periods: int = 1,
        fill_method: str | None = None,
        *args: Any,
        **kwargs: Any,
    ) -> FinlabDataFrame:
        """Fractional change without filling missing values by default.

        This follows pandas 3 on every supported pandas version. To carry the
        last valid price across a gap, use ``frame.ffill().pct_change()``.
        Explicit arguments are passed through to pandas.
        """
        return pd.DataFrame.pct_change(self, periods, fill_method, *args, **kwargs)

    def lazy(self) -> LazyWide:
        """Wrap this DataFrame into a lazy computation handle.

        Returns a ``LazyWide`` proxy that records operations without
        executing them.  Call ``.rebalance(freq)`` or ``.collect()``
        on the result to trigger execution at specific dates only.

        Example::

            close = data.get('price:收盤價')
            position = (
                close.lazy()
                .rolling(60).mean()
                .rank(axis=1, pct=True)
                .is_largest(10)
                .rebalance('M')
            )
        """
        from finlab.dataframe.lazy import lazy

        return lazy(self)

    @_deferred()
    def quantile_row(self, c: float) -> pd.Series:
        """股票當天數值分位數

        取得每列c定分位數的值。
        Args:
          c (positive-int): 設定每列 n 定分位數的值。
        Returns:
          (pd.DataFrame): data
        Examples:
            取每日股價前90％分位數
            ```py
            from finlab import data
            data.get('price:收盤價').quantile_row(0.9)
            ```
        """
        return self.index_str_to_date().quantile(c, axis=1)


FinlabDataFrame.shift = _shift_quarter_mask(pd.DataFrame.shift)  # type: ignore[method-assign]

# pandas methods an expression answers without computing every date.
for _name in (
    "shift", "diff", "ffill", "cumsum", "cummax", "cummin",
    "notna", "isna", "abs", "clip", "astype", "replace",
    "sum", "mean", "max", "min", "std", "median", "count", "quantile",
):  # fmt: skip
    setattr(FinlabDataFrame, _name, _deferred()(getattr(FinlabDataFrame, _name)))
FinlabDataFrame.sustain = _deferred()(SignalMixin.sustain)  # type: ignore[method-assign]


def _resample_labels(index: pd.DatetimeIndex, freq: str) -> pd.DatetimeIndex:
    """Labels for ``resample(freq)`` bins, never earlier than a bin's last row.

    Start-labelled frequencies (``'MS'``, ``'QS'``, ``'5D'``) date a bin before
    the rows it holds, so those bins move to their last row; end-labelled ones
    (``'ME'``, ``'W'``) keep their labels.
    """
    last = index.to_series().resample(freq).max()
    after_label = last > last.index
    if not after_label.any():
        return last.index  # keeps the index freq ('W-SUN', 'ME') for end-labelled bins
    return pd.DatetimeIndex(last.where(after_label, last.index))


def _repeat_series(series: pd.Series, columns: pd.Index) -> FinlabDataFrame:
    """``FinlabDataFrame(dict.fromkeys(columns, series))``, without a Series per column."""
    keys = list(dict.fromkeys(columns))
    # Numbers and bools only: pandas would infer other dtypes (dates, strings) from
    # an object block that the columns themselves keep as object.
    if not keys or not (
        isinstance(series.dtype, np.dtype) and series.dtype.kind in "biuf"
    ):
        return FinlabDataFrame(dict.fromkeys(columns, series))
    # One row per column, as pandas stores a frame built from columns.
    block = np.repeat(series.to_numpy()[None, :], len(keys), axis=0)
    return FinlabDataFrame(
        block.T, index=series.index, columns=pd.Index(keys), copy=False
    )


def _top_n(df: FinlabDataFrame, n: int, *, largest: bool) -> FinlabDataFrame:
    """Vectorised top-/bottom-n row selector for is_largest/is_smallest.

    Uses ``np.partition`` (``O(ncols)`` per row) instead of a full sort to
    find the top/bottom threshold. Values tied at the threshold are selected
    in their original column order, matching stable sort semantics. Rows are
    independent, so ranges of rows run concurrently.
    """

    vals = df.to_numpy(dtype="float64", na_value=np.nan, copy=True)
    nrows, ncols = vals.shape

    if nrows == 0 or ncols == 0 or n <= 0:
        return FinlabDataFrame(
            np.zeros((nrows, ncols), dtype=bool),
            index=df.index,
            columns=df.columns,
        )

    valid = ~np.isnan(vals)
    if n >= ncols:
        return FinlabDataFrame(valid, index=df.index, columns=df.columns)

    result = np.zeros((nrows, ncols), dtype=bool)
    # Per range: padded row indices, slot counts, and tied values (negated for largest).
    padding: dict[int, tuple[np.ndarray, np.ndarray, np.ndarray]] = {}

    def run(first: int, stop: int) -> None:
        part, ok, out = vals[first:stop], valid[first:stop], result[first:stop]
        if largest:
            np.negative(part, out=part)
        # Worst valid value per row (fmax skips NaN, before NaN becomes inf).
        floor = np.fmax.reduce(part, axis=1)
        part[~ok] = np.inf
        select_all = ok.sum(axis=1) <= n
        out[select_all] = ok[select_all]

        rows = np.flatnonzero(~select_all)
        if not rows.size:
            return
        candidates = part[rows]
        thresholds = np.partition(candidates, n - 1, axis=1)[:, n - 1]
        better = candidates < thresholds[:, None]
        out[rows] = better
        # Rows here hold more than n valid values, so a threshold equal to the
        # row's worst valid value means the floor tie group exceeds the free
        # slots and column order picked the rest.
        need = n - better.sum(axis=1)
        padded = np.flatnonzero(thresholds == floor[rows])
        padding[first] = (first + rows[padded], need[padded], thresholds[padded])

        # The first ``need`` ties of each row, in column order, fill its free slots.
        tie_rows, tie_cols = np.nonzero(ok[rows] & (candidates == thresholds[:, None]))
        order_in_row = np.arange(tie_rows.size) - np.searchsorted(tie_rows, tie_rows)
        keep = order_in_row < need[tie_rows]
        out[rows[tie_rows[keep]], tie_cols[keep]] = True

    for_each_range(nrows, vals.size, run)

    if padding:
        padded_rows, padded_need, padded_values = (
            np.concatenate(parts)
            for parts in zip(
                *(padding[first] for first in sorted(padding)), strict=True
            )
        )
        if padded_rows.size:
            shown = slice(_TOP_N_PADDING_EXAMPLE_DATES)
            _warn_top_n_padding(
                n,
                padded_rows.size,
                df.index[padded_rows[shown]],
                padded_need[shown],
                largest=largest,
                zero_padding=bool(np.any(padded_values == 0)),
            )

    return FinlabDataFrame(result, index=df.index, columns=df.columns)


def _warn_top_n_padding(
    n: int,
    n_dates: int,
    example_dates: pd.Index,
    padded: np.ndarray,
    *,
    largest: bool,
    zero_padding: bool,
) -> None:
    call = f"{'is_largest' if largest else 'is_smallest'}({n})"
    floor, floor_zh = ("lowest", "最低") if largest else ("highest", "最高")
    labels = (
        example_dates.strftime("%Y-%m-%d")
        if isinstance(example_dates, pd.DatetimeIndex)
        else example_dates
    )
    examples = ", ".join(
        f"{label} ({count})" for label, count in zip(labels, padded, strict=True)
    )
    advice = advice_zh = ""
    if largest and zero_padding:
        advice = (
            f"This usually comes from (cond * score).{call}: "
            f"stocks failing cond get score 0 and fill the slots when fewer than {n} "
            f"qualify. Use score[cond].{call} or score.where(cond).{call} to exclude "
            "them. "
        )
        advice_zh = (
            f"常見原因是 (cond * score).{call}：不符合 cond 的股票分數為 0，"
            f"符合的股票少於 {n} 檔時會被補進來。請改用 score[cond].{call} 或 "
            f"score.where(cond).{call} 排除它們。"
        )
    warnings.warn(
        f"{call} filled its slots with stocks tied at the row's {floor} value, "
        f"picked by column order, on {n_dates} date(s), e.g. {examples} "
        f"(date (stocks filled)). {advice}The selection result is unchanged.\n"
        f"{call} 在 {n_dates} 個日期用每列{floor_zh}值的同分股票補滿名額，"
        f"依欄位順序挑選，例如 {examples}（日期（補入檔數））。"
        f"{advice_zh}選股結果不變。",
        TopNPaddingWarning,
        stacklevel=4,
    )
