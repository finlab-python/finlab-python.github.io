from __future__ import annotations

import datetime
import gzip
import json
import logging
import os
import pickle
import shutil
import sys
import tempfile
import threading

__all__ = ["CacheStorage", "FileStorage", "LocalDataReadError"]
from contextlib import contextmanager
from typing import IO, TYPE_CHECKING, Any, ClassVar, cast

if TYPE_CHECKING:
    from collections.abc import Callable, Generator

import pandas as pd
import pyarrow as pa
import requests
from pandas.compat import pickle_compat
from pyarrow import feather

import finlab.utils

logger = logging.getLogger(__name__)


class LocalDataReadError(RuntimeError):
    """Raised when an existing local dataframe cache cannot be read."""

    def __init__(self, name: str, file_path: str) -> None:
        super().__init__(f"Failed to read local cache for {name}: {file_path}")
        self.name = name
        self.file_path = file_path


fcntl: Any | None
try:
    import fcntl
except ImportError:
    fcntl = None

msvcrt: Any | None
try:
    import msvcrt
except ImportError:
    msvcrt = None


class _LegacyNDArrayBackedUnpickler(pickle_compat.Unpickler):
    _NO_VALUE: ClassVar[object] = object()

    def __init__(self, *args: object, normalize_state: Any, **kwargs: object) -> None:
        self._normalize_state = normalize_state
        super().__init__(*args, **kwargs)

    def find_class(self, module: str, name: str) -> object:
        obj = super().find_class(module, name)
        if module == "pandas._libs.arrays" and name == "__pyx_unpickle_NDArrayBacked":

            def compat_unpickle(
                klass: type,
                checksum: int,
                state: object,
            ) -> object:
                return obj(klass, checksum, self._normalize_state(state))

            return compat_unpickle
        return obj

    def load_build(self) -> None:
        state = self._normalize_state(self.stack.pop())
        inst = self.stack[-1]
        setstate = getattr(inst, "__setstate__", self._NO_VALUE)
        if setstate is not self._NO_VALUE:
            cast("Any", setstate)(state)
            return

        slotstate = None
        if isinstance(state, tuple) and len(state) == 2:
            state, slotstate = state
        if state:
            inst_dict = inst.__dict__
            intern = sys.intern
            for key, value in state.items():
                if type(key) is str:
                    inst_dict[intern(key)] = value
                else:
                    inst_dict[key] = value
        if slotstate:
            for key, value in slotstate.items():
                setattr(inst, key, value)


_LegacyNDArrayBackedUnpickler.dispatch = pickle_compat.Unpickler.dispatch.copy()
_LegacyNDArrayBackedUnpickler.dispatch[pickle.BUILD[0]] = (
    _LegacyNDArrayBackedUnpickler.load_build
)


class CacheStorage:
    def __init__(self) -> None:
        """將歷史資料儲存於快取中

        Examples:
            欲切換成以檔案方式儲存，可以用以下之方式：

            ``` py
            from finlab import data
            data.set_storage(data.CacheStorage())
            close = data.get('price:收盤價')
            ```

            可以直接調閱快取資料：

            ``` py
            close = data._storage._cache['price:收盤價']
            ```
        """

        self._cache: dict[str, pd.DataFrame] = {}
        self._cache_time: dict[str, datetime.datetime] = {}
        self._cache_expiry: dict[str, datetime.datetime] = {}

    @staticmethod
    def now() -> datetime.datetime:
        return datetime.datetime.now(tz=datetime.timezone.utc)

    def set_dataframe(
        self, name: str, df: pd.DataFrame, expiry: datetime.datetime | None = None
    ) -> None:
        self._cache[name] = df
        self._cache_time[name] = self.now()
        self._cache_expiry[name] = expiry or self.now()

    def get_time_created(self, name: str) -> datetime.datetime | None:
        if name not in self._cache or name not in self._cache_time:
            return None

        return self._cache_time[name]

    def get_time_expired(self, name: str) -> datetime.datetime | None:
        if name in self._cache_expiry:
            return self._cache_expiry[name]

        return None

    def set_time_expired(self, name: str, expiry: datetime.datetime) -> None:
        self._cache_expiry[name] = expiry

    def get_dataframe(
        self, name: str, use_cache: bool | None = None
    ) -> pd.DataFrame | None:
        # not exists
        if name not in self._cache or name not in self._cache_time:
            return None

        return self._cache[name]


class FileStorage:
    _last_reset_check_time: ClassVar[datetime.datetime | None] = (
        None  # UTC datetime of last check (shared across instances)
    )
    _FEATHER_SUFFIX: ClassVar[str] = ".feather"
    _LEGACY_PICKLE_SUFFIX: ClassVar[str] = ".pickle"
    _DATA_FILE_SUFFIXES: ClassVar[tuple[str, ...]] = (
        _FEATHER_SUFFIX,
        _LEGACY_PICKLE_SUFFIX,
    )
    _GZIP_MAGIC: ClassVar[bytes] = b"\x1f\x8b"

    def __init__(self, path: str | None = None, use_cache: bool = True) -> None:
        """將歷史資料儲存於檔案中

        Args:
              path (str): 資料儲存的路徑
              use_cache (bool): 是否額外使用快取，將資料複製一份到記憶體中。

        Examples:
            欲切換成以檔案方式儲存，可以用以下之方式：

            ``` py
            from finlab import data
            data.set_storage(data.FileStorage())
            close = data.get('price:收盤價')
            ```

            可以在本地端的 `./finlab_db/price#收盤價.feather` 中，看到下載的資料，
            可以使用 `pandas.read_feather` 調閱歷史資料：
            ``` py
            import pandas as pd
            close = pd.read_feather('finlab_db/price#收盤價.feather')
            ```
        """
        if path is None:
            path = finlab.utils.get_tmp_dir()

        self._path: str = path
        self._cache: dict[str, pd.DataFrame] = {}
        self._expiry: dict[str, datetime.datetime] = {}
        self.use_cache: bool = use_cache
        self._created: dict[str, datetime.datetime] = {}
        self._save_expiry_lock: threading.RLock = threading.RLock()
        self._reset_thread: threading.Thread | None = None

        if not os.path.isdir(path):
            os.mkdir(path)

        f_expiry = os.path.join(self._path, "expiry.pkl")
        self._expiry_loaded_time: datetime.datetime = datetime.datetime.fromtimestamp(
            0, tz=datetime.timezone.utc
        )

        if os.path.isfile(f_expiry):
            with open(f_expiry, "rb") as f:
                try:
                    self._expiry = pickle.load(f)
                    self._expiry_loaded_time = datetime.datetime.fromtimestamp(
                        os.path.getmtime(f_expiry), tz=datetime.timezone.utc
                    )
                except (
                    pickle.UnpicklingError,
                    EOFError,
                    AttributeError,
                    ModuleNotFoundError,
                ):
                    self._expiry = {}

        if self._expiry:
            now = CacheStorage.now()
            if (
                FileStorage._last_reset_check_time is None
                or (now - FileStorage._last_reset_check_time).total_seconds() > 900
            ):
                FileStorage._last_reset_check_time = now
                if "pyodide" in sys.modules:
                    self._check_and_apply_reset_time()
                else:
                    self._reset_thread = threading.Thread(
                        target=self._check_and_apply_reset_time, daemon=True
                    )
                    self._reset_thread.start()

    @staticmethod
    def _lock_path(file_path: str) -> str:
        return file_path + ".lock"

    def _data_file_path(self, name: str, suffix: str) -> str:
        return os.path.join(self._path, name.replace(":", "#") + suffix)

    def _existing_data_file_path(self, name: str) -> str | None:
        for suffix in self._DATA_FILE_SUFFIXES:
            file_path = self._data_file_path(name, suffix)
            if os.path.isfile(file_path):
                return file_path
        return None

    @classmethod
    def _is_legacy_pickle_data_file(cls, file_path: str) -> bool:
        return file_path.endswith(cls._LEGACY_PICKLE_SUFFIX)

    @staticmethod
    def _wrap_local_read_error(name: str, file_path: str, read_fn: Any) -> Any:
        try:
            return read_fn()
        except LocalDataReadError:
            raise
        except Exception as exc:
            raise LocalDataReadError(name, file_path) from exc

    @classmethod
    def _read_legacy_pickle_dataframe(cls, file_path: str) -> pd.DataFrame:
        """Read a legacy FileStorage dataframe cache.

        Older FileStorage versions wrote pandas pickles, sometimes gzip-compressed,
        while keeping the `.pickle` suffix. Keep all data-pickle compatibility here
        so new storage paths stay feather-only.
        """
        with open(file_path, "rb") as f:
            is_gzip = f.read(len(cls._GZIP_MAGIC)) == cls._GZIP_MAGIC

        compression = "gzip" if is_gzip else None
        try:
            df = pd.read_pickle(file_path, compression=compression)
        except NotImplementedError as exc:
            df = cls._read_legacy_pickle_dataframe_with_ndarray_compat(
                file_path,
                compression=compression,
                original_error=exc,
            )
        if not isinstance(df, pd.DataFrame):
            raise TypeError(f"Legacy pickle cache is not a DataFrame: {file_path}")
        return df

    @classmethod
    def _read_legacy_pickle_dataframe_with_ndarray_compat(
        cls,
        file_path: str,
        *,
        compression: str | None,
        original_error: NotImplementedError,
    ) -> pd.DataFrame:
        """Retry old pandas pickles with legacy datetime/timedelta backing state.

        Some legacy pandas pickles store NDArrayBacked datetime/timedelta state
        as ``(dtype, values)``. Pandas 2.3 on Pyodide Python 3.13 expects the
        newer three-part state and rejects the old tuple during unpickle.
        Normalize only this narrow state format while reading legacy caches.
        """
        try:
            opener = gzip.open if compression == "gzip" else open
            with opener(file_path, "rb") as f:
                return _LegacyNDArrayBackedUnpickler(
                    f,
                    normalize_state=cls._normalize_legacy_ndarray_backed_state,
                ).load()
        except Exception as exc:
            raise original_error from exc

    @staticmethod
    def _normalize_legacy_ndarray_backed_state(state: object) -> object:
        if not isinstance(state, tuple) or len(state) not in (2, 3):
            return state

        dtype = state[0]
        values = state[1]
        if getattr(dtype, "kind", None) not in ("M", "m"):
            return state
        if getattr(values, "ndim", None) != 2 or 1 not in values.shape:
            return state

        if len(state) == 2:
            return (dtype, values, {})
        return state

    def has_dataframe(self, name: str) -> bool:
        return self._existing_data_file_path(name) is not None

    def get_dataframe_row_count(self, name: str) -> int | None:
        """Return the local dataframe row count."""
        file_path = self._existing_data_file_path(name)
        if file_path is None:
            return None

        def read_row_count() -> int | None:
            with self._file_lock(file_path, exclusive=False):
                if not os.path.isfile(file_path):
                    return None
                if self._is_legacy_pickle_data_file(file_path):
                    return len(self._read_legacy_pickle_dataframe(file_path))
                return self._read_feather_row_count(file_path)

        return self._wrap_local_read_error(name, file_path, read_row_count)

    def get_dataframe_index(self, name: str) -> pd.Index | None:
        """Return the local dataframe index."""
        file_path = self._existing_data_file_path(name)
        if file_path is None:
            return None

        def read_index() -> pd.Index | None:
            with self._file_lock(file_path, exclusive=False):
                if not os.path.isfile(file_path):
                    return None
                if self._is_legacy_pickle_data_file(file_path):
                    df = self._read_legacy_pickle_dataframe(file_path)
                    return self._index_from_dataframe(name, df)
                return self._read_feather_index(file_path, dataset=name)

        return self._wrap_local_read_error(name, file_path, read_index)

    @staticmethod
    def _read_feather_row_count(file_path: str) -> int:
        with pa.memory_map(file_path, "r") as source:
            reader = pa.ipc.open_file(source)
            if reader.num_record_batches == 0:
                return 0
            column_names = reader.schema.names
            if not column_names:
                return sum(
                    reader.get_batch(i).num_rows
                    for i in range(reader.num_record_batches)
                )
            return feather.read_table(file_path, columns=[column_names[0]]).num_rows

    @staticmethod
    def _read_pandas_feather_metadata(schema: pa.Schema) -> dict[str, Any]:
        raw = (schema.metadata or {}).get(b"pandas")
        if raw is None:
            return {}
        return json.loads(raw.decode())

    @staticmethod
    def _range_index_from_metadata(
        index_columns: list[object],
    ) -> pd.RangeIndex | None:
        if len(index_columns) != 1 or not isinstance(index_columns[0], dict):
            return None
        metadata = index_columns[0]
        if metadata.get("kind") != "range":
            return None
        return pd.RangeIndex(
            start=int(metadata.get("start", 0)),
            stop=int(metadata.get("stop", 0)),
            step=int(metadata.get("step", 1)),
            name=metadata.get("name"),
        )

    @staticmethod
    def _raw_index_columns(dataset: str, column_names: list[str]) -> list[str]:
        if ":" not in dataset:
            return []
        id_col = next(
            (column for column in ("symbol", "stock_id") if column in column_names),
            None,
        )
        if id_col is not None and "date" in column_names:
            return [id_col, "date"]
        if "date" in column_names:
            return ["date"]
        if id_col is not None:
            return [id_col]
        return []

    @classmethod
    def _index_from_dataframe(cls, dataset: str, df: pd.DataFrame) -> pd.Index:
        column_names = [column for column in df.columns if isinstance(column, str)]
        raw_index_columns = cls._raw_index_columns(dataset, column_names)
        if raw_index_columns:
            return df.set_index(raw_index_columns).index
        return df.index

    @classmethod
    def _read_feather_index(cls, file_path: str, *, dataset: str) -> pd.Index:
        with pa.memory_map(file_path, "r") as source:
            reader = pa.ipc.open_file(source)
            schema = reader.schema
            column_names = schema.names
            pandas_metadata = cls._read_pandas_feather_metadata(schema)

        index_columns = pandas_metadata.get("index_columns", [])
        if not isinstance(index_columns, list):
            index_columns = []

        range_index = cls._range_index_from_metadata(index_columns)
        stored_index_columns = [
            column
            for column in index_columns
            if isinstance(column, str) and column in column_names
        ]
        if stored_index_columns:
            return pd.read_feather(file_path, columns=stored_index_columns).index

        raw_index_columns = cls._raw_index_columns(dataset, column_names)
        if raw_index_columns:
            frame = pd.read_feather(file_path, columns=raw_index_columns)
            return frame.set_index(raw_index_columns).index

        if range_index is not None:
            return range_index
        return pd.RangeIndex(cls._read_feather_row_count(file_path))

    def _remove_data_file(self, name: str, suffix: str) -> None:
        file_path = self._data_file_path(name, suffix)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)
        except OSError:
            logger.warning(f"failed to remove stale data file: {file_path}")

    @staticmethod
    def _acquire_lock(lock_file: IO[bytes], exclusive: bool) -> None:
        if fcntl is not None:
            mode = fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH
            fcntl.flock(lock_file.fileno(), mode)
            return
        if msvcrt is not None:
            # Lock 1 byte for coarse cross-process synchronization.
            mode = msvcrt.LK_LOCK if exclusive else msvcrt.LK_RLCK
            lock_file.seek(0)
            msvcrt.locking(lock_file.fileno(), mode, 1)
            return

    @staticmethod
    def _release_lock(lock_file: IO[bytes]) -> None:
        if fcntl is not None:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
            return
        if msvcrt is not None:
            lock_file.seek(0)
            msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
            return

    @contextmanager
    def _file_lock(
        self, target_file_path: str, exclusive: bool
    ) -> Generator[None, None, None]:
        lock_path = self._lock_path(target_file_path)
        with open(lock_path, "a+b") as lock_file:
            self._acquire_lock(lock_file, exclusive=exclusive)
            try:
                yield
            finally:
                self._release_lock(lock_file)

    def _atomic_file_replace(
        self,
        file_path: str,
        write_fn: Callable[[str], Any],
    ) -> None:
        tmp_path = None
        try:
            fd, tmp_path = tempfile.mkstemp(
                prefix=os.path.basename(file_path) + ".",
                suffix=".tmp",
                dir=self._path,
            )
            os.close(fd)
            write_fn(tmp_path)
            os.replace(tmp_path, file_path)
        finally:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    logger.warning(
                        f"failed to remove tmp file: {tmp_path}", exc_info=True
                    )

    def _atomic_file_write(
        self,
        file_path: str,
        write_fn: Callable[[str], Any],
    ) -> None:
        with self._file_lock(file_path, exclusive=True):
            self._atomic_file_replace(file_path, write_fn)

    def _read_dataframe_with_shared_lock(
        self, file_path: str
    ) -> tuple[Any, datetime.datetime | None]:
        with self._file_lock(file_path, exclusive=False):
            if not os.path.isfile(file_path):
                return None, None
            if self._is_legacy_pickle_data_file(file_path):
                ret = self._read_legacy_pickle_dataframe(file_path)
            else:
                ret = pd.read_feather(file_path)
            mtime = datetime.datetime.fromtimestamp(
                os.path.getmtime(file_path), tz=datetime.timezone.utc
            )
            return ret, mtime

    def _is_reset_already_applied(self, raw_text: str) -> bool:
        """Check if this reset was already applied to the current expiry.pkl."""
        marker_path = os.path.join(self._path, "_reset_data_time.txt")
        expiry_path = os.path.join(self._path, "expiry.pkl")
        try:
            if not os.path.isfile(marker_path):
                return False
            with open(marker_path) as f:
                lines = f.read().strip().split("\n")
            if len(lines) != 2 or lines[0] != raw_text:
                return False
            current_mtime = (
                os.path.getmtime(expiry_path) if os.path.isfile(expiry_path) else 0
            )
            return float(lines[1]) == current_mtime
        except (OSError, ValueError):
            return False

    def _save_last_reset_data_time(self, raw_text: str) -> None:
        """Record reset timestamp and current expiry.pkl mtime."""
        marker_path = os.path.join(self._path, "_reset_data_time.txt")
        expiry_path = os.path.join(self._path, "expiry.pkl")
        try:
            mtime = os.path.getmtime(expiry_path) if os.path.isfile(expiry_path) else 0
            with open(marker_path, "w") as f:
                f.write(f"{raw_text}\n{mtime}")
        except OSError:
            pass  # best-effort marker; failure does not affect correctness

    def _check_and_apply_reset_time(self) -> None:
        url = "https://asia-east1-fdata-299302.cloudfunctions.net/data_reset_time"
        try:
            if "pyodide" in sys.modules:
                from finlab.data.auth import _pyodide_get_text

                raw_text = _pyodide_get_text(url)
            else:
                res = finlab.utils.requests.get(url, timeout=300)
                raw_text = res.text

            if self._is_reset_already_applied(raw_text):
                return

            reset_data_time = datetime.datetime.fromtimestamp(
                float(raw_text), tz=datetime.timezone.utc
            )
            with self._save_expiry_lock:
                for k, _ in list(self._expiry.items()):
                    created = self.get_time_created(k)
                    if created and created < reset_data_time:
                        logger.info(
                            f" set {k} time expired since the system reset time: {reset_data_time} > created time: {created}"
                        )
                        self.set_time_expired(k, reset_data_time, save=False)
                if self.save_expiry():
                    self._save_last_reset_data_time(raw_text)
        except (
            requests.RequestException,
            OSError,
            RuntimeError,
            ValueError,
            ImportError,
        ) as e:
            logger.warning("Failed to check data reset time: %s", e)

    def _reload_expiry_if_modified(self) -> None:
        """Reload expiry data from disk if the file has been modified by another process."""
        expiry_file = os.path.join(self._path, "expiry.pkl")
        if not os.path.isfile(expiry_file):
            return

        file_mtime = datetime.datetime.fromtimestamp(
            os.path.getmtime(expiry_file), tz=datetime.timezone.utc
        )

        if file_mtime > self._expiry_loaded_time:
            with self._save_expiry_lock:
                # Double-check after acquiring lock
                file_mtime = datetime.datetime.fromtimestamp(
                    os.path.getmtime(expiry_file), tz=datetime.timezone.utc
                )
                if file_mtime > self._expiry_loaded_time:
                    with (
                        self._file_lock(expiry_file, exclusive=False),
                        open(expiry_file, "rb") as f,
                    ):
                        self._expiry = pickle.load(f)
                    self._expiry_loaded_time = file_mtime
                    logger.debug(
                        "Reloaded expiry data from disk (modified by another process)"
                    )

    def _record_data_file_write(
        self,
        name: str,
        expiry: datetime.datetime | None = None,
    ) -> None:
        with self._save_expiry_lock:
            self._cache.pop(name, None)
            self._expiry[name] = expiry or CacheStorage.now()
            self._created[name] = CacheStorage.now()
            self._remove_data_file(name, self._LEGACY_PICKLE_SUFFIX)
            self.save_expiry()

    def set_dataframe(
        self, name: str, df: pd.DataFrame, expiry: datetime.datetime | None = None
    ) -> None:
        self._persist_feather(name, df.to_feather, expiry=expiry)

    def set_dataframe_bytes(
        self,
        name: str,
        payload: bytes,
        expiry: datetime.datetime | None = None,
    ) -> None:
        """Persist a feather payload verbatim, skipping pandas re-encoding."""

        def write_payload(tmp_path: str) -> None:
            with open(tmp_path, "wb") as f:
                f.write(payload)

        self._persist_feather(name, write_payload, expiry=expiry)

    def _persist_feather(
        self,
        name: str,
        write_fn: Callable[[str], Any],
        expiry: datetime.datetime | None = None,
    ) -> None:
        file_path = self._data_file_path(name, ".feather")
        with self._file_lock(file_path, exclusive=True):
            try:
                self._atomic_file_replace(file_path, write_fn)
            except OSError as e:
                error_msg = f"{name} save dataframe fail. Path: {file_path}. Error: {e}"
                logger.warning(error_msg)
                print(f"Warning: {error_msg}")
                print(
                    "Please check disk permission, available space, or filename encoding issues."
                )
                raise

            if not os.path.isfile(file_path):
                error_msg = (
                    f"{name} save dataframe fail - file not created at {file_path}"
                )
                logger.warning(error_msg)
                print(f"Warning: {error_msg}")
                raise FileNotFoundError(error_msg)

            self._record_data_file_write(name, expiry=expiry)

    def get_time_created(self, name: str) -> datetime.datetime | None:
        if name in self._created:
            return self._created[name]

        # check existence
        file_path = self._existing_data_file_path(name)
        if file_path is None:
            return None

        return datetime.datetime.fromtimestamp(
            os.path.getmtime(file_path), tz=datetime.timezone.utc
        )

    def get_time_expired(self, name: str) -> datetime.datetime | None:
        # Reload expiry from disk if it's been modified by another process
        self._reload_expiry_if_modified()

        if name in self._expiry:
            return self._expiry[name]

        return None

    def set_time_expired(
        self, name: str, expiry: datetime.datetime, save: bool = True
    ) -> None:
        with self._save_expiry_lock:
            self._expiry[name] = expiry
            if save:
                self.save_expiry()

    def save_expiry(self) -> bool:
        expiry_file = os.path.join(self._path, "expiry.pkl")
        with self._save_expiry_lock:
            try:

                def write_expiry(tmp_path: str) -> None:
                    with open(tmp_path, "wb") as f:
                        pickle.dump(self._expiry, f)

                self._atomic_file_write(expiry_file, write_expiry)
                self._expiry_loaded_time = CacheStorage.now()
                return True
            except (OSError, pickle.PicklingError) as e:
                logger.warning(f"save expiry fail: {e}")
                return False

    def get_dataframe(
        self, name: str, use_cache: bool | None = None
    ) -> pd.DataFrame | None:
        should_use_cache = self.use_cache if use_cache is None else use_cache
        file_path = self._existing_data_file_path(name)

        # If we have a cached version, check if the file on disk is newer
        if should_use_cache and name in self._cache:
            if file_path is None:
                return None
            cache_file_mtime = datetime.datetime.fromtimestamp(
                os.path.getmtime(file_path), tz=datetime.timezone.utc
            )
            cached_time = self._created.get(name)

            # If file was modified after we cached it, invalidate cache
            if cached_time and cache_file_mtime > cached_time:
                logger.debug(
                    f"{name} file on disk is newer than cache, reloading from disk"
                )
                del self._cache[name]
            else:
                # Cache is still valid
                return self._cache[name]

        if file_path is None:
            return None

        # Load from disk under shared lock to avoid partially-read files during writes.
        ret, loaded_mtime = self._wrap_local_read_error(
            name,
            file_path,
            lambda: self._read_dataframe_with_shared_lock(file_path),
        )
        if ret is None:
            return None
        if loaded_mtime is None:
            raise RuntimeError(f"Missing mtime for loaded cache file: {file_path}")
        if should_use_cache:
            self._cache[name] = ret
            self._created[name] = loaded_mtime
        return ret

    def clear(self) -> None:
        folder_path = self._path
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except OSError as e:
                print(f"Failed to delete {file_path}. Reason: {e}")

    def diagnose(self, dataset: str | None = None) -> None:
        """診斷本地儲存狀態

        Args:
            dataset (str, optional): 指定要檢查的資料集名稱，例如 'price:收盤價'。如果不指定，則列出所有本地資料。

        Examples:
            ``` py
            from finlab import data
            data._storage.diagnose()  # 列出所有本地資料
            data._storage.diagnose('price:收盤價')  # 檢查特定資料集
            ```
        """
        print(f"Storage path: {self._path}")
        print(f"Path exists: {os.path.isdir(self._path)}")

        if dataset:
            file_path = self._existing_data_file_path(dataset)
            expected_file = self._data_file_path(dataset, ".feather")
            print(f"\nDataset: {dataset}")
            print(f"Expected file: {expected_file}")
            print(f"File exists: {file_path is not None}")
            if file_path is not None:
                print(f"Actual file: {file_path}")
                size_mb = os.path.getsize(file_path) / (1024 * 1024)
                mtime = datetime.datetime.fromtimestamp(os.path.getmtime(file_path))
                print(f"File size: {size_mb:.2f} MB")
                print(f"Last modified: {mtime}")
            if dataset in self._expiry:
                print(f"Expiry time: {self._expiry[dataset]}")
            else:
                print("Expiry time: Not set")
            if dataset in self._cache:
                print(f"In memory cache: Yes ({len(self._cache[dataset])} rows)")
            else:
                print("In memory cache: No")
        else:
            print("\nLocal data files:")
            data_files = [
                f
                for f in os.listdir(self._path)
                if f.endswith(self._DATA_FILE_SUFFIXES)
            ]
            if not data_files:
                print("  (No data files found)")
            for f in sorted(data_files)[:20]:  # Show first 20 files
                file_path = os.path.join(self._path, f)
                size_mb = os.path.getsize(file_path) / (1024 * 1024)
                dataset_name = (
                    f.replace("#", ":")
                    .removesuffix(self._FEATHER_SUFFIX)
                    .removesuffix(self._LEGACY_PICKLE_SUFFIX)
                )
                print(f"  {dataset_name}: {size_mb:.2f} MB")
            if len(data_files) > 20:
                print(f"  ... and {len(data_files) - 20} more files")
            print(f"\nTotal: {len(data_files)} data files")
