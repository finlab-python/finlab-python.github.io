from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

from finlab import data
from finlab.analysis import Analysis
from finlab.markets.tw import TWMarket

__all__ = ["LiquidityAnalysis"]

if TYPE_CHECKING:
    from pandas.io.formats.style import Styler

    from finlab.core.report import Report
    from finlab.market import Market


def _previous_trading_day_slice(
    frame: pd.DataFrame, target_dates: pd.Index
) -> pd.DataFrame:
    """Return ``frame[prev_trading_day(d)]`` for each ``d`` in ``target_dates``.

    Equivalent to ``frame.shift().reindex(target_dates, method='pad')``
    for trade-date lookups, but avoids materialising the full ``.shift()``
    copy.
    """

    pos = frame.index.get_indexer(target_dates, method="pad")
    prev_pos = np.where(pos > 0, pos - 1, -1)
    values = np.full((len(target_dates), frame.shape[1]), np.nan)
    valid = prev_pos >= 0
    if valid.any():
        values[valid] = frame.values[prev_pos[valid]]
    return pd.DataFrame(values, index=target_dates, columns=frame.columns)


class LiquidityAnalysis(Analysis):
    def __init__(
        self, required_volume: int = 200000, required_turnover: int = 1000000
    ) -> None:
        """分析台股策略流動性風險項目的機率

        !!! note
            參考[VIP限定文章](https://www.finlab.tw/customized_liquidityanalysis/)更了解流動性檢測內容細節。
        Args:
            required_volume (int): 要求進出場時的單日成交股數至少要多少？
            required_turnover (int): 要求進出場時的單日成交金額至少要多少元？避免成交股數夠，但因低價股因素，造成胃納量仍無法符合資金需求。

        Examples:
            ``` py

            # better syntax
            report.run_analysis('LiquidityAnalysis', required_volume=100000)

            # original syntax
            from finlab.analysis.liquidityAnalysis import LiquidityAnalysis
            report.run_analysis(LiquidityAnalysis(required_volume=100000))
            ```
        """
        super().__init__()

        self._required_volume: int = required_volume
        self._required_turnover: int = required_turnover
        self._result: pd.DataFrame | None = None

    def is_market_supported(self, market: Market) -> bool:
        """Check if the market is supported for liquidity analysis.

        Currently only Taiwan stock market is supported, as it has unique
        features like disposal stocks, warning stocks, full delivery stocks,
        and price limit regulations.
        """
        return market.get_name() == "tw_stock"

    def calculate_trade_info(self, report: Report) -> list[list[object]]:
        from finlab.backtest.report import _prefilter_for_trade_dates

        signal_dates = ["entry_sig_date", "exit_sig_date"]
        trading_dates = ["entry_date", "exit_date"]

        if isinstance(report.trade_at, str):
            adj_trade_price = report.market.get_trading_price(report.trade_at, adj=True)
            trade_price = report.market.get_trading_price(report.trade_at, adj=False)
        else:
            adj_trade_price = report.trade_at
            trade_price = report.trade_at
        adj_close_frame = report.market.get_trading_price("close", adj=True)
        volume = report.market.get_price("volume", adj=False)

        # Slim each input to the trade dates BEFORE arithmetic, and skip
        # materialising ``close.shift()`` on the full frame — we only need
        # the previous trading day's close at each trade date, which is a
        # direct index-based lookup on the full close.
        adj_trade_slim = _prefilter_for_trade_dates(
            adj_trade_price, report.trades, trading_dates
        )
        trade_price_slim = _prefilter_for_trade_dates(
            trade_price, report.trades, trading_dates
        )
        volume_slim = _prefilter_for_trade_dates(volume, report.trades, trading_dates)
        adj_prev_close_slim = _previous_trading_day_slice(
            adj_close_frame, adj_trade_slim.index
        )

        pct_change = adj_trade_slim / adj_prev_close_slim - 1
        turnover = trade_price_slim * volume_slim

        ret = [
            ["pct_change", pct_change, trading_dates],
            ["turnover", turnover, trading_dates],
            ["volume", volume_slim, trading_dates],
        ]

        if isinstance(report.market, TWMarket):
            flagged = _prefilter_for_trade_dates(
                data.get("etl:is_flagged_stock"), report.trades, signal_dates
            )
            ret.append(["類別", flagged, signal_dates])

        return ret

    def analyze(self, report: Report) -> dict[str, object]:
        trades = report.get_trades()

        if isinstance(report.market, TWMarket):
            # 漲跌幅限制使用實際交易日期
            entry_pct_range = (trades.entry_date >= "2015-6-1") * 0.03 + 0.07
            exit_pct_range = (trades.exit_date >= "2015-6-1") * 0.03 + 0.07
        else:
            entry_pct_range = 0.1
            exit_pct_range = 0.1

        long_position = trades.position > 0

        # 漲跌幅相關判斷使用實際交易日期
        entry_buy_at_top = long_position & (
            trades["pct_change@entry_date"] > entry_pct_range * 0.95
        )
        entry_sell_at_bottom = (~long_position) & (
            trades["pct_change@entry_date"] < -entry_pct_range * 0.95
        )

        exit_sell_at_bottom = long_position & (
            trades["pct_change@exit_date"] < -exit_pct_range * 0.95
        )
        exit_buy_at_top = (~long_position) & (
            trades["pct_change@exit_date"] > exit_pct_range * 0.95
        )
        (
            trades["pct_change@entry_date"].notna()
            & trades["pct_change@exit_date"].notna()
        )

        ret_dict = {
            "buy_high": [entry_buy_at_top.mean(), exit_buy_at_top.mean()],
            "sell_low": [entry_sell_at_bottom.mean(), exit_sell_at_bottom.mean()],
            "low_volume_stocks": [
                (trades["volume@entry_date"] < self._required_volume).mean(),
                (trades["volume@exit_date"] < self._required_volume).mean(),
            ],
            "low_turnover_stocks": [
                (trades["turnover@entry_date"] < self._required_turnover).mean(),
                (trades["turnover@exit_date"] < self._required_turnover).mean(),
            ],
        }

        is_tw = isinstance(report.market, TWMarket)
        if is_tw and "類別@entry_sig_date" in trades.columns:
            # Decode bit-flags into local Series (don't mutate report.trades)
            entry_flags = trades["類別@entry_sig_date"].fillna(0).astype(int)
            exit_flags = trades["類別@exit_sig_date"].fillna(0).astype(int)

            ret_dict = {
                **ret_dict,
                "警示股": [
                    ((entry_flags & 0x1) != 0).mean(),
                    ((exit_flags & 0x1) != 0).mean(),
                ],
                "處置股": [
                    ((entry_flags & 0x2) != 0).mean(),
                    ((exit_flags & 0x2) != 0).mean(),
                ],
                "全額交割股": [
                    ((entry_flags & 0x4) != 0).mean(),
                    ((exit_flags & 0x4) != 0).mean(),
                ],
            }

        self._result = pd.DataFrame(ret_dict)

        self._result.index = ["entry", "exit"]

        return self._result.to_dict()

    def display(self) -> Styler:
        if self._result is None:
            raise RuntimeError("analyze() must be called before display()")

        def percentage(v: float) -> str:
            return str(round(v * 100, 1)) + "%"

        def make_pretty(styler: Styler) -> Styler:
            styler.set_caption("低流動性交易")
            styler.format(percentage)
            styler.background_gradient(axis=None, vmin=0, vmax=0.5, cmap="YlGnBu")
            return styler

        return self._result.style.pipe(make_pretty)
