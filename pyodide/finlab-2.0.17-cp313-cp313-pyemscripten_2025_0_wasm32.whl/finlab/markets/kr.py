from __future__ import annotations

import datetime
from typing import ClassVar

import pandas as pd

from finlab import data

__all__ = ["KRFundMarket", "KRMarket"]
from finlab.market import Market


class KRMarket(Market):
    """Korea stock market (KRX)."""

    _price_table: ClassVar[str] = "kr_price"
    _adj_prefix: ClassVar[str] = "etl:kr_adj_"

    @staticmethod
    def get_freq() -> str:
        return "1D"

    @staticmethod
    def get_name() -> str:
        return "kr_stock"

    @staticmethod
    def get_benchmark() -> pd.Series:
        return data.get("world_index:adj_close")["^KS11"]

    @staticmethod
    def get_asset_id_to_name() -> dict[str, str]:
        try:
            from finlab.compat import resolve_id_column

            tickers = data.get("kr_tickers")
            return dict(
                zip(tickers[resolve_id_column(tickers)], tickers["name"], strict=True)
            )
        except (ImportError, KeyError, ValueError, RuntimeError):
            return {}

    def market_close_at_timestamp(
        self, timestamp: pd.Timestamp | None = None
    ) -> pd.Timestamp:
        if timestamp is None:
            timestamp = self.get_price("close").index[-1]

        timestamp = self._normalize_market_timestamp(timestamp, "Asia/Seoul")

        market_close = pd.Timestamp(timestamp.date()) + pd.Timedelta("15:30:00")
        return market_close.tz_localize("Asia/Seoul")

    @staticmethod
    def market_open_time() -> tuple[int, int]:
        return (9, 0)

    @staticmethod
    def default_fee_ratio() -> float:
        return 0.15 / 1000

    @staticmethod
    def default_tax_ratio() -> float:
        return 2.3 / 1000

    @staticmethod
    def tzinfo() -> datetime.timezone:
        return datetime.timezone(datetime.timedelta(hours=9))


class KRFundMarket(KRMarket):
    """Korea fund/ETF market using kr_fund_price data."""

    _price_table: ClassVar[str] = "kr_fund_price"
    _adj_prefix: ClassVar[str] = "etl:kr_fund_adj_"

    @staticmethod
    def get_name() -> str:
        return "kr_fund"
