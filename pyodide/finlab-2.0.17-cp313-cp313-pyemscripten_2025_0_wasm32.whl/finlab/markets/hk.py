from __future__ import annotations

import datetime
from typing import ClassVar

import pandas as pd

from finlab import data

__all__ = ["HKFundMarket", "HKMarket"]
from finlab.market import Market


class HKMarket(Market):
    """Hong Kong stock market (HKEX)."""

    _price_table: ClassVar[str] = "hk_price"
    _adj_prefix: ClassVar[str] = "etl:hk_adj_"

    @staticmethod
    def get_freq() -> str:
        return "1D"

    @staticmethod
    def get_name() -> str:
        return "hk_stock"

    @staticmethod
    def get_benchmark() -> pd.Series:
        return data.get("world_index:adj_close")["^HSI"]

    @staticmethod
    def get_asset_id_to_name() -> dict[str, str]:
        try:
            from finlab.compat import resolve_id_column

            tickers = data.get("hk_tickers")
            return dict(
                zip(tickers[resolve_id_column(tickers)], tickers["name"], strict=True)
            )
        except (ImportError, KeyError, ValueError, RuntimeError):
            return {}

    def market_close_at_timestamp(
        self, timestamp: pd.Timestamp | None = None
    ) -> pd.Timestamp:
        if timestamp is None:
            timestamp = self.get_price("close").index[-1]

        timestamp = self._normalize_market_timestamp(timestamp, "Asia/Hong_Kong")

        market_close = pd.Timestamp(timestamp.date()) + pd.Timedelta("16:00:00")
        return market_close.tz_localize("Asia/Hong_Kong")

    @staticmethod
    def market_open_time() -> tuple[int, int]:
        return (9, 30)

    @staticmethod
    def default_fee_ratio() -> float:
        return 1.0 / 1000

    @staticmethod
    def default_tax_ratio() -> float:
        return 1.3 / 1000

    @staticmethod
    def tzinfo() -> datetime.timezone:
        return datetime.timezone(datetime.timedelta(hours=8))


class HKFundMarket(HKMarket):
    """Hong Kong fund/ETF market using hk_fund_price data."""

    _price_table: ClassVar[str] = "hk_fund_price"
    _adj_prefix: ClassVar[str] = "etl:hk_fund_adj_"

    @staticmethod
    def get_name() -> str:
        return "hk_fund"
