"""Shared Metrics construction and JSON transport for formal backtests."""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any, cast

from finlab.core.metrics import Metrics  # type: ignore[import-not-found]

if TYPE_CHECKING:
    import pandas as pd


SCHEMA_VERSION = "finlab.agent-research.v2"


def metrics_from_creturn(creturn: pd.Series, backend: str) -> Metrics:
    """Build the same ``Metrics`` type exposed by ``Report.metrics``."""

    metrics = Metrics.from_creturn(creturn)
    metrics.warnings = []
    metrics.provenance = metrics_provenance(creturn, backend)
    return metrics


def metrics_to_dict(metrics: Metrics) -> dict[str, float | None]:
    """Serialize the formal screening subset at the JS/JSON boundary."""

    def json_float(value: object) -> float | None:
        number = float(cast("Any", value))
        return number if math.isfinite(number) else None

    return {
        "cagr": json_float(metrics.annual_return()),
        "sharpe_ratio": json_float(metrics.sharpe_ratio()),
        "max_drawdown": json_float(metrics.max_drawdown()),
    }


def metrics_provenance(creturn: pd.Series, backend: str) -> dict[str, Any]:
    daily = creturn.resample("1D").last().dropna()
    return {
        "schema_version": SCHEMA_VERSION,
        "metrics_backend": backend,
        "metrics_only": True,
        "return_series_frequency": "daily",
        "return_observations": len(daily),
        "effective_sample_start": (daily.index[0].isoformat() if len(daily) else None),
        "effective_sample_end": daily.index[-1].isoformat() if len(daily) else None,
    }
