"""Lazy evaluation for wide-format financial DataFrames.

Record a computation tree over FinlabDataFrame / pandas operations, then replay
using actual pandas methods on date-sliced data.
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING, Any

from finlab.dataframe.lazy_execution import (
    collect as _collect,
)
from finlab.dataframe.lazy_execution import (
    rebalance as _rebalance,
)
from finlab.dataframe.lazy_explain import _depth
from finlab.dataframe.lazy_explain import explain as _explain
from finlab.dataframe.lazy_nodes import (
    _NEEDS_HISTORY,
    BinaryNode,
    GetitemNode,
    Node,
    ReindexNode,
    RollingNode,
    ScalarNode,
    SourceNode,
    StorageSourceNode,
    UnaryNode,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    import pandas as pd


def lazy(df: pd.DataFrame) -> LazyWide:
    """Wrap a DataFrame into a lazy computation handle."""
    return LazyWide(SourceNode(df))


def lazy_from_storage(
    dataset: str,
    storage: object,
    loader: Callable[[], pd.DataFrame],
    index_loader: Callable[[], pd.Index] | None = None,
) -> LazyWide:
    """Wrap a storage-backed dataset without loading its DataFrame."""
    return LazyWide(StorageSourceNode(dataset, storage, loader, index_loader))


class LazyWide:
    """Records pandas operations; replays them on date-sliced data."""

    __array_priority__ = 1000
    # Unhashable: __eq__ returns LazyWide (not bool), so default hash would lie.
    __hash__ = None  # type: ignore[assignment]
    __slots__ = ("_node",)

    def __init__(self, node: Node) -> None:
        self._node = node

    def rolling(self, window: int, **kwargs: Any) -> _RollingProxy:
        return _RollingProxy(self, window, kwargs)

    def shift(self, periods: int = 1, **kw: Any) -> LazyWide:
        return self._unary("shift", periods, lookback=abs(periods), **kw)

    def diff(self, periods: int = 1) -> LazyWide:
        return self._unary("diff", periods, lookback=abs(periods))

    def pct_change(self, periods: int = 1, **kw: Any) -> LazyWide:
        return self._unary("pct_change", periods, lookback=abs(periods), **kw)

    def rank(self, *args: Any, **kw: Any) -> LazyWide:
        axis = args[0] if args else kw.get("axis", 0)
        lookback = 0 if axis in (1, "columns") else _NEEDS_HISTORY
        return self._unary("rank", *args, lookback=lookback, **kw)

    def fillna(self, *args: Any, **kw: Any) -> LazyWide:
        return self._unary("fillna", *args, **kw)

    def abs(self) -> LazyWide:
        return self._unary("abs")

    def clip(self, *args: Any, **kw: Any) -> LazyWide:
        return self._unary("clip", *args, **kw)

    def where(self, *args: Any, **kw: Any) -> LazyWide:
        return self._unary("where", *args, **kw)

    def mask(self, *args: Any, **kw: Any) -> LazyWide:
        return self._unary("mask", *args, **kw)

    def reindex(self, *args: Any, **kw: Any) -> LazyWide:
        return LazyWide(ReindexNode(self._node, args, kw))

    def astype(self, *args: Any, **kw: Any) -> LazyWide:
        return self._unary("astype", *args, **kw)

    def ffill(self, **kw: Any) -> LazyWide:
        return self._unary("ffill", lookback=_NEEDS_HISTORY, **kw)

    def cummax(self, **kw: Any) -> LazyWide:
        return self._unary("cummax", lookback=_NEEDS_HISTORY, **kw)

    def cummin(self, **kw: Any) -> LazyWide:
        return self._unary("cummin", lookback=_NEEDS_HISTORY, **kw)

    def cumsum(self, **kw: Any) -> LazyWide:
        return self._unary("cumsum", lookback=_NEEDS_HISTORY, **kw)

    def cumprod(self, **kw: Any) -> LazyWide:
        return self._unary("cumprod", lookback=_NEEDS_HISTORY, **kw)

    def bfill(self, **kw: Any) -> LazyWide:
        warnings.warn(
            "bfill() in lazy mode uses future data (look-ahead bias). "
            "This is usually unsafe for backtesting signals.",
            stacklevel=2,
        )
        return self._unary("bfill", lookback=_NEEDS_HISTORY, **kw)

    def average(self, n: int) -> LazyWide:
        return self.rolling(n, min_periods=int(n / 2)).mean()

    def is_smallest(self, n: int) -> LazyWide:
        return self._unary("is_smallest", n)

    def is_largest(self, n: int) -> LazyWide:
        return self._unary("is_largest", n)

    def sustain(self, nwindow: int, nsatisfy: int | None = None) -> LazyWide:
        return self.rolling(nwindow).sum() >= (nsatisfy or nwindow)

    def __eq__(self, other: object) -> LazyWide:  # type: ignore[override]
        return _binop(self, other, "__eq__")

    def __ne__(self, other: object) -> LazyWide:  # type: ignore[override]
        return _binop(self, other, "__ne__")

    def __invert__(self) -> LazyWide:
        return self._unary("__invert__")

    def __neg__(self) -> LazyWide:
        return self._unary("__neg__")

    def __getitem__(self, key: Any) -> LazyWide:
        key_node = key._node if isinstance(key, LazyWide) else key
        return LazyWide(GetitemNode(self._node, key_node))

    def __array_ufunc__(
        self,
        ufunc: Any,
        method: str,
        *inputs: Any,
        **kwargs: Any,
    ) -> LazyWide:
        if method != "__call__" or len(inputs) != 1 or inputs[0] is not self:
            return NotImplemented
        if "out" in kwargs:
            return NotImplemented
        return self._unary("__array_ufunc__", ufunc, **kwargs)

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)

        def _proxy(*args: Any, **kwargs: Any) -> LazyWide:
            return self._unary(name, *args, lookback=_NEEDS_HISTORY, **kwargs)

        return _proxy

    def rebalance(
        self,
        freq: str | pd.Index | list | LazyWide = "M",
        offset: str | None = None,
        start: str | pd.Timestamp | None = None,
        end: str | pd.Timestamp | None = None,
    ) -> pd.DataFrame:
        """Execute, computing only at rebalance dates."""
        freq = freq._node if isinstance(freq, LazyWide) else freq
        return _rebalance(self._node, freq=freq, offset=offset, start=start, end=end)

    def collect(self, dates: pd.DatetimeIndex | list | None = None) -> pd.DataFrame:
        """Execute at explicit dates, or all dates if *dates* is None."""
        return _collect(self._node, dates=dates)

    def explain(self) -> str:
        """Return a human-readable plan of the computation tree."""
        return _explain(self._node)

    def _unary(
        self, method_name: str, *args: Any, lookback: int = 0, **kw: Any
    ) -> LazyWide:
        return LazyWide(UnaryNode(self._node, method_name, args, kw, lookback=lookback))

    def __repr__(self) -> str:
        return f"LazyWide(depth={_depth(self._node)})"


def _binop(left: Any, right: Any, op: str) -> LazyWide:
    lnode = left._node if isinstance(left, LazyWide) else ScalarNode(left)
    rnode = right._node if isinstance(right, LazyWide) else ScalarNode(right)
    return LazyWide(BinaryNode(lnode, rnode, op))


def _install_binary_operator(name: str, op: str, *, reverse: bool) -> None:
    if reverse:

        def method(self: LazyWide, other: Any) -> LazyWide:
            return _binop(other, self, op)
    else:

        def method(self: LazyWide, other: Any) -> LazyWide:
            return _binop(self, other, op)

    setattr(LazyWide, name, method)


_FORWARD_OPS = (
    "__add__",
    "__sub__",
    "__mul__",
    "__truediv__",
    "__floordiv__",
    "__mod__",
    "__pow__",
    "__gt__",
    "__ge__",
    "__lt__",
    "__le__",
    "__and__",
    "__or__",
    "__xor__",
)

_REVERSE_OPS = {
    "__radd__": "__add__",
    "__rsub__": "__sub__",
    "__rmul__": "__mul__",
    "__rtruediv__": "__truediv__",
    "__rand__": "__and__",
    "__ror__": "__or__",
}

for _name in _FORWARD_OPS:
    _install_binary_operator(_name, _name, reverse=False)

for _name, _op in _REVERSE_OPS.items():
    _install_binary_operator(_name, _op, reverse=True)

del _name, _op


class _RollingProxy:
    """Captures ``df.rolling(n).method()`` as a single RollingNode."""

    __slots__ = ("_kwargs", "_parent", "_window")

    def __init__(self, parent: LazyWide, window: int, kwargs: dict) -> None:
        self._parent = parent
        self._window = window
        self._kwargs = kwargs

    def __getattr__(self, name: str) -> Any:
        def _method(*args: Any, **kwargs: Any) -> LazyWide:
            return LazyWide(
                RollingNode(
                    child=self._parent._node,
                    window=self._window,
                    rolling_kwargs=self._kwargs,
                    method=name,
                    method_args=args,
                    method_kwargs=kwargs,
                )
            )

        return _method
