"""Opt-in profiling for mixed-frequency dataframe alignment."""

from __future__ import annotations

import contextlib
import contextvars
import sys
import time
import tracemalloc
from collections.abc import Callable, Iterator
from dataclasses import asdict, dataclass
from functools import wraps
from typing import Any, TypeVar, cast

F = TypeVar("F", bound=Callable[..., Any])


@dataclass(slots=True)
class FactorAlignmentProfile:
    alignment_calls: int = 0
    alignment_wall_ms: float = 0.0
    total_wall_ms: float = 0.0
    peak_traced_bytes: int = 0
    runtime: str = "pyodide" if sys.platform == "emscripten" else "native"

    def to_dict(self) -> dict[str, int | float | str]:
        return asdict(self)


_ACTIVE: contextvars.ContextVar[FactorAlignmentProfile | None] = contextvars.ContextVar(
    "finlab_factor_alignment_profile", default=None
)


def profile_alignment_call(function: F) -> F:
    """Decorator with effectively zero timing work outside a profile context."""

    @wraps(function)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        profile = _ACTIVE.get()
        if profile is None:
            return function(*args, **kwargs)
        started = time.perf_counter()
        try:
            return function(*args, **kwargs)
        finally:
            profile.alignment_calls += 1
            profile.alignment_wall_ms += (time.perf_counter() - started) * 1000

    return cast("F", wrapper)


@contextlib.contextmanager
def factor_alignment_profile() -> Iterator[FactorAlignmentProfile]:
    """Measure reshape/alignment wall time and Python allocation peak."""
    profile = FactorAlignmentProfile()
    token = _ACTIVE.set(profile)
    already_tracing = tracemalloc.is_tracing()
    if not already_tracing:
        tracemalloc.start()
    _, starting_peak = tracemalloc.get_traced_memory()
    started = time.perf_counter()
    try:
        yield profile
    finally:
        profile.total_wall_ms = (time.perf_counter() - started) * 1000
        _, peak = tracemalloc.get_traced_memory()
        profile.peak_traced_bytes = max(peak - starting_peak, 0)
        if not already_tracing:
            tracemalloc.stop()
        _ACTIVE.reset(token)
