"""Public facade for the ``finlab.data`` package.

Implementation lives in focused submodules. Keep this file import-only so
navigation stays shallow and backward-compatible public imports remain stable.
"""

from __future__ import annotations

from . import context as _context
from .catalog import (
    search,
)
from .category_cache import category_cache_stats, clear_category_cache
from .context import DataContext, _default_context, clear, set_storage
from .freshness import (
    is_tradable,
    next_future_expiry,
    suggested_tradable_time,
)
from .get import (
    get,
    get_role,
    is_vip,
)
from .gets import gets
from .indicator import get_strategies, indicator
from .market import (
    market,
    set_market,
)

_CONTEXT_ATTRS = _context._CONTEXT_ATTRS

__all__ = [
    "DataContext",
    "_default_context",
    "category_cache_stats",
    "clear",
    "clear_category_cache",
    "get",
    "get_role",
    "get_strategies",
    "gets",
    "indicator",
    "is_tradable",
    "is_vip",
    "market",
    "next_future_expiry",
    "search",
    "set_market",
    "set_storage",
    "suggested_tradable_time",
]
