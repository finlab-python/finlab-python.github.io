"""Session-aware caches for security categories and column mappings.

The cache intentionally lives in :mod:`finlab.data` so dataframe and market
implementations can share it without importing one another.
"""

from __future__ import annotations

import hashlib
import threading
from collections import OrderedDict
from dataclasses import dataclass
from typing import TYPE_CHECKING

import pandas as pd

if TYPE_CHECKING:
    from collections.abc import Callable

_MAX_MAPPINGS = 64
_LOCK = threading.RLock()


@dataclass(frozen=True, slots=True)
class CategoryCacheStats:
    raw_hits: int
    raw_misses: int
    mapping_hits: int
    mapping_misses: int
    raw_entries: int
    mapping_entries: int


_raw: dict[str, tuple[str, pd.DataFrame]] = {}
_mappings: OrderedDict[tuple[str, str, str], pd.Series] = OrderedDict()
_counts = {"raw_hits": 0, "raw_misses": 0, "mapping_hits": 0, "mapping_misses": 0}
_generation = 0


def _canonical_market_key(market: str) -> str:
    key = market.lower()
    return {"tw": "tw_stock", "us": "us_stock"}.get(key, key)


def current_market_key() -> str:
    """Return the active data/config market without importing market classes."""
    from finlab import config
    from finlab.data.context import _default_context

    data_market = _default_context._current_market
    if data_market:
        return data_market.lower()
    return str(config.get_market().get_name()).lower()


def _frame_version(frame: pd.DataFrame) -> str:
    """Build a stable version token once per fetched categories frame."""
    for key in ("version", "updated_at", "generated_at", "last_modified"):
        value = frame.attrs.get(key)
        if value is not None:
            return f"{key}:{value}"
    digest = hashlib.blake2b(digest_size=12)
    digest.update(str(frame.shape).encode())
    digest.update(pd.util.hash_pandas_object(frame, index=True).values.tobytes())
    return digest.hexdigest()


def columns_fingerprint(columns: pd.Index) -> str:
    digest = hashlib.blake2b(digest_size=12)
    digest.update(type(columns).__qualname__.encode())
    digest.update(str(columns.dtype).encode())
    for value in columns:
        encoded = repr((type(value).__qualname__, value)).encode(
            "utf-8", errors="backslashreplace"
        )
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
    return digest.hexdigest()


def get_categories(
    loader: Callable[[], pd.DataFrame], *, market: str | None = None
) -> tuple[pd.DataFrame, str]:
    """Return raw categories once per active market/session."""
    key = _canonical_market_key(market or current_market_key())
    while True:
        with _LOCK:
            cached = _raw.get(key)
            if cached is not None:
                _counts["raw_hits"] += 1
                return cached[1], cached[0]
            load_generation = _generation

        frame = loader()
        version = _frame_version(frame)
        with _LOCK:
            existing = _raw.get(key)
            if existing is not None:
                _counts["raw_hits"] += 1
                return existing[1], existing[0]
            if load_generation != _generation:
                continue
            _raw[key] = (version, frame)
            _counts["raw_misses"] += 1
            return frame, version


def get_column_mapping(
    categories: pd.DataFrame,
    columns: pd.Index,
    builder: Callable[[pd.DataFrame, pd.Index], pd.Series],
    *,
    market: str | None = None,
    version: str | None = None,
) -> pd.Series:
    """Return an immutable-by-convention mapping for a columns fingerprint."""
    market_key = _canonical_market_key(market or current_market_key())
    version_key = version or _frame_version(categories)
    key = (market_key, version_key, columns_fingerprint(columns))
    with _LOCK:
        cached = _mappings.get(key)
        if cached is not None and cached.index.equals(columns):
            _mappings.move_to_end(key)
            _counts["mapping_hits"] += 1
            return cached
        if cached is not None:
            _mappings.pop(key, None)

    mapping = builder(categories, columns)
    with _LOCK:
        cached = _mappings.get(key)
        if cached is not None:
            _mappings.move_to_end(key)
            _counts["mapping_hits"] += 1
            return cached
        _mappings[key] = mapping
        _mappings.move_to_end(key)
        _counts["mapping_misses"] += 1
        while len(_mappings) > _MAX_MAPPINGS:
            _mappings.popitem(last=False)
    return mapping


def clear_category_cache(*, market: str | None = None) -> None:
    """Clear all category cache entries, or only entries for one market."""
    global _generation
    with _LOCK:
        _generation += 1
        if market is None:
            _raw.clear()
            _mappings.clear()
        else:
            key = _canonical_market_key(market)
            _raw.pop(key, None)
            for mapping_key in [k for k in _mappings if k[0] == key]:
                _mappings.pop(mapping_key, None)


def category_cache_stats() -> CategoryCacheStats:
    with _LOCK:
        return CategoryCacheStats(
            **_counts,
            raw_entries=len(_raw),
            mapping_entries=len(_mappings),
        )


def _reset_category_cache_stats() -> None:
    with _LOCK:
        for key in _counts:
            _counts[key] = 0
