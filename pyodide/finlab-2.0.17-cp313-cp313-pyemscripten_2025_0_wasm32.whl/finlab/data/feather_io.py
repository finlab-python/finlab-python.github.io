"""Feather V2 (Arrow IPC) read/write helpers.

pyarrow deprecated the ``pyarrow.feather`` module in 24.0.0; Feather V2 is
the Arrow IPC file format, so these helpers are drop-in equivalents built on
``pyarrow.ipc`` that read and write the same files without FutureWarnings.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pyarrow as pa

if TYPE_CHECKING:
    import pandas as pd


def read_frame(source: Any) -> pd.DataFrame:
    """Read a Feather V2 payload (buffer or open file) into a DataFrame."""
    return pa.ipc.open_file(source).read_all().to_pandas()


def read_frame_from_path(path: str, columns: list[str] | None = None) -> pd.DataFrame:
    """Read a Feather V2 file, optionally projecting to ``columns``.

    Selecting ``columns`` preserves the stored pandas schema metadata, so an
    index column selected here is restored as the DataFrame index, matching
    ``pd.read_feather(..., columns=...)``. Projection goes through
    ``pyarrow.dataset`` so only the selected columns are decompressed —
    ``read_all().select()`` would decompress the whole lz4 table first.
    """
    if columns is not None:
        try:
            import pyarrow.dataset as ds
        except ImportError:  # minimal pyarrow builds (e.g. wasm) lack dataset
            pass
        else:
            dataset = ds.dataset(path, format="feather")
            return dataset.to_table(columns=columns).to_pandas()
    with pa.memory_map(path, "r") as source:
        table = pa.ipc.open_file(source).read_all()
        if columns is not None:
            table = table.select(columns)
        return table.to_pandas()


def write_frame(df: pd.DataFrame, path: str) -> None:
    """Write a DataFrame as a Feather V2 file (lz4, like ``df.to_feather``)."""
    table = pa.Table.from_pandas(df)
    options = pa.ipc.IpcWriteOptions(compression="lz4")
    with (
        pa.OSFile(path, "wb") as sink,
        pa.ipc.new_file(sink, table.schema, options=options) as writer,
    ):
        writer.write_table(table)
