from __future__ import annotations

import logging
from typing import TYPE_CHECKING, TypeAlias, TypeGuard, cast

__all__ = ["Portfolio"]

if TYPE_CHECKING:
    from collections.abc import Callable

import pandas as pd

from finlab.core.report import Report, ReportExecution

logger = logging.getLogger(__name__)

PositionScheduler: TypeAlias = ReportExecution
POSITION_SCHEDULER_CLASS: type[ReportExecution] = ReportExecution


def is_position_scheduler(value: object) -> TypeGuard[PositionScheduler]:
    return isinstance(value, POSITION_SCHEDULER_CLASS)


def _compute_returns_and_position(
    reports: dict[str, tuple[Report, float]],
    active_reports: dict[str, tuple[Report, float]],
) -> tuple[pd.Series, pd.DataFrame]:
    """Compute cumulative returns and blended position from sub-reports."""
    pct = pd.DataFrame(
        {k: v[0].creturn.pct_change() for k, v in active_reports.items()}
    ).dropna(how="any")
    weight = pd.Series({k: v[1] for k, v in active_reports.items()})
    creturn = (pct * weight).sum(axis=1).add(1).cumprod()

    union_cols: list[str] = sorted(
        {col for report, _ in reports.values() for col in report.position.columns}
    )
    position = sum(
        report.position.reindex(union_cols, axis=1, fill_value=0) * w
        for _, (report, w) in reports.items()
    )
    return creturn, position.fillna(0)


def _merge_trades(reports: dict[str, tuple[Report, float]]) -> pd.DataFrame:
    """Merge trades from all sub-reports, sorted by entry date."""
    trades = (
        pd.concat([v[0].trades for v in reports.values()])
        .sort_values("entry_sig_date")
        .reset_index(drop=True)
        .tail(500)
    )
    trades.index.name = "trade_index"
    return trades


def _merge_mae_mfe(reports: dict[str, tuple[Report, float]]) -> pd.DataFrame:
    """Merge MAE/MFE data from sub-reports."""
    parts = [
        v[0].mae_mfe
        for v in reports.values()
        if hasattr(v[0], "mae_mfe") and len(v[0].mae_mfe) > 0
    ]
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def _get_source_execution(report: Report) -> object | None:
    """Extract the execution source from a report."""
    if hasattr(report, "execution"):
        return report.execution
    if hasattr(report, "position_schedulers"):
        return report.position_schedulers
    return None


def _build_position_schedulers(
    reports: dict[str, tuple[Report, float]],
) -> dict[str, PositionScheduler]:
    """Build the position_schedulers dict from sub-reports."""
    schedulers: dict[str, PositionScheduler] = {}
    for name, (report, weight) in reports.items():
        if "|" in name:
            raise ValueError('name should not contain "|"')

        source_execution = _get_source_execution(report)

        if isinstance(source_execution, dict):
            for sub_name, sub_exec in source_execution.items():
                if not is_position_scheduler(sub_exec):
                    raise ValueError(
                        f"position_schedulers[{sub_name}] should be a PositionScheduler"
                    )
                schedulers[f"{name}|{sub_name}"] = sub_exec._replace(
                    total_weight=sub_exec.total_weight * weight
                )
        elif is_position_scheduler(source_execution):
            schedulers[name] = source_execution._replace(
                total_weight=source_execution.total_weight * weight
            )
        elif isinstance(report, Report):
            execution = report.execution
            if is_position_scheduler(execution):
                schedulers[name] = execution._replace(total_weight=weight)

    return schedulers


def _validate_schedulers(schedulers: dict[str, PositionScheduler]) -> None:
    """Validate that all schedulers have correct types."""
    for name, scheduler in schedulers.items():
        if not is_position_scheduler(scheduler):
            raise ValueError(
                "position_schedulers should be a dict of PositionScheduler"
            )
        if not isinstance(scheduler.weights, pd.Series):
            raise ValueError(f"weights should be a pd.Series for scheduler '{name}'")
        if not isinstance(scheduler.next_weights, pd.Series):
            raise ValueError(
                f"next_weights should be a pd.Series for scheduler '{name}'"
            )


class Portfolio(Report):
    def __init__(self, reports: dict[str, tuple[Report, float]] | Report) -> None:
        """建構 Portfolio 物件。

        Parameters:
            - reports (dict[str, tuple[Report, float]]): 代表投資組合的字典，key 為資產名稱，value 是回測報告與部位。
            A dictionary representing the portfolio, where the keys are the names of the assets and the values are tuples containing the asset's report and weight.


        Example:
            **組合多個策略**
            ```
            from finlab import sim
            from finlab.portfolio import Portfolio

            # 請參閱 sim 函數的文件以獲取更多信息
            # https://doc.finlab.tw/getting-start/

            report_strategy1 = sim(...)
            report_strategy2 = sim(...)
            report_strategy3 = sim(...)

            portfolio = Portfolio({
                'strategy1': (report_strategy1, 0.3),
                'strategy2': (report_strategy2, 0.4),
                'strategy3': (report_strategy3, 0.3),
            })
            ```
        """

        # mind user about this is the beta version
        logger.info(
            "Portfolio is in beta version, please report any issue to FinLab Team at https://discord.gg/tAr4ysPqvR"
        )

        if isinstance(reports, Report):
            reports = {"strategy": (reports, 1.0)}

        # Filter out strategies with zero weight to ensure consistency
        active_reports = {k: v for k, v in reports.items() if v[1] != 0}
        if not active_reports:
            raise ValueError(
                "All strategies have zero weight. At least one strategy must have non-zero weight."
            )

        self.portfolio: dict[str, tuple[Report, float]] = reports
        creturn, position = _compute_returns_and_position(reports, active_reports)
        self.creturn: pd.Series = creturn
        self.position: pd.DataFrame = position

        sample_report = next(iter(reports.values()))[0]
        next_trading_date = min(v[0].next_trading_date for v in reports.values())

        super().__init__(
            creturn,
            self.position,
            sample_report.fee_ratio,
            sample_report.tax_ratio,
            sample_report.trade_at,
            next_trading_date,
            sample_report.market,
        )

        self.trades: pd.DataFrame = _merge_trades(reports)
        self.live_performance_start: pd.Timestamp = self.trades.entry_sig_date.min()
        self.stop_loss: float | None = None
        self.take_profit: float | None = None
        self.trail_stop: float | None = None
        self.resample: str | None = None
        self.mae_mfe: pd.DataFrame = _merge_mae_mfe(reports)

        self.position_schedulers = _build_position_schedulers(reports)
        _validate_schedulers(self.position_schedulers)
        self.execution: dict[str, PositionScheduler] = self.position_schedulers

    @classmethod
    def from_weight_function(
        cls, reports: dict[str, Report], weight_function: Callable[[], pd.DataFrame]
    ) -> Portfolio:
        creturns = pd.DataFrame({k: r.creturn for k, r in reports.items()})
        weight = weight_function()
        if not creturns.columns.isin(weight.columns).all():
            raise ValueError("Report names must be a subset of weight columns")
        if not weight.iloc[-1].notna().all():
            raise ValueError("Latest weight row contains NaN values")

        current_weight = weight.iloc[-1]
        ret = cls({k: (r, current_weight[k]) for k, r in reports.items()})
        ret.creturn = (creturns.pct_change() * weight).sum(axis=1).add(1).cumprod()
        return ret

    def position_info2(self) -> dict[str, object]:
        # get position info for all reports in self.portfolio
        position: dict[str, object] = {}

        for name, (report, weight) in self.portfolio.items():
            pinfo = report.position_info2()

            if "positionConfig" in pinfo:
                config = cast("dict[str, float]", pinfo["positionConfig"])
                config["weight"] = weight
                position[name] = pinfo

            # handle recursive position
            else:
                for sub_name, sub_position in pinfo.items():
                    sub_position = cast("dict[str, object]", sub_position)
                    config = cast("dict[str, float]", sub_position["positionConfig"])
                    config["weight"] *= weight
                    position[f"{name}|{sub_name}"] = sub_position

        return position

    def is_stop_triggered(self) -> bool:
        position_schedulers = self.position_schedulers
        if not isinstance(position_schedulers, dict):
            position_schedulers = {"strategy": position_schedulers}

        for scheduler in position_schedulers.values():
            if scheduler.actions.isin(["sl", "tp"]).any():
                return True

        return False
