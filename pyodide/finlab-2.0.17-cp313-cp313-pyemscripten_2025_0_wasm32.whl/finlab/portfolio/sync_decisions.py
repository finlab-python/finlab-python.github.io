"""Strategy-update decision logic for PortfolioSyncManager.update().

Extracted from portfolio_sync_manager.py so that the pure decision
paths -- which strategies need rebalancing, which have drifted, etc. --
can be tested without broker or market dependencies.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from finlab.compat import resolve_position_entry_symbol

if TYPE_CHECKING:
    from finlab.portfolio.portfolio import PositionScheduler
    from finlab.schemas import StrategyPositionDataDict

logger = logging.getLogger(__name__)

__all__ = ["identify_updated_strategies"]


def identify_updated_strategies(
    *,
    portfolio: dict[str, PositionScheduler],
    position: dict[str, StrategyPositionDataDict],
    smooth_transition: bool,
    force_override_difference: bool,
) -> list[str]:
    """Return the list of strategy IDs that should be rebalanced.

    This encapsulates two decision passes:

    1. **Rebalance triggers** -- a strategy is marked for update when its
       rebalance date has arrived or when its weight changed (unless
       *smooth_transition* suppresses the latter).
    2. **Stock-list drift** -- if a strategy's current position contains
       symbols no longer present in its report, it is also marked (only
       when *force_override_difference* is True).
    """
    updated: list[str] = []

    # --- Pass 1: rebalance / weight triggers ---
    for sid, allocation in portfolio.items():
        weight = allocation.total_weight

        if weight == 0 and sid not in position:
            continue

        weight_is_updated = sid not in position or weight != position[sid]["weight"]
        is_trading_date = allocation.is_rebalance_due()

        update_conditions = [
            (is_trading_date, "today is trading date"),
            (
                not smooth_transition and weight_is_updated,
                "weight changed (set smooth_transition=True to avoid this)",
            ),
        ]

        if any(flag for flag, _ in update_conditions):
            logger.info(
                "%s should be updated because: %s",
                sid,
                ", ".join(reason for (flag, reason) in update_conditions if flag),
            )
            updated.append(sid)

        if smooth_transition and weight_is_updated:
            logger.info(
                "%s weight changed, but not updated because "
                "smooth_transition is enabled. It will be updated when "
                "next rebalance date comes.",
                sid,
            )
            logger.info(
                "If you want to update the weight immediately, "
                "set smooth_transition=False"
            )

    # --- Pass 2: stock-list drift detection ---
    for sid, info in position.items():
        if sid in updated:
            continue
        if sid not in portfolio:
            logger.warning("%s not in portfolio", sid)
            continue

        position_sids = sorted(
            resolve_position_entry_symbol(p) for p in info["position"]
        )
        report = portfolio[sid]
        report_ids = [s.split(" ")[0] for s in sorted(report.weights.index.tolist())]

        if not all(s in report_ids for s in position_sids):
            logger.warning("%s has changed stock list", sid)
            logger.warning("current: %s", position_sids)
            logger.warning("report: %s", report_ids)

            if force_override_difference:
                logger.warning("force override")
                updated.append(sid)
            else:
                logger.warning("please set force_override=True to override")

    return updated
