"""PE/PB river chart functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import plotly.express as px
import plotly.graph_objects as go

if TYPE_CHECKING:
    import pandas as pd

from finlab import data
from finlab.compat import param_alias, resolve_id_column
from finlab.plot._core import df_date_filter
from finlab.utils import logger

__all__ = [
    "get_pe_river_data",
    "plot_tw_stock_river",
]


@param_alias("stock_id", "symbol")
def get_pe_river_data(
    start: str | None = None,
    end: str | None = None,
    symbol: str = "2330",
    mode: str = "pe",
    split_range: int = 6,
) -> pd.DataFrame | None:
    if mode not in {"pe", "pb"}:
        logger.error("mode error")
        return None
    close = df_date_filter(data.get("price:收盤價"), start, end)
    pe = df_date_filter(data.get("price_earning_ratio:本益比"), start, end)
    pb = df_date_filter(data.get("price_earning_ratio:股價淨值比"), start, end)
    df = {"pe": pe, "pb": pb}[mode]
    if symbol not in df.columns:
        logger.error("symbol input is not in data.")
        return None
    df = df[symbol]
    max_value = df.max()
    min_value = df.min()
    quan_value = (max_value - min_value) / split_range
    river_borders = [
        round(min_value + quan_value * i, 2) for i in range(split_range + 1)
    ]
    result = (close[symbol] / df).dropna().to_frame()
    index_name = f"{mode}/close"
    result.columns = [index_name]
    result["close"] = close[symbol]
    result["pe"] = pe[symbol]
    result["pb"] = pb[symbol]
    for r in river_borders:
        col_name = f"{r} {mode}"
        result[col_name] = result[index_name] * r
    return round(result, 2)


@param_alias("stock_id", "symbol")
def plot_tw_stock_river(
    symbol: str = "2330",
    start: str | None = None,
    end: str | None = None,
    mode: str = "pe",
    split_range: int = 8,
) -> go.Figure | None:
    """繪製台股河流圖

    使用 PE or PB 的最高與最低值繪製河流圖，判斷指標所處位階。

    Args:
      symbol (str): 台股股號，ex:`'2330'`。
      start (str): 資料開始日，ex:`'2020-01-02'`。
      end (str): 資料結束日，ex:`'2022-01-05'`。
      mode (str): `'pe'` or `'pb'` (本益比或股價淨值比)。
      split_range (int): 河流階層數。
    Returns:
        (plotly.graph_objects.Figure): 河流圖
    Examples:
      ```py
      from finlab.plot import plot_tw_stock_river
      plot_tw_stock_river(symbol='2330', start='2015-1-1', end='2022-7-1', mode='pe', split_range=10)
      ```
      ![單檔標的子選指標雷達圖](/docs/reference/img/plot/pe_river.png)
    """
    df = get_pe_river_data(start, end, symbol, mode, split_range)
    if df is None:
        logger.error("data error")
        return None
    col_name_set = [i for i in df.columns if any(map(str.isdigit, i))]

    fig = go.Figure()
    for n, c in enumerate(col_name_set):
        fill_mode = None if n == 0 else "tonexty"
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=df[c],
                fill=fill_mode,
                line={"width": 0, "color": px.colors.qualitative.Prism[n]},
                name=c,
            )
        )
    customdata = [(c, p) for c, p in zip(df["close"], df[mode], strict=True)]
    hovertemplate = (
        "<br>date:%{x|%Y/%m/%d}<br>close:%{customdata[0]}"
        f"<br>{mode}:%{{customdata[1]}}"
    )
    fig.add_trace(
        go.Scatter(
            x=df.index,
            y=df["close"],
            line={"width": 2.5, "color": "#2e4391"},
            customdata=customdata,
            hovertemplate=hovertemplate,
            name="close",
        )
    )

    _cats = data.get("security_categories")
    security_categories = _cats.set_index(resolve_id_column(_cats))
    stock_name = security_categories.loc[symbol]["name"]
    fig.update_layout(
        title=f"{symbol} {stock_name} {mode.upper()} River Chart",
        template="ggplot2",
        yaxis={
            "title": "price",
        },
    )
    fig.update_xaxes(showspikes=True)
    fig.update_yaxes(showspikes=True)
    return fig
