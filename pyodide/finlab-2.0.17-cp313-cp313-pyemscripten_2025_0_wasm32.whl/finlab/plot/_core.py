"""Shared constants, type aliases, and colour utilities for the plot package."""

from __future__ import annotations

import itertools
from collections.abc import Callable
from numbers import Real
from typing import TYPE_CHECKING, Final, Protocol, TypeAlias, cast

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

if TYPE_CHECKING:
    from collections.abc import Generator, Sequence

__all__ = [
    "IndicatorSpec",
    "average",
    "color_generator",
    "df_date_filter",
]

# A single indicator: DataFrame, Series, ndarray, column name, or a callable returning one of those.
IndicatorSpec: TypeAlias = (
    pd.DataFrame
    | pd.Series
    | np.ndarray
    | str
    | Callable[[pd.DataFrame], pd.DataFrame | pd.Series | np.ndarray]
)

_PLOTLY_PALETTE: Final[list[str]] = px.colors.qualitative.Plotly
_YI: Final[int] = 100_000_000  # 億


class _Comparable(Protocol):
    def __lt__(self, other: object) -> bool: ...

    def __gt__(self, other: object) -> bool: ...


def _convert_color(c: object) -> str:
    """Map simple colour names to Plotly palette; pass through others."""
    color = str(c)
    mapping = {
        "blue": _PLOTLY_PALETTE[0],
        "red": _PLOTLY_PALETTE[1],
        "green": _PLOTLY_PALETTE[2],
        "purple": _PLOTLY_PALETTE[3],
        "orange": _PLOTLY_PALETTE[4],
        "yellow": _PLOTLY_PALETTE[4],
        "cyan": _PLOTLY_PALETTE[5],
        "pink": _PLOTLY_PALETTE[6],
        "brown": _PLOTLY_PALETTE[7],
        "grey": "lightgray",
        "gray": "lightgray",
    }
    return mapping.get(color.lower(), color)


def _add_last_point_marker(
    fig: go.Figure, x: pd.Timestamp, y: float, colour: str
) -> None:
    fig.add_trace(
        go.Scatter(
            x=[x],
            y=[y],
            mode="markers",
            marker={"size": 16, "color": colour, "line": {"width": 0}},
            hoverinfo="skip",
            showlegend=False,
        ),
    )
    fig.add_annotation(
        x=x,
        y=y,
        text=f"{y:.2f}",
        showarrow=False,
        xshift=10,
        font={"size": 16, "color": colour},
        xanchor="left",
        yanchor="middle",
    )


def _in_range(val: object, lower: object | None, upper: object | None) -> bool:
    """Return True if lower <= val <= upper with None as an open bound."""
    comparable = cast("_Comparable", val)
    try:
        if lower is not None and comparable < lower:
            return False
        if upper is not None and comparable > upper:
            return False
    except TypeError:
        return False
    return True


def _as_float_or_none(value: object) -> float | None:
    return float(value) if isinstance(value, Real) else None


def _resolve_color(
    x: object,
    y: object,
    default_color: str,
    h_line_ranges: Sequence[Sequence[object]],
    v_line_ranges: Sequence[Sequence[object]],
) -> str:
    """
    Decide colour for point (x,y). Later ranges override earlier ones.
    Accept formats:
        [lower, upper, color]      # full
        [threshold, color]         # lower bound only
    """
    colour = default_color

    # horizontal (y) ranges
    for rng in h_line_ranges:
        if len(rng) == 3:
            lo, hi, clr = rng
        elif len(rng) == 2:
            lo, clr = rng
            hi = None
        else:
            continue  # skip malformed
        lo = _as_float_or_none(lo)
        hi = _as_float_or_none(hi)
        if _in_range(y, lo, hi):
            colour = _convert_color(clr)
    # vertical (x) ranges
    for rng in v_line_ranges:
        if len(rng) == 3:
            lo, hi, clr = rng
        elif len(rng) == 2:
            lo, clr = rng
            hi = None
        else:
            continue
        if _in_range(x, lo, hi):
            colour = _convert_color(clr)
    return colour


def df_date_filter(
    df: pd.DataFrame, start: str | None = None, end: str | None = None
) -> pd.DataFrame:
    if start:
        df = df[df.index >= start]
    if end:
        df = df[df.index <= end]
    return df


def color_generator() -> Generator[str]:
    yield from itertools.cycle(px.colors.qualitative.Plotly)


def average(series: pd.Series, n: int) -> pd.Series:
    return series.rolling(n, min_periods=int(n / 2)).mean()
