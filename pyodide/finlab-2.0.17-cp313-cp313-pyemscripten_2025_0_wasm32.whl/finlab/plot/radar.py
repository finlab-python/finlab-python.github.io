"""Radar chart functions."""

from __future__ import annotations

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from finlab import data
from finlab.utils import logger

__all__ = [
    "plot_tw_stock_radar",
]


def _get_rank(item: str, period: str | None = None, cut_bins: int = 10) -> pd.Series:
    df = data.get(item)
    df = df.iloc[-1] if period is None else df.loc[period]

    df_rank = df.rank(pct=True)
    return pd.cut(x=df_rank, bins=cut_bins, labels=list(range(1, cut_bins + 1)))


def _get_rank_df(
    feats: list[str], period: str | None = None, cut_bins: int = 10
) -> pd.DataFrame:
    df = pd.concat([_get_rank(f, period, cut_bins) for f in feats], axis=1)
    columns_name = [f[f.index(":") + 1 :] for f in feats]
    df.columns = columns_name
    df.index.name = "symbol"
    return df


def _plot_radar(
    df: pd.DataFrame,
    mode: str = "bar_polar",
    line_polar_fill: str | None = None,
    title: str | None = None,
    polar_range: int = 10,
) -> go.Figure:
    args = {
        "data_frame": df,
        "r": "value",
        "theta": "variable",
        "color": "symbol",
        "line_close": True,
        "color_discrete_sequence": px.colors.sequential.Plasma_r,
        "template": "plotly_dark",
    }
    if mode != "line_polar":
        args.pop("line_close")

    fig = getattr(px, mode)(**args)
    if title is None:
        title = "Features Radar"
    fig.update_layout(
        title={
            "text": title,
            "x": 0.49,
            "y": 0.99,
            "xanchor": "center",
            "yanchor": "top",
        },
        paper_bgcolor="rgb(41, 30, 109)",
        polar={"radialaxis": {"visible": True, "range": [0, polar_range]}},
        width=1200,
        height=600,
    )
    if mode == "line_polar":
        # None,toself,tonext
        fig.update_traces(fill=line_polar_fill)
    return fig


def plot_tw_stock_radar(
    portfolio: list[str],
    feats: list[str] | None = None,
    mode: str = "line_polar",
    line_polar_fill: str | None = None,
    period: str | None = None,
    cut_bins: int = 10,
    title: str | None = None,
    custom_data: pd.DataFrame | None = None,
) -> go.Figure | None:
    """繪製台股雷達圖

    比較持股組合的指標分級特性。若數值為nan，則不顯示分級。

    Args:
      portfolio (list):持股組合，ex:`['1101','1102']`。
      feats (list): 選定FinLab資料庫內的指標組成資料集。預設為18項財務指標。
                    ex:['fundamental_features:營業毛利率','fundamental_features:營業利益率']
      mode (str): 雷達圖模式 ，ex:'bar_polar','scatter_polar','line_polar'`。
        !!!note

            參考[不同模式的差異](https://plotly.com/python-api-reference/generated/plotly.express.html)
      line_polar_fill (str):將區域設置為用純色填充 。ex:`None,'toself','tonext'`
                           `'toself'`將跡線的端點（或跡線的每一段，如果它有間隙）連接成一個封閉的形狀。
                           如果一條完全包圍另一條（例如連續的等高線），則`'tonext'`填充兩條跡線之間的空間，如果之前沒有跡線，
                           則其行為類似於`'toself'`。如果一條跡線不包含另一條跡線，則不應使用`'tonext'`。
        欲使用 line_polar，請將pandas版本降至 1.4.4。
        !!!note

            參考[plotly.graph_objects.Scatterpolar.fill](https://plotly.github.io/plotly.py-docs/generated/plotly.graph_objects.Scatterpolar.html)

      period (str): 選擇第幾期的特徵資料，預設為近一季。
                    ex: 設定數值為'2020-Q2，取得2020年第二季資料比較。
      cut_bins (int):特徵分級級距。
      title (str):圖片標題名稱。
      custom_data (pd.DataFrame): 客製化指標分級，欄名為特徵
                    格式範例:

        | stock_id   |  營業毛利率 |營業利益率|稅後淨利率|
        |:-----------|-------:|-------:|-------:|
        | 1101       |   2    |    5   |      3|
        | 1102       |   1    |    8   |      4|
    Returns:
        (plotly.graph_objects.Figure): 雷達圖
    Examples:
        ex1:比較持股組合累計分數，看持股組合偏重哪像特徵。
        ```py
        from finlab.plot import plot_tw_stock_radar
        plot_tw_stock_radar(portfolio=["1101", "2330", "8942", "6263"], mode="bar_polar", line_polar_fill='None')
        ```
        ![持股組合雷達圖](/docs/reference/img/plot/radar_many.png)
        ex2:看單一個股特徵分級落點。
        ```py
        from finlab.plot import plot_tw_stock_radar
        feats = ['fundamental_features:營業毛利率', 'fundamental_features:營業利益率', 'fundamental_features:稅後淨利率',
                 'fundamental_features:現金流量比率', 'fundamental_features:負債比率']
        plot_tw_stock_radar(portfolio=["9939"], feats=feats, mode="line_polar", line_polar_fill='toself', cut_bins=8)
        ```
        ![單檔標的子選指標雷達圖](/docs/reference/img/plot/radar_single.png)
    """
    if custom_data is None:
        if feats is None:
            feats = [
                "fundamental_features:營業毛利率",
                "fundamental_features:營業利益率",
                "fundamental_features:稅後淨利率",
                "fundamental_features:ROA綜合損益",
                "fundamental_features:ROE綜合損益",
                "fundamental_features:業外收支營收率",
                "fundamental_features:現金流量比率",
                "fundamental_features:負債比率",
                "fundamental_features:流動比率",
                "fundamental_features:速動比率",
                "fundamental_features:存貨週轉率",
                "fundamental_features:營收成長率",
                "fundamental_features:營業毛利成長率",
                "fundamental_features:營業利益成長率",
                "fundamental_features:稅前淨利成長率",
                "fundamental_features:稅後淨利成長率",
                "fundamental_features:資產總額成長率",
                "fundamental_features:淨值成長率",
            ]
        df = _get_rank_df(feats, period=period, cut_bins=cut_bins)
    else:
        df = custom_data.copy()

    col_name = df.columns
    portfolio = df.index.intersection(portfolio)
    if len(portfolio) < 1:
        logger.error("data is not existed.")
        return None
    df = df.loc[portfolio]
    df = df.reset_index()
    df = pd.melt(df, id_vars=["symbol"], value_vars=col_name)
    polar_range = cut_bins * len(portfolio)
    return _plot_radar(
        df=df,
        mode=mode,
        line_polar_fill=line_polar_fill,
        title=title,
        polar_range=polar_range,
    )
