from __future__ import annotations

import importlib
import random
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Final, Protocol, TypeAlias, cast

__all__ = ["VerifyResult", "verify_strategy"]

if TYPE_CHECKING:
    from collections.abc import Callable, Generator

    from finlab.core.report import Report

import numpy as np
import pandas as pd

from finlab import data as _data_module


class _BacktestSimModule(Protocol):
    _suppress_upload: bool


VerifySummary: TypeAlias = dict[str, object]
VerifyDetail: TypeAlias = dict[str, object]


_backtest_sim_module = cast(
    "_BacktestSimModule", importlib.import_module("finlab.backtest.sim")
)


@contextmanager
def _sandbox(truncate_end: str | None = None) -> Generator[None, None, None]:
    """Temporarily suppress uploads and override truncate_end."""
    with _data_module._default_context.override(
        truncate_end=truncate_end or _data_module._default_context.truncate_end,
    ):
        _backtest_sim_module._suppress_upload = True
        try:
            yield
        finally:
            _backtest_sim_module._suppress_upload = False


_MISMATCH_COLS: Final[list[str]] = ["symbol", "column", "full_value", "truncated_value"]
_COMPARE_COLS: Final[list[str]] = ["exit_date", "exit_sig_date", "return", "position"]


@dataclass(slots=True)
class VerifyResult:
    """Result of ``verify_strategy``."""

    passed: bool
    n_tests: int
    n_passed: int
    n_failed: int
    summary_df: pd.DataFrame = field(repr=False)
    details: list[VerifyDetail] = field(repr=False)


def _empty_result(verbose: bool, message: str) -> VerifyResult:
    """Return a trivially-passing VerifyResult with no test data."""
    if verbose:
        print(message)
    return VerifyResult(
        passed=True,
        n_tests=0,
        n_passed=0,
        n_failed=0,
        summary_df=pd.DataFrame(),
        details=[],
    )


def _select_test_dates(
    candidates: list[pd.Timestamp],
    n_tests: int,
    test_dates: list[str] | None,
) -> list[pd.Timestamp]:
    """Choose which truncation dates to verify against."""
    explicit = {pd.Timestamp(d) for d in test_dates} if test_dates else set()
    remaining = [d for d in candidates if d not in explicit]
    n_random = max(0, n_tests - len(explicit))
    sampled = random.sample(remaining, min(n_random, len(remaining)))
    return sorted(explicit | set(sampled))


def _run_single_verification(
    strategy: Callable[[], Report],
    test_date: pd.Timestamp,
    trades_full: pd.DataFrame,
) -> tuple[VerifySummary, VerifyDetail]:
    """Run one truncated backtest and return (summary_row, detail_entry)."""
    _data_module._default_context.truncate_end = f"{test_date:%Y-%m-%d}"
    report_t = strategy()
    trades_t = report_t.trades.copy()
    mismatches = _compare_trades(trades_full, trades_t)
    n_checked = int(trades_t["exit_date"].notna().sum())
    n_mismatch = len(mismatches)
    summary = {
        "test_date": test_date,
        "trades_checked": n_checked,
        "mismatches": n_mismatch,
        "passed": n_mismatch == 0,
    }
    detail = {"test_date": test_date, "mismatches": mismatches, "error": None}
    return summary, detail


def _print_verification_result(
    label: str, summary: VerifySummary, detail: VerifyDetail
) -> None:
    """Print result for one verification date."""
    if summary.get("passed"):
        print(f"  {label}: {summary['trades_checked']} trades checked — PASSED")
        return
    n_mismatch = summary["mismatches"]
    print(
        f"  {label}: {summary['trades_checked']} trades checked — "
        f"FAILED ({n_mismatch} mismatches)"
    )
    mismatches = detail["mismatches"]
    if not isinstance(mismatches, pd.DataFrame) or mismatches.empty:
        return
    for _, row in mismatches.head(5).iterrows():
        print(
            f"    - {row['symbol']}: {row['column']} "
            f"differs ({row['full_value']} vs {row['truncated_value']})"
        )


def verify_strategy(
    strategy: Callable[[], Report],
    n_tests: int = 5,
    test_dates: list[str] | None = None,
    verbose: bool = True,
) -> VerifyResult:
    """Detect lookahead bias by comparing trades at historical truncation points.

    The *strategy* callable should build positions **and** call ``sim()``
    internally, returning the :class:`~finlab.core.report.Report`::

        def my_strategy():
            close = data.get('price:收盤價')
            pos = (close == close.rolling(20).max())
            return sim(pos, resample='M')

        result = verify_strategy(my_strategy)

    Args:
        strategy: Zero-arg callable that returns a ``Report`` (the return
            value of ``sim()``).
        n_tests: Number of random truncation dates to test (default 5).
        test_dates: Explicit date strings to include in addition to the
            random sample.
        verbose: Print progress and summary to stdout.
    """
    with _sandbox():
        report_full = strategy()
        trades_full = report_full.trades.copy()

        completed = trades_full[trades_full["exit_date"].notna()]
        if completed.empty:
            return _empty_result(verbose, "No completed trades — nothing to verify.")

        candidates = sorted(
            pd.to_datetime(completed["exit_date"]).dt.normalize().unique()
        )
        candidates = candidates[:-2] if len(candidates) > 2 else candidates
        if not candidates:
            return _empty_result(
                verbose, "No suitable candidate dates found for verification."
            )

        selected = _select_test_dates(candidates, n_tests, test_dates)
        if verbose:
            print(f"Verifying strategy consistency across {len(selected)} dates...")

        summary_rows: list[VerifySummary] = []
        details: list[VerifyDetail] = []

        for idx, test_date in enumerate(selected):
            label = f"[{idx + 1}/{len(selected)}] {test_date:%Y-%m-%d}"
            try:
                summary, detail = _run_single_verification(
                    strategy, test_date, trades_full
                )
            except (KeyError, ValueError, TypeError, RuntimeError) as e:
                summary = {
                    "test_date": test_date,
                    "trades_checked": 0,
                    "mismatches": 0,
                    "passed": False,
                }
                detail = {
                    "test_date": test_date,
                    "mismatches": pd.DataFrame(),
                    "error": str(e),
                }
                if verbose:
                    print(f"  {label}: ERROR — {e}")
                summary_rows.append(summary)
                details.append(detail)
                continue

            summary_rows.append(summary)
            details.append(detail)
            if verbose:
                _print_verification_result(label, summary, detail)

        summary_df = pd.DataFrame(summary_rows)
        n_passed = int(summary_df["passed"].sum())
        n_failed = len(summary_df) - n_passed

        if verbose:
            print(
                f"\nResult: {n_passed}/{len(summary_df)} PASSED, "
                f"{n_failed}/{len(summary_df)} FAILED"
            )

        return VerifyResult(
            passed=(n_failed == 0),
            n_tests=len(summary_df),
            n_passed=n_passed,
            n_failed=n_failed,
            summary_df=summary_df,
            details=details,
        )


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _base_id(df: pd.DataFrame) -> pd.Series:
    """Extract base symbol (strip name suffix) for merge keys."""
    col = "symbol" if "symbol" in df.columns else "stock_id"
    return df[col].astype(str).str.split(" ").str[0]


def _series_differ(a: pd.Series, b: pd.Series) -> pd.Series:
    """Vectorized comparison: True where values meaningfully differ."""
    a_na, b_na = a.isna(), b.isna()
    both_present = ~a_na & ~b_na
    # One NA, one not → different
    differ = a_na ^ b_na
    if both_present.any():
        ap, bp = a[both_present], b[both_present]
        if pd.api.types.is_numeric_dtype(a) and pd.api.types.is_numeric_dtype(b):
            differ.loc[both_present] = ~np.isclose(
                ap.astype(float), bp.astype(float), rtol=1e-5
            )
        else:
            differ.loc[both_present] = ap != bp
    return differ


def _compare_trades(
    trades_full: pd.DataFrame,
    trades_trunc: pd.DataFrame,
    columns: list[str] | None = None,
) -> pd.DataFrame:
    """Compare closed trades from a truncated run against the full run."""
    if trades_trunc.empty or trades_full.empty:
        return pd.DataFrame(columns=_MISMATCH_COLS)

    closed = trades_trunc[trades_trunc["exit_date"].notna()]
    if closed.empty:
        return pd.DataFrame(columns=_MISMATCH_COLS)

    compare_cols = columns if columns is not None else _COMPARE_COLS
    compare_cols = [
        c for c in compare_cols if c in trades_full.columns and c in closed.columns
    ]

    full = trades_full.assign(_key=_base_id(trades_full)).drop_duplicates(
        subset=["_key", "entry_date"], keep="first"
    )
    trunc = closed.assign(_key=_base_id(closed))

    merged = trunc.merge(
        full[["_key", "entry_date", *compare_cols]],
        on=["_key", "entry_date"],
        how="left",
        suffixes=("_trunc", "_full"),
        indicator=True,
    )

    parts: list[pd.DataFrame] = []

    # Phantom trades: present in truncated but missing in full run
    if columns is None:
        missing = merged.loc[merged["_merge"] == "left_only"]
        if not missing.empty:
            _id_col = "symbol" if "symbol" in missing.columns else "stock_id"
            parts.append(
                pd.DataFrame(
                    {
                        "symbol": missing[_id_col].values,
                        "column": "(missing in full run)",
                        "full_value": None,
                        "truncated_value": None,
                    }
                )
            )

    # Column-level mismatches on matched trades
    matched = merged[merged["_merge"] == "both"]
    if not matched.empty:
        for col in compare_cols:
            diff = _series_differ(matched[f"{col}_trunc"], matched[f"{col}_full"])
            if diff.any():
                m = matched.loc[diff]
                _id_col = "symbol" if "symbol" in m.columns else "stock_id"
                parts.append(
                    pd.DataFrame(
                        {
                            "symbol": m[_id_col].values,
                            "column": col,
                            "full_value": m[f"{col}_full"].values,
                            "truncated_value": m[f"{col}_trunc"].values,
                        }
                    )
                )

    if not parts:
        return pd.DataFrame(columns=_MISMATCH_COLS)
    return pd.concat(parts, ignore_index=True)[_MISMATCH_COLS]
