"""Terminal chart utilities for FinLab."""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeAlias

__all__ = ["plot", "plot_cumulative_return", "plot_drawdown"]

if TYPE_CHECKING:
    from collections.abc import Sequence
    from types import ModuleType

    import numpy as np
    import pandas as pd

    # Type alias for series-like data accepted by terminal chart functions
    _SeriesLike: TypeAlias = pd.Series | np.ndarray | list[float]


def _ensure_asciichartpy() -> ModuleType:
    """確保 asciichartpy 已安裝，否則提示安裝方式"""
    try:
        import asciichartpy

        return asciichartpy
    except ModuleNotFoundError as e:
        raise ModuleNotFoundError(
            "finlab[terminal] is not installed. Please install it with:\n"
            "    pip install 'finlab[terminal]'\n"
            "or\n"
            "    uv add 'finlab[terminal]'"
        ) from e


def _to_list(data: _SeriesLike) -> list[float]:
    """將資料轉換為 list（支援 pandas Series 等）"""
    return data.tolist() if hasattr(data, "tolist") else list(data)


def _print_title(title: str) -> None:
    """印出圖表標題"""
    if title:
        print(f"\n📈 {title}")
        print("─" * 50)


def plot(
    data: list[float] | list[list[float]],
    title: str = "",
    height: int = 10,
    colors: list[str] | None = None,
) -> None:
    """繪製終端圖表

    Args:
        data: 單一 list 或多條線的 list of lists
        title: 圖表標題
        height: 圖表高度（行數）
        colors: 顏色列表（用於多線）
    """
    acp = _ensure_asciichartpy()

    # 判斷是否為多條線
    is_multi_line = (
        isinstance(data, list)
        and data
        and (isinstance(data[0], (list, tuple)) or hasattr(data[0], "tolist"))
    )

    if is_multi_line:
        series_data = [_to_list(d) for d in data]
        if colors is None:
            default_colors = [
                acp.red,
                acp.green,
                acp.blue,
                acp.yellow,
                acp.cyan,
                acp.magenta,
            ]
            colors = default_colors[: len(series_data)]
    else:
        series_data = [_to_list(data)]

    config: dict[str, object] = {"height": height}
    if colors:
        config["colors"] = colors

    _print_title(title)
    print(acp.plot(series_data, config))


def _downsample(data: Sequence[float], max_points: int = 80) -> list[float]:
    """將資料降採樣到指定點數，保留頭尾

    Args:
        data: list of values
        max_points: 最大點數

    Returns:
        downsampled list
    """
    if len(data) <= max_points:
        return list(data)

    # 計算間隔，保留最後一個點
    step = len(data) / max_points
    indices = [int(i * step) for i in range(max_points - 1)]
    indices.append(len(data) - 1)  # 確保包含最後一點

    return [data[i] for i in indices]


def plot_cumulative_return(
    creturn: _SeriesLike,
    benchmark: _SeriesLike | None = None,
    title: str = "Cumulative Return",
    height: int = 12,
    width: int = 80,
) -> None:
    """繪製累積報酬曲線

    Args:
        creturn: 累積報酬 Series 或 list
        benchmark: 對照基準（可選）
        title: 標題
        height: 高度
        width: 圖表寬度（資料點數），預設 80
    """
    acp = _ensure_asciichartpy()

    data = _downsample(_to_list(creturn), width)
    config: dict[str, object] = {"height": height}

    _print_title(title)

    if benchmark is not None:
        bench_data = _downsample(_to_list(benchmark), width)
        config["colors"] = [acp.green, acp.red]
        print("🟢 Strategy  🔴 Benchmark")
        print(acp.plot([data, bench_data], config))
    else:
        config["colors"] = [acp.green]
        print(acp.plot([data], config))


def _calculate_drawdown(creturn: Sequence[float]) -> list[float]:
    """從累積報酬計算 drawdown（百分比）

    Args:
        creturn: 累積報酬 list

    Returns:
        list of drawdown percentages (負值)
    """
    drawdown: list[float] = []
    peak = creturn[0]
    for value in creturn:
        peak = max(peak, value)
        dd = (value / peak - 1) * 100  # 轉為百分比
        drawdown.append(dd)
    return drawdown


def plot_drawdown(
    creturn: _SeriesLike,
    benchmark: _SeriesLike | None = None,
    title: str = "Drawdown",
    height: int = 8,
    width: int = 80,
) -> None:
    """繪製回撤曲線

    Args:
        creturn: 累積報酬 Series 或 list
        benchmark: 對照基準（可選）
        title: 標題
        height: 高度
        width: 圖表寬度（資料點數），預設 80
    """
    acp = _ensure_asciichartpy()

    data = _to_list(creturn)
    drawdown = _downsample(_calculate_drawdown(data), width)

    config: dict[str, object] = {"height": height}

    _print_title(title)

    if benchmark is not None:
        bench_data = _to_list(benchmark)
        bench_dd = _downsample(_calculate_drawdown(bench_data), width)
        config["colors"] = [acp.green, acp.red]
        print("🟢 Strategy  🔴 Benchmark")
        print(acp.plot([drawdown, bench_dd], config))
    else:
        config["colors"] = [acp.green]
        print(acp.plot([drawdown], config))
