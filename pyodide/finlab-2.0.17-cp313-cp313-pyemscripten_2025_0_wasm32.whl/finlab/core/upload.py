from __future__ import annotations

from typing import Any


def post_legacy_upload_pyodide_no_cors(url: str, payload: dict[str, Any]) -> bool:
    """Fire a legacy upload POST from Pyodide without browser CORS response access."""
    try:
        import js
        from pyodide.ffi import to_js
    except ImportError:
        return False

    js_payload = to_js(payload, dict_converter=js.Object.fromEntries)
    body = js.URLSearchParams.new(js_payload)
    options = to_js(
        {
            "method": "POST",
            "body": body,
            "mode": "no-cors",
        },
        dict_converter=js.Object.fromEntries,
    )
    js.fetch(url, options)
    return True
