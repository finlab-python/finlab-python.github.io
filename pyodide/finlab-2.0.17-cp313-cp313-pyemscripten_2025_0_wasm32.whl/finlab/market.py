from __future__ import annotations

import contextlib
import sys
from typing import TYPE_CHECKING, ClassVar, TypeAlias, cast

__all__ = ["Market", "MarketSharedMemory"]

if TYPE_CHECKING:
    import datetime

import numpy as np
import pandas as pd

if sys.platform != "emscripten":
    from multiprocessing import shared_memory

    # Type alias for one set of shared memory args (data, index, columns)
    SharedMemoryTriple: TypeAlias = tuple[
        shared_memory.SharedMemory,
        tuple[int, ...],
        np.dtype[np.generic],
        shared_memory.SharedMemory,
        tuple[int, ...],
        np.dtype[np.generic],
        shared_memory.SharedMemory,
        tuple[int, ...],
        np.dtype[np.generic],
    ]


class Market:
    """市場類別
    假如希望開發新的交易市場套用到回測系統，可以繼承 `finlab.market.Market` 來實做新類別。
    """

    _price_table: ClassVar[str] = ""
    _adj_prefix: ClassVar[str] = ""

    @staticmethod
    def get_freq() -> str:
        """
        Returns the frequency of the data.
        Used to determine how to resample the data when the data is not daily.
        The freq will be saved in `finlab.core.report`.

        Returns:
        str: The frequency of the data.
        """
        return "1D"

    @staticmethod
    def get_name() -> str:
        """
        Returns the name of the market data source.

        This function is used to get the name of the market data source.
        """
        return "auto"

    @staticmethod
    def get_benchmark() -> pd.Series:
        """設定對標報酬率的時間序列

        這個函數用於設定對標報酬率的時間序列。

        Returns:
            pd.Series: 時間序列的報酬率。

        Raises:
            ExceptionType: Description of conditions under which the exception is raised.

        Examples:
            | date       |   0050 |
            |:-----------|-------:|
            | 2007-04-23 |   100 |
            | 2007-04-24 |   100.1 |
            | 2007-04-25 |   99 |
            | 2007-04-26 |   98.3 |
            | 2007-04-27 |   99.55 |
        """
        return pd.Series(
            [], index=pd.Index([], dtype="datetime64[ns]"), dtype="float64"
        )

    @staticmethod
    def get_asset_id_to_name() -> dict[str, str]:
        """設定對標報酬率的時間序列
        Returns:
          (dict): 股號與股名對照表，ex:`{'2330':'台積電'}`
        """
        return {}

    def get_price(
        self, trade_at_price: str | pd.Series | pd.DataFrame, adj: bool = True
    ) -> pd.DataFrame:
        """取得回測用價格或成交量數據

        Subclasses that define ``_price_table`` and ``_adj_prefix`` class
        variables inherit this default implementation automatically.
        Markets with different schemas (e.g. TWMarket) should override.

        Args:
           trade_at_price: 價格類型或自訂資料
               - str: 可選 'open', 'close', 'high', 'low', 'volume'
               - pd.Series: 自訂價格序列（單一股票或時間序列）
               - pd.DataFrame: 自訂價格資料（多檔股票）
           adj (bool): 是否使用還原股價計算。僅對價格資料有效，volume 會忽略此參數。

        Returns:
          (pd.DataFrame): 價格或成交量數據，index 為日期，columns 為股票代號。

        Note:
            **必須實作的 trade_at_price 值：**

            - **'open', 'close', 'high', 'low'**: 基本價格資料（必須實作）
              - 用於 `get_trading_price()` 計算組合價格
              - 用於回測的交易價格

            - **'volume'**: 成交量資料（強烈建議實作）
              - `LiquidityAnalysis`: 流動性分析需要計算成交金額
              - `ml/qlib.py`: 機器學習特徵生成
              - `portfolio_sync_manager.py`: 實時 portfolio 管理
              - 若不實作，相關分析功能會失效

            - **pd.Series, pd.DataFrame**: 自訂資料（建議支援）
              - 用於彈性回測，允許傳入自訂價格資料
              - Series 會自動轉換為單欄 DataFrame

        Examples:
            **回傳格式範例：**

            | date       |   0015 |   0050 |   0051 |   0052 |
            |:-----------|-------:|-------:|-------:|-------:|
            | 2007-04-23 |   9.54 |  57.85 |  32.83 |  38.4  |
            | 2007-04-24 |   9.54 |  58.1  |  32.99 |  38.65 |
            | 2007-04-25 |   9.52 |  57.6  |  32.8  |  38.59 |
            | 2007-04-26 |   9.59 |  57.7  |  32.8  |  38.6  |
            | 2007-04-27 |   9.55 |  57.5  |  32.72 |  38.4  |

            詳細實作可參考 `finlab.markets.tw.TWMarket.get_price()`
        """
        if isinstance(trade_at_price, pd.Series):
            return trade_at_price.to_frame()

        if isinstance(trade_at_price, pd.DataFrame):
            return trade_at_price

        if isinstance(trade_at_price, str):
            from finlab import data

            if trade_at_price == "volume":
                return data.get(f"{self._price_table}:volume")

            prefix = self._adj_prefix if adj else f"{self._price_table}:"
            return data.get(f"{prefix}{trade_at_price}")

        raise ValueError(
            "trade_at_price is not allowed (accepted types: pd.DataFrame, pd.Series, str)."
        )

    @staticmethod
    def get_market_value() -> pd.DataFrame:
        """取得回測用市值數據

        Returns:
          (pd.DataFrame): 市值數據，其中 index 為日期，而 columns 是股票代號。

        """
        return pd.DataFrame()

    @staticmethod
    def get_industry() -> dict[str, str]:
        return {}

    def get_trading_price(self, name: str, adj: bool = True) -> pd.DataFrame:
        """取得回測用價格數據

        Args:
            name (str): 選擇回測之還原股價以收盤價或開盤價計算，預設為'close'。可選 'open'、'close'、'high'、'low'、'open_close_avg'、'high_low_avg'、或 'price_avg'。
        Returns:
            (pd.DataFrame): 價格數據

        """

        if name in {"open", "close", "high", "low"}:
            return self.get_price(name, adj=adj)
        if name in {"close_open_avg", "open_close_avg"}:
            return (
                self.get_price("open", adj=adj) + self.get_price("close", adj=adj)
            ) / 2
        if name in {"high_low_avg", "low_high_avg"}:
            return (
                self.get_price("high", adj=adj) + self.get_price("low", adj=adj)
            ) / 2
        if name == "price_avg":
            return (
                self.get_price("open", adj=adj)
                + self.get_price("close", adj=adj)
                + self.get_price("high", adj=adj)
                + self.get_price("low", adj=adj)
            ) / 4

        raise ValueError(f"Unknown trade price name: {name}")

    @staticmethod
    def _normalize_market_timestamp(
        timestamp: str | datetime.datetime | pd.Timestamp | None, timezone_name: str
    ) -> pd.Timestamp:
        """Normalize datetime-like input into a timezone-aware pandas Timestamp."""
        if timestamp is None:
            return pd.Timestamp.now(tz=timezone_name)

        ts = pd.Timestamp(timestamp)
        if ts.tz is None:
            return ts.tz_localize(timezone_name)
        return ts.tz_convert(timezone_name)

    def market_close_at_timestamp(
        self, timestamp: pd.Timestamp | None = None
    ) -> pd.Timestamp:
        """
        Returns the timestamp of the market close of the given timestamp.

        Args:
            timestamp (datetime): The timestamp to find the market close to.

        Returns:
            datetime: The timestamp of the closest market close.
        """

        indexes = self.get_price("close").index

        if timestamp is None:
            timestamp = indexes[-1]

        # find min delta between indexes
        delta = np.abs(indexes[1:] - indexes[:-1]).min()
        return timestamp + delta

    def get_reference_price(self) -> dict[str, float]:
        """Returns the most recent reference price of the market.

        Returns:
            pandas.Series: The most recent reference price of the market.
        """
        return self.get_price("close").iloc[-1].to_dict()

    @staticmethod
    def market_open_time() -> tuple[int, int]:
        """Returns (hour, minute) of market open in local timezone."""
        return (9, 0)

    @staticmethod
    def tzinfo() -> datetime.timezone | None:
        """Returns the timezone of the market.

        Returns:
            datetime.timezone: The timezone of the market.
        """
        return None

    @staticmethod
    def default_fee_ratio() -> float:
        """Returns the default fee ratio for this market.

        Returns:
            float: The default fee ratio.
        """
        return 1.425 / 1000

    @staticmethod
    def default_tax_ratio() -> float:
        """Returns the default tax ratio for this market.

        Returns:
            float: The default tax ratio.
        """
        return 3 / 1000

    @staticmethod
    def get_odd_lot() -> int:
        """Returns the odd lot size of the market.

        Returns:
            int: The odd lot size of the market.
        """
        return 1

    @staticmethod
    def get_board_lot_size() -> int:
        """Returns the board lot size of the market.

        Returns:
            int: The board lot size of the market.
        """
        return 1


def create_shared_memory_from_df(df: pd.DataFrame, name: str) -> SharedMemoryTriple:
    """Create a shared memory from a pandas DataFrame."""

    # close if already exist
    for n in [name, name + "_index", name + "_columns"]:
        with contextlib.suppress(FileNotFoundError):
            shm = shared_memory.SharedMemory(name=n)
            shm.close()
            shm.unlink()

    # create
    array = df.to_numpy()
    shm = shared_memory.SharedMemory(create=True, size=array.nbytes, name=name)
    np_array = np.ndarray(array.shape, dtype=array.dtype, buffer=shm.buf)
    np_array[:] = array[:]

    # index
    array_index = df.index.to_numpy()
    shm_index = shared_memory.SharedMemory(
        create=True, size=array_index.nbytes, name=name + "_index"
    )
    np_array_index = np.ndarray(
        array_index.shape, dtype=array_index.dtype, buffer=shm_index.buf
    )
    np_array_index[:] = array_index[:]

    # columns
    array_columns = np.asarray(df.columns.astype(str), dtype=object)
    shm_columns = shared_memory.SharedMemory(
        create=True, size=array_columns.nbytes, name=name + "_columns"
    )
    np_array_columns = np.ndarray(
        array_columns.shape, dtype=array_columns.dtype, buffer=shm_columns.buf
    )
    np_array_columns[:] = array_columns[:]

    return (
        shm,
        array.shape,
        array.dtype,
        shm_index,
        array_index.shape,
        array_index.dtype,
        shm_columns,
        array_columns.shape,
        array_columns.dtype,
    )


def create_df_from_shared_memory(
    shm: shared_memory.SharedMemory,
    shape: tuple[int, ...],
    dtype: np.dtype[np.generic],
    shm_index: shared_memory.SharedMemory,
    index_shape: tuple[int, ...],
    index_dtype: np.dtype[np.generic],
    shm_columns: shared_memory.SharedMemory,
    columns_shape: tuple[int, ...],
    columns_dtype: np.dtype[np.generic],
) -> pd.DataFrame:
    """Create a pandas DataFrame from a shared memory."""

    np_array = np.ndarray(
        shape, dtype=dtype, buffer=shm.buf
    )  # np.frombuffer(shm.buf).reshape(shape)#
    np_array_index = np.ndarray(index_shape, dtype=index_dtype, buffer=shm_index.buf)
    return pd.DataFrame(np_array, index=np_array_index)


class MarketSharedMemory(Market):
    names: ClassVar[list[str]] = ["close", "open", "high", "low", "volume"]

    @staticmethod
    def _fetch_price_df(
        market: Market,
        name: str,
        adj: bool,
        start_time: str | pd.Timestamp | None,
        end_time: str | pd.Timestamp | None,
    ) -> pd.DataFrame:
        """Fetch one price DataFrame and ensure DatetimeIndex."""
        df = (
            market.get_price(name, adj=adj)
            .loc[slice(start_time, end_time)]
            .dropna(axis=1, how="all")
        )
        if not isinstance(df.index, pd.DatetimeIndex):
            try:
                df.index = pd.to_datetime(df.index)
            except (ValueError, TypeError) as e:
                raise TypeError(
                    f"Index of DataFrame for '{name}' could not be converted to DatetimeIndex: {e}"
                ) from e
        return df

    @staticmethod
    def _validate_timezone(
        current_tz: datetime.tzinfo | None,
        new_tz: datetime.tzinfo | None,
    ) -> datetime.tzinfo | None:
        """Return the resolved timezone, raising on mismatch."""
        if current_tz is None:
            return new_tz
        if current_tz != new_tz:
            raise TypeError(
                "The timezone of the data is not the same. "
                "Please check if the timezone of the data is correct."
            )
        return current_tz

    def __init__(
        self,
        market: Market,
        adj: bool = True,
        start_time: str | pd.Timestamp | None = None,
        end_time: str | pd.Timestamp | None = None,
    ) -> None:
        super().__init__()

        self.df_args: list[SharedMemoryTriple] = []
        self.cache: dict[str, pd.DataFrame] = {}
        self.localize: datetime.tzinfo | None = None

        dfs: dict[str, pd.DataFrame] = {}
        for n in self.names:
            df = self._fetch_price_df(market, n, adj, start_time, end_time)
            self.localize = self._validate_timezone(
                self.localize, getattr(df.index, "tzinfo", None)
            )
            self.cache[n] = df.copy()
            if df.index.tz is None:
                df.index = df.index.tz_localize(None)
            dfs[n] = df

        # Intersect columns and build shared memory
        columns = dfs["close"].columns.copy()
        for df in dfs.values():
            columns = columns.intersection(df.columns)
        for name in dfs:
            dfs[name] = dfs[name][columns]

        shape_check = None
        for n, df in dfs.items():
            if shape_check is None:
                shape_check = df.shape
            elif shape_check != df.shape:
                raise ValueError(
                    "Shape of open, high, low, close, volume are not the same. "
                    "This is because the data is not updated yet. "
                    "Please try again few minutes later."
                )
            self.df_args.append(create_shared_memory_from_df(df, n))

    def to_args(self) -> list[SharedMemoryTriple | datetime.tzinfo | None]:
        return [*self.df_args, self.localize]

    @classmethod
    def from_args(
        cls, args: list[SharedMemoryTriple | datetime.tzinfo | None]
    ) -> MarketSharedMemory:
        self = cls.__new__(cls)
        self.df_args = cast("list[SharedMemoryTriple]", list(args[:-1]))
        self.localize = cast("datetime.tzinfo | None", args[-1] if args else None)
        self.cache = {}
        return self

    def get_price(
        self, trade_at_price: str | pd.Series | pd.DataFrame, adj: bool = True
    ) -> pd.DataFrame:
        if trade_at_price in self.cache:
            return self.cache[trade_at_price]

        args = self.df_args[self.names.index(trade_at_price)]
        df = create_df_from_shared_memory(*args)

        # Ensure index is DatetimeIndex
        if not isinstance(df.index, pd.DatetimeIndex):
            try:
                df.index = pd.to_datetime(df.index)
            except (ValueError, TypeError) as e:
                raise TypeError(
                    f"Index of DataFrame for '{trade_at_price}' could not be converted to DatetimeIndex: {e}"
                ) from e

        # Only tz_localize if not already tz-aware
        if df.index.tz is None and self.localize is not None:
            df.index = df.index.tz_localize(self.localize)
        self.cache[trade_at_price] = df
        return df

    def close(self) -> None:
        for args in self.df_args:
            args[0].close()
            args[0].unlink()
            args[3].close()
            args[3].unlink()
            args[6].close()
            args[6].unlink()
