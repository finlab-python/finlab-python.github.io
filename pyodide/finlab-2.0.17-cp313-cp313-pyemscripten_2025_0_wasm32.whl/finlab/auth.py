"""Firebase Auth module for finlab CLI.

Handles browser-based login, credential storage, and id_token refresh.
Credentials stored in ~/.finlab/credentials.json, encrypted with machine-bound key.
"""

from __future__ import annotations

import base64
import contextlib
import hashlib
import json
import logging
import os
import socket

__all__ = [
    "browser_login",
    "clear_session",
    "get_data_status",
    "get_id_token",
    "get_session",
    "get_status",
    "invalidate_token_cache",
    "logout_session",
    "save_session",
]
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from typing import Any, Final

logger = logging.getLogger(__name__)

CREDENTIALS_DIR: Final[str] = os.path.expanduser("~/.finlab")
CREDENTIALS_FILE: Final[str] = os.path.join(CREDENTIALS_DIR, "credentials.json")

# Firebase REST API for token exchange
FIREBASE_TOKEN_URL: Final[str] = "https://securetoken.googleapis.com/v1/token"

# User-Agent required to avoid Cloudflare bot blocking
_UA: Final[str] = "finlab-cli/1.0"
_DATA_STATUS_URL: Final[str] = (
    "https://asia-east2-fdata-299302.cloudfunctions.net/auth_generate_data_url"
)
_DATA_STATUS_BUCKET: Final[str] = "finlab_tw_stock_item"
_DATA_STATUS_BLOB: Final[str] = "price#收盤價.recent.feather"

# In-memory cache to avoid repeated disk reads and Firebase API calls
_cached_id_token: str | None = None
_cached_id_token_expiry: float = 0


def _get_machine_id() -> str:
    """Get a stable machine identifier.

    uuid.getnode() is unreliable — some Python builds return a random MAC
    each process (multicast bit set).  Use OS-level hardware IDs instead.
    """
    # macOS: IOPlatformUUID (stable across reboots)
    if sys.platform == "darwin":
        try:
            out = subprocess.check_output(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                text=True,
                timeout=5,
            )
            for line in out.splitlines():
                if "IOPlatformUUID" in line:
                    return line.split('"')[-2]
        except (subprocess.SubprocessError, OSError, IndexError):
            pass

    # Linux: /etc/machine-id
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        with contextlib.suppress(OSError), open(path, encoding="utf-8") as f:
            mid = f.read().strip()
            if mid:
                return mid

    # Fallback: hostname (not ideal but stable per machine)
    return socket.gethostname()


def _get_machine_key() -> bytes:
    """Derive encryption key from a stable machine identifier."""
    machine_id = _get_machine_id()
    raw_key = f"finlab-{machine_id}-credential-key".encode()
    return base64.urlsafe_b64encode(hashlib.sha256(raw_key).digest())


def _encrypt(data: bytes) -> bytes:
    """Encrypt data with machine-bound Fernet key."""
    from cryptography.fernet import Fernet

    f = Fernet(_get_machine_key())
    return f.encrypt(data)


def _decrypt(data: bytes) -> bytes:
    """Decrypt data with machine-bound Fernet key."""
    from cryptography.fernet import Fernet

    f = Fernet(_get_machine_key())
    return f.decrypt(data)


def _detect_session_name() -> str:
    """Auto-detect a session name for reuse-by-name.

    Returns 'colab' if running in Google Colab, otherwise the hostname.
    """
    if os.environ.get("COLAB_RELEASE_TAG"):
        return "colab"
    return socket.gethostname()


def get_session() -> dict[str, Any] | None:
    """Read stored credentials. Checks env vars first, then encrypted file."""
    # Env var priority: for Cloud Functions / Lambda / headless environments
    env_refresh = os.environ.get("FINLAB_REFRESH_TOKEN")
    env_session = os.environ.get("FINLAB_SESSION_ID")
    env_api_key = os.environ.get("FINLAB_API_KEY")

    if env_refresh and env_session and env_api_key:
        return {
            "refresh_token": env_refresh,
            "session_id": env_session,
            "api_key": env_api_key,
            "source": "env",
        }

    if not os.path.exists(CREDENTIALS_FILE):
        return None
    try:
        with open(CREDENTIALS_FILE, "rb") as f:
            encrypted = f.read()
        decrypted = _decrypt(encrypted)
        return json.loads(decrypted)
    except (OSError, json.JSONDecodeError, ValueError) as e:
        logger.debug(
            "Failed to read credentials, may be corrupted or from another machine: %s",
            e,
        )
        return None


def save_session(data: dict[str, Any]) -> None:
    """Encrypt and write credentials to disk."""
    os.makedirs(CREDENTIALS_DIR, exist_ok=True)
    encrypted = _encrypt(json.dumps(data).encode())
    with open(CREDENTIALS_FILE, "wb") as f:
        f.write(encrypted)
    # Restrict file permissions (owner-only)
    os.chmod(CREDENTIALS_FILE, 0o600)


def clear_session() -> None:
    """Delete local credentials and drop any in-memory cached token."""
    invalidate_token_cache()
    if os.path.exists(CREDENTIALS_FILE):
        os.remove(CREDENTIALS_FILE)


def get_id_token() -> str | None:
    """Exchange refresh_token for a fresh id_token via Firebase REST API.

    Uses in-memory cache to avoid repeated disk reads and Firebase API calls.
    Returns the id_token string, or None on failure.
    """
    global _cached_id_token, _cached_id_token_expiry

    now = time.time()

    # Fast path: return in-memory cached token if still valid
    if _cached_id_token and _cached_id_token_expiry > now + 60:
        return _cached_id_token

    session = get_session()
    if not session:
        return None

    refresh_token = session.get("refresh_token")
    api_key = session.get("api_key")
    if not refresh_token or not api_key:
        return None

    # Check disk-cached id_token (only if in-memory cache missed)
    cached_token = session.get("id_token")
    token_expiry = session.get("id_token_expiry", 0)

    if cached_token and token_expiry > now + 60:  # 60s buffer
        _cached_id_token = cached_token
        _cached_id_token_expiry = token_expiry
        return cached_token

    # Exchange refresh token for new id_token
    url = f"{FIREBASE_TOKEN_URL}?key={api_key}"
    data = urllib.parse.urlencode(
        {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
        }
    ).encode()

    result = _exchange_refresh_token(url, data)
    if result is None:
        return None

    id_token = result.get("id_token")
    expires_in = int(result.get("expires_in", 3600))
    new_refresh = result.get("refresh_token", refresh_token)

    if not id_token:
        return None

    # Update in-memory cache
    _cached_id_token = id_token
    _cached_id_token_expiry = now + expires_in

    # Update disk cache (skip for env-var sessions)
    session["id_token"] = id_token
    session["id_token_expiry"] = now + expires_in
    session["refresh_token"] = new_refresh
    if session.get("source") != "env":
        save_session(session)

    return id_token


# HTTP codes worth retrying: rate limiting and transient server errors.
_TRANSIENT_HTTP_CODES: Final[frozenset[int]] = frozenset({429, 500, 502, 503, 504})
# Codes meaning the refresh token itself is rejected — retrying cannot help.
_AUTH_REJECTED_HTTP_CODES: Final[frozenset[int]] = frozenset({400, 401, 403})
_REFRESH_MAX_ATTEMPTS: Final[int] = 3


def _exchange_refresh_token(url: str, data: bytes) -> dict[str, Any] | None:
    """POST to the Firebase token endpoint, retrying transient failures.

    Retries network errors and 429/5xx responses with exponential backoff.
    Auth rejections (400/401/403) are terminal: the stored refresh token is
    invalid or revoked, so retrying would only hammer the server.
    Returns the parsed JSON response, or None on failure.
    """
    delay = 1.0
    for attempt in range(_REFRESH_MAX_ATTEMPTS):
        # A shorter timeout on retries caps worst-case blocking on outages.
        timeout = 30 if attempt == 0 else 10
        try:
            req = urllib.request.Request(url, data=data, method="POST")
            req.add_header("Content-Type", "application/x-www-form-urlencoded")
            req.add_header("User-Agent", _UA)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return json.loads(response.read().decode())
        except urllib.error.HTTPError as e:
            if e.code in _AUTH_REJECTED_HTTP_CODES:
                logger.warning(
                    "Refresh token rejected by auth server (HTTP %s). "
                    "Run `finlab login` to re-authenticate.",
                    e.code,
                )
                return None
            if e.code not in _TRANSIENT_HTTP_CODES:
                logger.warning(
                    "Token refresh failed with server error: HTTP %s", e.code
                )
                return None
            error = f"HTTP {e.code}"
        except (urllib.error.URLError, OSError, json.JSONDecodeError) as e:
            error = str(e)

        if attempt < _REFRESH_MAX_ATTEMPTS - 1:
            logger.debug("Token refresh failed (%s), retrying in %.0fs", error, delay)
            time.sleep(delay)
            delay *= 2
        else:
            logger.warning(
                "Token refresh failed after %d attempts: %s",
                _REFRESH_MAX_ATTEMPTS,
                error,
            )
    return None


def invalidate_token_cache() -> None:
    """Clear in-memory token cache, forcing next call to re-read from disk."""
    global _cached_id_token, _cached_id_token_expiry
    _cached_id_token = None
    _cached_id_token_expiry = 0


def _init_login_session(base_url: str, session_name: str) -> dict[str, Any] | None:
    """POST /api/auth/cli/init to get session data. Return dict or None on failure."""
    init_url = f"{base_url}/api/auth/cli/init"
    try:
        body = json.dumps({"v": 2, "session_name": session_name}).encode()
        req = urllib.request.Request(init_url, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", _UA)
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode())
    except (urllib.error.URLError, OSError, json.JSONDecodeError) as e:
        print(f"Error: Failed to initialize login session: {e}")
        return None


def _handle_login_success(result: dict[str, Any], session_name: str) -> bool:
    """Process a successful poll result. Return True if credentials saved."""
    refresh_token = result.get("refresh_token")
    api_key = result.get("api_key")

    if refresh_token and api_key:
        creds = {
            "refresh_token": refresh_token,
            "api_key": api_key,
            "session_id": result.get("session_id"),
            "api_token": result.get("token"),
            "session_name": result.get("session_name", session_name),
            "created_at": time.time(),
        }
        save_session(creds)
        print("Login successful! Credentials saved.")
        if result.get("session_name"):
            print(f'Session name: {result["session_name"]}')
        return True

    # Old flow fallback: just got api_token
    token = result.get("token")
    if token:
        os.environ["FINLAB_API_TOKEN"] = token[:64]
        print("Login successful!")
        return True
    return False


def _handle_session_limit(result: dict[str, Any]) -> bool:
    """Print session-limit error details. Always returns False."""
    print(f'\n{result.get("message", "")}')
    sessions = result.get("sessions", {})
    if sessions:
        print("\nActive sessions:")
        for sid, info in sessions.items():
            device = (
                info.get("device_name", "Unknown")
                if isinstance(info, dict)
                else "Unknown"
            )
            sname = info.get("session_name", "") if isinstance(info, dict) else ""
            label = device
            if sname:
                label += f" ({sname})"
            print(f"  {sid[:8]}... - {label}")
    print("\nPlease run `python -m finlab logout` on another device, then retry.")
    return False


def _poll_for_token(poll_url: str, expires_in: int, session_name: str) -> bool:
    """Poll the server for login result. Return True on success."""
    start_time = time.time()
    poll_interval = 2

    print("Waiting for login...", end="", flush=True)
    while time.time() - start_time < expires_in:
        time.sleep(poll_interval)
        print(".", end="", flush=True)

        try:
            req = urllib.request.Request(poll_url)
            req.add_header("User-Agent", _UA)
            with urllib.request.urlopen(req, timeout=15) as response:
                result = json.loads(response.read().decode())
        except urllib.error.HTTPError as e:
            try:
                result = json.loads(e.read().decode())
            except (json.JSONDecodeError, OSError):
                continue
        except (urllib.error.URLError, OSError):
            continue

        status = result.get("status")
        if status == "success":
            print(" Done!")
            return _handle_login_success(result, session_name)
        if status == "pending":
            continue

        # Error response
        error = result.get("error", "Unknown error")
        if error == "SESSION_LIMIT_REACHED":
            return _handle_session_limit(result)

        print(f"\nError: {error}")
        message = result.get("message", "")
        if message:
            print(f"  {message}")
        return False

    print("\nTimeout: Login session expired. Please try again.")
    return False


def browser_login(base_url: str = "https://www.finlab.finance") -> bool:
    """Perform browser-based login flow.

    1. POST /api/auth/cli/init to get sessionId + pollSecret
    2. Open browser with auth URL
    3. Poll /api/auth/poll for token
    4. Store credentials

    Returns True on success, False on failure.
    """
    session_name = _detect_session_name()
    init_data = _init_login_session(base_url, session_name)
    if init_data is None:
        return False

    session_id = init_data.get("sessionId")
    poll_secret = init_data.get("pollSecret")
    auth_url = init_data.get("authUrl")
    expires_in = init_data.get("expiresIn", 300)

    if not session_id or not poll_secret or not auth_url:
        print("Error: Invalid response from server")
        return False

    print("Opening browser for login...")
    print(f"If browser does not open, visit: {auth_url}")
    webbrowser.open(auth_url)

    poll_url = f"{base_url}/api/auth/poll?s={session_id}&secret={poll_secret}"
    return _poll_for_token(poll_url, expires_in, session_name)


def logout_session(base_url: str = "https://www.finlab.finance") -> bool:
    """Logout: clear local credentials and remove session from server.

    Returns True if local cleanup succeeded.
    """
    session = get_session()

    # Try to remove server-side session
    if session and session.get("session_id"):
        id_token = get_id_token()
        if id_token:
            try:
                url = f"{base_url}/api/auth/cli/sessions"
                data = json.dumps({"session_id": session["session_id"]}).encode()
                req = urllib.request.Request(url, data=data, method="DELETE")
                req.add_header("Content-Type", "application/json")
                req.add_header("Authorization", f"Bearer {id_token}")
                req.add_header("User-Agent", _UA)
                urllib.request.urlopen(req, timeout=15)
            except (urllib.error.URLError, OSError) as e:
                logger.debug(f"Failed to remove server session: {e}")

    clear_session()
    return True


def get_status(base_url: str = "https://www.finlab.finance") -> dict[str, Any] | None:
    """Get session info from server. Returns dict with sessions, plan info."""
    id_token = get_id_token()
    if not id_token:
        return None

    try:
        url = f"{base_url}/api/auth/cli/sessions"
        req = urllib.request.Request(url)
        req.add_header("Authorization", f"Bearer {id_token}")
        req.add_header("User-Agent", _UA)
        with urllib.request.urlopen(req, timeout=15) as response:
            return json.loads(response.read().decode())
    except (urllib.error.URLError, OSError, json.JSONDecodeError) as e:
        logger.debug(f"Failed to get session status: {e}")
        return None


def get_data_status() -> dict[str, Any] | None:
    """Get quota usage and core TW-price freshness without downloading data."""
    id_token = get_id_token()
    session = get_session()
    if not id_token or not session:
        return None

    now = time.strftime("%Y%m%d%H%M%S", time.gmtime())
    payload = {
        "id_token": id_token,
        "items": [
            {
                "bucket_name": _DATA_STATUS_BUCKET,
                "blob_name": _DATA_STATUS_BLOB,
                "time_saved": now,
            }
        ],
    }
    session_id = session.get("session_id")
    if isinstance(session_id, str) and session_id:
        payload["session_id"] = session_id

    try:
        req = urllib.request.Request(
            _DATA_STATUS_URL,
            data=json.dumps(payload).encode(),
            method="POST",
        )
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", _UA)
        with urllib.request.urlopen(req, timeout=15) as response:
            result = json.loads(response.read().decode())

        items = result.get("results")
        if not isinstance(items, list) or not items or not isinstance(items[0], dict):
            return None
        item = items[0]
        if item.get("error"):
            logger.debug("Failed to get data status: %s", item["error"])
            return None
        return {
            "fresh_until": item.get("time_scheduled"),
            "quota": item.get("quota"),
            "limit_size": item.get("limit_size"),
        }
    except (urllib.error.URLError, OSError, json.JSONDecodeError) as e:
        logger.debug("Failed to get data status: %s", e)
        return None
