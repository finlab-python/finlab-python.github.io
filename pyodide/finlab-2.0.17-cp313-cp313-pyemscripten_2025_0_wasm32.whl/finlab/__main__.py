"""Entry point for `python -m finlab` commands.

Usage:
    python -m finlab login     # Browser-based login
    python -m finlab logout    # Clear credentials + remove server session
    python -m finlab status    # Show active sessions and plan info
    python -m finlab token --env  # Export credentials as env vars
    python -m finlab migrate   # Migration guide from FINLAB_API_TOKEN
    python -m finlab blog top  # Show top blog posts
    python -m finlab blog search "keyword"
    python -m finlab blog show <slug> --paid
"""

from __future__ import annotations

import argparse
import datetime
import json
import sys
from typing import Any, NoReturn, cast


def cmd_login(args: argparse.Namespace) -> NoReturn:
    from finlab.auth import browser_login

    success = browser_login()
    sys.exit(0 if success else 1)


def cmd_logout(args: argparse.Namespace) -> None:
    from finlab.auth import clear_session, get_session, logout_session

    session = get_session()
    if session is None:
        print("Not logged in. Nothing to do.")
        return

    if session.get("source") == "env":
        print("Credentials come from environment variables.")
        print(
            "Unset FINLAB_REFRESH_TOKEN, FINLAB_SESSION_ID and FINLAB_API_KEY"
            " to log out."
        )
        return

    success = logout_session()
    if success:
        print("Logged out successfully.")
    else:
        # At least clear local
        clear_session()
        print("Local credentials cleared.")


def cmd_token(args: argparse.Namespace) -> None:
    from finlab.auth import get_session

    session = get_session()
    if not session:
        print("Not logged in. Run: python -m finlab login", file=sys.stderr)
        sys.exit(1)

    if session.get("source") == "env":
        print("Credentials are already from env vars.", file=sys.stderr)
        sys.exit(1)

    refresh_token = session.get("refresh_token")
    session_id = session.get("session_id")
    api_key = session.get("api_key")

    if not refresh_token or not session_id or not api_key:
        print("Incomplete credentials. Run: python -m finlab login", file=sys.stderr)
        sys.exit(1)

    if args.env:
        print(f'export FINLAB_REFRESH_TOKEN="{refresh_token}"')
        print(f'export FINLAB_SESSION_ID="{session_id}"')
        print(f'export FINLAB_API_KEY="{api_key}"')
    else:
        print(f"FINLAB_REFRESH_TOKEN={refresh_token}")
        print(f"FINLAB_SESSION_ID={session_id}")
        print(f"FINLAB_API_KEY={api_key}")


def cmd_migrate(args: argparse.Namespace) -> None:
    import os

    from finlab import _detect_environment
    from finlab.auth import get_session

    env = _detect_environment()
    has_new_creds = get_session() is not None
    has_old_token = bool(os.environ.get("FINLAB_API_TOKEN"))

    if has_new_creds and has_old_token:
        print("Already migrated to new auth system!")
        print("Remove FINLAB_API_TOKEN from your environment to complete migration.")
        if env == "desktop":
            print("Check your shell profile (~/.bashrc, ~/.zshrc) or .env files.")
        elif env == "cloud_functions":
            print(
                "Remove FINLAB_API_TOKEN from your Cloud Functions environment variables."
            )
    elif has_new_creds and not has_old_token:
        print("Already migrated! No action needed.")
    elif env == "colab":
        print("Migration guide for Google Colab:")
        print('  1. Replace finlab.login("YOUR_API_TOKEN") with finlab.login()')
        print("  2. Follow the browser login flow")
        print("  3. Remove any FINLAB_API_TOKEN references from your notebook")
    elif env == "cloud_functions":
        print("Migration guide for Cloud Functions:")
        print("  1. On your local machine, run: python -m finlab login")
        print("  2. Then run: python -m finlab token --env")
        print("  3. Set these 3 env vars in your Cloud Functions config:")
        print("       FINLAB_REFRESH_TOKEN")
        print("       FINLAB_SESSION_ID")
        print("       FINLAB_API_KEY")
        print("  4. Remove FINLAB_API_TOKEN from your config")
    else:
        print("Migration guide:")
        print("  1. Run: python -m finlab login")
        print("  2. Remove FINLAB_API_TOKEN from your shell profile")
        print("     (check ~/.bashrc, ~/.zshrc, or .env files)")


_AI_PLAN_NAMES: dict[int, str] = {2: "AI MAX", 1: "AI"}


def _resolve_plan_name(plan: dict[str, object]) -> str:
    """Derive human-readable plan name from plan dict."""
    role = plan.get("role", "unknown")
    if role != "vip_m":
        return "Free"
    ai_level = plan.get("ai", 0)
    return _AI_PLAN_NAMES.get(ai_level, "VIP") if isinstance(ai_level, int) else "VIP"


def _print_active_sessions(
    sessions: dict[str, dict[str, str]], current_session_id: str | None
) -> None:
    """Print active session list."""
    print("\nActive sessions:")
    for sid, info in sessions.items():
        device = info.get("device_name", "Unknown")
        sname = info.get("session_name", "")
        current = " (this device)" if sid == current_session_id else ""
        label = device
        if sname:
            label += f" [{sname}]"
        print(f"  {sid[:8]}... - {label}{current}")


_UTC_PLUS_8 = datetime.timezone(datetime.timedelta(hours=8))


def _format_data_freshness(data_status: dict[str, object] | None) -> str:
    """Format the representative TW-price freshness returned by the server."""
    if not data_status:
        return "unavailable"
    raw_fresh_until = data_status.get("fresh_until")
    if not isinstance(raw_fresh_until, str):
        return "unavailable"
    try:
        fresh_until = datetime.datetime.strptime(
            raw_fresh_until, "%Y%m%d%H%M%S"
        ).replace(tzinfo=datetime.timezone.utc)
    except ValueError:
        return "unavailable"

    label = fresh_until.astimezone(_UTC_PLUS_8).strftime("%Y-%m-%d %H:%M UTC+8")
    state = (
        "fresh until"
        if fresh_until > datetime.datetime.now(tz=datetime.timezone.utc)
        else "stale since"
    )
    return f"{state} {label} (TW price)"


def _format_quota(data_status: dict[str, object] | None) -> str:
    """Format consumed and available daily data quota."""
    if not data_status:
        return "unavailable"
    quota = data_status.get("quota")
    limit_size = data_status.get("limit_size")
    if not isinstance(quota, (int, float)) or not isinstance(limit_size, (int, float)):
        return "unavailable"
    if limit_size <= 0:
        return "unavailable"
    return f"{quota:.1f} / {limit_size:g} MB ({quota / limit_size:.1%})"


def _next_quota_reset(now: datetime.datetime | None = None) -> datetime.datetime:
    """Return the next daily quota reset at 08:00 UTC+8."""
    current = now or datetime.datetime.now(tz=datetime.timezone.utc)
    current_local = current.astimezone(_UTC_PLUS_8)
    reset = current_local.replace(hour=8, minute=0, second=0, microsecond=0)
    if current_local >= reset:
        reset += datetime.timedelta(days=1)
    return reset


def cmd_status(args: argparse.Namespace) -> None:
    from finlab.auth import get_data_status, get_session, get_status

    session = get_session()
    if not session:
        print("Not logged in.")
        print("Run: python -m finlab login")
        sys.exit(1)

    session_id = session.get("session_id")
    session_label = session_id[:8] if isinstance(session_id, str) else "n/a"
    print(f"Local session: {session_label}...")
    print(f'API key: {"configured" if session.get("api_key") else "not configured"}')
    if session.get("session_name"):
        print(f'Session name: {session["session_name"]}')
    if session.get("source") == "env":
        print("Source: environment variables")

    status = get_status()
    if not status:
        print("Could not fetch server status (token may have expired).")
        print("Try: python -m finlab login")
        return

    plan = status.get("plan", {})
    print(f"Plan: {_resolve_plan_name(plan if isinstance(plan, dict) else {})}")
    data_status = get_data_status()
    print(f"Data freshness: {_format_data_freshness(data_status)}")
    print(f"Quota consumed: {_format_quota(data_status)}")
    next_reset = _next_quota_reset().strftime("%Y-%m-%d %H:%M UTC+8")
    print(f"Next reset: {next_reset}")
    print(f"Sessions: {status.get('count', 0)}/{status.get('max_sessions', 0)}")

    sessions = status.get("sessions", {})
    if isinstance(sessions, dict) and sessions:
        _print_active_sessions(
            cast("dict[str, dict[str, str]]", sessions),
            session_id if isinstance(session_id, str) else None,
        )


def _add_blog_common_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--lang",
        choices=["zh", "en"],
        default="zh",
        help="Post language",
    )
    parser.add_argument(
        "--base-url",
        default=None,
        help="FinLab website base URL, defaults to https://finlab.finance",
    )
    parser.add_argument("--json", action="store_true", help="Print raw JSON response")


def register_blog_commands(
    sub: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    blog_parser = sub.add_parser("blog", help="Read FinLab blog/tutorial content")
    blog_sub = blog_parser.add_subparsers(dest="blog_command")

    top_parser = blog_sub.add_parser("top", help="Show top blog posts")
    _add_blog_common_args(top_parser)
    top_parser.add_argument("--limit", type=int, default=10, help="Number of posts")

    search_parser = blog_sub.add_parser("search", help="Search blog posts")
    _add_blog_common_args(search_parser)
    search_parser.add_argument("query", nargs="?", default="", help="Search keyword")
    search_parser.add_argument("--limit", type=int, default=10, help="Number of posts")

    show_parser = blog_sub.add_parser("show", help="Show a blog post by slug")
    _add_blog_common_args(show_parser)
    show_parser.add_argument("slug", help="Post slug")
    show_parser.add_argument(
        "--paid",
        action="store_true",
        help="Request VIP-only content with the current FinLab login",
    )
    show_parser.add_argument(
        "--format",
        choices=["markdown", "html", "both"],
        default="markdown",
        dest="content_format",
        help="Content format requested from the blog API",
    )


def cmd_blog(args: argparse.Namespace) -> None:
    from finlab import blog

    try:
        if args.blog_command == "top":
            payload = blog.top_posts(
                lang=args.lang,
                limit=args.limit,
                base_url=args.base_url,
            )
            output = blog.format_post_list(payload)
        elif args.blog_command == "search":
            payload = blog.search_posts(
                args.query,
                lang=args.lang,
                limit=args.limit,
                base_url=args.base_url,
            )
            output = blog.format_post_list(payload)
        elif args.blog_command == "show":
            payload = blog.show_post(
                args.slug,
                lang=args.lang,
                include_paid=args.paid,
                content_format=args.content_format,
                base_url=args.base_url,
            )
            output = blog.format_post(payload)
        else:
            print("Run: python -m finlab blog --help", file=sys.stderr)
            sys.exit(1)
    except blog.BlogApiError as exc:
        print(f"Blog API error: {exc}", file=sys.stderr)
        if exc.payload and args.json:
            print(
                json.dumps(exc.payload, ensure_ascii=False, indent=2), file=sys.stderr
            )
        sys.exit(1)

    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(output)


# Single source of truth for the `finlab auth` aliases, kept for
# compatibility with the old Click-based CLI (`finlab auth login|logout`).
_AUTH_COMMANDS: dict[str, tuple[str, Any]] = {
    "login": ("Login via browser", cmd_login),
    "logout": ("Logout and clear credentials", cmd_logout),
    "status": ("Show plan, data, quota, and session info", cmd_status),
}


def cmd_auth(args: argparse.Namespace) -> None:
    """Dispatch `finlab auth <subcommand>` to the top-level handlers."""
    entry = _AUTH_COMMANDS.get(args.auth_command or "")
    if entry is None:
        print("Run: finlab auth --help", file=sys.stderr)
        sys.exit(1)
    entry[1](args)


def register_auth_commands(
    sub: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    auth_parser = sub.add_parser("auth", help="Authentication commands")
    auth_sub = auth_parser.add_subparsers(dest="auth_command")
    for name, (help_text, _handler) in _AUTH_COMMANDS.items():
        auth_sub.add_parser(name, help=help_text)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="finlab",
        description="FinLab CLI - Login, session management, and blog access",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("login", help="Login via browser")
    sub.add_parser("logout", help="Logout and clear credentials")
    sub.add_parser("status", help="Show plan, data, quota, and session info")
    sub.add_parser("migrate", help="Migration guide from FINLAB_API_TOKEN")

    token_parser = sub.add_parser(
        "token", help="Export credentials for headless environments"
    )
    token_parser.add_argument(
        "--env", action="store_true", help="Output as export commands for shell"
    )

    register_auth_commands(sub)
    register_blog_commands(sub)

    commands = {
        "login": cmd_login,
        "logout": cmd_logout,
        "status": cmd_status,
        "token": cmd_token,
        "migrate": cmd_migrate,
        "auth": cmd_auth,
        "blog": cmd_blog,
    }

    # Cloud strategy scheduling is optional: a broken or partially installed
    # sub-module must not take down unrelated commands like `finlab --help`.
    try:
        from finlab.cli.cloud_schedule import dispatch_cloud, register_cloud_commands

        register_cloud_commands(sub)
        commands["cloud"] = dispatch_cloud
    except ImportError:  # pragma: no cover - only hits on broken installs
        pass

    args = parser.parse_args()

    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
