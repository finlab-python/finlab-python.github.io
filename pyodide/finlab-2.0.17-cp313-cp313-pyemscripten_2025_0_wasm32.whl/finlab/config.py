from __future__ import annotations

from typing import TYPE_CHECKING

__all__ = ["get_default_market", "get_market", "reset_market", "set_market"]

if TYPE_CHECKING:
    from finlab.market import Market


def get_default_market() -> Market:
    from finlab.markets.tw import TWMarket

    return TWMarket()


_market: Market | None = None


def set_market(market: Market | type[Market]) -> None:
    """
    Set the stock market for FinLab machine learning model to generate features and labels.

    Args:
        market (Market): A Market object representing the market.
    """

    global _market

    _market = market() if isinstance(market, type) else market


def get_market() -> Market:
    global _market
    if _market is None:
        _market = get_default_market()
    return _market


def reset_market() -> None:
    """
    Reset the stock market for FinLab machine learning model to the default market, TWMarket.
    """

    global _market
    _market = get_default_market()
