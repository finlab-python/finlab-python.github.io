"""PCA-based rolling asset centrality computation."""

from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from tqdm import tqdm

logger = logging.getLogger(__name__)

try:
    from sklearn.decomposition import PCA
except ImportError:
    logger.warning("sklearn is not installed, calc_centrality will not be available")
    PCA = None


def _calc_centrality_for_window(
    window_data: pd.DataFrame, n_components: int
) -> pd.Series:
    """Compute PCA centrality scores for a single rolling window.

    Centrality ``C(i)`` is a weighted average of asset *i*'s relative
    influence across all principal components, weighted by each
    component's absorption ratio.

    Args:
        window_data: Factor portfolio returns for one window.
        n_components: Number of PCA components to use.

    Returns:
        Series of centrality scores indexed by column name.
    """
    if window_data.empty or window_data.shape[1] < n_components:
        return pd.Series(dtype=np.float64)

    clean_data = window_data.dropna()

    if len(clean_data) <= n_components or clean_data.shape[1] < n_components:
        return pd.Series(np.nan, index=window_data.columns)

    try:
        if PCA is None:
            raise ImportError(
                "sklearn is not installed, calc_centrality will not be available"
            )

        pca = PCA(n_components=min(n_components, clean_data.shape[1]))
        pca.fit(clean_data)

        cov_matrix = clean_data.cov()
        total_variance = np.sum(np.diag(cov_matrix))
        if total_variance == 0:
            return pd.Series(np.nan, index=window_data.columns)

        absorption_ratio = pca.explained_variance_ / total_variance

        abs_eigenvectors = np.abs(pca.components_)
        sum_of_abs = np.sum(abs_eigenvectors, axis=1, keepdims=True)
        sum_of_abs[sum_of_abs == 0] = 1.0
        normalized_abs_ev = abs_eigenvectors / sum_of_abs

        numerator = (absorption_ratio[:, np.newaxis] * normalized_abs_ev).sum(axis=0)
        denominator = np.sum(absorption_ratio)

        with np.errstate(divide="ignore", invalid="ignore"):
            centrality_values = numerator / denominator

        result = pd.Series(centrality_values, index=clean_data.columns)
        result.replace([np.inf, -np.inf], np.nan, inplace=True)

        return result.reindex(window_data.columns)

    except (ValueError, np.linalg.LinAlgError) as e:
        logger.warning(f"Centrality calculation failed for a window: {e}")
        return pd.Series(np.nan, index=window_data.columns)


def calc_centrality(
    return_df: pd.DataFrame, window_periods: int, n_components: int = 1
) -> pd.DataFrame:
    """Compute rolling PCA centrality over *return_df*.

    Args:
        return_df: Time-series DataFrame (dates x assets/factors).
        window_periods: Rolling window length in rows.
        n_components: Number of PCA components.

    Returns:
        DataFrame of rolling centrality scores.
    """
    logger.info(
        f"Calculating rolling centrality with window of {window_periods} periods..."
    )

    if return_df.empty or return_df.shape[0] < window_periods:
        logger.warning(
            "Input DataFrame is empty or has fewer rows than the window period. "
            "Returning empty DataFrame."
        )
        return pd.DataFrame(columns=return_df.columns)

    min_p = max(n_components + 1, int(window_periods * 0.8))
    rolling_obj = return_df.rolling(window=window_periods, min_periods=min_p)

    centrality_results: list[pd.Series] = []

    for _i, window_data in enumerate(
        tqdm(rolling_obj, total=len(return_df) - min_p + 1, desc="Rolling Centrality")
    ):
        if window_data.shape[0] < min_p:
            continue

        centrality_series = _calc_centrality_for_window(window_data, n_components)
        centrality_series.name = window_data.index[-1]
        centrality_results.append(centrality_series)

    if not centrality_results:
        logger.warning(
            "No centrality results were calculated. "
            "The resulting DataFrame will be empty."
        )
        return pd.DataFrame(columns=return_df.columns, index=pd.to_datetime([]))

    centrality_df = pd.concat(centrality_results, axis=1).T
    centrality_df.index.name = "date"
    logger.info("Rolling centrality calculation complete.")
    return centrality_df
