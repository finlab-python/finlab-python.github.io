"""Pure rebalance schedule helpers shared by backtest and lazy execution."""

from __future__ import annotations

import datetime as _dt

import pandas as pd
from pandas.tseries.frequencies import to_offset
from pandas.tseries.offsets import DateOffset


def generate_string_rebalance_dates(
    position_start: pd.Timestamp | _dt.datetime,
    present_data_date: pd.Timestamp | _dt.datetime,
    price_end: pd.Timestamp | _dt.datetime,
    resample: str,
    resample_offset: str | None,
    tz: object | None,
) -> list[pd.Timestamp]:
    """Build a list of rebalance timestamps from a frequency string."""
    if pd.__version__ >= "2.2.0":
        old_names = ["M", "BM", "SM", "CBM", "Q", "BQ", "A", "Y", "BY"]
        if resample in old_names:
            resample += "E"

    # Pandas now expects weekly weekday suffixes in uppercase, e.g. W-SUN.
    if resample.startswith("W-"):
        head, tail = resample.split("-", 1)
        resample = f"{head}-{tail.upper()}"

    offset_days = 0
    if "+" in resample:
        resample, offset_str = resample.rsplit("+", 1)
        offset_days = int(offset_str)
    elif "-" in resample:
        parts = resample.rsplit("-", 1)
        if parts[-1].isdigit():
            resample = parts[0]
            offset_days = -int(parts[-1])

    alldates = pd.date_range(
        position_start,
        present_data_date + _dt.timedelta(days=360),
        freq=resample,
        tz=tz,
    )
    alldates += DateOffset(days=offset_days)

    if resample_offset is not None:
        alldates += to_offset(resample_offset)

    dates = [d for d in alldates if position_start <= d <= present_data_date]

    if price_end > dates[-1]:
        remain = set(alldates) - set(dates)
        if remain:
            dates.append(min(remain))

    return dates
