"""FinLab blog API client and CLI formatters."""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Final

from finlab.auth import get_id_token

DEFAULT_BASE_URL: Final[str] = "https://finlab.finance"
_UA: Final[str] = "finlab-cli/1.0"


class BlogApiError(RuntimeError):
    """Raised when the FinLab blog API returns an error or invalid response."""

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        payload: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status = status
        self.payload = payload

    def __str__(self) -> str:
        if self.status is None:
            return self.message
        return f"{self.message} (HTTP {self.status})"


def _base_url(base_url: str | None = None) -> str:
    return (
        base_url or os.environ.get("FINLAB_BLOG_BASE_URL") or DEFAULT_BASE_URL
    ).rstrip("/")


def _request_json(
    path: str,
    params: dict[str, str | int | bool | None] | None = None,
    *,
    base_url: str | None = None,
    use_auth: bool = True,
) -> dict[str, Any]:
    query = {
        key: str(value)
        for key, value in (params or {}).items()
        if value is not None and value is not False
    }
    url = f"{_base_url(base_url)}{path}"
    if query:
        url += "?" + urllib.parse.urlencode(query)

    req = urllib.request.Request(url)
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", _UA)

    if use_auth:
        token = get_id_token()
        if token:
            req.add_header("Authorization", f"Bearer {token}")

    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            body = response.read().decode("utf-8")
            payload = json.loads(body)
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace") if exc.fp else ""
        payload = _loads_json_object(body)
        message = _error_message(payload) or body[:200] or exc.reason
        raise BlogApiError(message, status=exc.code, payload=payload) from exc
    except urllib.error.URLError as exc:
        raise BlogApiError(f"Could not reach FinLab blog API: {exc.reason}") from exc
    except (OSError, json.JSONDecodeError) as exc:
        raise BlogApiError(f"Invalid response from FinLab blog API: {exc}") from exc

    if not isinstance(payload, dict):
        raise BlogApiError("Invalid response from FinLab blog API")
    return payload


def _loads_json_object(body: str) -> dict[str, Any] | None:
    try:
        payload = json.loads(body)
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None


def _error_message(payload: dict[str, Any] | None) -> str | None:
    if not payload:
        return None
    error = payload.get("error")
    if isinstance(error, str):
        return error
    message = payload.get("message")
    return message if isinstance(message, str) else None


def auth_status() -> dict[str, Any]:
    """Return whether the local FinLab login can provide a Firebase ID token."""
    return {
        "authenticated": get_id_token() is not None,
        "credentialSource": "finlab.auth.get_id_token",
        "tokenReturned": False,
    }


def search_posts(
    query: str = "",
    *,
    lang: str = "zh",
    limit: int = 10,
    base_url: str | None = None,
) -> dict[str, Any]:
    """Search public FinLab blog posts."""
    return _request_json(
        "/api/blog/search",
        {"q": query, "lang": lang, "limit": limit},
        base_url=base_url,
    )


def top_posts(
    *,
    lang: str = "zh",
    limit: int = 10,
    base_url: str | None = None,
) -> dict[str, Any]:
    """Return the top FinLab blog posts."""
    return search_posts("", lang=lang, limit=limit, base_url=base_url)


def show_post(
    slug: str,
    *,
    lang: str = "zh",
    include_paid: bool = False,
    content_format: str = "markdown",
    base_url: str | None = None,
) -> dict[str, Any]:
    """Fetch a FinLab blog post by slug.

    Set ``include_paid`` to request VIP-only content. The API only returns paid
    content when the local FinLab login belongs to an entitled account.
    """
    safe_slug = urllib.parse.quote(slug.strip(), safe="")
    return _request_json(
        f"/api/blog/{safe_slug}",
        {
            "lang": lang,
            "includePaid": "1" if include_paid else "0",
            "format": content_format,
        },
        base_url=base_url,
    )


def format_post_list(payload: dict[str, Any]) -> str:
    posts = payload.get("results") or payload.get("posts") or []
    if not isinstance(posts, list) or not posts:
        return "No posts found."

    lines: list[str] = []
    for index, post in enumerate(posts[:10], start=1):
        if not isinstance(post, dict):
            continue
        title = _string(post.get("title")) or "(untitled)"
        slug = _string(post.get("slug")) or "(missing-slug)"
        url = _string(post.get("url"))
        date = _string(post.get("date"))
        is_paid = bool(
            post.get("hasPaidContent") or post.get("isPaid") or post.get("paid")
        )
        marker = " [VIP]" if is_paid else ""

        lines.append(f"{index}. {title}{marker}")
        lines.append(f"   slug: {slug}")
        if url:
            lines.append(f"   url: {url}")
        if date:
            lines.append(f"   date: {date}")

    return "\n".join(lines) if lines else "No posts found."


def format_post(payload: dict[str, Any]) -> str:
    post = payload.get("post")
    if not isinstance(post, dict):
        return "Post not found."

    title = _string(post.get("title")) or "(untitled)"
    url = _string(post.get("url"))
    content = _content_text(post, "freeContent")
    paid_content = _paid_content_text(payload, post)
    has_paid_content = bool(
        post.get("hasPaidContent") or post.get("isPaid") or post.get("paid")
    )

    lines = [title]
    if url:
        lines.append(url)
    lines.append("")

    if content:
        lines.append(content.rstrip())
    else:
        lines.append("(No free content returned.)")

    if paid_content:
        lines.extend(["", "--- VIP content ---", "", paid_content.rstrip()])
    elif has_paid_content:
        reason = _paid_content_reason(payload)
        hint = (
            "VIP content was not returned. Run `python -m finlab login` with an "
            "entitled account, then retry with `--paid`."
        )
        if reason == "includePaid=false":
            hint = "VIP content was not requested. Retry with `--paid`."
        lines.extend(
            [
                "",
                "--- VIP content ---",
                "",
                hint,
            ]
        )

    return "\n".join(lines)


def _content_text(post: dict[str, Any], prefix: str) -> str:
    for key in (f"{prefix}Markdown", f"{prefix}Html", prefix):
        value = post.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return ""


def _paid_content_text(payload: dict[str, Any], post: dict[str, Any]) -> str:
    info = payload.get("paidContent")
    if isinstance(info, dict):
        for key in ("markdown", "html", "content"):
            value = info.get(key)
            if isinstance(value, str) and value.strip():
                return value
    return _content_text(post, "paidContent")


def _paid_content_reason(payload: dict[str, Any]) -> str:
    info = payload.get("paidContent")
    if not isinstance(info, dict):
        return ""
    reason = info.get("reason")
    return reason if isinstance(reason, str) else ""


def _string(value: object) -> str:
    return value if isinstance(value, str) else ""
