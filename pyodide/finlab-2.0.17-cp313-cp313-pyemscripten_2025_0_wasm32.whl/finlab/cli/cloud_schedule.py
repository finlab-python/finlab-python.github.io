"""CLI commands for cloud-based strategy scheduling via finlab-auto-update.

Thin HTTP client that calls the Management CF and Trigger CF.
Auth uses finlab.auth.get_id_token() which handles refresh automatically.
"""

from __future__ import annotations

import argparse
import base64
import json
import sys
import urllib.error
import urllib.request
from typing import Any, Final

MANAGEMENT_CF_URL: Final[str] = (
    "https://asia-east1-fdata-299302.cloudfunctions.net/strategy-management"
)
TRIGGER_CF_URL: Final[str] = (
    "https://asia-east1-fdata-299302.cloudfunctions.net/strategy-trigger"
)


def _get_token() -> str:
    from finlab.auth import get_id_token

    token = get_id_token()
    if not token:
        print("Not logged in. Run: python -m finlab login", file=sys.stderr)
        sys.exit(1)
    return token


def _api_call(url: str, payload: dict[str, Any]) -> dict[str, Any]:
    """POST JSON to a Cloud Function with Firebase auth."""
    token = _get_token()
    body = json.dumps(payload).encode()
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "User-Agent": "finlab-cli/1.0",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        try:
            error_body = json.loads(e.read())
            msg = _format_api_error(error_body, str(e))
        except (json.JSONDecodeError, ValueError):
            msg = str(e)
        print(f"Error ({e.code}): {msg}", file=sys.stderr)
        sys.exit(1)


def _format_api_error(error_body: dict[str, Any], fallback: str) -> str:
    msg = str(error_body.get("error") or fallback)
    pricing_url = error_body.get("pricing_url")
    if pricing_url:
        msg += f"\nPricing: {pricing_url}"
    return msg


def _manage(action: str, **params: Any) -> dict[str, Any]:
    return _api_call(MANAGEMENT_CF_URL, {"action": action, **params})


def _close_file(file_obj: Any) -> None:
    close = getattr(file_obj, "close", None)
    if close:
        close()


def _format_value(value: object) -> str:
    return "-" if value is None else str(value)


def _format_contest_status(value: object) -> str:
    if value is True:
        return "yes"
    if value is False:
        return "no"
    return "-"


def _truncate(value: object, width: int) -> str:
    text = _format_value(value)
    if len(text) <= width:
        return text
    return text[: max(width - 1, 0)] + "…"


def _read_deploy_source(args: argparse.Namespace) -> tuple[dict[str, Any], str]:
    code_file = getattr(args, "code", None)
    zip_file = getattr(args, "zip", None)

    if zip_file is not None:
        try:
            code_zip = zip_file.read()
        finally:
            _close_file(zip_file)

        entry_script = getattr(args, "entry_script", None)
        if not entry_script:
            print("--entry-script is required when using --zip", file=sys.stderr)
            sys.exit(1)
        if not entry_script.endswith(".py"):
            print("--entry-script must end with .py", file=sys.stderr)
            sys.exit(1)

        return {
            "sid": args.sid,
            "code_type": "zip",
            "code_zip_b64": base64.b64encode(code_zip).decode("ascii"),
            "entry_script": entry_script,
        }, "zip"

    if code_file is None:
        print("--code or --zip is required", file=sys.stderr)
        sys.exit(1)
    try:
        code = code_file.read()
    finally:
        _close_file(code_file)

    return {"sid": args.sid, "code": code}, "inline"


def _add_deploy_options(
    params: dict[str, Any],
    args: argparse.Namespace,
) -> dict[str, Any]:
    options = {
        "time": getattr(args, "time", None),
        "tier": getattr(args, "tier", None),
        "contest_enabled": getattr(args, "contest_enabled", None),
        "contest_alias": getattr(args, "contest_alias", None),
    }
    if options["time"]:
        params["schedule_time"] = options["time"]
    if options["tier"]:
        params["tier_id"] = options["tier"]
    if options["contest_enabled"] is not None:
        params["contest_enabled"] = options["contest_enabled"]
    if options["contest_alias"] is not None:
        params["contest_alias"] = options["contest_alias"]
    return options


def _format_deploy_message(
    args: argparse.Namespace,
    code_type: str,
    params: dict[str, Any],
    options: dict[str, Any],
) -> str:
    msg = f"Deployed '{args.sid}'"
    if code_type == "zip":
        msg += f" from zip entry {params['entry_script']}"
    if options["time"]:
        msg += f" scheduled at {options['time']}"
    if options["contest_enabled"] is True:
        msg += " with contest enabled"
    elif options["contest_enabled"] is False:
        msg += " with contest disabled"
    if options["contest_alias"] is not None:
        msg += f" (contest alias: {options['contest_alias'] or '-'})"
    return msg


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------


def cmd_deploy(args: argparse.Namespace) -> None:
    """Deploy a strategy to the cloud."""
    params, code_type = _read_deploy_source(args)
    options = _add_deploy_options(params, args)
    _manage("strategy.deploy", **params)
    print(_format_deploy_message(args, code_type, params, options))


def cmd_get(args: argparse.Namespace) -> None:
    """Get strategy metadata and inline source if available."""
    result = _manage("strategy.get", sid=args.sid)

    code = result.get("code")
    if getattr(args, "code_only", False):
        if code is not None:
            print(code)
        return

    print(f"SID:          {_format_value(result.get('sid'))}")
    print(f"Tier:         {_format_value(result.get('tier_id'))}")
    print(f"Schedule:     {_format_value(result.get('schedule_time'))}")
    print(f"Code type:    {_format_value(result.get('code_type', 'inline'))}")
    print(f"Entry script: {_format_value(result.get('entry_script'))}")
    print(f"Contest:      {_format_contest_status(result.get('contest_enabled'))}")
    print(f"Contest ID:   {_format_value(result.get('contest_entry_id'))}")
    print(f"Alias:        {_format_value(result.get('contest_alias'))}")
    print(f"Joined at:    {_format_value(result.get('contest_joined_at'))}")

    if code is None:
        return

    print("\nCode:")
    print(code)


def cmd_run(args: argparse.Namespace) -> None:
    """Trigger a manual strategy execution."""
    payload: dict[str, Any] = {"sid": args.sid}
    tier = getattr(args, "tier", None)
    if tier:
        payload["tier_id"] = tier
    result = _api_call(TRIGGER_CF_URL, payload)
    exec_id = result.get("exec_id", "unknown")
    status = result.get("status", "queued")
    print(f"Triggered '{args.sid}' ({status}) - exec_id: {exec_id}")


def cmd_list(args: argparse.Namespace) -> None:
    """List all cloud strategies."""
    result = _manage("strategy.list", limit=getattr(args, "limit", 100))
    strategies = result.get("strategies", [])
    if not strategies:
        print("No strategies found.")
        return

    # Simple table output
    header = (
        f"{'SID':<30} {'TIER':<6} {'SCHEDULE':<10} {'TYPE':<8} "
        f"{'CONTEST':<8} {'ALIAS':<20}"
    )
    print(header)
    print("-" * len(header))
    for s in strategies:
        sid = s.get("sid", "?")
        tier = s.get("tier_id", "-")
        schedule = s.get("schedule_time") or "-"
        code_type = s.get("code_type", "inline")
        contest = _format_contest_status(s.get("contest_enabled"))
        alias = _truncate(s.get("contest_alias"), 20)
        print(
            f"{sid:<30} {tier:<6} {schedule:<10} {code_type:<8} "
            f"{contest:<8} {alias:<20}"
        )


def cmd_logs(args: argparse.Namespace) -> None:
    """Show recent execution logs for a strategy."""
    result = _manage("execution.list", sid=args.sid, limit=args.limit)
    executions = result.get("executions", [])
    if not executions:
        print(f"No executions found for '{args.sid}'.")
        return

    header = (
        f"{'EXEC_ID':<28} {'STATUS':<10} {'DURATION':<10} {'COST':<10} {'QUEUED_AT'}"
    )
    print(header)
    print("-" * len(header))
    for e in executions:
        exec_id = e.get("exec_id", "?")
        status = e.get("status", "?")
        duration = e.get("duration_s")
        duration_str = f"{duration:.1f}s" if duration is not None else "-"
        cost_data = e.get("cost")
        cost_str = f"${cost_data['usd']:.4f}" if cost_data else "-"
        queued = e.get("queued_at", "-")
        if isinstance(queued, str) and len(queued) > 19:
            queued = queued[:19]
        print(f"{exec_id:<28} {status:<10} {duration_str:<10} {cost_str:<10} {queued}")

        if getattr(args, "show_output", False):
            stdout = e.get("stdout")
            stderr = e.get("stderr")
            error = e.get("error")
            if stdout:
                print("\nstdout:")
                print(stdout)
            if stderr:
                print("\nstderr:")
                print(stderr)
            if error:
                print("\nerror:")
                print(error)
            if stdout or stderr or error:
                print()


def cmd_delete(args: argparse.Namespace) -> None:
    """Delete a cloud strategy."""
    if not args.yes:
        confirm = input(f"Delete strategy '{args.sid}' and its schedule? [y/N] ")
        if confirm.lower() != "y":
            print("Cancelled.")
            return

    _manage("strategy.delete", sid=args.sid)
    print(f"Deleted '{args.sid}'")


def cmd_schedule_set(args: argparse.Namespace) -> None:
    """Set or change a daily strategy schedule."""
    _manage("schedule.set", sid=args.sid, time=args.time)
    print(f"Scheduled '{args.sid}' at {args.time}")


def cmd_schedule_delete(args: argparse.Namespace) -> None:
    """Delete a daily strategy schedule."""
    _manage("schedule.delete", sid=args.sid)
    print(f"Removed schedule for '{args.sid}'")


def cmd_status(args: argparse.Namespace) -> None:
    """Show billing and quota status."""
    month = getattr(args, "month", None)
    params = {"month": month} if month else {}
    result = _manage("billing.get", **params)
    billing = result.get("billing", {})
    config = result.get("config", {})
    role_limit = result.get("role_limit", {})

    budget = role_limit.get("budget_usd", 0.0)
    used = billing.get("total_cost_usd", 0.0)
    remaining = budget - used
    allowed_tiers = role_limit.get("allowed_tiers", [])

    print(f"Budget:        ${budget:.2f}/month")
    print(f"Used:          ${used:.4f}")
    print(f"Remaining:     ${remaining:.4f}")
    print(f"Allowed tiers: {', '.join(allowed_tiers) or 'none'}")
    print(
        f"Executions:    {billing.get('execution_count', 0)} "
        f"(success: {billing.get('success_count', 0)}, "
        f"error: {billing.get('error_count', 0)}, "
        f"timeout: {billing.get('timeout_count', 0)})"
    )
    print(f"Default tier:  {config.get('tier_id', 's')}")


def register_cloud_commands(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register 'cloud' subcommand group under the main CLI."""
    cloud_parser = subparsers.add_parser(
        "cloud",
        help="Cloud strategy scheduling",
        description=(
            "Deploy and run FinLab trading strategies on the cloud. "
            "Strategies are Python scripts that use the finlab SDK to backtest "
            "and execute trading strategies. Once deployed, they can run on a "
            "daily schedule (Asia/Taipei timezone) or be triggered manually. "
            "Each execution runs in an isolated container with the finlab SDK "
            "pre-installed. Requires login first: python -m finlab login"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  python -m finlab cloud deploy my-strat --code strategy.py --time 09:30 --tier s\n"
            "  python -m finlab cloud deploy contest-strat --code strategy.py --contest --contest-alias TeamA\n"
            "  python -m finlab cloud deploy zip-strat --zip strategy.zip --entry-script main.py\n"
            "  python -m finlab cloud get my-strat\n"
            "  python -m finlab cloud list\n"
            "  python -m finlab cloud run my-strat\n"
            "  python -m finlab cloud logs my-strat --limit 5\n"
            "  python -m finlab cloud schedule set my-strat 14:30\n"
            "  python -m finlab cloud status\n"
            "  python -m finlab cloud delete my-strat -y\n"
        ),
    )
    cloud_sub = cloud_parser.add_subparsers(dest="cloud_command")

    # deploy
    deploy_p = cloud_sub.add_parser(
        "deploy",
        help="Deploy a strategy to the cloud",
        description=(
            "Upload a Python strategy file and optionally set a daily schedule. "
            "The strategy code is stored server-side and executed in an isolated "
            "container with finlab SDK pre-installed. A preamble is automatically "
            "prepended that calls finlab.login() and sets up data storage. "
            "Re-deploying the same SID overwrites the previous code and settings."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  python -m finlab cloud deploy my-strat --code strategy.py\n"
            "  python -m finlab cloud deploy my-strat --code strategy.py --time 09:30\n"
            "  python -m finlab cloud deploy my-strat --code strategy.py --tier m --time 14:00\n"
            "  python -m finlab cloud deploy contest-strat --code strategy.py --contest --contest-alias TeamA\n"
            "  python -m finlab cloud deploy zip-strat --zip strategy.zip --entry-script main.py\n"
        ),
    )
    deploy_p.add_argument(
        "sid",
        help="Strategy ID — a unique name for this strategy (e.g. 'momentum-tw50')",
    )
    deploy_source = deploy_p.add_mutually_exclusive_group(required=True)
    deploy_source.add_argument(
        "--code",
        type=argparse.FileType("r", encoding="utf-8"),
        help="Path to the strategy .py file to upload",
    )
    deploy_source.add_argument(
        "--zip",
        type=argparse.FileType("rb"),
        help=(
            "Path to a zipped multi-file strategy. The zip is base64 encoded "
            "and sent as code_zip_b64."
        ),
    )
    deploy_p.add_argument(
        "--entry-script",
        help="Python entry script inside --zip, e.g. main.py",
    )
    deploy_p.add_argument(
        "--time",
        metavar="HH:MM",
        help="Daily schedule time in HH:MM format (Asia/Taipei timezone, e.g. '09:30'). "
        "Omit to deploy without a schedule (manual-only). "
        "Re-deploying without --time keeps the existing schedule unchanged.",
    )
    deploy_p.add_argument(
        "--tier",
        choices=["s", "m", "l", "xl"],
        help=(
            "Compute tier: "
            "s = 1 CPU / 2 GiB / 120s timeout, "
            "m = 2 CPU / 4 GiB / 180s, "
            "l = 4 CPU / 16 GiB / 300s, "
            "xl = 8 CPU / 32 GiB / 600s. "
            "Higher tiers require a higher plan. Default: s"
        ),
    )
    contest_group = deploy_p.add_mutually_exclusive_group()
    contest_group.add_argument(
        "--contest",
        dest="contest_enabled",
        action="store_true",
        help=(
            "Opt this strategy into the contest. Only scheduled executions "
            "are contest-eligible; the strategy must upload a report with "
            "sim(..., upload=True)."
        ),
    )
    contest_group.add_argument(
        "--no-contest",
        dest="contest_enabled",
        action="store_false",
        help=(
            "Withdraw this strategy from the contest. Rejoining a withdrawn "
            "contest entry is not supported by the backend."
        ),
    )
    deploy_p.set_defaults(contest_enabled=None)
    deploy_p.add_argument(
        "--contest-alias",
        help=(
            "Public leaderboard alias for this strategy, up to 64 characters. "
            "Can be used with --contest or to rename an existing contest entry."
        ),
    )

    # get
    get_p = cloud_sub.add_parser(
        "get",
        help="Get strategy metadata and inline code",
        description=(
            "Fetch one strategy's metadata. Inline strategies include source code; "
            "zip strategies show metadata only because source files are stored in GCS."
        ),
    )
    get_p.add_argument("sid", help="Strategy ID to fetch")
    get_p.add_argument(
        "--code-only",
        action="store_true",
        help="Print only inline source code when code is available",
    )

    # run
    run_p = cloud_sub.add_parser(
        "run",
        help="Trigger a manual execution",
        description=(
            "Immediately queue a one-off execution of the strategy. "
            "The strategy must already be deployed. "
            "Rate-limited to 5 manual triggers per strategy per hour."
        ),
    )
    run_p.add_argument(
        "sid",
        help="Strategy ID of the deployed strategy to execute",
    )
    run_p.add_argument(
        "--tier",
        choices=["s", "m", "l", "xl"],
        help=(
            "Override compute tier for this manual run. If omitted, the backend "
            "uses the strategy's saved tier, then the user default."
        ),
    )

    # list
    list_p = cloud_sub.add_parser(
        "list",
        help="List all cloud strategies",
        description=(
            "Show all deployed strategies with their SID, compute tier, "
            "schedule time, and code type (inline or zip)."
        ),
    )
    list_p.add_argument(
        "--limit",
        type=int,
        default=100,
        metavar="N",
        help="Maximum strategies to return (default: 100, max: 500)",
    )

    # logs
    logs_p = cloud_sub.add_parser(
        "logs",
        help="Show execution logs",
        description=(
            "Show recent executions for a strategy, newest first. "
            "Displays exec_id, status (success/error/timeout/queued/running), "
            "duration, cost in USD, and queued timestamp."
        ),
    )
    logs_p.add_argument(
        "sid",
        help="Strategy ID to show logs for",
    )
    logs_p.add_argument(
        "--limit",
        type=int,
        default=10,
        metavar="N",
        help="Number of recent executions to show (default: 10, max: 100)",
    )
    logs_p.add_argument(
        "--show-output",
        action="store_true",
        help="Print capped stdout, stderr, and error fields after each execution row",
    )

    # delete
    delete_p = cloud_sub.add_parser(
        "delete",
        help="Delete a strategy",
        description=(
            "Permanently delete a deployed strategy, its code, and its schedule. "
            "Execution history is preserved for auditing. "
            "Asks for confirmation unless -y is passed."
        ),
    )
    delete_p.add_argument(
        "sid",
        help="Strategy ID to delete",
    )
    delete_p.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip the confirmation prompt",
    )

    # schedule
    schedule_p = cloud_sub.add_parser(
        "schedule",
        help="Manage daily schedules",
        description="Set or remove a strategy's daily schedule in Asia/Taipei time.",
    )
    schedule_sub = schedule_p.add_subparsers(dest="schedule_command")

    schedule_set_p = schedule_sub.add_parser(
        "set",
        help="Set or change a daily schedule",
        description="Set a strategy's daily schedule time in HH:MM Asia/Taipei time.",
    )
    schedule_set_p.add_argument("sid", help="Strategy ID to schedule")
    schedule_set_p.add_argument("time", metavar="HH:MM", help="Daily run time")

    schedule_delete_p = schedule_sub.add_parser(
        "delete",
        help="Remove a daily schedule",
        description="Remove a strategy's schedule without deleting the strategy.",
    )
    schedule_delete_p.add_argument("sid", help="Strategy ID to unschedule")

    # status
    status_p = cloud_sub.add_parser(
        "status",
        help="Show billing and quota",
        description=(
            "Show current month's billing summary: budget, amount used, "
            "remaining balance, allowed compute tiers, execution counts "
            "(success/error/timeout), and default tier setting."
        ),
    )
    status_p.add_argument(
        "--month",
        metavar="YYYY-MM",
        help="Billing month to fetch. Defaults to the current UTC month.",
    )


_CLOUD_COMMANDS = {
    "deploy": cmd_deploy,
    "get": cmd_get,
    "run": cmd_run,
    "list": cmd_list,
    "logs": cmd_logs,
    "delete": cmd_delete,
    "status": cmd_status,
}

_SCHEDULE_COMMANDS = {
    "set": cmd_schedule_set,
    "delete": cmd_schedule_delete,
}


def dispatch_cloud(args: argparse.Namespace) -> None:
    """Dispatch a cloud subcommand."""
    if args.cloud_command == "schedule":
        handler = _SCHEDULE_COMMANDS.get(args.schedule_command)
        if handler:
            handler(args)
            return
        print("Usage: python -m finlab cloud schedule <set|delete>")
        sys.exit(1)

    handler = _CLOUD_COMMANDS.get(args.cloud_command)
    if handler:
        handler(args)
    else:
        print(
            "Usage: python -m finlab cloud "
            "<deploy|get|run|list|logs|schedule|delete|status>"
        )
        sys.exit(1)
