"""Authentication, cloud fetch helpers, and batch request building."""

from __future__ import annotations

import datetime
import sys
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Final, cast
from urllib.parse import urlencode

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    import pandas as pd

import pyarrow as pa
import requests

import finlab
import finlab.utils
from finlab.data import feather_io

# Import the context module lazily (not the attribute) so auth.py can be
# imported during context.py's initialization — required for the pyodide
# FileStorage path, where _check_and_apply_reset_time fires synchronously
# during DataContext.__init__ and re-enters auth.py.
from . import context as _context
from .market import _get_bucket_for_dataset

__all__ = [
    "FetchMetadata",
    "MetadataRequestMap",
    "MetadataResultMap",
    "fetch_metadata_batch",
]


@dataclass(slots=True)
class FetchMetadata:
    """Typed metadata payload returned by auth URL signing endpoint."""

    expiry: datetime.datetime | None
    url: str | None = None
    data: pd.DataFrame | None = None
    hash: str | None = None
    error: str | None = None
    role: str | None = None
    quota: float | None = None
    limit_size: float | None = None
    market: str | None = None


MetadataRequestMap = OrderedDict[str, datetime.datetime | None]
MetadataResultMap = OrderedDict[str, FetchMetadata | None]

_DEFAULT_HEADERS: Final[dict[str, str]] = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/68.0.3440.106 Safari/537.36"
    ),
}
_AUTH_URL: Final[str] = (
    "https://asia-east2-fdata-299302.cloudfunctions.net/auth_generate_data_url"
)
_AUTH_ERRORS: Final[list[str]] = [
    "request not valid",
    "User not found",
    "api_token not valid",
    "api_token not match",
]


def _dataset_to_blob(dataset: str) -> str:
    """Convert dataset name to GCS blob name."""
    return dataset.replace(":", "#") + ".feather"


def _blob_to_dataset(blob_name: str) -> str:
    """Convert a GCS blob name back to dataset name."""
    for suffix in (".feather", ".pickle"):
        if blob_name.endswith(suffix):
            blob_name = blob_name[: -len(suffix)]
            break
    return blob_name.replace("#", ":")


def _parse_expiry(time_scheduled: str | None) -> datetime.datetime | None:
    """Parse ``time_scheduled`` into a UTC datetime."""
    if time_scheduled is None:
        return None
    return datetime.datetime.strptime(time_scheduled, "%Y%m%d%H%M%S").replace(
        tzinfo=datetime.timezone.utc
    )


def _classify_fetch_error(error: str, last_token_type: str | None) -> str:
    """Classify the auth endpoint error string."""
    if error == "token_expired" and last_token_type == "id_token":
        return "token_expired"
    if error in _AUTH_ERRORS:
        return "auth"
    if error == "Usage exceed 500 MB/day. Please consider upgrade to VIP program.":
        return "quota_500"
    if error == "Usage exceed 5000 MB/day. Please consider upgrade to VIP program.":
        return "quota_5000"
    return "unknown"


def _resolve_auth_params() -> dict[str, str]:
    """Resolve auth token and return params dict with token + optional session_id."""
    token_result = finlab.get_token()
    if isinstance(token_result, tuple):
        token, token_type = token_result
    else:
        token, token_type = token_result, "api_token"

    _context._default_context._last_token_type = token_type

    params: dict[str, str] = {}
    if token_type == "id_token":
        params["id_token"] = token
        try:
            from finlab.auth import get_session

            session = get_session()
            if session and session.get("session_id"):
                params["session_id"] = session["session_id"]
        except ImportError:
            pass
    else:
        params["api_token"] = token
    return params


def _build_batch_items(request_map: MetadataRequestMap) -> dict[str, Any]:
    """Build the POST body for a batch auth_generate_data_url request."""
    body: dict[str, Any] = {**_resolve_auth_params()}
    items: list[dict[str, str]] = []
    for dataset, time_saved in request_map.items():
        item: dict[str, str] = {
            "bucket_name": _get_bucket_for_dataset(dataset),
            "blob_name": _dataset_to_blob(dataset),
        }
        if time_saved is not None:
            item["time_saved"] = time_saved.strftime("%Y%m%d%H%M%S")
        items.append(item)
    body["items"] = items
    return body


def _to_fetch_metadata(raw_result: Mapping[str, Any]) -> FetchMetadata:
    """Convert untyped auth response payload into a typed metadata object."""
    quota = raw_result.get("quota")
    limit_size = raw_result.get("limit_size")
    error = raw_result.get("error")
    return FetchMetadata(
        expiry=_parse_expiry(raw_result.get("time_scheduled")),
        url=raw_result.get("url"),
        data=raw_result.get("data"),
        hash=raw_result.get("hash"),
        error=error if isinstance(error, str) else None,
        role=raw_result.get("role"),
        quota=float(quota) if quota is not None else None,
        limit_size=float(limit_size) if limit_size is not None else None,
        market=raw_result.get("market"),
    )


def _dataset_key_from_raw_result(raw_result: Mapping[str, Any]) -> str | None:
    """Extract dataset key from batch item payload."""
    dataset = raw_result.get("dataset")
    if isinstance(dataset, str) and dataset:
        return dataset

    blob_name = raw_result.get("blob_name")
    if isinstance(blob_name, str) and blob_name:
        return _blob_to_dataset(blob_name)

    return None


def _refresh_id_token() -> None:
    """Invalidate cached id_token and force a refresh on next call."""
    from finlab.auth import get_session, invalidate_token_cache, save_session

    invalidate_token_cache()
    session = get_session()
    if session:
        session.pop("id_token", None)
        session.pop("id_token_expiry", None)
        save_session(session)


_DOWNLOAD_CHUNK_SIZE: Final[int] = 1 << 20  # 1 MiB; matches pyarrow IPC block size


def _resolve_pyodide_run_sync() -> Callable[[object], object]:
    """Return ``pyodide.ffi.run_sync`` (preferred) or ``pyodide.code.run_sync``."""
    try:
        from pyodide.ffi import run_sync
    except ImportError:
        from pyodide.code import run_sync
    return run_sync


def _is_pyodide_stack_switch_error(exc: BaseException) -> bool:
    """Return True when the current Pyodide entrypoint cannot use JSPI."""
    message = str(exc)
    return (
        "Cannot stack switch" in message and "callPromising" in message
    ) or "WebAssembly stack switching not supported" in message


_JS_BUFFER_TO_LATIN1_SOURCE = """
(buf, offset, length) => {
    const arr = new Uint8Array(buf, offset, length);
    const CHUNK = 0x8000;
    let out = '';
    for (let i = 0; i < arr.length; i += CHUNK) {
        out += String.fromCharCode.apply(
            null, arr.subarray(i, Math.min(i + CHUNK, arr.length))
        );
    }
    return out;
}
"""

_js_buffer_to_latin1: object | None = None


def _array_buffer_to_bytes(array_buffer: object) -> bytes:
    """Convert a JS ``ArrayBuffer`` to Python ``bytes`` in bounded chunks.

    Each byte (0x00–0xFF) becomes a Python codepoint of the same value, then
    Python's true-8-bit ``latin-1`` encode round-trips back to bytes.

    We can't use ``TextDecoder('latin1')`` / ``TextDecoder('iso-8859-1')``
    because the WHATWG Encoding spec maps both names to **Windows-1252** in
    browsers — bytes 0x80–0x9F get translated to non-latin-1 codepoints
    (e.g. 0x88 → U+02C6) that Python's strict 8-bit ``latin-1`` then refuses
    to encode. ``String.fromCharCode`` is the only browser-portable way to
    get a true byte-preserving JS string.
    """
    global _js_buffer_to_latin1
    if _js_buffer_to_latin1 is None:
        from pyodide.code import run_js

        _js_buffer_to_latin1 = run_js(_JS_BUFFER_TO_LATIN1_SOURCE)
    # Keep each JS string below engine limits (large tables exceed 512 MiB).
    # BytesIO avoids retaining every intermediate string/bytes chunk.
    from io import BytesIO

    chunk_size = 8 * 1024 * 1024
    size = int(array_buffer.byteLength)  # type: ignore[attr-defined]
    output = BytesIO()
    for offset in range(0, size, chunk_size):
        length = min(chunk_size, size - offset)
        text = cast(
            "str",
            _js_buffer_to_latin1(array_buffer, offset, length),  # type: ignore[operator]
        )
        output.write(text.encode("latin-1"))
    return output.getvalue()


async def _pyfetch_bytes_async(
    url: str,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: str | None = None,
    raise_for_status: bool = True,
) -> bytes:
    """Async primitive: fetch raw bytes via ``pyodide.http.pyfetch``.

    Pyodide 0.29.x's typed-array bridge is unstable for fetch-backed
    buffers (``response.bytes()`` raises ``RangeError: offset is out of
    bounds``; ``ReadableStream`` chunks raise ``Unknown typed array type
    'Uint8Array'``). Get the entire ``ArrayBuffer`` and feed it to a
    JS-side ``String.fromCharCode`` helper in bounded chunks, then encode
    each byte-preserving string back to ``bytes`` in Python.
    """
    from pyodide.http import pyfetch

    kwargs: dict[str, object] = {"method": method}
    if headers is not None:
        kwargs["headers"] = headers
    if body is not None:
        kwargs["body"] = body
    response = await pyfetch(url, **kwargs)
    if raise_for_status:
        response.raise_for_status()
    array_buffer = await response.js_response.arrayBuffer()
    return _array_buffer_to_bytes(array_buffer)


def _pyfetch_bytes_sync(
    url: str,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: str | None = None,
    raise_for_status: bool = True,
) -> bytes:
    """Sync wrapper around ``_pyfetch_bytes_async`` via ``run_sync``.

    Falls back to a direct synchronous ``XMLHttpRequest`` when the browser
    or current Python entrypoint cannot use JSPI. FinLab's browser runtimes
    execute in Web Workers, where the synchronous fallback does not block UI.
    """
    run_sync = _resolve_pyodide_run_sync()
    awaitable = _pyfetch_bytes_async(
        url,
        method=method,
        headers=headers,
        body=body,
        raise_for_status=raise_for_status,
    )
    try:
        return cast("bytes", run_sync(awaitable))
    except RuntimeError as exc:
        close = getattr(awaitable, "close", None)
        if callable(close):
            close()
        if not _is_pyodide_stack_switch_error(exc):
            raise
    return _xhr_sync_bytes(
        url,
        method=method,
        headers=headers,
        body=body,
        raise_for_status=raise_for_status,
    )


def _pyodide_get_bytes(url: str) -> bytes:
    """Fetch raw bytes in a pyodide notebook.

    Prefers a JS-side ``getBytes`` shim if finlab's web bootstrap installed
    one; otherwise routes through ``pyodide.http.pyfetch``. Falls back to
    plain ``requests.get`` only when ``pyodide.http`` itself is unavailable
    (older pyodide builds).
    """
    if hasattr(finlab.utils.requests, "getBytes"):
        return finlab.utils.requests.getBytes(url)
    try:
        import pyodide.http  # noqa: F401
    except ImportError:
        res = finlab.utils.requests.get(url, timeout=300)
        if hasattr(res, "raise_for_status"):
            res.raise_for_status()
        return res.content
    return _pyfetch_bytes_sync(url)


_pyodide_form_post_fallback = False


def _is_pyodide_xhr_network_error(exc: BaseException) -> bool:
    """Return whether a browser transport failed before receiving a response."""
    message = str(exc)
    return exc.__class__.__name__ == "JsException" and "NetworkError" in message


def _pyodide_post_form_batch(url: str, body: dict[str, Any]) -> dict[str, Any]:
    """Send batch metadata requests as CORS-safelisted sequential form POSTs."""
    import json as _json

    items = body.get("items")
    if not isinstance(items, list):
        raise TypeError("Pyodide metadata batch body must contain an items list")

    auth_params = {key: value for key, value in body.items() if key != "items"}
    results: list[dict[str, Any]] = []
    for item in items:
        if not isinstance(item, dict):
            raise TypeError("Pyodide metadata batch items must be dictionaries")
        raw = _pyfetch_bytes_sync(
            url,
            method="POST",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            body=urlencode({**auth_params, **item}),
        )
        response = cast("dict[str, Any]", _json.loads(raw.decode("utf-8")))
        if "error" in response:
            return response
        response.setdefault("blob_name", item.get("blob_name"))
        results.append(response)
    return {"results": results}


def _pyodide_post_json(url: str, body: dict[str, Any]) -> dict[str, Any]:
    """Synchronously POST a JSON body via ``pyodide.http.pyfetch``.

    Bypasses urllib3-emscripten, whose ``to_js(req_body)`` chokes on the
    Python ``bytes`` representation of the JSON body with
    ``RuntimeError: Unknown typed array type 'Uint8Array'`` in pyodide 0.29.x.
    Passing the body as a Python ``str`` lets pyfetch hand it to the browser
    Fetch API as a JS string, sidestepping the typed-array bridge entirely.
    """
    import json as _json

    global _pyodide_form_post_fallback
    if _pyodide_form_post_fallback:
        return _pyodide_post_form_batch(url, body)

    headers = {**_DEFAULT_HEADERS, "Content-Type": "application/json"}
    try:
        raw = _pyfetch_bytes_sync(
            url, method="POST", headers=headers, body=_json.dumps(body)
        )
    except Exception as exc:
        if not _is_pyodide_xhr_network_error(exc):
            raise
        _pyodide_form_post_fallback = True
        return _pyodide_post_form_batch(url, body)
    return cast("dict[str, Any]", _json.loads(raw.decode("utf-8")))


def _pyodide_get_text(url: str) -> str:
    """Synchronously GET a text response via ``pyodide.http.pyfetch``."""
    return _pyfetch_bytes_sync(url).decode("utf-8")


def _xhr_sync_bytes(
    url: str,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: str | None = None,
    raise_for_status: bool = True,
) -> bytes:
    """Synchronous worker-safe HTTP fallback for runtimes without JSPI."""
    from js import Uint8Array, XMLHttpRequest

    try:
        xhr = XMLHttpRequest.new()
        xhr.open(method, url, False)
        for name, value in (headers or {}).items():
            xhr.setRequestHeader(name, value)
        xhr.responseType = "arraybuffer"
    except Exception as exc:
        raise RuntimeError(
            "Pyodide cannot use JSPI and synchronous XMLHttpRequest is "
            "unavailable. Run FinLab in a Web Worker or update the browser."
        ) from exc
    xhr.send(body)
    if raise_for_status and xhr.status >= 400:
        raise requests.HTTPError(f"HTTP {xhr.status} for {url}")
    return bytes(Uint8Array.new(xhr.response).to_py())


def _download_feather_bytes(
    url: str,
    headers: dict[str, str],
    on_progress: Callable[[int, int], None] | None = None,
) -> bytes:
    """Download a feather payload from *url* as raw bytes."""
    if "pyodide" in sys.modules:
        raw = _pyodide_get_bytes(url)
        if on_progress is not None:
            on_progress(len(raw), len(raw))
        return raw

    res = finlab.utils.requests.get(url, headers=headers, timeout=300, stream=True)
    res.raise_for_status()
    total = int(res.headers.get("content-length", 0))

    if total <= 0:
        buf = bytearray()
        for chunk in res.iter_content(chunk_size=_DOWNLOAD_CHUNK_SIZE):
            buf.extend(chunk)
            if on_progress is not None:
                on_progress(len(buf), len(buf))
        return bytes(buf)

    buf = bytearray(total)
    view = memoryview(buf)
    offset = 0
    for chunk in res.iter_content(chunk_size=_DOWNLOAD_CHUNK_SIZE):
        n = len(chunk)
        view[offset : offset + n] = chunk
        offset += n
        if on_progress is not None:
            on_progress(offset, total)
    if offset != total:
        return bytes(memoryview(buf)[:offset])
    return bytes(buf)


def _download_dataframe(
    url: str,
    headers: dict[str, str],
    on_progress: Callable[[int, int], None] | None = None,
) -> tuple[pd.DataFrame, bytes]:
    """Download a feather payload from *url*, returning ``(df, raw_bytes)``."""
    raw = _download_feather_bytes(url, headers, on_progress)
    return feather_io.read_frame(pa.py_buffer(raw)), raw


def _print_batch_user_warnings(result_map: MetadataResultMap) -> None:
    """Print free-user and quota warnings for batch metadata fetch."""
    ctx = _context._default_context
    finalized_results = [result for result in result_map.values() if result is not None]
    if finalized_results:
        first = finalized_results[0]
        ctx._role = first.role
        if not ctx._has_print_free_user_warning and ctx._role == "free":
            print(
                "Due to your status as a free user, "
                "the most recent data has been shortened or limited."
            )
            ctx._has_print_free_user_warning = True

    non_recent_items = [
        (dataset, result)
        for dataset, result in result_map.items()
        if result is not None and ".recent" not in dataset
    ]
    if not non_recent_items:
        return

    total_quota = max((result.quota or 0.0) for _, result in non_recent_items)
    limit_size = non_recent_items[0][1].limit_size or 0.0
    if total_quota <= 0 or limit_size <= 0:
        return

    if (
        not ctx._has_shown_quota_warning
        and ctx._role == "free"
        and total_quota / limit_size >= 0.8
    ):
        print(
            f"\n⚠️ 今日用量已達 80%（{total_quota:.0f}/{limit_size:g} MB）\n"
            f"繼續使用可能會中斷，升級 VIP 可享 10 倍額度\n"
            f"👉 https://www.finlab.finance/payment\n"
        )
        ctx._has_shown_quota_warning = True

    if len(non_recent_items) == 1:
        dataset, _ = non_recent_items[0]
        print(f"Daily usage: {total_quota:.1f} / {limit_size:g} MB - {dataset}")
    else:
        print(
            f"Daily usage: {total_quota:.1f} / {limit_size:g} MB - gets({len(non_recent_items)} items)"
        )


def _handle_fetch_batch_error(
    error: str,
    request_map: MetadataRequestMap,
) -> MetadataResultMap:
    """Handle auth endpoint errors for batch metadata fetch."""
    error_type = _classify_fetch_error(
        error, _context._default_context._last_token_type
    )
    if error_type == "token_expired":
        try:
            _refresh_id_token()
            return fetch_metadata_batch(request_map)
        except Exception as e:
            raise RuntimeError(
                "Token expired and refresh failed. "
                "Run `python -m finlab login` to re-authenticate."
            ) from e
    if error_type == "auth":
        finlab.login()
        return fetch_metadata_batch(request_map)
    if error_type == "quota_500":
        raise RuntimeError(f"**Error: {error}")
    if error_type == "quota_5000":
        raise RuntimeError(
            "**Error: Usage exceed 5000 MB/day. "
            "Please consider reaching out to us at "
            "https://discord.gg/tAr4ysPqvR to reset your usage."
        )
    raise RuntimeError(f"Batch fetch error: {error}")


def fetch_metadata_batch(request_map: MetadataRequestMap) -> MetadataResultMap:
    """Fetch per-dataset auth metadata through a single batch request."""
    body = _build_batch_items(request_map)

    if "pyodide" in sys.modules:
        ret = _pyodide_post_json(_AUTH_URL, body)
    else:
        try:
            res = finlab.utils.requests.post(
                _AUTH_URL, json=body, headers=_DEFAULT_HEADERS, timeout=300
            )
        except requests.RequestException:
            time.sleep(3)
            res = finlab.utils.requests.post(
                _AUTH_URL, json=body, headers=_DEFAULT_HEADERS, timeout=300
            )
        ret = res.json()
    if "error" in ret:
        return _handle_fetch_batch_error(ret["error"], request_map)

    raw_results: list[dict[str, Any] | None] = ret.get("results", [])
    mapped_results: dict[str, FetchMetadata] = {}
    unkeyed_results: list[FetchMetadata] = []

    for raw in raw_results:
        if raw is None:
            continue
        metadata = _to_fetch_metadata(raw)
        dataset_key = _dataset_key_from_raw_result(raw)
        if dataset_key is None:
            # Keep a positional fallback for old payload shapes with no key fields.
            unkeyed_results.append(metadata)
            continue
        mapped_results[dataset_key] = metadata

    ordered_results: MetadataResultMap = OrderedDict()
    for dataset in request_map:
        dataset_metadata = mapped_results.get(dataset)
        if dataset_metadata is None and unkeyed_results:
            dataset_metadata = unkeyed_results.pop(0)
        ordered_results[dataset] = dataset_metadata

    _print_batch_user_warnings(ordered_results)
    return ordered_results
