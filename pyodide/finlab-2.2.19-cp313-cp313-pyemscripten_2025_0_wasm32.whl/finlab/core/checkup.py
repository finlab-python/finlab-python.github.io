"""Text and structured exports of the dashboard's strategy check-up."""

from __future__ import annotations

import json
import math
import operator
from decimal import ROUND_HALF_UP, Decimal, localcontext
from functools import lru_cache
from numbers import Real
from pathlib import Path


@lru_cache(maxsize=1)
def _spec():
    # Emitted by the dashboard build from the definitions its UI imports.
    return json.loads(
        Path(__file__).with_name("checkup.json").read_text(encoding="utf-8")
    )


def _finite(value):
    return (
        isinstance(value, Real) and not isinstance(value, bool) and math.isfinite(value)
    )


def _fixed(value, digits):
    # JS toFixed rounds the binary value's magnitude, with ties away from zero.
    with localcontext() as context:
        context.prec = 330
        return format(
            Decimal(float(abs(value))).quantize(
                Decimal(10) ** -digits, rounding=ROUND_HALF_UP
            ),
            f".{digits}f",
        )


def _figure(value, kind, lang, text, bound=False, key=""):
    if not _finite(value):
        return "—"
    if kind == "money":
        size = abs(value)
        prefix = "−" if value < 0 else ""
        units = (
            ((1e12, "T", 2), (1e9, "B", 1), (1e6, "M", 1), (1e3, "K", 0))
            if lang == "en"
            else ((1e12, "兆", 2), (1e8, "億", 1), (1e4, "萬", 0))
        )
        scale, unit, digits = next(
            (entry for entry in units if size >= entry[0]), units[-1]
        )
        magnitude = _fixed(size / scale, digits)
        if lang == "en":
            return f"{prefix}NT${magnitude}{unit}"
        if digits == 0:
            magnitude = f"{int(magnitude):,}"
        return f"{prefix}{magnitude}\u00a0{unit}"
    if kind in ("days", "daysNumber"):
        number = math.floor(value + 0.5)
        return (
            str(number)
            if kind == "daysNumber"
            else text["dayUnit"].format(value=number)
        )
    if kind == "stocks":
        number = _fixed(value, 0 if bound or key == "maxNStock" else 1)
        return text["countUnit"].format(value=number)
    percent = kind in ("percent", "signedPercent", "wholePercent", "drop")
    value = (-value if kind == "drop" else value) * (100 if percent else 1)
    digits = (0 if bound or kind == "wholePercent" else 1) if percent else 2
    if bound and not percent:
        return str(int(value)) if value == int(value) else str(value)
    magnitude = _fixed(value, digits)
    sign = ""
    if float(magnitude) != 0:
        if value < 0:
            sign = "−"
        elif kind == "signedPercent" and not bound:
            sign = "+"
    return sign + magnitude + ("%" if percent else "")


def build_checkup(metrics, lang="zh-tw", *, no_trades=False):
    """Build JSON-safe results using the same rules and wording as HTML."""
    spec = _spec()
    if lang not in spec["texts"]:
        raise ValueError("lang must be 'zh-tw' or 'en'")
    text = spec["texts"][lang]

    def figure(key, value, bound=False):
        return _figure(value, spec["formats"][key], lang, text, bound, key)

    categories = []
    for category, rules in spec["rules"].items():
        if (
            category == "liquidity"
            and str(metrics.get("backtest", {}).get("market", "")).upper()
            not in spec["liquidityMarkets"]
        ):
            continue
        figures = metrics.get(category, {})
        checks = []

        for key, rule in rules.items():
            if key not in figures:
                continue
            if (
                key == "sortinoRatio"
                and metrics.get("backtest", {}).get("sortinoMethod")
                != "downside_deviation"
            ):
                rule = {"op": ">", "value": 1.8}
            value = figures[key]
            available = _finite(value)
            op = rule["op"]
            passed = bool(
                available
                and (
                    rule["low"] < value < rule["high"]
                    if op == "between"
                    else {
                        ">": operator.gt,
                        ">=": operator.ge,
                        "<": operator.lt,
                        "<=": operator.le,
                    }[op](value, rule["value"])
                )
            )
            target = (
                f"{figure(key, rule['low'], True)}–{figure(key, rule['high'], True)}"
                if op == "between"
                else f"{ {'>=': '≥', '<=': '≤'}.get(op, op) } {figure(key, rule['value'], True)}"
            )
            checks.append(
                {
                    "key": key,
                    "name": text[f"name_{key}"],
                    "explanation": text[f"explain_{key}"],
                    "value": float(value) if available else None,
                    "formatted": figure(key, value),
                    "rule": dict(rule),
                    "target": text["target"].format(rule=target),
                    "passed": passed,
                    "status": "passed"
                    if passed
                    else "failed"
                    if available
                    else "insufficient_data",
                }
            )
        passed = sum(c["passed"] for c in checks)
        params = spec["summaries"][category]
        summary = (
            text[f"answer_{category}"].format(
                **{
                    name: _figure(figures[key], kind, lang, text)
                    for name, (key, kind) in params.items()
                }
            )
            if all(_finite(figures.get(key)) for key, _ in params.values())
            else text["answerChecks"].format(passed=passed, total=len(checks))
        )
        weights = [
            spec["capacityWeight"]
            if category == "liquidity" and c["key"] == "capacity"
            else 1
            for c in checks
        ]
        score = sum(w for w, c in zip(weights, checks) if c["passed"]) / (
            sum(weights) or 1
        )
        health = next(
            (h for h, threshold in spec["health"].items() if score >= threshold), "bad"
        )
        categories.append(
            {
                "key": category,
                "question": text[f"question_{category}"],
                "summary": summary,
                "health": health,
                "health_label": spec["healthLabels"][lang][health],
                "passed": passed,
                "total": len(checks),
                "checks": checks,
            }
        )
    return {
        "title": text["checkup"],
        "lang": lang,
        "categories": categories,
        "note": text["noTrades"] if no_trades else "",
    }


def checkup_text(checkup):
    """Format a check-up without opening a browser or printing as a side effect."""
    text = _spec()["texts"][checkup["lang"]]
    insufficient = "資料不足" if checkup["lang"] == "zh-tw" else "Insufficient data"
    lines = [checkup["title"]]
    if checkup["note"]:
        lines.append(checkup["note"])
    for category in checkup["categories"]:
        lines.extend(
            [
                "",
                f"{category['question']} [{category['health_label']}]",
                category["summary"],
                text["answerChecks"].format(
                    passed=category["passed"], total=category["total"]
                ),
            ]
        )
        if not category["checks"]:
            lines.append(insufficient)
        for check in category["checks"]:
            status = (
                insufficient
                if check["status"] == "insufficient_data"
                else text["checkMet" if check["passed"] else "checkMissed"]
            )
            lines.append(
                f"  {check['name']}: {check['formatted']} | {check['target']} | {status}\n    {check['explanation']}"
            )
    return "\n".join(lines)
