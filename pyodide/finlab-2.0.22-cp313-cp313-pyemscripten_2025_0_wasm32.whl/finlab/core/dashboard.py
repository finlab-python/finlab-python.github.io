from __future__ import annotations

import base64
import html
import json
import os
import random
import string
from typing import Any
from urllib.parse import quote

import numpy as np
import pandas as pd

from finlab.core.trade_columns import to_wire_trades

DEFAULT_REPORT_TITLE = "FinLab Report"


def _decode_id_token_claims(id_token: str | None) -> dict[str, Any]:
    """Decode Firebase custom claims without treating them as authentication."""
    if not id_token:
        return {}
    try:
        payload = id_token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        decoded = json.loads(base64.urlsafe_b64decode(payload))
        return decoded if isinstance(decoded, dict) else {}
    except (IndexError, ValueError, json.JSONDecodeError):
        return {}


def _get_cached_id_token() -> str | None:
    """Read an available ID token without introducing network work."""
    env_token = os.environ.get("FINLAB_ID_TOKEN")
    if env_token:
        return env_token
    try:
        from finlab.auth import get_session

        session = get_session()
    except (ImportError, OSError):
        return None
    token = session.get("id_token") if session else None
    return token if isinstance(token, str) else None


def _resolve_dashboard_access(
    free_plan: bool | None,
    trial_date: str | None,
) -> tuple[bool, str | None]:
    """Resolve the report's upgrade prompt from explicit values or auth state."""
    role: str | None = None
    try:
        from finlab.data import get_role

        role = get_role()
    except (ImportError, AttributeError):
        pass

    if free_plan is None and role is not None:
        free_plan = role == "free"

    if free_plan is False:
        return False, None

    claims: dict[str, Any] = {}
    if free_plan is None or trial_date is None:
        claims = _decode_id_token_claims(_get_cached_id_token())

    if free_plan is None:
        merchant_ids = claims.get("merchant_ids")
        if isinstance(merchant_ids, list):
            free_plan = "taiwan_data" not in merchant_ids
        else:
            claim_role = claims.get("role")
            free_plan = claim_role in ("", "free")

    if free_plan and trial_date is None:
        claim_trial = claims.get("trial")
        trial_date = claim_trial if isinstance(claim_trial, str) else None

    return bool(free_plan), trial_date if free_plan else None


def _clean_title(value: Any) -> str | None:
    if value is None:
        return None
    title = str(value).strip()
    return title or None


def _report_title(
    report: Any, payload: dict[str, Any], title: Any | None = None
) -> str:
    explicit_title = _clean_title(title)
    if explicit_title:
        return explicit_title

    for candidate in (
        getattr(report, "title", None),
        getattr(report, "name", None),
        getattr(report, "strategy_name", None),
        payload.get("title"),
        payload.get("name"),
        payload.get("strategy_name"),
    ):
        candidate_title = _clean_title(candidate)
        if candidate_title and candidate_title != "未命名":
            return f"{candidate_title} | {DEFAULT_REPORT_TITLE}"

    return DEFAULT_REPORT_TITLE


def _favicon_data_uri() -> str:
    svg = (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
        '<rect width="64" height="64" rx="14" fill="#111827"/>'
        '<path d="M16 42h32M18 38l9-10 8 7 12-16" fill="none" '
        'stroke="#38bdf8" stroke-width="5" stroke-linecap="round" '
        'stroke-linejoin="round"/>'
        '<circle cx="47" cy="19" r="4" fill="#34d399"/>'
        "</svg>"
    )
    return "data:image/svg+xml," + quote(svg, safe="")


def default_serialize(obj: Any) -> int | float | bool | None:
    if isinstance(obj, np.bool_):
        return bool(obj)
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        return float(obj)
    if obj is pd.NaT:
        return None
    raise TypeError(
        f"Object of type '{obj.__class__.__name__}' is not JSON serializable"
    )


def read_resource_file(package: str, resource: str) -> str:
    try:
        # For Python 3.9 and later
        from importlib.resources import files

        resource_path = files(package) / resource
        with open(resource_path, encoding="utf-8") as file:
            return file.read()
    except ImportError:
        try:
            # For Python 3.7 and 3.8
            from importlib.resources import path

            with (
                path(package, resource) as resource_path,
                open(resource_path, encoding="utf-8") as file,
            ):
                return file.read()
        except ImportError:
            # Fallback for older Python versions without importlib.resources
            import pkg_resources

            resource_path = pkg_resources.resource_filename(package, resource)
            with open(resource_path, encoding="utf-8") as file:
                return file.read()
    raise ImportError("No compatible importlib.resources implementation found.")


def generate_html(
    report: Any,
    with_iframe: bool = False,
    title: Any | None = None,
    free_plan: bool | None = None,
    trial_date: str | None = None,
) -> str:
    """
    Display a report in an interactive dashboard.

    Args:
        report: The Report object containing backtest results

    Returns:
        None
    """
    j = report.to_json()
    j["trades"] = json.loads(
        to_wire_trades(report.trades.tail(500)).to_json(orient="records")
    )
    json_str = json.dumps(j, default=default_serialize)
    position_str = json.dumps(report.position_info2(), default=default_serialize)
    is_free_plan, resolved_trial_date = _resolve_dashboard_access(free_plan, trial_date)
    access_str = json.dumps(
        {
            "freePlan": is_free_plan,
            "trialDate": resolved_trial_date,
        }
    )
    page_title = html.escape(_report_title(report, j, title))
    favicon_href = html.escape(_favicon_data_uri(), quote=True)

    style_str = read_resource_file("finlab.core", "style.css")
    ctxt = read_resource_file("finlab.core", "everything.js")

    # Process JavaScript: strip SvelteKit virtual imports and export block
    lines = ctxt.split("\n")
    processed_lines = []
    for line in lines:
        if line.startswith("export"):
            break
        if line.startswith(('import "$env/', "import '$env/")):
            continue
        if 'from "$app/environment"' in line or "from '$app/environment'" in line:
            processed_lines.append("const t = true;")
            continue
        processed_lines.append(line)
    ctxt = "\n".join(processed_lines)

    http_txt = (
        """<!DOCTYPE html>
<html lang="en" class="bg-base-200">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>"""
        + page_title
        + """</title>
    <link rel="icon" type="image/svg+xml" href=\""""
        + favicon_href
        + """\">
    <meta name="theme-color" content="#111827">
</head>
<body class="bg-base-200">
    <script>const reportJson = """
        + json_str
        + """</script>
    <script>const positionJson = """
        + position_str
        + """</script>
    <script>const accessJson = """
        + access_str
        + """</script>
    <script type="module">
        """
        + ctxt
        + """
        console.log('create report')
        console.log('reportPosition', positionJson)
        const report = new Report(reportJson.timestamps, reportJson.strategy, reportJson.benchmark, reportJson.trades, reportJson.metrics)
        console.log('create report finish', report)
        report.metrics.backtest.startDate = new Date(report.metrics.backtest.startDate)
        report.metrics.backtest.endDate = new Date(report.metrics.backtest.endDate)
        report.metrics.backtest.updateDate = new Date(report.metrics.backtest.updateDate)
        report.metrics.backtest.nextTradingDate = new Date(report.metrics.backtest.nextTradingDate)
        report.metrics.backtest.livePerformanceStart = new Date(report.metrics.backtest.livePerformanceStart)


            function convertTrade(trade) {
                return Object.fromEntries(
                    Object.entries(trade).map(([key, val]) => {
                    let newkey = key;
                    let newval = val;

            switch (key) {
                case 'bmfe':
                break;
                case 'entry_date':
                newkey = 'entry';
                newval = val ? new Date(val) : null;
                break;
                case 'entry_index':
                newkey = 'entryIndex';
                break;
                case 'entry_sig_date':
                newkey = 'entrySig';
                newval = val ? new Date(val) : null;
                break;
                case 'exit_date':
                newkey = 'exit';
                newval = val ? new Date(val) : null;
                break;
                case 'exit_index':
                newkey = 'exitIndex';
                break;
                case 'exit_sig_date':
                newkey = 'exitSig';
                newval = val ? new Date(val) : null;
                break;
                case 'gmfe':
                case 'mae':
                case 'mdd':
                case 'pdays':
                case 'period':
                case 'position':
                case 'return':
                break;
                case 'symbol':
                case 'stock_id':
                newkey = 'stockId';
                break;
                case 'trade_price@entry_date':
                newkey = 'entryPrice';
                break;
                case 'trade_price@exit_date':
                newkey = 'exitPrice';
                break;
            }
            return [newkey, newval];
            })
        );

        }

        function safeLocalStorageGetItem(key) {
            try {
                return window.localStorage ? window.localStorage.getItem(key) : null;
            } catch (err) {
                return null;
            }
        }

        let theme = 'dark'

        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            console.log('User prefers dark theme');
        } else {
            console.log('User prefers light theme or has no preference');
            theme = 'dark' // default to dark
        }
        theme = safeLocalStorageGetItem('theme') || theme

        document.documentElement.setAttribute('data-theme', theme);
        report.trades = report.trades.map(convertTrade)

        console.log(report)

        const div = document.getElementById('panel')

        const analytic = document.querySelector('strategy-analytic');
        analytic.report = report;
        analytic.reportPosition = positionJson;
        analytic.browser = true;
        analytic.theme = theme;
        analytic.freePlan = accessJson.freePlan;
        if (accessJson.trialDate) {
            analytic.trialDate = accessJson.trialDate;
        }
        // Honor an explicit ?lang= query param (used by embedded report iframes,
        // e.g. English blog posts that load this report with ?lang=en). Only set
        // the default when no param is given: assigning analytic.lang explicitly
        // routes through a partial i18n path, whereas leaving it unset lets the
        // component read the query string and translate the dashboard fully.
        if (!new URLSearchParams(window.location.search).get('lang')) {
            analytic.lang = 'zh-tw';
        }
        analytic.webcomponent = true;

        function updateIconColor() {
            const theme = analytic.theme
            const textColor = theme === 'light' ? 'black' : 'white';
            const elements = document.querySelectorAll('.fill-current');
            elements.forEach(element => {
                element.style.color = textColor
            });

        }

        updateIconColor()
    </script>
<div id="panel" style="z-index: 2;position:relative;margin: 0 auto;padding-top:0;border-radius: 16px">
    <strategy-analytic></strategy-analytic>
</div>
<script>
// Self-resize when inside an iframe (Colab/Jupyter fallback)
// srcdoc iframes inherit parent origin, so frameElement is accessible
try {
    if (window.frameElement) {
        var _panel = document.getElementById('panel');
        if (_panel) {
            var _resizeFrame = 0;
            var _lastFrameHeight = 0;
            new ResizeObserver(function() {
                if (_resizeFrame) return;
                _resizeFrame = requestAnimationFrame(function() {
                    _resizeFrame = 0;
                    var height = Math.ceil(_panel.getBoundingClientRect().height);
                    if (!height || Math.abs(height - _lastFrameHeight) <= 1) return;
                    _lastFrameHeight = height;
                    window.frameElement.style.height = height + 'px';
                });
            }).observe(_panel);
        }
    }
} catch (err) {}
</script>
</body>

<style>"""
        + style_str
        + """
</style>
</html>"""
    )

    if not with_iframe:
        return http_txt

    iframe_id = "iframe_" + "".join(
        random.choice(string.ascii_letters) for _ in range(10)
    )
    return (
        """
        <iframe id=\""""
        + iframe_id
        + """\" srcdoc=\""""
        + html.escape(http_txt)
        + """\" style="height: 600px;width: 100%;max-width:800px; border: none;border-radius:20px"></iframe>
        <script>
            const _iframeId = 'IFRAME';
            window.addEventListener('message', function (event) {
                const data = event.data;
                if (!data.frameHeight) {
                    return;
                }

                const iframe = document.querySelector('#'+_iframeId);
                if (!iframe) return;

                const newHeight = data.frameHeight + 1;
                if (iframe.style.height === newHeight + 'px') return;

                iframe.style.height = newHeight + 'px';
                iframe.setAttribute('scrolling', 'no');
            });
        </script>
    """.replace("IFRAME", iframe_id)
    )
