"""One thread pool for work whose inner loops release the GIL.

numpy, pandas' Cython kernels and lz4 release the GIL while they work, so
splitting such work into ranges and running the ranges on threads uses every
core without changing what each range computes.
"""

from __future__ import annotations

import os
import sys
from concurrent.futures import ThreadPoolExecutor
from itertools import pairwise
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from collections.abc import Callable

# Below this many cells a frame is done before the threads would start.
PARALLEL_MIN_CELLS = 1 << 17
# Several ranges per thread even out columns that take longer than others.
_RANGES_PER_THREAD = 4
_executor: ThreadPoolExecutor | None = None


def _forget_pool() -> None:
    global _executor
    _executor = None


# A forked child inherits the pool but none of its threads; it starts its own.
if hasattr(os, "register_at_fork"):
    os.register_at_fork(after_in_child=_forget_pool)


def _threads() -> ThreadPoolExecutor | None:
    """The shared pool; None where threads cannot run (Pyodide) or would not help."""
    global _executor
    if "pyodide" in sys.modules or (os.cpu_count() or 1) < 2:
        return None
    if _executor is None:
        _executor = ThreadPoolExecutor(
            os.cpu_count(), thread_name_prefix="finlab-columns"
        )
    return _executor


def for_each_range(count: int, cells: int, run: Callable[[int, int], None]) -> None:
    """Call ``run(start, stop)`` over ranges covering ``range(count)``, concurrently."""
    executor = _threads() if cells >= PARALLEL_MIN_CELLS else None
    if executor is None or count < 2:
        run(0, count)
        return
    ranges = min(count, executor._max_workers * _RANGES_PER_THREAD)
    bounds = np.linspace(0, count, ranges + 1).astype(int)
    futures = []
    for start, stop in pairwise(bounds):
        try:
            futures.append(executor.submit(run, start, stop))
        except RuntimeError as exc:
            if str(exc) not in {
                "cannot schedule new futures after shutdown",
                "cannot schedule new futures after interpreter shutdown",
            }:
                raise
            # Background report uploads can outlive the pool during Python
            # shutdown. Finish only ranges that were never submitted.
            run(start, stop)
    for future in futures:
        future.result()
