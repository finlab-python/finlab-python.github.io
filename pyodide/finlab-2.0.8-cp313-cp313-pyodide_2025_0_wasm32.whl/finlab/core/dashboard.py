from __future__ import annotations

import html
import json
import random
import string
from typing import Any

import numpy as np
import pandas as pd


def default_serialize(obj: Any) -> int | float | bool | None:
    if isinstance(obj, np.bool_):
        return bool(obj)
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        return float(obj)
    if obj is pd.NaT:
        return None
    raise TypeError(
        f"Object of type '{obj.__class__.__name__}' is not JSON serializable"
    )


def read_resource_file(package: str, resource: str) -> str:
    try:
        # For Python 3.9 and later
        from importlib.resources import files

        resource_path = files(package) / resource
        with open(resource_path, encoding="utf-8") as file:
            return file.read()
    except ImportError:
        try:
            # For Python 3.7 and 3.8
            from importlib.resources import path

            with (
                path(package, resource) as resource_path,
                open(resource_path, encoding="utf-8") as file,
            ):
                return file.read()
        except ImportError:
            # Fallback for older Python versions without importlib.resources
            import pkg_resources

            resource_path = pkg_resources.resource_filename(package, resource)
            with open(resource_path, encoding="utf-8") as file:
                return file.read()
    raise ImportError("No compatible importlib.resources implementation found.")


def generate_html(report: Any, with_iframe: bool = False) -> str:
    """
    Display a report in an interactive dashboard.

    Args:
        report: The Report object containing backtest results

    Returns:
        None
    """
    j = report.to_json()
    j["trades"] = json.loads(report.trades.tail(500).to_json(orient="records"))
    json_str = json.dumps(j, default=default_serialize)
    position_str = json.dumps(report.position_info2(), default=default_serialize)

    style_str = read_resource_file("finlab.core", "style.css")
    ctxt = read_resource_file("finlab.core", "everything.js")

    # Process JavaScript: strip SvelteKit virtual imports and export block
    lines = ctxt.split("\n")
    processed_lines = []
    for line in lines:
        if line.startswith("export"):
            break
        if line.startswith(('import "$env/', "import '$env/")):
            continue
        if 'from "$app/environment"' in line or "from '$app/environment'" in line:
            processed_lines.append("const t = true;")
            continue
        processed_lines.append(line)
    ctxt = "\n".join(processed_lines)

    http_txt = (
        """<!DOCTYPE html>
<html lang="en" class="bg-base-200">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Component Example</title>
</head>
<body class="bg-base-200">
    <script>const reportJson = """
        + json_str
        + """</script>
    <script>const positionJson = """
        + position_str
        + """</script>
    <script type="module">
        """
        + ctxt
        + """
        console.log('create report')
        console.log('reportPosition', positionJson)
        const report = new Report(reportJson.timestamps, reportJson.strategy, reportJson.benchmark, reportJson.trades, reportJson.metrics)
        console.log('create report finish', report)
        report.metrics.backtest.startDate = new Date(report.metrics.backtest.startDate)
        report.metrics.backtest.endDate = new Date(report.metrics.backtest.endDate)
        report.metrics.backtest.updateDate = new Date(report.metrics.backtest.updateDate)
        report.metrics.backtest.nextTradingDate = new Date(report.metrics.backtest.nextTradingDate)
        report.metrics.backtest.livePerformanceStart = new Date(report.metrics.backtest.livePerformanceStart)


            function convertTrade(trade) {
                return Object.fromEntries(
                    Object.entries(trade).map(([key, val]) => {
                    let newkey = key;
                    let newval = val;

            switch (key) {
                case 'bmfe':
                break;
                case 'entry_date':
                newkey = 'entry';
                newval = val ? new Date(val) : null;
                break;
                case 'entry_index':
                newkey = 'entryIndex';
                break;
                case 'entry_sig_date':
                newkey = 'entrySig';
                newval = val ? new Date(val) : null;
                break;
                case 'exit_date':
                newkey = 'exit';
                newval = val ? new Date(val) : null;
                break;
                case 'exit_index':
                newkey = 'exitIndex';
                break;
                case 'exit_sig_date':
                newkey = 'exitSig';
                newval = val ? new Date(val) : null;
                break;
                case 'gmfe':
                case 'mae':
                case 'mdd':
                case 'pdays':
                case 'period':
                case 'position':
                case 'return':
                break;
                case 'symbol':
                case 'stock_id':
                newkey = 'stockId';
                break;
                case 'trade_price@entry_date':
                newkey = 'entryPrice';
                break;
                case 'trade_price@exit_date':
                newkey = 'exitPrice';
                break;
            }
            return [newkey, newval];
            })
        );

        }

        let theme = 'dark'

        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            console.log('User prefers dark theme');
        } else {
            console.log('User prefers light theme or has no preference');
            theme = 'dark' // default to dark
        }
        theme = localStorage.getItem('theme') || theme

        document.documentElement.setAttribute('data-theme', theme);
        report.trades = report.trades.map(convertTrade)

        console.log(report)

        const div = document.getElementById('panel')

        const analytic = document.querySelector('strategy-analytic');
        analytic.report = report;
        analytic.reportPosition = positionJson;
        analytic.browser = true;
        analytic.theme = theme;
        analytic.lang = 'zh-tw';
        analytic.webcomponent = true;

        function updateIconColor() {
            const theme = analytic.theme
            const textColor = theme === 'light' ? 'black' : 'white';
            const elements = document.querySelectorAll('.fill-current');
            elements.forEach(element => {
                element.style.color = textColor
            });

        }

        updateIconColor()
    </script>
<div id="panel" style="z-index: 2;position:relative;margin: 0 auto;padding-top:0;border-radius: 16px">
    <strategy-analytic></strategy-analytic>
</div>
<script>
// Self-resize when inside an iframe (Colab/Jupyter fallback)
// srcdoc iframes inherit parent origin, so frameElement is accessible
if (window.frameElement) {
    var _panel = document.getElementById('panel');
    if (_panel) {
        var _resizeFrame = 0;
        var _lastFrameHeight = 0;
        new ResizeObserver(function() {
            if (_resizeFrame) return;
            _resizeFrame = requestAnimationFrame(function() {
                _resizeFrame = 0;
                var height = Math.ceil(_panel.getBoundingClientRect().height);
                if (!height || Math.abs(height - _lastFrameHeight) <= 1) return;
                _lastFrameHeight = height;
                window.frameElement.style.height = height + 'px';
            });
        }).observe(_panel);
    }
}
</script>
</body>

<style>"""
        + style_str
        + """
</style>
</html>"""
    )

    if not with_iframe:
        return http_txt

    iframe_id = "iframe_" + "".join(
        random.choice(string.ascii_letters) for _ in range(10)
    )
    return (
        """
        <iframe id=\""""
        + iframe_id
        + """\" srcdoc=\""""
        + html.escape(http_txt)
        + """\" style="height: 600px;width: 100%;max-width:800px; border: none;border-radius:20px"></iframe>
        <script>
            const _iframeId = 'IFRAME';
            window.addEventListener('message', function (event) {
                const data = event.data;
                if (!data.frameHeight) {
                    return;
                }

                const iframe = document.querySelector('#'+_iframeId);
                if (!iframe) return;

                const newHeight = data.frameHeight + 1;
                if (iframe.style.height === newHeight + 'px') return;

                iframe.style.height = newHeight + 'px';
                iframe.setAttribute('scrolling', 'no');
            });
        </script>
    """.replace("IFRAME", iframe_id)
    )
