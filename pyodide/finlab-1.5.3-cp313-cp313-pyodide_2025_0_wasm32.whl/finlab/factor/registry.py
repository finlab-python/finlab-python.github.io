# -*- coding: utf-8 -*-
"""
Factor Registry (FinLab 版最小化)
- 可存取全域 REGISTRY
- 使用 finlab.data 取資料
- 支援參數 schema：傳入 (default, [choices]) 形式
- REGISTRY.to_cloud() / FactorRegistry.from_cloud()：只存/載 metadata（不含函式碼）
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Tuple
import json
from pathlib import Path
import hashlib
import warnings

# 依賴 pandas 用於快照摘要
try:
    import pandas as pd  # type: ignore
except Exception:  # 延遲依賴，非 DataFrame 結果將不使用快照
    pd = None  # type: ignore

# FinLab 資料
from finlab import data

# ---------- Registry 內部結構 ----------

@dataclass
class ParamSpec:
    default: Any
    choices: Optional[list] = None

@dataclass
class FactorMeta:
    name: str
    params: Dict[str, ParamSpec]
    doc: Optional[str] = None

class FactorRegistry:
    def __init__(self):
        self._funcs: Dict[str, Callable] = {}
        self._meta: Dict[str, FactorMeta] = {}
        # 快照儲存目錄（相對於工作目錄，避免汙染原始碼）
        self._snapshot_dir: Path = Path(".finlab_factor_snapshots")

    # 註冊：REGISTRY.register("sma", window=(120, [20,60,120,240]))
    def register(self, name: str, **param_defs):
        def deco(f: Callable):
            # 參數 schema 正規化
            params: Dict[str, ParamSpec] = {}
            for k, v in param_defs.items():
                if isinstance(v, tuple) and len(v) == 2 and isinstance(v[1], (list, tuple)):
                    params[k] = ParamSpec(default=v[0], choices=list(v[1]))
                else:
                    params[k] = ParamSpec(default=v, choices=None)

            meta = FactorMeta(
                name=name,
                params=params,
                doc=(f.__doc__ or None),
            )
            # 若重新註冊同名因子，清除舊快照
            self._clean_snapshots_for(name)
            self._funcs[name] = f
            self._meta[name] = meta
            return f
        return deco

    def get(self, name: str) -> Callable:
        return self._funcs[name]

    def meta(self, name: str) -> FactorMeta:
        return self._meta[name]

    def run(self, name: str, **params) -> Any:
        """合併預設參數，驗證 choices，呼叫對應函式"""
        f = self.get(name)
        meta = self.meta(name)

        # 填入預設
        merged = {k: (params[k] if k in params else spec.default)
                  for k, spec in meta.params.items()}

        # choices 驗證
        for k, spec in meta.params.items():
            if spec.choices is not None and merged[k] not in spec.choices:
                raise ValueError(f"param '{k}' must be one of {spec.choices}, got {merged[k]}")

        result = f(**merged)

        # 嘗試建立/比對資料快照（僅針對 pandas DataFrame 類型）
        if pd is not None and hasattr(result, "index") and hasattr(result, "columns"):
            try:
                self._snapshot_dir.mkdir(parents=True, exist_ok=True)
                snapshot_path = self._get_snapshot_path(name, merged)
                new_payload = self._compute_snapshot_payload(result, name, merged)
                old_payload = None
                if snapshot_path.exists():
                    try:
                        old_payload = json.loads(snapshot_path.read_text(encoding="utf-8"))
                    except Exception:
                        old_payload = None

                # 比對差異並提出警示
                if old_payload is not None:
                    self._alert_diff(old_payload, new_payload)

                # 儲存新快照
                snapshot_path.write_text(
                    json.dumps(new_payload, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            except Exception as e:
                # 快照流程不應中斷主流程
                warnings.warn(f"FactorRegistry snapshot failed for '{name}': {e}")

        return result

    # ---- 簡易「雲端」：只存 metadata，不存函式碼 ----
    def to_cloud(self, path: str | Path = "registry.cloud.json") -> None:
        payload = {
            "version": 1,
            "factors": {
                name: {
                    "doc": m.doc,
                    "params": {k: {"default": v.default, "choices": v.choices}
                               for k, v in m.params.items()}
                }
                for name, m in self._meta.items()
            }
        }
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    @staticmethod
    def from_cloud(path: str | Path = "registry.cloud.json") -> "FactorRegistry":
        """載回 metadata（函式仍需由程式碼再次 register）。"""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(p)
        obj = json.loads(p.read_text(encoding="utf-8"))
        reg = FactorRegistry()
        for name, item in obj.get("factors", {}).items():
            # 先建立空殼 meta，等待程式碼重新 register 時覆蓋/同步
            params = {k: ParamSpec(default=v["default"], choices=v.get("choices"))
                      for k, v in item.get("params", {}).items()}
            reg._meta[name] = FactorMeta(name=name, params=params, doc=item.get("doc"))
        return reg

    # ---------- 快照輔助 ----------
    def _clean_snapshots_for(self, name: str) -> None:
        try:
            if self._snapshot_dir.exists():
                for p in self._snapshot_dir.glob(f"{name}__*.json"):
                    try:
                        p.unlink()
                    except Exception:
                        pass
        except Exception:
            # 清理失敗不影響主要流程
            pass

    def _get_snapshot_path(self, name: str, merged_params: Dict[str, Any]) -> Path:
        params_json = json.dumps(merged_params, ensure_ascii=False, sort_keys=True)
        key_hash = hashlib.sha1(params_json.encode("utf-8")).hexdigest()[:16]
        filename = f"{name}__{key_hash}.json"
        return self._snapshot_dir / filename

    def _compute_snapshot_payload(self, df, name: str, merged_params: Dict[str, Any]) -> Dict[str, Any]:
        # 標準化 index/columns 至字串
        try:
            date_labels = [str(x) for x in list(df.index)]
        except Exception:
            date_labels = []
        try:
            stock_labels = [str(x) for x in list(df.columns)]
        except Exception:
            stock_labels = []

        def _is_na(value: Any) -> bool:
            try:
                if pd is not None:
                    return bool(pd.isna(value))  # type: ignore[attr-defined]
            except Exception:
                pass
            try:
                return (value is None) or (isinstance(value, float) and value != value)
            except Exception:
                return False

        def _series_hash(series) -> str:
            try:
                values = series.tolist()
            except Exception:
                # 退化處理
                return hashlib.sha1(str(series).encode("utf-8")).hexdigest()
            normalized = ["NaN" if _is_na(v) else str(v) for v in values]
            joined = "|".join(normalized)
            return hashlib.sha1(joined.encode("utf-8")).hexdigest()

        # 每個日期的橫向摘要
        date_hashes: Dict[str, str] = {}
        for d in date_labels:
            try:
                date_hashes[d] = _series_hash(df.loc[d])
            except Exception:
                # 若非標準索引擷取，嘗試使用 iloc by position
                try:
                    pos = df.index.get_loc(d)
                    date_hashes[d] = _series_hash(df.iloc[pos])
                except Exception:
                    date_hashes[d] = ""

        # 每個股票的縱向摘要
        stock_hashes: Dict[str, str] = {}
        for s in stock_labels:
            try:
                stock_hashes[s] = _series_hash(df[s])
            except Exception:
                stock_hashes[s] = ""

        return {
            "version": 1,
            "factor_name": name,
            "params": merged_params,
            "dates": date_labels,
            "stocks": stock_labels,
            "date_hashes": date_hashes,
            "stock_hashes": stock_hashes,
        }

    def _alert_diff(self, old: Dict[str, Any], new: Dict[str, Any]) -> None:
        old_dates = set(old.get("dates", []))
        new_dates = set(new.get("dates", []))
        old_stocks = set(old.get("stocks", []))
        new_stocks = set(new.get("stocks", []))

        added_dates = sorted(new_dates - old_dates)
        removed_dates = sorted(old_dates - new_dates)
        added_stocks = sorted(new_stocks - old_stocks)
        removed_stocks = sorted(old_stocks - new_stocks)

        # 值變動偵測（交集內比對 hash）
        changed_dates = []
        for d in sorted(new_dates & old_dates):
            if old.get("date_hashes", {}).get(d, None) != new.get("date_hashes", {}).get(d, None):
                changed_dates.append(d)

        changed_stocks = []
        for s in sorted(new_stocks & old_stocks):
            if old.get("stock_hashes", {}).get(s, None) != new.get("stock_hashes", {}).get(s, None):
                changed_stocks.append(s)

        if added_dates or removed_dates or changed_dates or added_stocks or removed_stocks or changed_stocks:
            parts = []
            if added_dates:
                parts.append(f"added dates: {added_dates}")
            if removed_dates:
                parts.append(f"removed dates: {removed_dates}")
            if changed_dates:
                parts.append(f"changed dates: {changed_dates}")
            if added_stocks:
                parts.append(f"added stock_ids: {added_stocks}")
            if removed_stocks:
                parts.append(f"removed stock_ids: {removed_stocks}")
            if changed_stocks:
                parts.append(f"changed stock_ids: {changed_stocks}")
            msg = "; ".join(parts)
            warnings.warn(f"Data snapshot diff detected for factor '{new.get('factor_name')}', params={new.get('params')}: {msg}")


# 全域存取點
REGISTRY = FactorRegistry()
def get_REGISTRY() -> FactorRegistry:
    return REGISTRY

# ---------- 指標（使用 FinLab 資料） ----------

# data fetcher 示例：取得收盤價（寬表：index=date, columns=asset）
# close = data.get('price:收盤價')

@REGISTRY.register("sma", window=(120, [20, 60, 120, 240]))
def sma(window: int):
    """
    簡單均線動能：close / SMA(window) - 1
    回傳與 FinLab data.get 相同形狀的 DataFrame（index=date, columns=asset）
    """
    close = data.get('price:收盤價')
    return close / close.rolling(window).mean() - 1


# ---------- 使用範例 ----------
if __name__ == "__main__":
    # 1) 直接跑
    df_sma = REGISTRY.run("sma", window=120)
    print(df_sma.tail())

    # 2) 存 metadata 到「雲端」（這裡用檔案模擬）
    REGISTRY.to_cloud("registry.cloud.json")

    # 3) 從「雲端」載回 metadata（函式需要由程式碼再次註冊）
    REGISTRY2 = FactorRegistry.from_cloud("registry.cloud.json")
    # 再次載入本檔案或你的指標模組後，REGISTRY2.register(...) 就能補上函式本體
