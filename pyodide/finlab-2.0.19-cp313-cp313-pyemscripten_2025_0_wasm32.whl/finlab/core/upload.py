from __future__ import annotations

import json
import warnings
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping

STRATEGY_NAME_ENV = "FINLAB_STRATEGY_NAME"
FORCED_STRATEGY_NAME_ENV = "FINLAB_FORCED_STRATEGY_NAME"
DEFAULT_STRATEGY_NAME = "未命名"
HTTP_OK = 200


def resolve_upload_name(name: str | None, environ: Mapping[str, str]) -> str:
    """Return the report name an upload writes to.

    Cloud runs set ``FINLAB_FORCED_STRATEGY_NAME`` to the deployed strategy id,
    which overrides ``sim(name=...)``. Warn when that silently discards an
    explicit name, otherwise the report appears to land under a name it never
    reaches.
    """
    forced = environ.get(FORCED_STRATEGY_NAME_ENV)
    if forced and name not in (None, DEFAULT_STRATEGY_NAME, forced):
        warnings.warn(
            f"Cloud run uploads the report to the deployed strategy {forced!r}; "
            f"sim(name={name!r}) is ignored. "
            f"雲端執行時報告一律寫入部署策略 {forced!r}，sim(name={name!r}) 不會生效。",
            stacklevel=2,
        )
    resolved = environ.get(STRATEGY_NAME_ENV, name)
    return environ.get(FORCED_STRATEGY_NAME_ENV, resolved) or DEFAULT_STRATEGY_NAME


def interpret_legacy_upload_response(
    status_code: int, text: str
) -> dict[str, str] | None:
    """Return an error payload when ``write_database`` rejected the upload."""
    if status_code != HTTP_OK:
        return {"status": "error", "message": text.strip() or f"HTTP {status_code}"}
    try:
        body = json.loads(text)
    except ValueError:
        return {"status": "error", "message": "cannot parse json object"}
    if isinstance(body, dict) and body.get("status") == "error":
        return {"status": "error", "message": str(body.get("message", "error"))}
    return None


def post_legacy_upload_pyodide_no_cors(url: str, payload: dict[str, Any]) -> bool:
    """Fire a legacy upload POST from Pyodide without browser CORS response access."""
    try:
        import js
        from pyodide.ffi import to_js
    except ImportError:
        return False

    js_payload = to_js(payload, dict_converter=js.Object.fromEntries)
    body = js.URLSearchParams.new(js_payload)
    options = to_js(
        {
            "method": "POST",
            "body": body,
            "mode": "no-cors",
        },
        dict_converter=js.Object.fromEntries,
    )
    js.fetch(url, options)
    return True
