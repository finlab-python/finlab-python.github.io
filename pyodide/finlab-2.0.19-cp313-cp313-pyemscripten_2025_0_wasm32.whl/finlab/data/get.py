"""Shared fetch pipeline plus ``data.get()`` single-dataset wrapper."""

from __future__ import annotations

import asyncio
import functools
import gc
import hashlib
import importlib.util
import logging
import sys
import threading
from collections import OrderedDict
from collections.abc import Callable, Iterator
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING, TypeAlias, cast

import pandas as pd
import pyarrow as pa
from requests.exceptions import HTTPError

import finlab.dataframe
import finlab.utils
from finlab.data import feather_io

from . import universe as universe_module

# Re-exports for backward compat: data.py imports these from get.py
from .auth import (
    _AUTH_ERRORS,  # noqa: F401
    _AUTH_URL,  # noqa: F401
    _DEFAULT_HEADERS,
    FetchMetadata,
    MetadataRequestMap,
    MetadataResultMap,
    _dataset_to_blob,  # noqa: F401
    _download_dataframe,
    _is_pyodide_stack_switch_error,
    _refresh_id_token,  # noqa: F401
    _resolve_auth_params,  # noqa: F401
    _resolve_pyodide_run_sync,
    fetch_metadata_batch,
)
from .context import _default_context
from .freshness import (
    _get_expiry_dict,  # noqa: F401
    is_tradable,
    next_future_expiry,
    suggested_tradable_time,
)
from .market import _resolve_dataset
from .progress import DownloadProgress, ProgressEvent, ProgressMode
from .recent_merge import HASH_HEXDIGEST_PREFIX
from .recent_merge import merge_recent_df as _merge_recent_df
from .storage import CacheStorage, FileStorage, LocalDataReadError
from .transform import (
    TABLE_INDEX_TRANSFORMERS,  # noqa: F401
    _apply_truncate_if_any,
    _mask_undisclosed_quarterly,  # noqa: F401
    _normalize_stock_columns,  # noqa: F401
    _set_dataframe_index,  # noqa: F401
    _should_mask_quarterly,
    has_index_name,  # noqa: F401
    process_data,
)

if TYPE_CHECKING:
    import datetime

    from .context import DataContext

logger = logging.getLogger(__name__)
_finalize_context_lock = threading.RLock()

StorageBackend: TypeAlias = CacheStorage | FileStorage

MetadataFetcher = Callable[
    [
        MetadataRequestMap,
    ],
    MetadataResultMap,
]

DownloadedFrame: TypeAlias = tuple[pd.DataFrame, bytes | None]
"""``(df, raw_feather_bytes)`` — bytes is None when payload was inlined."""

_MAX_PARALLEL_DOWNLOADS = 8


def _run_parallel_tasks(
    keys: list,
    worker: Callable,
    *,
    max_workers: int = _MAX_PARALLEL_DOWNLOADS,
) -> Iterator[tuple]:
    """Run *worker(key)* over *keys*, yielding ``(key, result)`` as workers complete.

    Falls back to in-thread execution when only one task is queued, so a single
    stale dataset doesn't pay the ThreadPoolExecutor setup cost. Also serializes
    in pyodide because workers may call into the single Python event loop via
    ``run_sync``, which would deadlock under concurrent threads.
    """
    n_workers = min(max_workers, len(keys))
    if n_workers <= 1 or "pyodide" in sys.modules:
        for key in keys:
            yield key, worker(key)
        return
    with ThreadPoolExecutor(max_workers=n_workers) as executor:
        futures = {executor.submit(worker, key): key for key in keys}
        for future in as_completed(futures):
            yield futures[future], future.result()


__all__ = [
    "get",
    "get_role",
    "is_tradable",
    "is_vip",
    "next_future_expiry",
    "process_data",
    "suggested_tradable_time",
]


# ---------------------------------------------------------------------------
# Finalize / cache pipeline
# ---------------------------------------------------------------------------


def _warn_local_cache_read_error(dataset: str, error: LocalDataReadError) -> None:
    logger.warning(
        "%s local cache is unreadable; falling back to cloud download. Path: %s",
        dataset,
        error.file_path,
        exc_info=True,
    )


def _finalize(dataset: str, df: pd.DataFrame, *, cache: bool = True) -> pd.DataFrame:
    with _finalize_context_lock:
        ctx = _default_context
        cache_key = (
            dataset,
            id(ctx._storage),
            id(df),
            (
                frozenset(universe_module.universe_stocks)
                if universe_module.universe_stocks
                and not universe_module._membership_read.get()
                else None
            ),
            ctx.truncate_start,
            ctx.truncate_end,
        )
        if cache:
            cached = ctx._finalized_cache.get(cache_key)
            if isinstance(cached, pd.DataFrame):
                return cached

        table_name = dataset.split(":", maxsplit=1)[0]
        skip_end = _should_mask_quarterly(table_name, ctx.truncate_end)
        df = _apply_truncate_if_any(df, skip_end=skip_end)

        if not isinstance(df, finlab.dataframe.FinlabDataFrame):
            df = finlab.dataframe.FinlabDataFrame(df)
        result = universe_module.refine_stock_id(dataset, df)
        if cache:
            ctx._finalized_cache[cache_key] = result
        return result


def hash(df: pd.DataFrame) -> str:
    return hashlib.md5(pd.util.hash_pandas_object(df, index=True).values).hexdigest()[
        :HASH_HEXDIGEST_PREFIX
    ]


def _is_local_usable(dataset: str, df: pd.DataFrame | None) -> bool:
    """Return whether the local dataframe can satisfy the request immediately."""
    present = df is not None
    return _local_cache_is_fresh(
        dataset,
        present=present,
        non_empty=present and not cast("pd.DataFrame", df).empty,
    )


def _local_cache_is_fresh(dataset: str, *, present: bool, non_empty: bool) -> bool:
    """Freshness policy for a local cache, decoupled from how it is materialised.

    ``present``/``non_empty`` let callers that only have cheap metadata (e.g. a
    date-range read that must avoid a full load) reuse the exact same policy as
    the normal full-frame fetch path.
    """
    ctx = _default_context
    storage = ctx._storage
    time_expired = storage.get_time_expired(dataset)

    # A free account may have upgraded since its last metadata response. Recheck
    # authorization before accepting its cache; paid users keep the fast path.
    # Explicit local-only/prefer-local modes are handled below as opt-outs.
    if (
        ctx._role == "free"
        and present
        and not ctx.prefer_local_if_exists
        and not ctx.use_local_data_only
    ):
        return False

    # Already loaded this session: skip server round-trip but still respect expiry
    if (
        dataset in ctx._loaded_datasets
        and time_expired
        and time_expired > CacheStorage.now()
        and non_empty
    ):
        logger.debug(f"{dataset} already loaded and not expired -> use cache")
        return True

    # Prefer local cache without checking expiry (user-set flag)
    if ctx.prefer_local_if_exists and non_empty:
        logger.debug(
            f"{dataset} prefer_local_if_exists enabled -> get data from local without update check"
        )
        return True

    if time_expired and time_expired > CacheStorage.now() and non_empty:
        logger.debug(f"{dataset} not expired -> get data from local")
        return True

    # Free user can only use historical data without merge
    return bool(ctx._role == "free" and present)


def _prepare_fetch(
    datasets: list[str],
    force_download: bool,
) -> tuple[DataContext, list[str], StorageBackend, bool]:
    """Apply shared preflight checks and resolve dataset aliases."""
    if not datasets:
        raise ValueError("at least one dataset name required")

    finlab.utils.check_version()
    ctx = _default_context
    force_download |= ctx.force_cloud_download

    if ctx.use_local_data_only and force_download:
        raise ValueError(
            "data.use_local_data_only and data.force_download cannot be both True"
        )

    resolved = [_resolve_dataset(dataset) for dataset in datasets]
    return ctx, resolved, ctx._storage, force_download


def _partition_datasets(
    resolved: list[str],
    storage: StorageBackend,
    force_download: bool,
    use_local_only: bool,
) -> tuple[
    dict[str, pd.DataFrame],
    list[str],
    list[str],
    dict[str, datetime.datetime | None],
    dict[str, pd.DataFrame | None],
]:
    """Split datasets into local hits, recent candidates, and full misses."""
    cache_hits: dict[str, pd.DataFrame] = {}
    recent_candidates: list[str] = []
    cache_misses: list[str] = []
    time_saved_map: dict[str, datetime.datetime | None] = {}
    local_frames: dict[str, pd.DataFrame | None] = {}

    if force_download:
        return (
            cache_hits,
            recent_candidates,
            list(resolved),
            time_saved_map,
            local_frames,
        )

    for dataset in resolved:
        try:
            df = storage.get_dataframe(dataset)
        except LocalDataReadError as exc:
            if use_local_only:
                raise
            _warn_local_cache_read_error(dataset, exc)
            df = None
        local_frames[dataset] = df

        if _is_local_usable(dataset, df):
            cache_hits[dataset] = _finalize(dataset, df)
            continue

        if use_local_only:
            if df is not None and not df.empty:
                cache_hits[dataset] = _finalize(dataset, df)
                continue
            raise FileNotFoundError(
                f"**Error: {dataset} not in local storage. "
                "Set data.use_local_data_only = False to download."
            )

        if df is not None:
            recent_candidates.append(dataset)
            time_saved_map[dataset] = storage.get_time_created(dataset)
            continue

        cache_misses.append(dataset)

    return cache_hits, recent_candidates, cache_misses, time_saved_map, local_frames


def _download_result_dataframe(
    result: FetchMetadata | None,
    dataset: str,
    on_progress: Callable[[int, int], None] | None = None,
) -> tuple[pd.DataFrame, bytes | None]:
    """Return ``(df, raw_feather_bytes)`` from a remote fetch result.

    ``raw_feather_bytes`` is ``None`` when the payload was inlined into the
    metadata response, since no wire bytes were ever produced.
    """
    if result is None:
        raise FileNotFoundError(f"**Error: {dataset} not exists")
    if result.data is not None:
        if on_progress is not None:
            on_progress(1, 1)
        return result.data, None

    url = result.url
    if not url:
        raise FileNotFoundError(f"**Error: {dataset} not exists")

    return _download_dataframe(url, _DEFAULT_HEADERS, on_progress=on_progress)


def _build_progress_callback(
    progress: DownloadProgress,
    dataset: str,
) -> tuple[Callable[[int, int], None], Callable[[], int]]:
    """Build per-dataset byte progress callback and final-size accessor."""
    state: dict[str, int] = {"downloaded": 0, "total": 0}

    def _on_progress(downloaded: int, total: int) -> None:
        total_effective = total if total > 0 else max(downloaded, 1)
        state["downloaded"] = downloaded
        state["total"] = total_effective
        progress.update(dataset, downloaded, total_effective)

    def _final_bytes() -> int:
        return state["total"] or state["downloaded"] or 1

    return _on_progress, _final_bytes


def _estimate_dataframe_bytes(df: pd.DataFrame) -> int:
    """Estimate display size for a downloaded dataframe."""
    try:
        return max(int(df.memory_usage(deep=True).sum()), 1)
    except (TypeError, ValueError):
        return 1


def _download_recent_delta(
    dataset: str,
    result: FetchMetadata,
    progress: DownloadProgress | None,
) -> tuple[pd.DataFrame, int | None]:
    """Download one ``.recent`` payload with optional progress updates."""
    if progress is None:
        short_df, _ = _download_result_dataframe(result, f"{dataset}.recent")
        return short_df, None

    on_progress, final_bytes = _build_progress_callback(progress, dataset)
    short_df, _ = _download_result_dataframe(
        result,
        f"{dataset}.recent",
        on_progress=on_progress,
    )
    nbytes = final_bytes()
    if nbytes <= 1:
        nbytes = _estimate_dataframe_bytes(short_df)
    return short_df, nbytes


def _resolve_recent_hit(
    dataset: str,
    df: pd.DataFrame,
    result: FetchMetadata,
    storage: StorageBackend,
    progress: DownloadProgress | None,
) -> pd.DataFrame | None:
    """Return finalized dataframe when recent-merge succeeds, else ``None``."""
    if result.error:
        logger.debug("Recent metadata error for %s: %s", dataset, result.error)
        return None

    # .recent may return metadata-only payload to indicate local cache is still valid.
    if result.data is None and not result.url:
        if result.expiry is not None:
            storage.set_time_expired(dataset, result.expiry)
        if progress is not None:
            progress.mark_cached(dataset)
        return _finalize(dataset, df)

    try:
        short_df, recent_nbytes = _download_recent_delta(dataset, result, progress)
        merged_df = _persist_recent_merge(dataset, df, short_df, result, storage)
    except HTTPError:
        logger.debug("HTTP error while downloading recent delta for %s", dataset)
        raise
    except (FileNotFoundError, KeyError, ValueError, TypeError):
        logger.debug("Failed to merge recent data for %s", dataset)
        return None

    if merged_df is None or merged_df.empty:
        return None

    if progress is not None and recent_nbytes is not None:
        progress.complete(dataset, recent_nbytes)
    logger.debug("get recent, is valid -> and merge recent to local data")
    return _finalize(dataset, merged_df)


def _persist_recent_merge(
    dataset: str,
    df: pd.DataFrame,
    short_df: pd.DataFrame,
    result: FetchMetadata,
    storage: StorageBackend,
) -> pd.DataFrame | None:
    """Merge the recent delta into the cache and return the merged frame.

    On-disk Feather caches use a streaming record-batch merge whose peak memory
    is ~= one batch + the delta; :class:`CacheStorage` and legacy pickle caches
    fall back to the in-memory :func:`_merge_recent_df`. Both verify the merged
    hash against the server-provided ``result.hash`` and return ``None`` on a
    mismatch so the caller reverts to a full download.
    """
    if (
        result.hash
        and isinstance(storage, FileStorage)
        and storage.has_feather_cache(dataset)
    ):
        if not storage.merge_recent_delta(
            dataset, short_df, result.hash, expiry=result.expiry
        ):
            return None
        return storage.get_dataframe(dataset)

    merged_df = _merge_recent_df(df, short_df)
    hash_df = hash(merged_df)
    logger.debug(f"hash df: {hash_df} url: {result.hash}")
    if result.hash != hash_df or merged_df.empty:
        return None
    storage.set_dataframe(dataset, merged_df, expiry=result.expiry)
    return merged_df


def _partition_recent_actionable(
    recent_candidates: list[str],
    local_frames: dict[str, pd.DataFrame | None],
    result_map: MetadataResultMap,
) -> tuple[list[tuple[str, pd.DataFrame, FetchMetadata]], list[str]]:
    """Split candidates into ``(actionable, full_misses)`` based on metadata."""
    actionable: list[tuple[str, pd.DataFrame, FetchMetadata]] = []
    full_misses: list[str] = []
    for dataset in recent_candidates:
        df = local_frames.get(dataset)
        result = result_map.get(f"{dataset}.recent")
        if result is None or df is None or df.empty:
            full_misses.append(dataset)
            continue
        actionable.append((dataset, df, result))
    return actionable, full_misses


def _resolve_recent_candidates(
    recent_candidates: list[str],
    time_saved_map: dict[str, datetime.datetime | None],
    storage: StorageBackend,
    local_frames: dict[str, pd.DataFrame | None],
    metadata_fetcher: MetadataFetcher,
    progress: DownloadProgress | None = None,
) -> tuple[dict[str, pd.DataFrame], list[str]]:
    """Try to satisfy stale local datasets through ``.recent`` fetches."""
    if not recent_candidates:
        return {}, []

    recent_requests: MetadataRequestMap = OrderedDict(
        (f"{dataset}.recent", time_saved_map.get(dataset))
        for dataset in recent_candidates
    )
    if progress is not None:
        progress.set_stage("Fetching recent metadata", done=0, total=1)
    role_before_fetch = _default_context._role
    result_map = metadata_fetcher(recent_requests)
    if progress is not None:
        progress.set_stage("Fetching recent metadata", done=1, total=1)
        progress.set_stage(
            "Downloading recent deltas",
            done=0,
            total=len(recent_candidates),
            datasets=recent_candidates,
        )

    # A free cache is truncated and cannot be made equivalent to paid full data
    # by a recent delta. An empty recent URL can also mean only that the paid blob
    # predates the local free-cache timestamp. Once metadata reports a paid role,
    # bypass both cases and fetch the paid full datasets directly.
    paid_role = next(
        (
            result.role
            for result in result_map.values()
            if result is not None and result.role not in {None, "free"}
        ),
        None,
    )
    if role_before_fetch == "free" and paid_role is not None:
        _default_context._role = paid_role
        if isinstance(storage, CacheStorage):
            storage.clear()
            _default_context._loaded_datasets.clear()
            _default_context._finalized_cache.clear()
        return {}, list(recent_candidates)

    actionable, full_misses = _partition_recent_actionable(
        recent_candidates, local_frames, result_map
    )
    cache_hits: dict[str, pd.DataFrame] = {}

    if not actionable:
        return cache_hits, full_misses

    actionable_map = {ds: (df, result) for ds, df, result in actionable}

    def _try_recent(dataset: str) -> pd.DataFrame | None:
        df, result = actionable_map[dataset]
        return _resolve_recent_hit(dataset, df, result, storage, progress)

    for dataset, recent_hit in _run_parallel_tasks(list(actionable_map), _try_recent):
        if recent_hit is None:
            full_misses.append(dataset)
        else:
            cache_hits[dataset] = recent_hit

    return cache_hits, full_misses


def _materialize_full_misses(
    cache_misses: list[str],
    storage: StorageBackend,
    metadata_fetcher: MetadataFetcher,
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full datasets for the remaining remote misses."""
    if not cache_misses:
        return {}

    gc.collect()
    request_map: MetadataRequestMap = OrderedDict(
        (dataset, None) for dataset in cache_misses
    )
    if progress is not None:
        progress.set_stage(
            "Fetching full metadata",
            done=0,
            total=1,
        )
    result_map = metadata_fetcher(request_map)
    if progress is not None:
        progress.set_stage(
            "Fetching full metadata",
            done=1,
            total=1,
        )
    target_storage = _resolve_full_miss_target_storage(storage, result_map)
    validated_results = _validate_full_miss_results(cache_misses, result_map)
    downloaded_frames = _download_full_miss_frames(
        cache_misses,
        validated_results,
        progress=progress,
    )
    return _persist_full_miss_frames(
        cache_misses,
        downloaded_frames,
        validated_results,
        target_storage,
    )


def _resolve_full_miss_target_storage(
    storage: StorageBackend,
    result_map: MetadataResultMap,
) -> StorageBackend:
    """Resolve storage backend for full misses, switching free users to cache storage."""
    if isinstance(storage, CacheStorage):
        return storage

    has_free_role = any(
        result is not None and result.role == "free" for result in result_map.values()
    )
    if not has_free_role:
        return storage

    if not isinstance(_default_context._storage, CacheStorage):
        _default_context._storage = CacheStorage()
    return _default_context._storage


def _validate_full_miss_results(
    cache_misses: list[str],
    result_map: MetadataResultMap,
) -> OrderedDict[str, FetchMetadata]:
    """Validate full-miss metadata and raise actionable per-item errors."""
    validated_results: OrderedDict[str, FetchMetadata] = OrderedDict()
    for dataset in cache_misses:
        result = result_map.get(dataset)
        if result is None:
            raise FileNotFoundError(f"**Error: {dataset} not exists")
        if result.error:
            raise RuntimeError(f"**Error: {result.error}")
        validated_results[dataset] = result
    return validated_results


@functools.lru_cache(maxsize=1)
def _use_pyodide_async_fetch() -> bool:
    """Return True when pyodide async parallel fetch is available."""
    if "pyodide" not in sys.modules:
        return False
    try:
        return importlib.util.find_spec("pyodide.http") is not None and (
            importlib.util.find_spec("pyodide.ffi") is not None
            or importlib.util.find_spec("pyodide.code") is not None
        )
    except (ImportError, ValueError):
        return False


def _download_full_miss_frames_threaded(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, DownloadedFrame]:
    """Download full-miss payloads via ThreadPoolExecutor."""

    def _download(dataset: str) -> tuple[DownloadedFrame, int | None]:
        return _download_one_full_miss_frame(dataset, validated_results, progress)

    downloaded: dict[str, DownloadedFrame] = {}
    for dataset, (payload, nbytes) in _run_parallel_tasks(cache_misses, _download):
        downloaded[dataset] = payload
        if progress is not None and nbytes is not None:
            progress.complete(dataset, nbytes)
    return downloaded


def _download_one_full_miss_frame(
    dataset: str,
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> tuple[DownloadedFrame, int | None]:
    """Download one full-miss dataframe; return ``((df, raw_bytes), display_nbytes)``."""
    if progress is None:
        df, raw = _download_result_dataframe(validated_results[dataset], dataset)
        return (df, raw), None

    on_progress, final_bytes = _build_progress_callback(progress, dataset)
    df, raw = _download_result_dataframe(
        validated_results[dataset],
        dataset,
        on_progress=on_progress,
    )
    nbytes = final_bytes()
    if nbytes <= 1:
        nbytes = _estimate_dataframe_bytes(df)
    return (df, raw), nbytes


def _download_full_miss_frames_sequential(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, DownloadedFrame]:
    """Download full-miss payloads without threads or async stack switching."""
    downloaded: dict[str, DownloadedFrame] = {}
    for dataset in cache_misses:
        payload, nbytes = _download_one_full_miss_frame(
            dataset,
            validated_results,
            progress,
        )
        downloaded[dataset] = payload
        if progress is not None and nbytes is not None:
            progress.complete(dataset, nbytes)
    return downloaded


def _can_run_pyodide_sync(run_sync: Callable[[object], object]) -> bool:
    """Return whether Pyodide run_sync is usable from this Python entrypoint."""

    async def _noop() -> None:
        return None

    awaitable = _noop()
    try:
        run_sync(awaitable)
    except RuntimeError as exc:
        awaitable.close()
        if _is_pyodide_stack_switch_error(exc):
            return False
        raise
    return True


def _run_pyodide_sync(
    run_sync: Callable[[object], object], awaitable: object
) -> object:
    """Run a Pyodide awaitable synchronously, closing it if the bridge rejects it."""
    try:
        return run_sync(awaitable)
    except RuntimeError:
        close = getattr(awaitable, "close", None)
        if callable(close):
            close()
        raise


def _download_full_miss_frames(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, DownloadedFrame]:
    """Download full-miss payloads concurrently when beneficial."""
    if progress is not None:
        progress.set_stage(
            "Downloading full datasets",
            done=0,
            total=len(cache_misses),
            datasets=cache_misses,
        )

    if _use_pyodide_async_fetch():
        run_sync = _resolve_pyodide_run_sync()
        if not _can_run_pyodide_sync(run_sync):
            logger.debug(
                "Pyodide async fetch unavailable from a synchronous entrypoint; "
                "falling back to sequential download."
            )
            return _download_full_miss_frames_sequential(
                cache_misses,
                validated_results,
                progress,
            )
        return _download_full_miss_frames_pyodide(
            cache_misses, validated_results, run_sync, progress
        )

    if "pyodide" in sys.modules:
        return _download_full_miss_frames_sequential(
            cache_misses,
            validated_results,
            progress,
        )

    return _download_full_miss_frames_threaded(
        cache_misses, validated_results, progress
    )


def _download_full_miss_frames_pyodide(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    run_sync: Callable[[object], object],
    progress: DownloadProgress | None = None,
) -> dict[str, DownloadedFrame]:
    """Download full-miss payloads in parallel using pyodide's async fetch."""
    from .auth import _pyfetch_bytes_async

    semaphore = asyncio.Semaphore(8)

    async def _fetch_one(
        dataset: str,
    ) -> tuple[str, pd.DataFrame, bytes | None, int | None]:
        result = validated_results[dataset]
        if result.data is not None:
            if progress is not None:
                progress.update(dataset, 1, 1)
            return dataset, result.data, None, 1

        url = result.url
        if not url:
            raise FileNotFoundError(f"**Error: {dataset} not exists")

        async with semaphore:
            raw = await _pyfetch_bytes_async(url)
        nbytes = len(raw)
        if progress is not None:
            progress.update(dataset, nbytes, nbytes)
        df = feather_io.read_frame(pa.py_buffer(raw))
        return dataset, df, raw, nbytes

    async def _fetch_all() -> list[tuple[str, pd.DataFrame, bytes | None, int | None]]:
        return await asyncio.gather(*[_fetch_one(ds) for ds in cache_misses])

    results = cast(
        "list[tuple[str, pd.DataFrame, bytes | None, int | None]]",
        _run_pyodide_sync(run_sync, _fetch_all()),
    )

    downloaded: dict[str, DownloadedFrame] = {}
    for dataset, df, raw, nbytes in results:
        downloaded[dataset] = (df, raw)
        if progress is not None and nbytes is not None:
            progress.complete(dataset, nbytes)
    return downloaded


def _persist_full_miss_frames(
    cache_misses: list[str],
    downloaded: dict[str, DownloadedFrame],
    validated_results: OrderedDict[str, FetchMetadata],
    target_storage: StorageBackend,
) -> dict[str, pd.DataFrame]:
    """Persist downloaded full misses and return finalized cache hits."""
    cache_hits: dict[str, pd.DataFrame] = {}
    for dataset in cache_misses:
        df, raw = downloaded[dataset]
        result = validated_results[dataset]
        _persist_downloaded_frame(target_storage, dataset, df, raw, result.expiry)
        logger.debug(f"{dataset} downloaded full data from cloud")
        cache_hits[dataset] = _finalize(dataset, df)
    return cache_hits


def _persist_downloaded_frame(
    storage: StorageBackend,
    dataset: str,
    df: pd.DataFrame,
    raw: bytes | None,
    expiry: datetime.datetime | None,
) -> None:
    """Persist a downloaded frame, writing raw feather bytes verbatim when available."""
    if df.empty:
        raise RuntimeError(f"**Error: {dataset} download fail")
    if raw is not None and isinstance(storage, FileStorage):
        storage.set_dataframe_bytes(dataset, raw, expiry=expiry)
    else:
        storage.set_dataframe(dataset, df, expiry=expiry)


def _fetch_many(
    datasets: list[str],
    force_download: bool,
    *,
    show_progress: bool = False,
    progress: ProgressMode | None = None,
    progress_callback: Callable[[ProgressEvent], None] | None = None,
) -> tuple[pd.DataFrame, ...]:
    """Fetch one or more datasets through shared cache and merge policy."""
    progress_display: DownloadProgress | None = None
    progress_mode: ProgressMode = progress or ("display" if show_progress else "silent")
    if progress_mode not in {"display", "event", "silent"}:
        raise ValueError("progress must be 'display', 'event', or 'silent'")
    ctx, resolved, storage, force_download = _prepare_fetch(datasets, force_download)
    try:
        (
            cache_hits,
            recent_candidates,
            cache_misses,
            time_saved_map,
            local_frames,
        ) = _partition_datasets(
            resolved,
            storage,
            force_download,
            ctx.use_local_data_only,
        )

        pending = recent_candidates + cache_misses
        if progress_mode != "silent" and (pending or progress_mode == "event"):
            progress_display = DownloadProgress(
                to_download=pending,
                cached=list(cache_hits),
                mode=progress_mode,
                callback=progress_callback,
            )
            progress_display.start()

        if recent_candidates:
            if progress_display is not None:
                progress_display.set_stage("Fetching recent metadata")
            recent_hits, promoted_misses = _resolve_recent_candidates(
                recent_candidates,
                time_saved_map,
                storage,
                local_frames,
                fetch_metadata_batch,
                progress=progress_display,
            )
            cache_hits.update(recent_hits)
            cache_misses.extend(promoted_misses)

        if cache_misses:
            cache_hits.update(
                _materialize_full_misses(
                    cache_misses,
                    storage,
                    fetch_metadata_batch,
                    progress=progress_display,
                )
            )

        results: list[pd.DataFrame] = []
        for dataset in resolved:
            results.append(cache_hits[dataset])
            ctx._loaded_datasets.add(dataset)

        if force_download and "security_categories" in resolved:
            from .category_cache import clear_category_cache

            clear_category_cache()

        return tuple(results)
    finally:
        if progress_display is not None:
            progress_display.finish()


# ---------------------------------------------------------------------------
# Role helpers
# ---------------------------------------------------------------------------


def get_role() -> str | None:
    """Return the current user role (e.g. ``'free'`` or ``'vip'``)."""
    return _default_context._role


def is_vip() -> bool:
    """Return True if the current user is a VIP member."""
    role = _default_context._role
    return role is not None and role != "free"


# ---------------------------------------------------------------------------
# Date-range (start/end) pushdown
# ---------------------------------------------------------------------------

DateBound: TypeAlias = "str | pd.Timestamp | datetime.datetime | None"


def _normalize_date_bound(bound: DateBound) -> pd.Timestamp | None:
    """Coerce a date-like bound to a ``pd.Timestamp`` (``None`` passes through)."""
    if bound is None:
        return None
    return pd.Timestamp(bound)


def _date_range_local_presence(
    storage: StorageBackend, dataset: str
) -> tuple[bool, bool]:
    """Return ``(present, non_empty)`` for a dataset without a full load."""
    if isinstance(storage, FileStorage):
        if not storage.has_dataframe(dataset):
            return False, False
        return True, (storage.get_dataframe_row_count(dataset) or 0) > 0
    df = storage.get_dataframe(dataset)
    return df is not None, df is not None and not df.empty


def _date_range_needs_refresh(
    storage: StorageBackend, dataset: str, force_download: bool
) -> bool:
    """Decide whether the local cache must be refreshed before a slice read.

    Reuses the normal full-fetch freshness policy so a date-range read never
    returns staler data than a plain ``data.get`` would.
    """
    ctx = _default_context
    if force_download or ctx.force_cloud_download:
        return True
    if ctx.use_local_data_only:
        return False
    present, non_empty = _date_range_local_presence(storage, dataset)
    return not _local_cache_is_fresh(dataset, present=present, non_empty=non_empty)


def _fetch_one_date_range(
    dataset: str,
    *,
    start: DateBound,
    end: DateBound,
    force_download: bool,
    progress: ProgressMode,
    progress_callback: Callable[[ProgressEvent], None] | None,
) -> pd.DataFrame:
    """Fetch a single dataset, pushing an inclusive ``[start, end]`` date filter
    down to the Arrow read so a slice of a huge table skips the full-table cost.
    """
    start_ts = _normalize_date_bound(start)
    end_ts = _normalize_date_bound(end)
    if start_ts is not None and end_ts is not None and start_ts > end_ts:
        raise ValueError(f"start ({start_ts}) must not be after end ({end_ts}).")

    finlab.utils.check_version()
    ctx = _default_context
    resolved = _resolve_dataset(dataset)
    storage = ctx._storage

    if _date_range_needs_refresh(storage, resolved, force_download):
        # Refresh the on-disk cache through the unchanged full pipeline (identical
        # freshness/hash semantics); the returned full frame is discarded and the
        # slice is re-read below via pushdown.
        if progress == "silent" and progress_callback is None:
            _fetch_many([dataset], force_download)
        else:
            _fetch_many(
                [dataset],
                force_download,
                progress=progress,
                progress_callback=progress_callback,
            )

    raw = storage.read_dataframe_date_range(resolved, start_ts, end_ts)
    if raw is None:
        raise FileNotFoundError(f"**Error: {resolved} not in local storage")
    ctx._loaded_datasets.add(resolved)
    return _finalize(resolved, raw, cache=False)


# ---------------------------------------------------------------------------
# data.get() -- main entry point
# ---------------------------------------------------------------------------


def get(
    dataset: str,
    save_to_storage: bool = True,
    force_download: bool = False,
    lazy: bool = False,
    progress: ProgressMode = "silent",
    progress_callback: Callable[[ProgressEvent], None] | None = None,
    *,
    start: DateBound = None,
    end: DateBound = None,
) -> pd.DataFrame:
    """Download historical data.

    See https://ai.finlab.tw/database for the full data catalogue.

    Args:
        dataset: The name of dataset.
        save_to_storage: Whether to save the dataset to storage for later use.
        force_download: Whether to force download the dataset from cloud.
        lazy: Return a lazy computation wrapper after fetching the dataset.
        progress: ``'display'``, ``'event'``, or ``'silent'``.
        progress_callback: Receives structured events in event mode.
        start: Optional inclusive lower bound on the ``date`` column. Accepts any
            date-like value (string or ``Timestamp``). Pushed down to the Arrow
            read so only in-range rows are materialised. Requires the dataset to
            have a ``date`` column/index, otherwise raises ``ValueError``.
        end: Optional inclusive upper bound on the ``date`` column. Same rules as
            ``start``. When both ``start`` and ``end`` are ``None`` the result is
            byte-identical to a plain read.

    Returns:
        financial data as a DataFrame.
    """
    if not save_to_storage:
        logger.warning(
            "save_to_storage will be deprecated after 2024/06/01. "
            "Please use data.set_storage(CacheStorage()) to disable data saved to local storage"
        )
    if start is None and end is None:
        if progress == "silent" and progress_callback is None:
            fetched = _fetch_many([dataset], force_download)
        else:
            fetched = _fetch_many(
                [dataset],
                force_download,
                progress=progress,
                progress_callback=progress_callback,
            )
        return fetched[0].lazy() if lazy else fetched[0]

    result = _fetch_one_date_range(
        dataset,
        start=start,
        end=end,
        force_download=force_download,
        progress=progress,
        progress_callback=progress_callback,
    )
    return result.lazy() if lazy else result
