"""Technical indicator computation: ``data.indicator()``."""

from __future__ import annotations

import contextlib
import json
import logging
from functools import reduce
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from typing import Protocol

    class _TalibAbstract(Protocol):
        input_names: dict[str, str | list[str]]


import numpy as np
import pandas as pd

import finlab.dataframe
import finlab.utils
from finlab import config

logger = logging.getLogger(__name__)

__all__ = [
    "get_strategies",
    "indicator",
]


# ---------------------------------------------------------------------------
# Indicator
# ---------------------------------------------------------------------------


def get_input_args(attr: _TalibAbstract) -> list[str]:
    input_names = attr.input_names
    refine_input_names: list[str] = []
    for key, val in input_names.items():
        if "price" in key:
            if isinstance(val, list):
                refine_input_names += val
            elif isinstance(val, str):
                refine_input_names.append(val)

    return refine_input_names


def _detect_indicator_package(indname: str) -> tuple[str, Any]:
    """Detect whether TA-Lib or pandas_ta provides *indname*."""
    try:
        import talib  # noqa: F401
        from talib import abstract

        return "talib", getattr(abstract, indname)
    except ImportError:
        pass

    try:
        import pandas_ta  # noqa: F401

        getattr(pd.DataFrame().ta, indname)

        def _pandas_ta_wrapper(df: pd.DataFrame, **kwargs: Any) -> pd.DataFrame:
            return getattr(df.ta, indname)(**kwargs)

        return "pandas_ta", _pandas_ta_wrapper
    except ImportError as e:
        raise ImportError(
            "Please install TA-Lib or pandas_ta to get indicators."
        ) from e


def _align_price_shapes(
    close: pd.DataFrame,
    open_: pd.DataFrame,
    high: pd.DataFrame,
    low: pd.DataFrame,
    volume: pd.DataFrame,
    indname: str,
    market: Any,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Intersect index/columns when OHLCV shapes differ."""
    dfs = [close, open_, high, low, volume]
    if all(close.shape == df.shape for df in dfs[1:]):
        return close, open_, high, low, volume

    latest_date = min(df.index[-1] for df in dfs)
    logger.warning(
        f"indicator: {indname} market: {market} has different end date, "
        f"cut to {latest_date}. This is due to server updating data. "
        "If you want to get the latest data, please try again 3 minutes later."
    )
    common_idx = reduce(lambda a, b: a.intersection(b), [df.index for df in dfs])
    common_cols = reduce(lambda a, b: a.intersection(b), [df.columns for df in dfs])

    return tuple(df.loc[common_idx, common_cols] for df in dfs)  # type: ignore[return-value]


def _compute_stock_indicator(
    package: str,
    attr: Any,
    indname: str,
    prices: dict[str, pd.Series],
    kwargs: dict[str, Any],
) -> dict[Any, Any]:
    """Run the indicator for one stock and normalize the output to a dict."""
    if package == "pandas_ta":
        result = attr(pd.DataFrame(prices), **kwargs)
    elif package == "talib":
        abstract_input = get_input_args(attr)

        if indname == "OBV":
            abstract_input = ["close", "volume"]
        if indname == "BETA":
            abstract_input = ["high", "low"]
        if isinstance(abstract_input, str):
            abstract_input = [abstract_input]
        result = attr(*[prices[k] for k in abstract_input], **kwargs)
    else:
        raise RuntimeError("Cannot determine technical package from indname")

    if isinstance(result, list):
        result = dict(enumerate(result))
    if isinstance(result, np.ndarray):
        result = {0: result}
    if isinstance(result, pd.Series):
        result = {0: result.values}
    if isinstance(result, pd.DataFrame):
        result = {i: series.values for i, series in result.items()}

    return result


def indicator(
    indname: str, adjust_price: bool = False, resample: str = "D", **kwargs: Any
) -> pd.DataFrame | tuple[pd.DataFrame, ...]:
    """支援 Talib 和 pandas_ta 上百種技術指標，計算 2000 檔股票、10年的所有資訊。

    在使用這個函式前，需要安裝計算技術指標的 Packages

    * [Ta-Lib](https://github.com/mrjbq7/ta-lib)
    * [Pandas-ta](https://github.com/twopirllc/pandas-ta)

    Args:
        indname (str): 指標名稱，
            以 TA-Lib 舉例，例如 SMA, STOCH, RSI 等，可以參考 [talib 文件](https://mrjbq7.github.io/ta-lib/doc_index.html)。

            以 Pandas-ta 舉例，例如 supertrend, ssf 等，可以參考 [Pandas-ta 文件](https://twopirllc.github.io/pandas-ta/#indicators-by-category)。
        adjust_price (bool): 是否使用還原股價計算。
        resample (str): 技術指標價格週期，ex: `D` 代表日線, `W` 代表週線, `M` 代表月線。
        market (str): 市場選擇，ex: `TW_STOCK` 代表台股, `US_STOCK` 代表美股。
        **kwargs (dict): 技術指標的參數設定，TA-Lib 中的 RSI 為例，調整項為計算週期 `timeperiod=14`。
    建議使用者可以先參考以下範例，並且搭配 talib官方文件，就可以掌握製作技術指標的方法了。
    """
    if "adj" in kwargs:
        adjust_price = kwargs.pop("adj")

    unsupported_price_kwargs = {
        "adj_open",
        "adj_high",
        "adj_low",
        "adj_close",
        "adj_volume",
    }.intersection(kwargs)
    if unsupported_price_kwargs:
        names = ", ".join(sorted(unsupported_price_kwargs))
        raise ValueError(
            f"`data.indicator()` does not accept {names}; "
            "use `adjust_price=True` to calculate indicators with adjusted prices."
        )

    if not isinstance(adjust_price, bool):
        usage_str = f"data.indicator({indname}, adjust_price={adjust_price}, resample={resample}, **kwargs)"
        example_str = 'k, d = data.indicator("STOCH", adjust_price=True, resample="D", fastk_period=14, fastd_period=3)'
        raise ValueError(
            f"`adjust_price` must be a bool, e.g. `True`, `False`. Usage: {usage_str}, Example: {example_str}"
        )

    package, attr = _detect_indicator_package(indname)

    if "market" in kwargs:
        market_name = kwargs.pop("market")
        from finlab.markets import get_market_by_name

        config.set_market(get_market_by_name(market_name.lower()))

    market = config.get_market()

    close = market.get_price("close", adj=adjust_price)
    open_ = market.get_price("open", adj=adjust_price)
    high = market.get_price("high", adj=adjust_price)
    low = market.get_price("low", adj=adjust_price)
    volume = market.get_price("volume", adj=adjust_price)

    close, open_, high, low, volume = _align_price_shapes(
        close, open_, high, low, volume, indname, market
    )

    if resample.upper() != "D":
        close = close.resample(resample).last()
        open_ = open_.resample(resample).first()
        high = high.resample(resample).max()
        low = low.resample(resample).min()
        volume = volume.resample(resample).sum()

    dfs: dict[str, dict[str, Any]] = {}
    default_output_columns: list[str] | None = None
    for key in close.columns:
        prices = {
            "open": open_[key].ffill(),
            "high": high[key].ffill(),
            "low": low[key].ffill(),
            "close": close[key].ffill(),
            "volume": volume[key].ffill(),
        }

        if prices["close"].iloc[-1] != prices["close"].iloc[-1]:
            continue

        s = _compute_stock_indicator(package, attr, indname, prices, kwargs)

        if default_output_columns is None:
            default_output_columns = list(s)

        for colname, series in s.items():
            dfs.setdefault(colname, {})[key] = series

    newdic: dict[str, pd.DataFrame] = {}
    for key, df in dfs.items():
        newdic[key] = pd.DataFrame(df, index=close.index)

    if default_output_columns is None:
        return finlab.dataframe.FinlabDataFrame(pd.DataFrame(index=close.index))

    ret = [newdic[n] for n in default_output_columns]
    ret = [d.apply(lambda s: pd.to_numeric(s, errors="coerce")) for d in ret]

    if len(ret) == 1:
        return finlab.dataframe.FinlabDataFrame(ret[0])

    return tuple([finlab.dataframe.FinlabDataFrame(df) for df in ret])


indicator_dynamic = cast("Any", indicator)
indicator_dynamic.us_stock = lambda *args, **kwargs: indicator(
    *args, **{**kwargs, "market": "US_STOCK"}
)
indicator_dynamic.tw_stock = lambda *args, **kwargs: indicator(
    *args, **{**kwargs, "market": "TW_STOCK"}
)


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------


def get_strategies(api_token: str | None = None) -> dict[str, Any] | str:
    """取得已上傳量化平台的策略回傳資料。

    可取得自己策略儀表板上的數據，例如每個策略的報酬率曲線、報酬率統計、夏普率、近期部位、近期換股日...，
    這些數據可以用來進行多策略彙整的應用喔！


    Args:
        api_token (str): 若未帶入finlab模組的api_token，會自動跳出[GUI](https://ai.finlab.tw/api_token/)頁面，
                         複製網頁內的api_token貼至輸入欄位即可。
    Returns:
        (dict): strategies data
    Response detail:

        ``` py
        {
          strategy1:{
            'asset_type': '',
            'drawdown_details': {
               '2015-06-04': {
                 'End': '2015-11-03',
                 'Length': 152,
                 'drawdown': -0.19879090089478024
                 },
                 ...
              },
            'fee_ratio': 0.000475,
            'last_trading_date': '2022-06-10',
            'last_updated': 'Sun, 03 Jul 2022 12:02:27 GMT',
            'ndays_return': {
              '1': -0.01132480035770611,
              '10': -0.0014737286933147464,
              '20': -0.06658015749110646,
              '5': -0.002292995729485159,
              '60': -0.010108700314771735
              },
            'next_trading_date': '2022-06-10',
            'positions': {
              '1413 宏洲': {
                'entry_date': '2022-05-10',
                'entry_price': 10.05,
                'exit_date': '',
                'next_weight': 0.1,
                'return': -0.010945273631840613,
                'status': '買進',
                'weight': 0.1479332345384493
                },
              'last_updated': 'Sun, 03 Jul 2022 12:02:27 GMT',
              'next_trading_date': '2022-06-10',
              'trade_at': 'open',
              'update_date': '2022-06-10'
              },
            'return_table': {
              '2014': {
                'Apr': 0.0,
                'Aug': 0.06315180932606546,
                'Dec': 0.0537589857541485,
                'Feb': 0.0,
                'Jan': 0.0,
                'Jul': 0.02937490104459939,
                'Jun': 0.01367930162104769,
                'Mar': 0.0,
                'May': 0.0,
                'Nov': -0.0014734320286596825,
                'Oct': -0.045082529665408266,
                'Sep': 0.04630906972509852,
                'YTD': 0.16626214846456966
                },
                ...
              },
            'returns': {
              'time': [
                '2014-06-10',
                '2014-06-11',
                '2014-06-12',
                ...
                ],
              'value': [
                100,
                99.9,
                100.2,
                ...
                ]
              },
            'stats': {
              'avg_down_month': -0.03304015302646822,
              'avg_drawdown': -0.0238021414698247,
              'avg_drawdown_days': 19.77952755905512,
              'avg_up_month': 0.05293384465715908,
              'cagr': 0.33236021285588846,
              'calmar': 1.65261094975066,
              'daily_kurt': 4.008888367138843,
              'daily_mean': 0.3090784769257415,
              'daily_sharpe': 1.747909002374217,
              'daily_skew': -0.6966018726321078,
              'daily_sortino': 2.8300677082214034,
              ...
              },
            'tax_ratio': 0.003,
            'trade_at': 'open',
            'update_date': '2022-06-10'
            },
          strategy2:{...},
          ...}
        ```
    """
    token_type = "api_token"
    if api_token is None:
        token_result = finlab.get_token()
        if isinstance(token_result, tuple):
            api_token, token_type = token_result
        else:
            api_token = token_result

    request_args: dict[str, str] = {}
    if token_type == "id_token":
        request_args["id_token"] = api_token
    else:
        request_args["api_token"] = api_token

    url = "https://asia-east2-fdata-299302.cloudfunctions.net/auth_get_strategies"
    response = finlab.utils.requests.get(url, request_args, timeout=300)
    status_code = response.status_code
    if status_code in {400, 401}:
        logger.error(
            "The authentication code is wrong or the account is not existed. "
            "Please input right authentication code or register account."
        )
        return {}
    with contextlib.suppress(json.JSONDecodeError, ValueError):
        return json.loads(response.text)

    return response.text
