from __future__ import annotations

import copy
import logging
import operator
import random
import re
import sys
import traceback
from functools import lru_cache, reduce

__all__ = ["combine", "create_feature", "ta", "ta_names"]
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from collections.abc import Callable, Generator, Mapping, Sequence

import numpy as np
import pandas as pd
import talib
from talib import abstract

from finlab import config, data
from finlab.dataframe import FinlabDataFrame
from finlab.market import Market, MarketSharedMemory
from finlab.ml.utils import resampler


class IndicatorName:
    @staticmethod
    def encode(
        package_name: str, func: str, output: str, params: Mapping[str, Any]
    ) -> str:
        parts = [f"{package_name}.{func}", output]
        for k, v in params.items():
            parts.extend((str(k), str(v)))
        return "__".join(parts) + "__"

    @staticmethod
    def decode(encoded: str) -> tuple[str, str, dict[str, str]]:
        tokens = encoded.removesuffix("__").split("__")

        func = tokens[0].split(".")[-1]
        output = tokens[1]
        params = dict(zip(tokens[2:][::2], tokens[2:][1::2], strict=True))

        return func, output, params


class TalibIndicatorFactory:
    @staticmethod
    def set_dynamic_types(f: Any, params: Mapping[str, Any]) -> dict[str, Any]:
        ret: dict[str, Any] = {}
        for k, v in params.items():
            try:
                f.set_parameters(**{k: v})

            except (TypeError, ValueError) as ex:
                s = str(ex)
                regex = re.compile(r"expected\s([a-z]*),\s")
                match = regex.search(s)
                if match is None:
                    raise
                correct_type = match.group(1)
                v = {"int": int, "float": float}[correct_type](v)
                f.set_parameters(**{k: v})

            ret[k] = v

        return ret

    def calculate_indicator(
        self, func: str, output: str, params: dict[str, Any], adj: bool = False
    ) -> pd.DataFrame:
        market = config.get_market()
        func = func.split(".", maxsplit=1)[0]

        # get ith output
        f = getattr(abstract, func)
        org_params = copy.copy(f.parameters)
        org_params = self.set_dynamic_types(f, org_params)

        params = self.set_dynamic_types(f, params)
        f.set_parameters(org_params)
        target_i = -1
        for i, o in enumerate(f.output_names):
            if o == output:
                target_i = i
                break

        if target_i == -1:
            raise ValueError("Cannot find output names")

        # apply talib
        indicator = data.indicator(func, adjust_price=adj, **params)
        f.set_parameters(org_params)

        if isinstance(indicator, tuple):
            indicator = indicator[target_i]

        # normalize result
        if func in TalibIndicatorFactory.normalized_funcs():
            indicator /= market.get_price("close", adj=adj)

        return indicator

    @staticmethod
    def all_functions() -> list[str]:
        talib_categories = [
            "Cycle Indicators",
            "Momentum Indicators",
            "Overlap Studies",
            "Price Transform",
            "Statistic Functions",
            "Volatility Indicators",
        ]

        talib_functions: list[str] = reduce(
            operator.iadd,
            [talib.get_function_groups()[c] for c in talib_categories],
            [],
        )
        return ["talib." + f for f in talib_functions if f not in {"SAREXT", "MAVP"}]

    @staticmethod
    @lru_cache
    def normalized_funcs() -> list[str]:
        talib_normalized = (
            talib.get_function_groups()["Overlap Studies"]
            + talib.get_function_groups()["Price Transform"]
            + [
                "APO",
                "MACD",
                "MACDEXT",
                "MACDFIX",
                "MOM",
                "MINUS_DM",
                "PLUS_DM",
                "HT_PHASOR",
            ]
        )
        return list(talib_normalized)

    def generate_feature_names(self, func: str, lb: int, ub: int, n: int) -> list[str]:
        func = func.rsplit(".", maxsplit=1)[-1]

        if func == "MAMA":
            return []

        f = getattr(abstract, func)
        outputs = f.output_names
        org_params = f.parameters
        params_lb = {k: v * lb for k, v in org_params.items()}
        params_ub = {k: v * ub for k, v in org_params.items()}

        min_value = {
            "signalperiod": 2,
            "timeperiod": 2,
            "fastperiod": 2,
            "slowperiod": 2,
            "timeperiod1": 2,
            "timeperiod2": 2,
            "timeperiod3": 2,
            "fastk_period": 2,
            "fastd_period": 2,
            "slowk_period": 2,
            "slowd_period": 2,
            "vfactor": 0,
        }

        ret: list[str] = []
        for _ in range(n):
            new_params = {}
            for k, v in org_params.items():
                rvalue = (
                    np.random.random_sample(1)[0] * (params_ub[k] - params_lb[k])
                    + params_lb[k]
                )
                rvalue = type(v)(rvalue)
                new_params[k] = rvalue

            if "nbdevup" in new_params:
                new_params["nbdevup"] = 2.0
            if "nbdevdn" in new_params:
                new_params["nbdevdn"] = 2.0
            if "vfactor" in new_params:
                new_params["vfactor"] = float(random.uniform(0, 1))
            if "nbdev" in new_params:
                new_params["nbdev"] = 2.5

            for p, v in new_params.items():
                if p in min_value and v < min_value[p]:
                    new_params[p] = min_value[p]

            ret.extend(
                IndicatorName.encode("talib", func, o, new_params) for o in outputs
            )

        return list(dict.fromkeys(ret))


class Factory(Protocol):
    def __init__(self, market: Market | None) -> None:
        pass

    def all_functions(self) -> list[str]:
        return []

    def generate_feature_names(self, func: str, lb: int, ub: int, n: int) -> list[str]:
        return []

    def calculate_indicator(
        self, func: str, output: Sequence[str], params: Mapping[str, Any]
    ) -> pd.DataFrame:
        return pd.DataFrame()


def ta_names(
    lb: int = 1, ub: int = 10, n: int = 1, factory: Factory | None = None
) -> list[str]:
    """
    Generate a list of technical indicator feature names.

    Args:
        lb (int): The lower bound of the multiplier of the default parameter for the technical indicators.
        ub (int): The upper bound of the multiplier of the default parameter for the technical indicators.
        n (int): The number of random samples for each technical indicator.
        factory (IndicatorFactory): A factory object to generate technical indicators.
            Defaults to TalibIndicatorFactory.

    Returns:
        list[str]: A list of technical indicator feature names.

    Examples:
        ```py
        import finlab.ml.feature as f


        # method 1: generate each indicator with random parameters
        features = f.ta()

        # method 2: generate specific indicator
        feature_names = ['talib.MACD__macdhist__fastperiod__52__slowperiod__212__signalperiod__75__']
        features = f.ta(feature_names, resample='W')

        # method 3: generate some indicator
        feature_names = f.ta_names()
        features = f.ta(feature_names)
        ```
    """

    _factory = factory or TalibIndicatorFactory()
    return reduce(
        operator.iadd,
        [
            _factory.generate_feature_names(f, lb, ub, n)
            for f in _factory.all_functions()
        ],
        [],
    )


def create_feature(params: tuple[Any, ...]) -> tuple[str, np.ndarray] | None:
    name, factories, resample, _end_time, adj, kwargs = params[:6]
    config.get_market()
    market = MarketSharedMemory.from_args(*params[6:])
    config.set_market(market)
    func, output, indicator_params = IndicatorName.decode(name)

    factory = factories[name.split(".")[0]]
    try:
        f = resampler(
            factory.calculate_indicator(func, output, indicator_params, adj=adj),
            resample,
            **kwargs,
        ).T.unstack()
        return name, np.array(f.values)

    except (KeyError, ValueError, TypeError, RuntimeError):
        traceback.print_exc(file=sys.stdout)
        logging.warning(
            f"Cannot calculate indicator {(func, output, indicator_params)}. Skipped"
        )
        logging.warning(f"Exception occurred: {traceback.format_exc()}")
    return None


def _create_features_single(
    feature_names: list[str],
    factories: dict[str, TalibIndicatorFactory],
    resample: str | None,
    adj: bool,
    **kwargs: Any,
) -> Generator[tuple[str, np.ndarray], None, None]:
    """Yield (name, values) for each indicator computed in single-process mode."""
    for name in feature_names:
        func, output, params = IndicatorName.decode(name)
        factory = factories[name.split(".")[0]]
        values = resampler(
            factory.calculate_indicator(func, output, params, adj=adj),
            resample,
            **kwargs,
        ).T.unstack()
        if values is not None:
            yield name, values


def _create_features_multi(
    feature_names: list[str],
    factories: dict[str, TalibIndicatorFactory],
    resample: str | None,
    end_time: str | None,
    adj: bool,
    cpu: int,
    market: MarketSharedMemory,
    kwargs: dict[str, Any],
) -> Generator[tuple[str, np.ndarray], None, None]:
    """Yield (name, values) for each indicator computed in multi-process mode."""
    import multiprocessing

    with multiprocessing.Pool(processes=cpu) as pool:
        for result in pool.imap_unordered(
            create_feature,
            [
                (
                    name,
                    factories,
                    resample,
                    end_time,
                    adj,
                    kwargs,
                    *(market.to_args(),),
                )
                for name in feature_names
            ],
        ):
            if result is not None:
                yield result


def _resolve_cpu(cpu: int) -> int:
    """Resolve cpu=-1 to actual core count."""
    if cpu == -1:
        import multiprocessing

        return multiprocessing.cpu_count()
    return cpu


def ta(
    feature_names: list[str] | None,
    factories: dict[str, TalibIndicatorFactory] | None = None,
    resample: str | None = None,
    start_time: str | None = None,
    end_time: str | None = None,
    adj: bool = False,
    cpu: int = -1,
    **kwargs: Any,
) -> pd.DataFrame:
    """Calculate technical indicator values for a list of feature names.

    Args:
        feature_names (list[str] | None): A list of technical indicator feature names. Defaults to None.
        factories (dict[str, TalibIndicatorFactory] | None): A dictionary of factories to generate technical indicators. Defaults to {"talib": TalibIndicatorFactory()}.
        resample (str | None): The frequency to resample the data to. Defaults to None.
        start_time (str | None): The start time of the data. Defaults to None.
        end_time (str | None): The end time of the data. Defaults to None.
        **kwargs: Additional keyword arguments to pass to the resampler function.

    Returns:
        pd.DataFrame: technical indicator feature names and their corresponding values.
    """

    if factories is None:
        factories = {"talib": TalibIndicatorFactory()}

    if feature_names is None:
        feature_names = ta_names()

    cpu = _resolve_cpu(cpu)
    org_market = config.get_market()

    if cpu != 1:
        market = MarketSharedMemory(
            config.get_market(), adj=adj, start_time=start_time, end_time=end_time
        )
        config.set_market(market)

    test_f = resampler(
        TalibIndicatorFactory().calculate_indicator("RSI", "real", {}, adj=adj),
        resample,
        **kwargs,
    ).T.unstack()

    final_columns: list[str] = []

    if cpu == 1:
        results = _create_features_single(
            feature_names, factories, resample, adj, **kwargs
        )
    else:
        results = _create_features_multi(
            feature_names, factories, resample, end_time, adj, cpu, market, kwargs
        )

    def collect_results() -> Generator[np.ndarray, None, None]:
        for name, values in results:
            final_columns.append(name)
            yield values

    values = np.fromiter(collect_results(), dtype=np.dtype((np.float64, len(test_f))))

    if cpu != 1:
        market.close()

    config.set_market(org_market)

    final_names = set(final_columns)
    ordered_names = [n for n in feature_names if n in final_names]

    ret = pd.DataFrame(values.T, index=test_f.index, columns=final_columns, copy=False)

    ret.index.names = ["datetime", "instrument"]
    return ret[ordered_names]


def _partition_features(
    features: dict[str, pd.DataFrame | Callable[[], pd.DataFrame]],
    resample_fn: Callable[[pd.DataFrame], pd.DataFrame],
) -> tuple[
    dict[str, pd.DataFrame], list[pd.DataFrame], pd.Index | None, pd.Index | None
]:
    """Partition features into wide (single-index) and multi-index groups.

    Returns (wide_dfs, multi_index_dfs, union_index, union_columns).
    """
    union_index: pd.Index | None = None
    union_columns: pd.Index | None = None
    wide: dict[str, pd.DataFrame] = {}
    multi: list[pd.DataFrame] = []

    for name, df in features.items():
        if callable(df):
            df = df()

        if isinstance(df.index, pd.MultiIndex):
            multi.append(resample_fn(df))
            continue

        if isinstance(df, FinlabDataFrame):
            df = df.index_str_to_date()

        udf = resample_fn(df)
        wide[name] = udf
        union_index = udf.index if union_index is None else union_index.union(udf.index)
        union_columns = (
            udf.columns
            if union_columns is None
            else union_columns.intersection(udf.columns)
        )

    return wide, multi, union_index, union_columns


def _apply_sample_filter(
    ret: pd.DataFrame,
    sample_filter: pd.DataFrame,
    resample_fn: Callable[[pd.DataFrame], pd.DataFrame],
    union_index: pd.Index | None,
    union_columns: pd.Index | None,
) -> pd.DataFrame:
    """Apply a boolean sample filter to the combined DataFrame."""
    if isinstance(sample_filter, FinlabDataFrame):
        sample_filter = sample_filter.index_str_to_date()
    usf = resample_fn(sample_filter)

    if union_index is not None and union_columns is not None:
        usf = usf.reindex(index=union_index, columns=union_columns)

    usf = usf.ffill().T.unstack().reindex(ret.index).astype(bool).fillna(False)
    return ret.loc[usf.values]


def combine(
    features: dict[str, pd.DataFrame | Callable[[], pd.DataFrame]],
    resample: str | pd.DatetimeIndex | None = None,
    sample_filter: pd.DataFrame | None = None,
    **kwargs: Any,
) -> pd.DataFrame:
    """The combine function takes a dictionary of features as input and combines them into a single pandas DataFrame. combine 函數接受一個特徵字典作為輸入，並將它們合併成一個 pandas DataFrame。

    Args:
        features (dict[str, pd.DataFrame | Callable]): a dictionary where values
            are dataframes or callables returning dataframes. 索引為日期時間，欄位
            為證券代碼的 DataFrame，或可呼叫以取得 DataFrame 的函式。
        resample (str | pd.DatetimeIndex): Optional argument to resample the data in the features. Default is None. 選擇性的參數，用於重新取樣特徵中的資料。預設為 None。
            MultiIndex features use the same resampling as wide features. String
            frequencies use calendar period labels (e.g. Sunday for 'W'). Pass a
            DatetimeIndex for explicit trading-date anchors. MultiIndex 與寬表
            共用重採樣方式；字串週頻標在週日，實際交易日錨點可用指定日期。
        sample_filter (pd.DataFrame): a boolean dictionary where index is date and columns are instrument representing the filter of features.
        **kwargs: Additional keyword arguments to pass to the resampler function. 傳遞給重新取樣函數 resampler 的其他關鍵字引數。

    Returns:
        A pandas DataFrame containing all the input features combined. 一個包含所有輸入特徵合併後的 pandas DataFrame。

    Examples:
        這段程式碼教我們如何使用finlab.ml.feature和finlab.data模組，來合併兩個特徵：RSI和股價淨值比。我們使用f.combine函數來進行合併，其中特徵的名稱是字典的鍵，對應的資料是值。
        我們從data.indicator('RSI')取得'rsi'特徵，這個函數計算相對強弱指數。我們從data.get('price_earning_ratio:股價淨值比')取得'pb'特徵，這個函數獲取股價淨值比。最後，我們得到一個包含這兩個特徵的DataFrame。

        ``` py
        from finlab import data
        import finlab.ml.feature as f
        import finlab.ml.qlib as q

        features = f.combine({

            # 用 data.get 簡單產生出技術指標
            'pb': data.get('price_earning_ratio:股價淨值比'),

            # 用 data.indicator 產生技術指標的特徵
            'rsi': data.indicator('RSI'),

            # 用 f.ta 枚舉超多種 talib 指標
            'talib': f.ta(f.ta_names()),

            # 利用 qlib alph158 產生技術指標的特徵(請先執行 q.init(), q.dump() 才能使用)
            'qlib158': q.alpha('Alpha158')

            })

        features.head()
        ```

        |    datetime   | instrument |     rsi    |     pb     |
        |---------------|------------|------------|------------|
        |   2020-01-01  |    1101    |     0      |     2      |
        |   2020-01-02  |    1102    |     100    |     3      |
        |   2020-01-03  |    1108    |     100    |     4      |

        以每週最後交易日為錨點，特徵與未來兩期報酬使用同一組日期：

        ``` py
        import pandas as pd
        from finlab.ml import label
        f158 = q.alpha('Alpha158')
        calendar = f158.index.get_level_values('datetime').unique().sort_values()
        weekly = pd.DatetimeIndex(calendar.to_series().resample('W').last().dropna())
        features = f.combine({'qlib158': f158}, resample=weekly)
        labels = label.return_percentage(features.index, resample=weekly, period=2)
        ```

    """

    if not features:
        return pd.DataFrame()

    def resample_fn(df: pd.DataFrame) -> pd.DataFrame:
        return resampler(df, resample, **kwargs)

    wide, concats, union_index, union_columns = _partition_features(
        features, resample_fn
    )

    final_index = None
    unstacked: dict[str, np.ndarray] = {}
    for name, udf in wide.items():
        udf = udf.reindex(index=union_index, columns=union_columns).ffill().T.unstack()
        unstacked[name] = udf.values
        if final_index is None:
            final_index = udf.index

    for i, c in enumerate(concats):
        c.index = c.index.set_names(["datetime", "instrument"])
        if union_index is not None:
            concats[i] = c[c.index.get_level_values("datetime").isin(union_index)]

    if unstacked:
        unstack_df = pd.DataFrame(unstacked, index=final_index)
        unstack_df.index = unstack_df.index.set_names(["datetime", "instrument"])
        concats.append(unstack_df)

    ret = pd.concat(concats, axis=1)
    ret.sort_index(inplace=True)

    if sample_filter is not None:
        ret = _apply_sample_filter(
            ret, sample_filter, resample_fn, union_index, union_columns
        )

    return ret
