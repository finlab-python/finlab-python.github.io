# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
from finlab.ml._qlib import _SINGLE_THREAD_OPENMP

try:
    from .catboost_model import CatBoostModel
except ModuleNotFoundError:
    CatBoostModel = None
    print(
        "ModuleNotFoundError. CatBoostModel are skipped. (optional: maybe installing CatBoostModel can fix it.)"
    )
try:
    from .double_ensemble import DEnsembleModel
    from .gbdt import LGBModel
except ModuleNotFoundError:
    DEnsembleModel, LGBModel = None, None
    print(
        "ModuleNotFoundError. DEnsembleModel and LGBModel are skipped. (optional: maybe installing lightgbm can fix it.)"
    )
try:
    from .xgboost import XGBModel
except ModuleNotFoundError:
    XGBModel = None
    print(
        "ModuleNotFoundError. XGBModel is skipped(optional: maybe installing xgboost can fix it)."
    )
try:
    from .linear import LinearModel
except ModuleNotFoundError:
    LinearModel = None
    print(
        "ModuleNotFoundError. LinearModel is skipped(optional: maybe installing scipy and sklearn can fix it)."
    )
# import pytorch models
try:
    from .pytorch_alstm import ALSTM
    from .pytorch_lstm import LSTM
    from .pytorch_nn import DNNModelPytorch
    from .pytorch_sfm import SFM_Model
    from .pytorch_tabnet import TabnetModel
    from .pytorch_tcn import TCN

    pytorch_classes = (
        ALSTM,
        LSTM,
        DNNModelPytorch,
        TabnetModel,
        SFM_Model,
        TCN,
    )
except ModuleNotFoundError as e:
    pytorch_classes = ()
    print(f"PyTorch models are skipped: missing dependency {e.name!r}.")
else:
    # These optional upstream models need pyqlib as well as torch. Their absence
    # must not hide the bundled DNN, TabNet and SFM models.
    try:
        from .pytorch_add import ADD
        from .pytorch_gats import GATs
        from .pytorch_gru import GRU

        pytorch_classes += (ADD, GATs, GRU)
    except ModuleNotFoundError as e:
        print(
            f"Optional ADD/GATs/GRU models are skipped: missing dependency {e.name!r}."
        )

# Also limit runtimes already initialized by earlier sklearn/torch imports.
if _SINGLE_THREAD_OPENMP:
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=1, user_api="openmp")

all_model_classes = (
    CatBoostModel,
    DEnsembleModel,
    LGBModel,
    XGBModel,
    LinearModel,
    *pytorch_classes,
)
