"""Shared fetch pipeline plus ``data.get()`` single-dataset wrapper."""

from __future__ import annotations

import asyncio
import datetime
import errno
import functools
import gc
import hashlib
import importlib.util
import logging
import os
import sys
import threading
import time
import warnings
import weakref
from collections import OrderedDict
from collections.abc import Callable, Iterator
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, NamedTuple, TypeAlias, cast

import pandas as pd
import pyarrow as pa

import finlab.dataframe
import finlab.utils
from finlab.data import feather_io

from . import universe as universe_module

# Re-exports for backward compat: data.py imports these from get.py
from .auth import (
    _AUTH_ERRORS,  # noqa: F401
    _AUTH_URL,
    _DEFAULT_HEADERS,
    FetchMetadata,
    MetadataRequestMap,
    MetadataResultMap,
    SignedDownloadError,
    _dataset_to_blob,  # noqa: F401
    _download_dataframe,
    _is_pyodide_stack_switch_error,
    _refresh_id_token,  # noqa: F401
    _resolve_auth_params,  # noqa: F401
    _resolve_pyodide_run_sync,
    fetch_metadata_batch,
)
from .context import FREE_ROLE, _default_context
from .freshness import (
    is_tradable,
    next_future_expiry,
    suggested_tradable_time,
)
from .market import _resolve_dataset
from .missing import (
    dataset_not_found_error,
    equivalent_key_alias,
    is_not_found_error,
    redirect_warning_message,
)
from .progress import DownloadProgress, ProgressEvent, ProgressMode
from .readiness import record_publication
from .recent_merge import HASH_HEXDIGEST_PREFIX
from .recent_merge import merge_recent_df as _merge_recent_df
from .revisions import (
    Correction,
    Published,
    confirm,
    correction,
    published,
    published_delta,
)
from .storage import CacheStorage, FileStorage, LocalDataReadError, StorageBackend
from .table_delta import DELTA_SUFFIX, TableDelta, merge_table_delta_frame
from .tiers import holds_signed_blob, offered_storage, storage_for_role
from .transform import (
    FISCAL_TABLE_POSTFIX,
    TABLE_INDEX_TRANSFORMERS,  # noqa: F401
    _apply_truncate_if_any,
    _mask_undisclosed_quarterly,  # noqa: F401
    _normalize_stock_columns,  # noqa: F401
    _set_dataframe_index,  # noqa: F401
    _should_mask_quarterly,
    has_index_name,  # noqa: F401
    process_data,
)

if TYPE_CHECKING:
    from .catalog import KeyAlias
    from .context import DataContext

logger = logging.getLogger(__name__)
_finalize_context_lock = threading.RLock()

MetadataFetcher = Callable[
    [
        MetadataRequestMap,
    ],
    MetadataResultMap,
]

DownloadedFrame: TypeAlias = tuple[pd.DataFrame, bytes | None]
"""``(df, raw_feather_bytes)`` — bytes is None when payload was inlined."""

_MAX_PARALLEL_DOWNLOADS = 8
_MAX_DOWNLOAD_WORKERS_ENV = "FINLAB_MAX_DOWNLOAD_WORKERS"

# Routine reasons to replace a ``.recent`` or table delta update with a full
# download, handled silently as before #232: schema drift such as a wide table
# gaining or renaming a stock column (``KeyError``), cached types that cannot hold
# the delta (``ArrowInvalid`` is a ``ValueError``), or a cache file removed meanwhile.
_UPDATE_FALLBACK_ERRORS = (FileNotFoundError, KeyError, ValueError, TypeError)
# A full download writes the same cache directory, so after these write failures
# falling back would only download the dataset before failing again: no space
# left, disk quota exceeded, read-only file system. EACCES and EPERM stay out:
# the merge also raises them when reading an unreadable cache file, which a full
# download can still replace.
_UNWRITABLE_CACHE_ERRNOS = frozenset({errno.ENOSPC, errno.EDQUOT, errno.EROFS})


def _max_download_workers() -> int:
    """Read the download thread limit from ``FINLAB_MAX_DOWNLOAD_WORKERS``."""
    setting = os.environ.get(_MAX_DOWNLOAD_WORKERS_ENV)
    if setting is None:
        return _MAX_PARALLEL_DOWNLOADS
    try:
        workers = int(setting)
    except ValueError:
        workers = 0
    if workers <= 0:
        raise ValueError(f"{_MAX_DOWNLOAD_WORKERS_ENV} must be a positive integer")
    return workers


def _run_parallel_tasks(keys: list, worker: Callable) -> Iterator[tuple]:
    """Run *worker(key)* over *keys*, yielding ``(key, result)`` as workers complete.

    Falls back to in-thread execution when only one task is queued, so a single
    stale dataset doesn't pay the ThreadPoolExecutor setup cost. Also serializes
    in pyodide because workers may call into the single Python event loop via
    ``run_sync``, which would deadlock under concurrent threads.
    """
    n_workers = min(_max_download_workers(), len(keys))
    if n_workers <= 1 or "pyodide" in sys.modules:
        for key in keys:
            yield key, worker(key)
        return
    with ThreadPoolExecutor(max_workers=n_workers) as executor:
        futures = {executor.submit(worker, key): key for key in keys}
        for future in as_completed(futures):
            yield futures[future], future.result()


__all__ = [
    "get",
    "get_role",
    "is_tradable",
    "is_vip",
    "next_future_expiry",
    "process_data",
    "suggested_tradable_time",
]


# ---------------------------------------------------------------------------
# Finalize / cache pipeline
# ---------------------------------------------------------------------------


def _warn_local_cache_read_error(dataset: str, error: LocalDataReadError) -> None:
    logger.warning(
        "%s local cache is unreadable; falling back to cloud download. Path: %s",
        dataset,
        error.file_path,
        exc_info=True,
    )


def _full_download_would_fail(error: Exception) -> bool:
    # A full download needs at least the memory the merge ran out of.
    return isinstance(error, MemoryError) or (
        isinstance(error, OSError) and error.errno in _UNWRITABLE_CACHE_ERRNOS
    )


def _debug_update_fallback(
    kind: str, step: str, dataset: str, error: Exception
) -> None:
    # Routine, so debug only. Like the warning below, only the error type is
    # logged because messages may carry the signed URL.
    logger.debug(
        "Failed to %s %s data for %s (%s)", step, kind, dataset, type(error).__name__
    )


def _warn_merge_failed(kind: str, dataset: str, error: Exception) -> None:
    # One line for users, the traceback only at debug level. The metadata result
    # carries the signed URL, so only the error type and versions are logged.
    logger.warning(
        "%s %s merge failed with %s; falling back to full download (pyarrow %s, pandas %s)",
        dataset,
        kind,
        type(error).__name__,
        pa.__version__,
        pd.__version__,
    )
    logger.debug("%s %s merge traceback", dataset, kind, exc_info=error)


def _finalize(dataset: str, df: pd.DataFrame, *, cache: bool = True) -> pd.DataFrame:
    with _finalize_context_lock:
        ctx = _default_context
        if ctx.truncate_start is not None or ctx.truncate_end is not None:
            ctx._projected_datasets.add(dataset)
        filtering = not universe_module._membership_read.get()
        cache_key = (
            dataset,
            id(ctx._storage),
            id(df),
            (
                frozenset(universe_module.universe_stocks)
                if universe_module.universe_stocks and filtering
                else None
            ),
            universe_module._whitelist_active and filtering,
            ctx.truncate_start,
            ctx.truncate_end,
        )
        if cache:
            # Keyed by id(df), which a freed frame hands on to its successor.
            entry = ctx._finalized_cache.get(cache_key)
            if entry is not None and entry[0]() is df:
                return entry[1]
        source = weakref.ref(df)

        table_name = dataset.split(":", maxsplit=1)[0]
        skip_end = _should_mask_quarterly(table_name, ctx.truncate_end)
        if table_name not in FISCAL_TABLE_POSTFIX:
            df = _apply_truncate_if_any(df, skip_end=skip_end)

        if not isinstance(df, finlab.dataframe.FinlabDataFrame):
            df = finlab.dataframe.FinlabDataFrame(df)
        result = universe_module.refine_stock_id(dataset, df)
        if cache:
            ctx._finalized_cache[cache_key] = (source, result)
        return result


def hash(df: pd.DataFrame) -> str:
    return hashlib.md5(pd.util.hash_pandas_object(df, index=True).values).hexdigest()[
        :HASH_HEXDIGEST_PREFIX
    ]


def _base_route(revision: float, entry: Published) -> str:
    """Route a cache dated *revision* against the published base *entry*."""
    if revision >= entry.revision:
        return "current"
    return "recent" if revision >= entry.full_refresh_before else "full"


def _delta_route(revision: float, delta: Published) -> str | None:
    """Route a cache dated *revision* against a table *delta*; None when it is too old."""
    if revision >= delta.revision:
        return "current"
    return "delta" if revision >= delta.full_refresh_before else None


def _cache_route(dataset: str, has_rows: bool) -> tuple[str, Published | None]:
    """Route a local cache: ``"current"``, update via ``"delta"`` or ``"recent"``,
    or ``"full"`` download.

    Also returns the published entry the route was decided on: the latest one
    for a current cache, else the base entry whose revision a base download
    stamps on the cache. Callers that only have cheap metadata (e.g. a
    date-range read that must avoid a full load) share this exact policy.
    """
    ctx = _default_context
    checked = ctx._backtest_cache_versions
    checked_in_backtest = (
        checked is not None
        and (id(ctx._storage), dataset) in checked
        and checked[id(ctx._storage), dataset] == ctx._storage.cache_version(dataset)
    )
    if has_rows and (
        ctx.prefer_local_if_exists or ctx.use_local_data_only or checked_in_backtest
    ):
        # Never goes online; an index already read still dates the version used.
        base = published(dataset, refresh=False)
        entry = published_delta(dataset, base) or base
        current = entry is not None and _cache_revision(dataset) >= entry.revision
        return "current", entry if current else None
    if ctx._role == FREE_ROLE:
        # Neither the paid index nor a .recent reply dates a free cache, and the
        # account may have upgraded: offer the cache on the full blob instead.
        return "full", None
    entry = published(dataset)
    if not has_rows:
        return "full", entry
    if entry is None:
        return "recent", None
    revision = _cache_revision(dataset)
    delta = published_delta(dataset, entry)
    route = None if delta is None else _delta_route(revision, delta)
    if route == "current":
        return route, delta
    # Older than the delta reaches: sync with the base, which the delta then extends.
    return route or _base_route(revision, entry), entry


def _warn_corrected(dataset: str, changed: Correction) -> None:
    def utc(epoch: float) -> datetime.datetime:
        return datetime.datetime.fromtimestamp(epoch, datetime.timezone.utc)

    as_of = utc(changed.cutoff) - datetime.timedelta(microseconds=1)
    hint = (
        "請用 data.get('financial_statement_versions') 查詢保留的歷史版本。"
        if dataset.split(":", 1)[0] == "financial_statement"
        else f"若舊版本仍保留，可用 data.get({dataset!r}, as_of={as_of.isoformat()!r}) 查看修正前版本。"
    )
    logger.warning(
        "%s 資料曾在排程外更新（%s），歷史值與回測結果可能改變。異常紀錄："
        "https://studio.finlab.finance/support；%s",
        dataset,
        utc(changed.corrected_at).isoformat(),
        hint,
    )


def _cache_revision(dataset: str) -> float:
    created = _default_context._storage.get_time_created(dataset)
    return created.timestamp() if created else 0.0


def _stamping(
    fetcher: MetadataFetcher, entries: dict[str, Published]
) -> MetadataFetcher:
    """Wrap *fetcher* so each result carries the revision its download stamps."""

    def fetch(request_map: MetadataRequestMap) -> MetadataResultMap:
        results = fetcher(request_map)
        for key, result in results.items():
            entry = entries.get(key.removesuffix(".recent"))
            if result is not None and entry is not None:
                result.revision = datetime.datetime.fromtimestamp(
                    entry.revision, datetime.timezone.utc
                )
        return results

    return fetch


def _confirm_unindexed(synced: list[str], entries: dict[str, Published]) -> None:
    """Keep synced caches the index cannot vouch for current until the next check."""
    for dataset in synced:
        if dataset not in entries:
            confirm(dataset, _cache_revision(dataset))


def _mark_loaded(dataset: str, entry: Published | None) -> None:
    """Mark *dataset* loaded, recording the cache version read and its published expiry.

    Readiness evidence binds to that version, not to whatever replaces the cache
    later. An unknown expiry counts as due at load time, as for an expired cache,
    so freshness checks fail closed; it keeps a known one only for the same version.
    """
    ctx = _default_context
    ctx._loaded_datasets.add(dataset)
    version = ctx._storage.cache_version(dataset)
    if ctx._backtest_cache_versions is not None:
        ctx._backtest_cache_versions[id(ctx._storage), dataset] = version
    if entry is not None and entry.expiry is not None:
        ctx._loaded_versions[dataset] = (version, entry.expiry)
        ctx._storage._published_expiries[dataset] = (version, entry.expiry)
    elif ctx._loaded_versions.get(dataset, (None,))[0] != version:
        ctx._loaded_versions[dataset] = (version, int(time.time()))


def _prepare_fetch(
    datasets: list[str],
    force_download: bool,
) -> tuple[DataContext, list[str], StorageBackend, bool]:
    """Apply shared preflight checks and resolve dataset aliases."""
    if not datasets:
        raise ValueError("at least one dataset name required")

    finlab.utils.check_version()
    ctx = _default_context
    force_download |= ctx.force_cloud_download

    if ctx.use_local_data_only and force_download:
        raise ValueError(
            "data.use_local_data_only and data.force_download cannot be both True"
        )

    resolved = [_resolve_dataset(dataset) for dataset in datasets]
    return ctx, resolved, ctx._storage, force_download


@dataclass
class _Partition:
    """How one fetch routes its datasets, and the published entries it decided on.

    ``deltas`` holds the table deltas of the datasets still to update.
    """

    cache_hits: dict[str, pd.DataFrame] = field(default_factory=dict)
    recent_candidates: list[str] = field(default_factory=list)
    delta_candidates: list[str] = field(default_factory=list)
    cache_misses: list[str] = field(default_factory=list)
    local_frames: dict[str, pd.DataFrame | None] = field(default_factory=dict)
    entries: dict[str, Published] = field(default_factory=dict)
    deltas: dict[str, Published] = field(default_factory=dict)

    def queue(self, dataset: str, route: str) -> None:
        """Queue *dataset* for its ``"recent"``, ``"delta"`` or ``"full"`` update."""
        queues = {
            "recent": self.recent_candidates,
            "delta": self.delta_candidates,
            "full": self.cache_misses,
        }
        queues[route].append(dataset)

    def loaded_entries(self) -> dict[str, Published]:
        """The published entry of the version each cache now holds."""
        return {
            **self.entries,
            **{
                dataset: delta
                for dataset, delta in self.deltas.items()
                if _delta_route(_cache_revision(dataset), delta) == "current"
            },
        }


def _partition_datasets(
    resolved: list[str],
    storage: StorageBackend,
    force_download: bool,
    use_local_only: bool,
) -> _Partition:
    """Split datasets into local hits, recent and delta candidates, and full misses."""
    split = _Partition()
    for dataset in resolved:
        df = None
        if not force_download:
            try:
                df = storage.get_dataframe(dataset)
            except LocalDataReadError as exc:
                if use_local_only:
                    raise
                _warn_local_cache_read_error(dataset, exc)
        split.local_frames[dataset] = df
        has_rows = df is not None and not df.empty

        if use_local_only and not has_rows:
            raise FileNotFoundError(
                f"**Error: {dataset} not in local storage. "
                "Set data.use_local_data_only = False to download."
            )

        route, entry = _cache_route(dataset, has_rows)
        if entry is not None:
            split.entries[dataset] = entry
        if route == "current":
            split.cache_hits[dataset] = _finalize(dataset, df)
            continue
        changed = correction(dataset) if entry is not None else None
        if changed is not None and _cache_revision(dataset) < changed.corrected_at:
            _warn_corrected(dataset, changed)
        delta = published_delta(dataset, entry)
        if delta is not None:
            split.deltas[dataset] = delta
        split.queue(dataset, route)
    return split


def _download_result_dataframe(
    result: FetchMetadata | None,
    dataset: str,
    on_progress: Callable[[int, int], None] | None = None,
) -> tuple[pd.DataFrame, bytes | None]:
    """Return ``(df, raw_feather_bytes)`` from a remote fetch result.

    ``raw_feather_bytes`` is ``None`` when the payload was inlined into the
    metadata response, since no wire bytes were ever produced.
    """
    if result is None:
        raise FileNotFoundError(f"**Error: {dataset} not exists")
    if result.data is not None:
        if on_progress is not None:
            on_progress(1, 1)
        return result.data, None

    url = result.url
    if not url:
        raise FileNotFoundError(f"**Error: {dataset} not exists")

    try:
        return _download_dataframe(url, _DEFAULT_HEADERS, on_progress=on_progress)
    except SignedDownloadError as exc:
        if exc.status not in {404, 412}:
            raise exc.for_dataset(dataset) from None
        try:
            replacement = fetch_metadata_batch(OrderedDict([(dataset, None)])).get(
                dataset
            )
        except SignedDownloadError as resign_exc:
            resign_exc.for_dataset(dataset)
            raise
        if replacement is None or not replacement.url or replacement.error:
            raise exc.for_dataset(dataset) from None
        result.url, result.hash, result.publication, result.time_created = (
            replacement.url,
            replacement.hash,
            replacement.publication,
            replacement.time_created,
        )
    try:
        return _download_dataframe(
            result.url, _DEFAULT_HEADERS, on_progress=on_progress
        )
    except SignedDownloadError as exc:
        raise exc.for_dataset(dataset) from None


def _build_progress_callback(
    progress: DownloadProgress,
    dataset: str,
) -> tuple[Callable[[int, int], None], Callable[[], int]]:
    """Build per-dataset byte progress callback and final-size accessor."""
    state: dict[str, int] = {"downloaded": 0, "total": 0}

    def _on_progress(downloaded: int, total: int) -> None:
        total_effective = total if total > 0 else max(downloaded, 1)
        state["downloaded"] = downloaded
        state["total"] = total_effective
        progress.update(dataset, downloaded, total_effective)

    def _final_bytes() -> int:
        return state["total"] or state["downloaded"] or 1

    return _on_progress, _final_bytes


def _estimate_dataframe_bytes(df: pd.DataFrame) -> int:
    """Estimate display size for a downloaded dataframe."""
    try:
        return max(int(df.memory_usage(deep=True).sum()), 1)
    except (TypeError, ValueError):
        return 1


def _download_update(
    dataset: str,
    suffix: str,
    result: FetchMetadata,
    progress: DownloadProgress | None,
) -> tuple[pd.DataFrame, bytes | None, int | None]:
    """Download *dataset*'s ``.recent`` or delta payload: ``(df, raw_bytes, display_nbytes)``."""
    if progress is None:
        df, raw = _download_result_dataframe(result, f"{dataset}{suffix}")
        return df, raw, None

    on_progress, final_bytes = _build_progress_callback(progress, dataset)
    df, raw = _download_result_dataframe(
        result,
        f"{dataset}{suffix}",
        on_progress=on_progress,
    )
    nbytes = final_bytes()
    if nbytes <= 1:
        nbytes = _estimate_dataframe_bytes(df)
    return df, raw, nbytes


def _download_recent_delta(
    dataset: str,
    result: FetchMetadata,
    progress: DownloadProgress | None,
) -> tuple[pd.DataFrame, int | None]:
    """Download one ``.recent`` payload with optional progress updates."""
    short_df, _, nbytes = _download_update(dataset, ".recent", result, progress)
    return short_df, nbytes


def _refresh_cached(
    dataset: str,
    df: pd.DataFrame,
    result: FetchMetadata,
    storage: StorageBackend,
    progress: DownloadProgress | None,
) -> pd.DataFrame:
    """Keep the cached bytes after a metadata-only reply (nothing newer to download).

    A newer published revision then only refreshed publication metadata: the
    index sends a full table rewritten without its update straight to a full
    download, so these cached bytes are still the published ones.
    """
    if result.revision is not None:
        storage.set_revision(dataset, result.revision)
    if progress is not None:
        progress.mark_cached(dataset)
    record_publication(storage, dataset, result, df)
    return _finalize(dataset, df)


def _resolve_recent_hit(
    dataset: str,
    df: pd.DataFrame,
    result: FetchMetadata,
    storage: StorageBackend,
    progress: DownloadProgress | None,
) -> pd.DataFrame | None:
    """Return finalized dataframe when recent-merge succeeds, else ``None``."""
    if result.error:
        logger.debug("Recent metadata error for %s: %s", dataset, result.error)
        return None

    # A metadata-only payload means .recent has nothing newer than the cache.
    if not result.signed:
        return _refresh_cached(dataset, df, result, storage, progress)

    try:
        short_df, recent_nbytes = _download_recent_delta(dataset, result, progress)
    except SignedDownloadError:
        logger.debug("Failed to download recent delta for %s", dataset)
        raise
    except _UPDATE_FALLBACK_ERRORS as error:
        _debug_update_fallback("recent", "download", dataset, error)
        return None

    merged_df = _merge_or_fall_back(
        "recent",
        dataset,
        lambda: _persist_recent_merge(dataset, df, short_df, result, storage),
    )
    if merged_df is None or merged_df.empty:
        return None

    if progress is not None and recent_nbytes is not None:
        progress.complete(dataset, recent_nbytes)
    logger.debug("get recent, is valid -> and merge recent to local data")
    record_publication(storage, dataset, result, verified=True)
    return _finalize(dataset, merged_df)


def _merge_or_fall_back(
    kind: str, dataset: str, merge: Callable[[], pd.DataFrame | None]
) -> pd.DataFrame | None:
    """Run a ``.recent`` or delta *merge*; ``None`` asks for a full download instead."""
    try:
        return merge()
    except _UPDATE_FALLBACK_ERRORS as error:
        _debug_update_fallback(kind, "merge", dataset, error)
    except Exception as error:
        # data.get() must not fail on a merge bug (#232). The cache is only ever
        # replaced atomically by a hash-verified file, so a failed merge leaves a
        # valid cache for the full download to overwrite.
        if _full_download_would_fail(error):
            raise
        _warn_merge_failed(kind, dataset, error)
    return None


def _persist_recent_merge(
    dataset: str,
    df: pd.DataFrame,
    short_df: pd.DataFrame,
    result: FetchMetadata,
    storage: StorageBackend,
) -> pd.DataFrame | None:
    """Merge the recent delta into the cache and return the merged frame.

    On-disk Feather caches use a streaming record-batch merge whose peak memory
    is ~= one batch + the delta; :class:`CacheStorage` and legacy pickle caches
    fall back to the in-memory :func:`_merge_recent_df`. Both verify the merged
    hash against the server-provided ``result.hash`` and return ``None`` on a
    mismatch so the caller reverts to a full download.
    """
    if (
        result.hash
        and isinstance(storage, FileStorage)
        and storage.has_feather_cache(dataset)
    ):
        if not storage.merge_recent_delta(
            dataset, short_df, result.hash, revision=result.stamp
        ):
            return None
        return storage.get_dataframe(dataset)

    merged_df = _merge_recent_df(df, short_df)
    hash_df = hash(merged_df)
    logger.debug(f"hash df: {hash_df} url: {result.hash}")
    if result.hash != hash_df or merged_df.empty:
        return None
    storage.set_dataframe(dataset, merged_df, revision=result.stamp)
    return merged_df


def _partition_recent_actionable(
    recent_candidates: list[str],
    local_frames: dict[str, pd.DataFrame | None],
    result_map: MetadataResultMap,
) -> tuple[list[tuple[str, pd.DataFrame, FetchMetadata]], list[str]]:
    """Split candidates into ``(actionable, full_misses)`` based on metadata."""
    actionable: list[tuple[str, pd.DataFrame, FetchMetadata]] = []
    full_misses: list[str] = []
    for dataset in recent_candidates:
        df = local_frames.get(dataset)
        result = result_map.get(f"{dataset}.recent")
        if result is None or df is None or df.empty:
            full_misses.append(dataset)
            continue
        actionable.append((dataset, df, result))
    return actionable, full_misses


def _resolve_recent_candidates(
    recent_candidates: list[str],
    storage: StorageBackend,
    local_frames: dict[str, pd.DataFrame | None],
    metadata_fetcher: MetadataFetcher,
    progress: DownloadProgress | None = None,
) -> tuple[dict[str, pd.DataFrame], list[str]]:
    """Try to satisfy stale local datasets through ``.recent`` fetches."""
    if not recent_candidates:
        return {}, []

    recent_requests: MetadataRequestMap = OrderedDict(
        (f"{dataset}.recent", storage.get_time_created(dataset))
        for dataset in recent_candidates
    )
    if progress is not None:
        progress.set_stage("Fetching recent metadata", done=0, total=1)
    result_map = metadata_fetcher(recent_requests)
    if progress is not None:
        progress.set_stage("Fetching recent metadata", done=1, total=1)
        progress.set_stage(
            "Downloading recent deltas",
            done=0,
            total=len(recent_candidates),
            datasets=recent_candidates,
        )

    actionable, full_misses = _partition_recent_actionable(
        recent_candidates, local_frames, result_map
    )
    cache_hits: dict[str, pd.DataFrame] = {}

    if not actionable:
        return cache_hits, full_misses

    actionable_map = {ds: (df, result) for ds, df, result in actionable}

    def _try_recent(dataset: str) -> pd.DataFrame | None:
        df, result = actionable_map[dataset]
        return _resolve_recent_hit(dataset, df, result, storage, progress)

    for dataset, recent_hit in _run_parallel_tasks(list(actionable_map), _try_recent):
        if recent_hit is None:
            full_misses.append(dataset)
        else:
            cache_hits[dataset] = recent_hit

    return cache_hits, full_misses


class _Delta(NamedTuple):
    """A downloaded table delta, the reply that signed it and the table hash it rebuilds."""

    table: TableDelta
    result: FetchMetadata
    table_hash: str
    nbytes: int | None


def _download_delta(
    dataset: str, result: FetchMetadata | None, progress: DownloadProgress | None
) -> _Delta | None:
    """Download and parse *dataset*'s delta; None when it is unavailable or malformed."""
    if result is None or result.error or not result.hash or not result.url:
        return None
    try:
        _, raw, nbytes = _download_update(dataset, DELTA_SUFFIX, result, progress)
        if raw is None:
            return None
        return _Delta(TableDelta.from_feather(raw), result, result.hash, nbytes)
    except SignedDownloadError:
        raise
    except (*_UPDATE_FALLBACK_ERRORS, pa.ArrowException) as error:
        _debug_update_fallback("delta", "download", dataset, error)
        return None


def _persist_delta_merge(
    dataset: str, df: pd.DataFrame | None, delta: _Delta, storage: StorageBackend
) -> pd.DataFrame | None:
    """Merge *delta* into the cache; None when the result does not hash to the table.

    On-disk Feather caches stream the merge; others merge in memory, reading
    the cache when *df* is None.
    """
    revision = delta.result.stamp
    if isinstance(storage, FileStorage) and storage.has_feather_cache(dataset):
        if not storage.merge_table_delta(
            dataset, delta.table, delta.table_hash, revision=revision
        ):
            return None
        return storage.get_dataframe(dataset)
    if df is None:
        df = storage.get_dataframe(dataset)
    if df is None:
        return None
    merged = merge_table_delta_frame(df, delta.table, delta.table_hash)
    if merged is not None:
        storage.set_dataframe(dataset, merged, revision=revision)
    return merged


def _apply_delta(
    dataset: str, df: pd.DataFrame | None, delta: _Delta, storage: StorageBackend
) -> pd.DataFrame | None:
    """Merge *delta* into the cache and finalize it; None when it does not apply."""
    merged = _merge_or_fall_back(
        "delta", dataset, lambda: _persist_delta_merge(dataset, df, delta, storage)
    )
    if merged is None or merged.empty:
        return None
    record_publication(storage, dataset, delta.result, verified=True)
    return _finalize(dataset, merged)


def _sync_delta(
    dataset: str,
    df: pd.DataFrame,
    result: FetchMetadata | None,
    storage: StorageBackend,
    progress: DownloadProgress | None,
) -> pd.DataFrame | _Delta | None:
    """Bring a cache up to its table delta.

    Returns the finalized frame; the downloaded delta when it does not apply to
    this cache, for a base download to catch up with; or None when the delta is
    unavailable or malformed.
    """
    if result is None or result.error:
        return None
    if not result.signed:
        return _refresh_cached(dataset, df, result, storage, progress)
    delta = _download_delta(dataset, result, progress)
    if delta is None:
        return None
    merged = _apply_delta(dataset, df, delta, storage)
    if merged is None:
        return delta
    if progress is not None and delta.nbytes is not None:
        progress.complete(dataset, delta.nbytes)
    return merged


def _resolve_delta_candidates(
    split: _Partition,
    storage: StorageBackend,
    metadata_fetcher: MetadataFetcher,
    progress: DownloadProgress | None = None,
) -> dict[str, _Delta]:
    """Update stale caches through their table delta, moving the others in *split*.

    A dataset whose delta is unavailable falls back to its base route; one
    whose cache the delta does not apply to downloads its base, and the
    returned downloaded delta is kept for :func:`_catch_up_deltas`.
    """
    candidates = split.delta_candidates
    if not candidates:
        return {}
    request_map: MetadataRequestMap = OrderedDict(
        (f"{dataset}{DELTA_SUFFIX}", storage.get_time_created(dataset))
        for dataset in candidates
    )
    if progress is not None:
        progress.set_stage("Fetching delta metadata", done=0, total=1)
    result_map = metadata_fetcher(request_map)
    if progress is not None:
        progress.set_stage(
            "Downloading table deltas",
            done=0,
            total=len(candidates),
            datasets=candidates,
        )

    def sync(dataset: str) -> pd.DataFrame | _Delta | None:
        df = cast("pd.DataFrame", split.local_frames[dataset])
        result = result_map.get(f"{dataset}{DELTA_SUFFIX}")
        return _sync_delta(dataset, df, result, storage, progress)

    deltas: dict[str, _Delta] = {}
    for dataset, outcome in _run_parallel_tasks(candidates, sync):
        if isinstance(outcome, pd.DataFrame):
            split.cache_hits[dataset] = outcome
            continue
        if isinstance(outcome, _Delta):
            deltas[dataset] = outcome
            split.queue(dataset, "full")
            continue
        route = _base_route(_cache_revision(dataset), split.entries[dataset])
        if route != "current":
            split.queue(dataset, route)
            continue
        if progress is not None:
            progress.mark_cached(dataset)
        df = cast("pd.DataFrame", split.local_frames[dataset])
        split.cache_hits[dataset] = _finalize(dataset, df)
    return deltas


def _catch_up_deltas(
    synced: list[str],
    published_deltas: dict[str, Published],
    deltas: dict[str, _Delta],
    storage: StorageBackend,
    metadata_fetcher: MetadataFetcher,
) -> dict[str, pd.DataFrame]:
    """Merge newer table deltas into caches just synced from their base.

    fdata publishes a delta that extends its base, so one that cannot be
    applied to the base will not apply on a retry either: the cache keeps the
    base, dated at the delta so that it is not downloaded again before the
    next publication.
    """
    due = [
        dataset
        for dataset in synced
        if dataset in published_deltas
        and _delta_route(_cache_revision(dataset), published_deltas[dataset]) == "delta"
    ]
    unfetched = [dataset for dataset in due if dataset not in deltas]
    result_map = (
        metadata_fetcher(
            OrderedDict((f"{dataset}{DELTA_SUFFIX}", None) for dataset in unfetched)
        )
        if unfetched
        else {}
    )

    def catch_up(dataset: str) -> pd.DataFrame | None:
        delta = deltas.get(dataset) or _download_delta(
            dataset, result_map.get(f"{dataset}{DELTA_SUFFIX}"), None
        )
        if delta is None:
            return None
        merged = _apply_delta(dataset, None, delta, storage)
        if merged is None and delta.result.stamp is not None:
            logger.warning(
                "%s delta could not be applied to its base; "
                "keeping the base until the next publication",
                dataset,
            )
            storage.set_revision(dataset, delta.result.stamp)
        return merged

    return {
        dataset: frame
        for dataset, frame in _run_parallel_tasks(due, catch_up)
        if frame is not None
    }


def _materialize_full_misses(
    cache_misses: list[str],
    storage: StorageBackend,
    metadata_fetcher: MetadataFetcher,
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full datasets for the remaining remote misses.

    Free caches are offered with their stamp first; those the reply vouches for
    are read from disk instead of downloaded.
    """
    if not cache_misses:
        return {}

    offered = offered_storage(storage, _default_context._role)
    request_map: MetadataRequestMap = OrderedDict(
        (dataset, offered.get_time_created(dataset) if offered else None)
        for dataset in cache_misses
    )
    if progress is not None:
        progress.set_stage(
            "Fetching full metadata",
            done=0,
            total=1,
        )
    result_map = metadata_fetcher(request_map)
    target_storage = _switch_storage_for_reply(storage, offered, result_map)
    cache_hits: dict[str, pd.DataFrame] = {}
    if offered is not None:
        cache_hits, resign = _reuse_offered_caches(request_map, result_map, offered)
        if resign:
            result_map.update(
                metadata_fetcher(OrderedDict((dataset, None) for dataset in resign))
            )
    if progress is not None:
        progress.set_stage(
            "Fetching full metadata",
            done=1,
            total=1,
        )
        for dataset in cache_hits:
            progress.mark_cached(dataset)
    downloads = [dataset for dataset in cache_misses if dataset not in cache_hits]
    if not downloads:
        return cache_hits
    gc.collect()
    validated_results = _validate_full_miss_results(downloads, result_map)
    downloaded_frames = _download_full_miss_frames(
        downloads,
        validated_results,
        progress=progress,
    )
    cache_hits.update(
        _persist_full_miss_frames(
            downloads,
            downloaded_frames,
            validated_results,
            target_storage,
        )
    )
    return cache_hits


def _switch_storage_for_reply(
    storage: StorageBackend,
    offered: StorageBackend | None,
    result_map: MetadataResultMap,
) -> StorageBackend:
    """Make the storage for the role the reply reports the active one, and return it.

    A paid account never reads a free cache: a FileStorage's free namespace gives
    way to its base storage, and an offered CacheStorage, which holds a free
    account's data, is emptied.
    """
    ctx = _default_context
    role = next(
        (result.role for result in result_map.values() if result and result.role),
        None,
    )
    if role is None:
        return storage
    ctx._role = role
    if role != FREE_ROLE and isinstance(offered, CacheStorage):
        offered.clear()
        ctx._loaded_datasets.clear()
        ctx._projected_datasets.clear()
        ctx._finalized_cache.clear()
    ctx._storage = storage_for_role(storage, role)
    return ctx._storage


def _reuse_offered_caches(
    request_map: MetadataRequestMap,
    result_map: MetadataResultMap,
    offered: StorageBackend,
) -> tuple[dict[str, pd.DataFrame], list[str]]:
    """Split offered caches into those still current and those to sign again.

    Any other unsigned reply to an offer (a newer blob, a paid account, an
    unreadable cache) is requested again without the offer.
    """
    reused: dict[str, pd.DataFrame] = {}
    resign: list[str] = []
    for dataset, stamp in request_map.items():
        result = result_map.get(dataset)
        if stamp is None or result is None or result.error or result.signed:
            continue  # not offered, failed (raised below) or downloaded below
        df = None
        if holds_signed_blob(stamp, result):
            try:
                df = offered.get_dataframe(dataset)
            except LocalDataReadError as exc:
                _warn_local_cache_read_error(dataset, exc)
        if df is None or df.empty:
            resign.append(dataset)
            continue
        record_publication(offered, dataset, result, df)
        reused[dataset] = _finalize(dataset, df)
    return reused, resign


def _validate_full_miss_results(
    cache_misses: list[str],
    result_map: MetadataResultMap,
) -> OrderedDict[str, FetchMetadata]:
    """Validate full-miss metadata and raise actionable per-item errors."""
    validated_results: OrderedDict[str, FetchMetadata] = OrderedDict()
    for dataset in cache_misses:
        result = result_map.get(dataset)
        if result is None:
            raise FileNotFoundError(f"**Error: {dataset} not exists")
        if result.error:
            if is_not_found_error(result.error):
                key_alias = equivalent_key_alias(dataset)
                if key_alias is not None:
                    raise _EquivalentKeyRedirect(key_alias)
                raise dataset_not_found_error(dataset)
            raise RuntimeError(f"**Error: {result.error}")
        validated_results[dataset] = result
    return validated_results


class _EquivalentKeyRedirect(Exception):
    """Signals that a missing key has a published equivalent to fetch instead."""

    def __init__(self, key_alias: KeyAlias) -> None:
        super().__init__(key_alias.alias)
        self.key_alias = key_alias


def _accept_redirect(redirect: _EquivalentKeyRedirect, redirected: set[str]) -> str:
    """Warn about an equivalent-key redirect and return the key to fetch.

    Raises the plain not-found error when the alias was already redirected once,
    so a cyclic alias table cannot loop forever.
    """
    key_alias = redirect.key_alias
    if key_alias.alias in redirected:
        raise dataset_not_found_error(key_alias.alias) from None
    redirected.add(key_alias.alias)
    warnings.warn(
        redirect_warning_message(key_alias),
        UserWarning,
        stacklevel=_stacklevel_outside_data_package(),
    )
    return key_alias.target


def _stacklevel_outside_data_package() -> int:
    """``warnings.warn`` stacklevel pointing at the first caller outside finlab.data.

    ``data.get``, ``data.gets`` and date-range reads reach the redirect through
    different call depths, so a fixed stacklevel would blame internal code.
    """
    frame = sys._getframe(1)
    level = 1
    while frame.f_back is not None and frame.f_globals.get("__name__", "").startswith(
        __package__ or __name__
    ):
        frame = frame.f_back
        level += 1
    return level


@functools.lru_cache(maxsize=1)
def _use_pyodide_async_fetch() -> bool:
    """Return True when pyodide async parallel fetch is available."""
    if "pyodide" not in sys.modules:
        return False
    try:
        return importlib.util.find_spec("pyodide.http") is not None and (
            importlib.util.find_spec("pyodide.ffi") is not None
            or importlib.util.find_spec("pyodide.code") is not None
        )
    except (ImportError, ValueError):
        return False


def _download_full_miss_frames_threaded(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, DownloadedFrame]:
    """Download full-miss payloads via ThreadPoolExecutor."""

    def _download(dataset: str) -> tuple[DownloadedFrame, int | None]:
        return _download_one_full_miss_frame(dataset, validated_results, progress)

    downloaded: dict[str, DownloadedFrame] = {}
    for dataset, (payload, nbytes) in _run_parallel_tasks(cache_misses, _download):
        downloaded[dataset] = payload
        if progress is not None and nbytes is not None:
            progress.complete(dataset, nbytes)
    return downloaded


def _download_one_full_miss_frame(
    dataset: str,
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> tuple[DownloadedFrame, int | None]:
    """Download one full-miss dataframe; return ``((df, raw_bytes), display_nbytes)``."""
    if progress is None:
        df, raw = _download_result_dataframe(validated_results[dataset], dataset)
        return (df, raw), None

    on_progress, final_bytes = _build_progress_callback(progress, dataset)
    df, raw = _download_result_dataframe(
        validated_results[dataset],
        dataset,
        on_progress=on_progress,
    )
    nbytes = final_bytes()
    if nbytes <= 1:
        nbytes = _estimate_dataframe_bytes(df)
    return (df, raw), nbytes


def _download_full_miss_frames_sequential(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, DownloadedFrame]:
    """Download full-miss payloads without threads or async stack switching."""
    downloaded: dict[str, DownloadedFrame] = {}
    for dataset in cache_misses:
        payload, nbytes = _download_one_full_miss_frame(
            dataset,
            validated_results,
            progress,
        )
        downloaded[dataset] = payload
        if progress is not None and nbytes is not None:
            progress.complete(dataset, nbytes)
    return downloaded


def _can_run_pyodide_sync(run_sync: Callable[[object], object]) -> bool:
    """Return whether Pyodide run_sync is usable from this Python entrypoint."""

    async def _noop() -> None:
        return None

    awaitable = _noop()
    try:
        run_sync(awaitable)
    except RuntimeError as exc:
        awaitable.close()
        if _is_pyodide_stack_switch_error(exc):
            return False
        raise
    return True


def _run_pyodide_sync(
    run_sync: Callable[[object], object], awaitable: object
) -> object:
    """Run a Pyodide awaitable synchronously, closing it if the bridge rejects it."""
    try:
        return run_sync(awaitable)
    except RuntimeError:
        close = getattr(awaitable, "close", None)
        if callable(close):
            close()
        raise


def _download_full_miss_frames(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, DownloadedFrame]:
    """Download full-miss payloads concurrently when beneficial."""
    if progress is not None:
        progress.set_stage(
            "Downloading full datasets",
            done=0,
            total=len(cache_misses),
            datasets=cache_misses,
        )

    if _use_pyodide_async_fetch():
        run_sync = _resolve_pyodide_run_sync()
        if not _can_run_pyodide_sync(run_sync):
            logger.debug(
                "Pyodide async fetch unavailable from a synchronous entrypoint; "
                "falling back to sequential download."
            )
            return _download_full_miss_frames_sequential(
                cache_misses,
                validated_results,
                progress,
            )
        return _download_full_miss_frames_pyodide(
            cache_misses, validated_results, run_sync, progress
        )

    if "pyodide" in sys.modules:
        return _download_full_miss_frames_sequential(
            cache_misses,
            validated_results,
            progress,
        )

    return _download_full_miss_frames_threaded(
        cache_misses, validated_results, progress
    )


async def _download_pyodide_with_retry(dataset: str, result: FetchMetadata) -> bytes:
    from .auth import _fetch_signed_bytes_async, _pyfetch_bytes_async

    if not result.url:
        raise FileNotFoundError(f"No data URL for {dataset}")
    try:
        return await _fetch_signed_bytes_async(result.url)
    except SignedDownloadError as exc:
        if exc.status not in {404, 412}:
            raise exc.for_dataset(dataset) from None
        import json

        from .auth import _build_batch_items, _load_signing_reply, _to_fetch_metadata

        body = _build_batch_items(OrderedDict([(dataset, None)]))
        try:
            reply = _load_signing_reply(
                await _pyfetch_bytes_async(
                    _AUTH_URL,
                    method="POST",
                    headers={"Content-Type": "application/json"},
                    body=json.dumps(body),
                )
            )
        except SignedDownloadError as resign_exc:
            resign_exc.for_dataset(dataset)
            raise
        items = reply.get("results", [])
        if len(items) != 1:
            raise exc.for_dataset(dataset) from None
        replacement = _to_fetch_metadata(items[0])
        if replacement.error or not replacement.url:
            raise exc.for_dataset(dataset) from None
        result.url, result.hash, result.publication, result.time_created = (
            replacement.url,
            replacement.hash,
            replacement.publication,
            replacement.time_created,
        )
    try:
        return await _fetch_signed_bytes_async(result.url)
    except SignedDownloadError as exc:
        raise exc.for_dataset(dataset) from None


def _download_full_miss_frames_pyodide(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    run_sync: Callable[[object], object],
    progress: DownloadProgress | None = None,
) -> dict[str, DownloadedFrame]:
    """Download full-miss payloads in parallel using pyodide's async fetch."""
    semaphore = asyncio.Semaphore(8)

    async def _fetch_one(
        dataset: str,
    ) -> tuple[str, pd.DataFrame, bytes | None, int | None]:
        result = validated_results[dataset]
        if result.data is not None:
            if progress is not None:
                progress.update(dataset, 1, 1)
            return dataset, result.data, None, 1

        url = result.url
        if not url:
            raise FileNotFoundError(f"**Error: {dataset} not exists")

        async with semaphore:
            raw = await _download_pyodide_with_retry(dataset, result)
        nbytes = len(raw)
        if progress is not None:
            progress.update(dataset, nbytes, nbytes)
        df = feather_io.read_frame(pa.py_buffer(raw))
        return dataset, df, raw, nbytes

    async def _fetch_all() -> list[tuple[str, pd.DataFrame, bytes | None, int | None]]:
        return await asyncio.gather(*[_fetch_one(ds) for ds in cache_misses])

    results = cast(
        "list[tuple[str, pd.DataFrame, bytes | None, int | None]]",
        _run_pyodide_sync(run_sync, _fetch_all()),
    )

    downloaded: dict[str, DownloadedFrame] = {}
    for dataset, df, raw, nbytes in results:
        downloaded[dataset] = (df, raw)
        if progress is not None and nbytes is not None:
            progress.complete(dataset, nbytes)
    return downloaded


def _persist_full_miss_frames(
    cache_misses: list[str],
    downloaded: dict[str, DownloadedFrame],
    validated_results: OrderedDict[str, FetchMetadata],
    target_storage: StorageBackend,
) -> dict[str, pd.DataFrame]:
    """Persist downloaded full misses and return finalized cache hits."""
    cache_hits: dict[str, pd.DataFrame] = {}
    for dataset in cache_misses:
        df, raw = downloaded[dataset]
        result = validated_results[dataset]
        _persist_downloaded_frame(target_storage, dataset, df, raw, result.stamp)
        record_publication(target_storage, dataset, result, df)
        logger.debug(f"{dataset} downloaded full data from cloud")
        cache_hits[dataset] = _finalize(dataset, df)
    return cache_hits


def _persist_downloaded_frame(
    storage: StorageBackend,
    dataset: str,
    df: pd.DataFrame,
    raw: bytes | None,
    revision: datetime.datetime | None,
) -> None:
    """Persist a downloaded frame, writing raw feather bytes verbatim when available."""
    if df.empty:
        raise RuntimeError(f"**Error: {dataset} download fail")
    if raw is not None and isinstance(storage, FileStorage):
        storage.set_dataframe_bytes(dataset, raw, revision=revision)
    else:
        storage.set_dataframe(dataset, df, revision=revision)


def _fetch_many(
    datasets: list[str],
    force_download: bool,
    *,
    show_progress: bool = False,
    progress: ProgressMode | None = None,
    progress_callback: Callable[[ProgressEvent], None] | None = None,
) -> tuple[pd.DataFrame, ...]:
    """Fetch one or more datasets, following published equivalent-key aliases."""
    _, frames = _fetch_many_following_aliases(
        datasets,
        force_download,
        show_progress=show_progress,
        progress=progress,
        progress_callback=progress_callback,
    )
    return frames


def _fetch_many_following_aliases(
    datasets: list[str],
    force_download: bool,
    *,
    show_progress: bool = False,
    progress: ProgressMode | None = None,
    progress_callback: Callable[[ProgressEvent], None] | None = None,
) -> tuple[list[str], tuple[pd.DataFrame, ...]]:
    """Fetch datasets and return the keys actually fetched alongside the frames.

    A missing key with a published ``equivalent`` alias is replaced by its target
    (with a ``UserWarning``) and the fetch is retried.
    """
    requested = list(datasets)
    redirected: set[str] = set()
    while True:
        try:
            frames = _fetch_many_once(
                requested,
                force_download,
                show_progress=show_progress,
                progress=progress,
                progress_callback=progress_callback,
            )
        except _EquivalentKeyRedirect as redirect:
            target = _accept_redirect(redirect, redirected)
            requested = [
                target
                if _resolve_dataset(dataset) == redirect.key_alias.alias
                else dataset
                for dataset in requested
            ]
        else:
            return requested, frames


def _fetch_many_once(
    datasets: list[str],
    force_download: bool,
    *,
    show_progress: bool = False,
    progress: ProgressMode | None = None,
    progress_callback: Callable[[ProgressEvent], None] | None = None,
) -> tuple[pd.DataFrame, ...]:
    """Fetch one or more datasets through shared cache and merge policy."""
    progress_display: DownloadProgress | None = None
    progress_mode: ProgressMode = progress or ("display" if show_progress else "silent")
    if progress_mode not in {"display", "event", "silent"}:
        raise ValueError("progress must be 'display', 'event', or 'silent'")
    ctx, resolved, storage, force_download = _prepare_fetch(datasets, force_download)
    try:
        split = _partition_datasets(
            resolved,
            storage,
            force_download,
            ctx.use_local_data_only,
        )
        cache_hits, entries = split.cache_hits, split.entries
        fetch = _stamping(
            fetch_metadata_batch,
            {
                **entries,
                **{f"{ds}{DELTA_SUFFIX}": delta for ds, delta in split.deltas.items()},
            },
        )

        pending = split.recent_candidates + split.delta_candidates + split.cache_misses
        if progress_mode != "silent" and (pending or progress_mode == "event"):
            progress_display = DownloadProgress(
                to_download=pending,
                cached=list(cache_hits),
                mode=progress_mode,
                callback=progress_callback,
            )
            progress_display.start()

        deltas = _resolve_delta_candidates(
            split, storage, fetch, progress=progress_display
        )
        recent_candidates, cache_misses = split.recent_candidates, split.cache_misses
        synced_from_base = recent_candidates + cache_misses

        if recent_candidates:
            if progress_display is not None:
                progress_display.set_stage("Fetching recent metadata")
            recent_hits, promoted_misses = _resolve_recent_candidates(
                recent_candidates,
                storage,
                split.local_frames,
                fetch,
                progress=progress_display,
            )
            cache_hits.update(recent_hits)
            cache_misses.extend(promoted_misses)

        if cache_misses:
            cache_hits.update(
                _materialize_full_misses(
                    cache_misses,
                    storage,
                    fetch,
                    progress=progress_display,
                )
            )

        cache_hits.update(
            _catch_up_deltas(synced_from_base, split.deltas, deltas, storage, fetch)
        )
        _confirm_unindexed(pending, entries)
        loaded = split.loaded_entries()
        for dataset in resolved:
            _mark_loaded(dataset, loaded.get(dataset))
        if force_download and "security_categories" in resolved:
            from .category_cache import clear_category_cache

            clear_category_cache()

        return tuple(cache_hits[dataset] for dataset in resolved)
    finally:
        if progress_display is not None:
            progress_display.finish()


# ---------------------------------------------------------------------------
# Role helpers
# ---------------------------------------------------------------------------


def get_role() -> str | None:
    """Return the current user role (e.g. ``'free'`` or ``'vip'``)."""
    return _default_context._role


def is_vip() -> bool:
    """Return True if the current user is a VIP member."""
    role = _default_context._role
    return role is not None and role != FREE_ROLE


# ---------------------------------------------------------------------------
# Date-range (start/end) pushdown
# ---------------------------------------------------------------------------

DateBound: TypeAlias = "str | pd.Timestamp | datetime.datetime | None"


def _normalize_date_bound(bound: DateBound) -> pd.Timestamp | None:
    """Coerce a date-like bound to a ``pd.Timestamp`` (``None`` passes through)."""
    if bound is None:
        return None
    return pd.Timestamp(bound)


def _date_range_has_rows(storage: StorageBackend, dataset: str) -> bool:
    """Return whether the local cache has rows, without a full load."""
    if isinstance(storage, FileStorage):
        return (storage.get_dataframe_row_count(dataset) or 0) > 0
    df = storage.get_dataframe(dataset)
    return df is not None and not df.empty


def _date_range_route(
    storage: StorageBackend, dataset: str, force_download: bool
) -> tuple[str, Published | None]:
    """Route the local cache before a slice read, as a plain ``data.get`` would.

    A date-range read never returns staler data than a full read.
    """
    ctx = _default_context
    if force_download or ctx.force_cloud_download:
        return "full", None
    if ctx.use_local_data_only:
        return "current", None
    return _cache_route(dataset, _date_range_has_rows(storage, dataset))


def _fetch_one_date_range(
    dataset: str,
    *,
    start: DateBound,
    end: DateBound,
    force_download: bool,
    progress: ProgressMode,
    progress_callback: Callable[[ProgressEvent], None] | None,
) -> pd.DataFrame:
    """Fetch a single dataset, pushing an inclusive ``[start, end]`` date filter
    down to the Arrow read so a slice of a huge table skips the full-table cost.
    """
    start_ts = _normalize_date_bound(start)
    end_ts = _normalize_date_bound(end)
    if start_ts is not None and end_ts is not None and start_ts > end_ts:
        raise ValueError(f"start ({start_ts}) must not be after end ({end_ts}).")

    finlab.utils.check_version()
    ctx = _default_context
    resolved = _resolve_dataset(dataset)

    route, entry = _date_range_route(ctx._storage, resolved, force_download)
    if route != "current":
        # Refresh the on-disk cache through the unchanged full pipeline (identical
        # freshness/hash semantics); the returned full frame is discarded and the
        # slice is re-read below via pushdown. That pipeline marks it loaded.
        fetched, _ = _fetch_many_following_aliases(
            [dataset],
            force_download,
            progress=progress,
            progress_callback=progress_callback,
        )
        resolved = _resolve_dataset(fetched[0])

    # The active storage, which a reply may have switched to the account's tier.
    raw = ctx._storage.read_dataframe_date_range(resolved, start_ts, end_ts)
    if raw is None:
        raise FileNotFoundError(f"**Error: {resolved} not in local storage")
    if start_ts is not None or end_ts is not None:
        ctx._projected_datasets.add(resolved)
    if route == "current":
        _mark_loaded(resolved, entry)
    return _finalize(resolved, raw, cache=False)


# ---------------------------------------------------------------------------
# data.get() -- main entry point
# ---------------------------------------------------------------------------


def _get_version(
    dataset: str,
    *,
    as_of: DateBound,
    version: str | int | None,
    force_download: bool,
    save_to_storage: bool,
    lazy: bool,
    dated: bool,
    progress: ProgressMode,
    progress_callback: Callable[[ProgressEvent], None] | None,
) -> pd.DataFrame:
    """``data.get()`` of one retained version: immutable, so never merged or refreshed."""
    from .dataset_versions import get_version

    if dated or progress != "silent" or progress_callback is not None:
        msg = "as_of/version cannot be combined with start, end or progress reporting"
        raise ValueError(msg)
    finlab.utils.check_version()
    resolved, raw = get_version(
        dataset,
        as_of=as_of,
        version=version,
        force_download=force_download,
        save_to_storage=save_to_storage,
    )
    result = _finalize(resolved, raw, cache=False)
    return result.lazy() if lazy else result


def get(
    dataset: str,
    save_to_storage: bool = True,
    force_download: bool = False,
    lazy: bool = False,
    progress: ProgressMode = "silent",
    progress_callback: Callable[[ProgressEvent], None] | None = None,
    *,
    start: DateBound = None,
    end: DateBound = None,
    as_of: DateBound = None,
    version: str | int | None = None,
) -> pd.DataFrame:
    """Download historical data.

    See https://ai.finlab.tw/database for the full data catalogue.

    Args:
        dataset: The name of dataset. ``tw_tick:SYMBOL`` and ``tw_minute:SYMBOL``
            return after-market long-form pandas frames and require both dates
            (at most 31 calendar days). See the intraday data guide.
        save_to_storage: Whether to save the dataset to storage for later use.
        force_download: Whether to force download the dataset from cloud.
        lazy: Return a lazy computation wrapper after fetching the dataset.
        progress: ``'display'``, ``'event'``, or ``'silent'``.
        progress_callback: Receives structured events in event mode.
        start: Optional inclusive lower bound on the ``date`` column. Accepts any
            date-like value (string or ``Timestamp``). Pushed down to the Arrow
            read so only in-range rows are materialised. Requires the dataset to
            have a ``date`` column/index, otherwise raises ``ValueError``.
        end: Optional inclusive upper bound on the ``date`` column. Same rules as
            ``start``. When both ``start`` and ``end`` are ``None`` the result is
            byte-identical to a plain read.
        as_of: Return the dataset exactly as it was published at this time
            (naive values are Asia/Taipei, for every market; a bare date means
            00:00 that day, before that day's publications). Only versions the
            server still retains are available; list them with
            ``data.versions(dataset)``. Requires a
            paid data plan and counts toward the download quota; a version
            already downloaded is read from local storage. ``financial_statement``
            keeps permanent vintages instead (``financial_statement_versions``).
        version: Return exactly this generation from ``data.versions(dataset)``.
            Mutually exclusive with ``as_of``.

    Returns:
        financial data as a DataFrame.
    """
    from .intraday import get_intraday, is_intraday

    if is_intraday(dataset):
        if as_of is not None or version is not None:
            msg = "Intraday data does not support as_of/version"
            raise ValueError(msg)
        return get_intraday(
            dataset,
            start=start,
            end=end,
            force_download=force_download,
            save_to_storage=save_to_storage,
            lazy=lazy,
            progress=progress,
            progress_callback=progress_callback,
        )
    if not save_to_storage:
        logger.warning(
            "save_to_storage will be deprecated after 2024/06/01. "
            "Please use data.set_storage(CacheStorage()) to disable data saved to local storage"
        )
    if as_of is not None or version is not None:
        return _get_version(
            dataset,
            as_of=as_of,
            version=version,
            force_download=force_download,
            save_to_storage=save_to_storage,
            lazy=lazy,
            dated=start is not None or end is not None,
            progress=progress,
            progress_callback=progress_callback,
        )
    if start is None and end is None:
        if progress == "silent" and progress_callback is None:
            fetched = _fetch_many([dataset], force_download)
        else:
            fetched = _fetch_many(
                [dataset],
                force_download,
                progress=progress,
                progress_callback=progress_callback,
            )
        return fetched[0].lazy() if lazy else fetched[0]

    result = _fetch_one_date_range(
        dataset,
        start=start,
        end=end,
        force_download=force_download,
        progress=progress,
        progress_callback=progress_callback,
    )
    return result.lazy() if lazy else result
