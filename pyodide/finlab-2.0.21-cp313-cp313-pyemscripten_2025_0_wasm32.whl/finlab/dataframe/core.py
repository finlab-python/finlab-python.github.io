"""Pandas-backed ``FinlabDataFrame`` frontend.

``FinlabDataFrame`` owns the pandas semantics and convenience APIs used by the
documented dataframe SDK.
"""

from __future__ import annotations

import inspect
import logging
import sys
import uuid
import warnings
from pathlib import Path
from typing import TYPE_CHECKING, cast

__all__ = ["FinlabDataFrame"]

if TYPE_CHECKING:
    from collections.abc import Callable

    from finlab.dataframe.cs import CsAccessor
    from finlab.dataframe.lazy import LazyWide
    from finlab.dataframe.sector import SectorAccessor
    from finlab.dataframe.weight import WeightAccessor

import numpy as np
import pandas as pd

from finlab.dataframe.core_index import IndexConversionMixin, fill_unknown_boolean
from finlab.dataframe.core_industry import IndustryMixin
from finlab.dataframe.core_neutralize import NeutralizeMixin
from finlab.dataframe.core_signals import SignalMixin
from finlab.dataframe.profiling import profile_alignment_call

logger = logging.getLogger(__name__)


class LookaheadWarning(UserWarning):
    """警告：偵測到可能的 look-ahead bias。"""


_LOGICAL_OPS = frozenset(
    {"__and__", "__or__", "__xor__", "__iand__", "__ior__", "__ixor__"}
)


def _is_plain_bool(data: object) -> bool:
    return isinstance(data, pd.DataFrame) and bool(
        (data.dtypes == np.dtype(bool)).all()
    )


def reshape_operations(cls: type) -> type:
    # Define a mapping of operations to override to their corresponding pandas method
    methods_to_check = [
        "__getitem__",
        "__add__",
        "__sub__",
        "__mul__",
        "__truediv__",
        "__floordiv__",
        "__mod__",
        "__pow__",
        "__lshift__",
        "__rshift__",
        "__and__",
        "__or__",
        "__xor__",
        "__iadd__",
        "__isub__",
        "__imul__",
        "__itruediv__",
        "__ifloordiv__",
        "__imod__",
        "__ipow__",
        "__ilshift__",
        "__irshift__",
        "__iand__",
        "__ior__",
        "__ixor__",
        "__lt__",
        "__le__",
        "__eq__",
        "__ne__",
        "__gt__",
        "__ge__",
    ]

    # find operation mapping that map str -> function for the function need reshape.

    base_class = pd.DataFrame
    operations_mapping: dict[str, Callable[..., pd.DataFrame]] = {}

    for method_name in methods_to_check:
        if hasattr(base_class, method_name):
            method = getattr(base_class, method_name)
            params = inspect.signature(method).parameters
            can_accept_df = any(
                param.annotation in (pd.DataFrame, inspect._empty)
                for param in params.values()
            )
            if can_accept_df:
                operations_mapping[method_name] = getattr(pd.DataFrame, method_name)

    # replace original function to reshaped function

    for op, pandas_method in operations_mapping.items():
        if hasattr(cls, op):

            def make_wrapped_method(
                op: str, pandas_method: Callable[..., pd.DataFrame]
            ) -> Callable[[pd.DataFrame, pd.DataFrame | pd.Series], pd.DataFrame]:
                def wrapped_method(
                    self: pd.DataFrame, other: pd.DataFrame | pd.Series
                ) -> pd.DataFrame:
                    df1, df2 = self.reshape(self, other)

                    if isinstance(other, pd.Series) and op == "__getitem__":
                        return df1.loc[df2.iloc[:, 0]]

                    result = pandas_method(df1, df2)
                    # A plain bool mask combined with a quarterly mask stays
                    # plain bool, as it did when quarterly masks were object.
                    if op in _LOGICAL_OPS and (
                        _is_plain_bool(df1) or _is_plain_bool(df2)
                    ):
                        return fill_unknown_boolean(result)
                    return result

                return wrapped_method

            setattr(cls, op, make_wrapped_method(op, pandas_method))

    return cls


def get_index_str_frequency(df: pd.DataFrame | pd.Series) -> str | None:
    if not hasattr(df, "index"):
        return None

    if len(df.index) == 0:
        return None

    if not isinstance(df.index[0], str):
        return None

    if (df.index.str.find("M") != -1).all():
        return "month"

    if (df.index.str.find("Q") != -1).all():
        return "season"

    return None


def _fetch_refined_categories() -> dict[str, str]:
    """Fetch security categories and normalize sector names.

    Returns a dict mapping stock_id -> refined sector name.
    Shared by the FinlabDataFrame accessors that need sector lookups.
    """
    from finlab import data
    from finlab.compat import resolve_id_column

    categories = data.get("security_categories")
    cat = categories.set_index(resolve_id_column(categories)).category.to_dict()
    org_set = set(cat.values())
    valid_names = {o for o in org_set if isinstance(o, str) and o != "nan"}

    refine_cat: dict[str, str] = {}
    for s, c in cat.items():
        if c is None or c == "nan":
            refine_cat[s] = "其他"
        elif c == "電腦及週邊":
            refine_cat[s] = "電腦及週邊設備業"
        elif c[-1] == "業" and c[:-1] in valid_names:
            refine_cat[s] = c[:-1]
        else:
            refine_cat[s] = c
    return refine_cat


@reshape_operations
class FinlabDataFrame(
    IndexConversionMixin,
    SignalMixin,
    NeutralizeMixin,
    IndustryMixin,
    pd.DataFrame,
):
    """回測語法糖
    除了使用熟悉的 Pandas 語法外，我們也提供很多語法糖，讓大家開發程式時，可以用簡易的語法完成複雜的功能，讓開發策略更簡潔！
    我們將所有的語法糖包裹在 `FinlabDataFrame` 中，用起來跟 `pd.DataFrame` 一樣，但是多了很多功能！
    只要使用 `finlab.data.get()` 所獲得的資料，皆為 `FinlabDataFrame` 格式，
    接下來我們就來看看， `FinlabDataFrame` 有哪些好用的語法糖吧！

    當資料日期沒有對齊（例如: 財報 vs 收盤價 vs 月報）時，在使用以下運算符號：
    `+`, `-`, `*`, `/`, `>`, `>=`, `==`, `<`, `<=`, `&`, `|`, `~`，
    不需要先將資料對齊，因為 `FinlabDataFrame` 會自動幫你處理，以下是示意圖。

    <img src="https://i.ibb.co/pQr5yx5/Screen-Shot-2021-10-26-at-5-32-44-AM.png" alt="steps">

    以下是範例：`cond1` 與 `cond2` 分別為「每天」，和「每季」的資料，假如要取交集的時間，可以用以下語法：

    ```py
    from finlab import data
    # 取得 FinlabDataFrame
    close = data.get('price:收盤價')
    roa = data.get('fundamental_features:ROA稅後息前')

    # 運算兩個選股條件交集
    cond1 = close > 37
    cond2 = roa > 0
    cond_1_2 = cond1 & cond2
    ```
    擷取 1101 台泥 的訊號如下圖，可以看到 `cond1` 跟 `cond2` 訊號的頻率雖然不相同，
    但是由於 `cond1` 跟 `cond2` 是 `FinlabDataFrame`，所以可以直接取交集，而不用處理資料頻率對齊的問題。
    <br />
    <img src="https://i.ibb.co/m9chXSQ/imageconds.png" alt="imageconds">

    總結來說，FinlabDataFrame 與一般 dataframe 唯二不同之處：
    1. 多了一些 method，如`df.is_largest()`, `df.sustain()`...等。
    2. 在做四則運算、不等式運算前，會將 df1、df2 的 index 取聯集，column 取交集。
    """

    def __init__(self, *args: object, **kwargs: object) -> None:
        init = cast("Callable[..., None]", super().__init__)
        init(*args, **kwargs)
        self.id: int = uuid.uuid4().int

    @property
    def _constructor(self) -> type[FinlabDataFrame]:
        return FinlabDataFrame

    @property
    def weight(self) -> WeightAccessor:
        from finlab.dataframe.weight import WeightAccessor

        return WeightAccessor(self)

    @property
    def cs(self) -> CsAccessor:
        from finlab.dataframe.cs import CsAccessor

        return CsAccessor(self)

    @property
    def sector(self) -> SectorAccessor:
        from finlab.dataframe.sector import SectorAccessor

        return SectorAccessor(self)

    def __setattr__(self, name: str, value: object) -> None:
        if name == "index":
            caller_file = sys._getframe(1).f_code.co_filename
            caller_path = Path(caller_file).resolve()
            pandas_root = Path(pd.__file__).resolve().parent
            finlab_root = Path(__file__).resolve().parents[1]
            is_internal_assignment = caller_path.is_relative_to(
                pandas_root
            ) or caller_path.is_relative_to(finlab_root)
            if not is_internal_assignment:
                raise AttributeError(
                    "\n不要直接覆寫 FinlabDataFrame 的 index！"
                    "\n"
                    "\n原因："
                    "\n  FinlabDataFrame 會保留季報/月報索引的資料時間語意。"
                    "\n  直接覆寫 index 可能把尚未公開的資料提前用在回測中，"
                    "\n  導致未來資料汙染 (lookahead bias)。"
                    "\n"
                    "\n如果你要對齊季報/月報資料，請改用："
                    "\n  df = df.deadline()          # 依財報截止日統一換股（所有股票同日換）"
                    "\n  df = df.index_str_to_date() # 依各股實際財報公布日換股（避免前視偏差）"
                    "\n"
                    "\n如果你確定只是要用 pandas 語意自行處理 index，"
                    "\n請先轉成一般 DataFrame，再自行承擔時間對齊責任："
                    "\n  df = pd.DataFrame(df)"
                    "\n  df.index = pd.to_datetime(df.index)"
                    "\n"
                    "\n範例："
                    "\n  ❌ df.index = pd.to_datetime(df.index)"
                    "\n  ✅ df = df.deadline()"
                    "\n  ✅ df = df.index_str_to_date()"
                    "\n  ✅ df = pd.DataFrame(df); df.index = pd.to_datetime(df.index)"
                )
        super().__setattr__(name, value)

    @staticmethod
    @profile_alignment_call
    def reshape(
        df1: pd.DataFrame,
        df2: pd.DataFrame | pd.Series,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        isdf1 = isinstance(df1, pd.DataFrame)
        isdf2 = isinstance(df2, (pd.DataFrame, pd.Series))

        d1_index_freq = get_index_str_frequency(df1) if isdf1 else None
        d2_index_freq = get_index_str_frequency(df2) if isdf2 else None

        if isinstance(df2, pd.Series):
            df2 = FinlabDataFrame(dict.fromkeys(df1.columns, df2))
            if d2_index_freq:
                # tell user has high chance to use future data
                logger.warning(
                    "Detect pd.Series has season/month index, the chance of using future data is high!\n"
                    "Please convert index from str to date first then perform calculations.\n"
                    "Example: df.quantile(0.3, axis=1) -> df.index_str_to_date().quantile(0.3, axis=1)"
                )

        if (
            ((d1_index_freq or d2_index_freq) and (d1_index_freq != d2_index_freq))
            and isdf1
            and isdf2
        ):
            df1 = df1.index_str_to_date() if isinstance(df1, FinlabDataFrame) else df1
            df2 = df2.index_str_to_date() if isinstance(df2, FinlabDataFrame) else df2

        if (
            isdf1
            and isdf2
            and len(df1)
            and len(df2)
            and isinstance(df1.index[0], pd.Timestamp)
            and isinstance(df2.index[0], pd.Timestamp)
        ):
            # Fast path: skip reindex when index and columns already match
            if (
                len(df1.index) == len(df2.index)
                and len(df1.columns) == len(df2.columns)
                and df1.index.equals(df2.index)
                and df1.columns.equals(df2.columns)
            ):
                return df1, df2

            index = df1.index.union(df2.index)
            columns = df1.columns.intersection(df2.columns)

            if len(df1.index) * len(df2.index) != 0:
                index_start = max(df1.index[0], df2.index[0])
                index = index[index >= index_start]

            return (
                df1.reindex(index=index, method="ffill")[columns],
                df2.reindex(index=index, method="ffill")[columns],
            )

        return df1, df2

    def average(self, n: int) -> FinlabDataFrame:
        """取 n 筆移動平均

        若股票在時間窗格內，有 N/2 筆 NaN，則會產生 NaN。
        Args:
          n (positive-int): 設定移動窗格數。
        Returns:
          (pd.DataFrame): data
        Examples:
            股價在均線之上
            ```py
            from finlab import data
            close = data.get('price:收盤價')
            sma = close.average(10)
            cond = close > sma
            ```
            只需要簡單的語法，就可以將其中一部分的訊號繪製出來檢查：
            ```py
            import matplotlib.pyplot as plt

            close.loc['2021', '2330'].plot()
            sma.loc['2021', '2330'].plot()
            cond.loc['2021', '2330'].mul(20).add(500).plot()

            plt.legend(['close', 'sma', 'cond'])
            ```
            <img src="https://i.ibb.co/Mg1P85y/sma.png" alt="sma">
        """
        return self.rolling(n, min_periods=int(n / 2)).mean()

    def is_largest(self, n: int) -> FinlabDataFrame:
        """取每列前 n 筆大的數值

        若符合 `True` ，反之為 `False` 。用來篩選每天數值最大的股票。

        <img src="https://i.ibb.co/8rh3tbt/is-largest.png" alt="is-largest">
        Args:
          n (positive-int): 設定每列前 n 筆大的數值。
        Returns:
          (pd.DataFrame): data
        Examples:
            每季 ROA 前 10 名的股票
            ```py
            from finlab import data

            roa = data.get('fundamental_features:ROA稅後息前')
            good_stocks = roa.is_largest(10)
            ```
        """
        return _top_n(self, n, largest=True)

    def is_smallest(self, n: int) -> FinlabDataFrame:
        """取每列前 n 筆小的數值

        若符合 `True` ，反之為 `False` 。用來篩選每天數值最小的股票。
        Args:
          n (positive-int): 設定每列前 n 筆小的數值。
        Returns:
          (pd.DataFrame): data
        Examples:
            股價淨值比最小的 10 檔股票
            ```py
            from finlab import data

            pb = data.get('price_earning_ratio:股價淨值比')
            cheap_stocks = pb.is_smallest(10)
            ```
        """
        return _top_n(self, n, largest=False)

    def rank(
        self,
        *args: object,
        valid: pd.DataFrame | pd.Series | None = None,
        **kwargs: object,
    ) -> FinlabDataFrame:
        """Cross-sectional or time-series ranking.

        Args:
            valid (DataFrame or Series of bool, optional):
                只有 valid 為 True 的 cell 才參與排名。
                valid 為 False/NaN 的 cell 在排名前設為 NaN，
                因此不影響 pct=True 的分母。
                常見用法：fillna 後傳入原始 notna() mask，
                避免新上市或歷史不足的股票污染百分位排名。
        """
        # 1) 解析 axis，預設為 0（沿時間軸）
        axis = args[0] if args else kwargs.get("axis", 0)

        # 2) look-ahead 檢查
        if axis in (0, "index"):
            warnings.warn(
                "Unsafe rank: 排名沿時間軸 (axis=0) 可能洩漏未來資料；"
                "請改用 rolling().rank()、expanding().rank()，或 axis=1。",
                LookaheadWarning,
                stacklevel=2,
            )

        # 3) Fast path: numpy argsort for axis=1 (cross-sectional) ranking
        #    Rank on raw data BEFORE index_str_to_date to avoid expensive
        #    row expansion (e.g. quarterly 51 rows -> daily 2110 rows).
        pct = kwargs.get("pct", False)
        ascending = kwargs.get("ascending", True)
        na_option = kwargs.get("na_option", "keep")

        if axis in (1, "columns") and na_option == "keep":
            source = self.where(valid) if valid is not None else self

            # Rank on the raw ndarray BEFORE index_str_to_date so we avoid the
            # expensive quarterly->daily row expansion, while delegating tie
            # handling to pandas.  The previous numpy-argsort fast path assigned
            # ordinal ranks (method="first"), which silently disagreed with
            # pandas' default method="average": tied cells received distinct
            # percentiles (e.g. low-cardinality/discrete factors), so the same
            # tied group had non-zero cross-sectional std instead of 0.
            method = kwargs.get("method", "average")
            ranks = pd.DataFrame(np.asarray(source.values, dtype=float)).rank(
                axis=1,
                method=method,
                ascending=ascending,
                pct=pct,
                na_option="keep",
            )

            result = FinlabDataFrame(
                ranks.to_numpy(), index=source.index, columns=source.columns
            )
            return result.index_str_to_date()

        # 4) Fallback: full index conversion + pandas rank
        converted = self.index_str_to_date()
        if valid is not None:
            converted = converted.where(valid)
        rank = cast("Callable[..., pd.DataFrame]", pd.DataFrame.rank)
        ranked = rank(converted, *args, **kwargs)
        return FinlabDataFrame(ranked)

    def rise(self, n: int = 1) -> FinlabDataFrame:
        """數值上升中

        取是否比前第n筆高，若符合條件的值則為True，反之為False。
        <img src="https://i.ibb.co/Y72bN5v/Screen-Shot-2021-10-26-at-6-43-41-AM.png" alt="Screen-Shot-2021-10-26-at-6-43-41-AM">
        Args:
          n (positive-int): 設定比較前第n筆高。
        Returns:
          (pd.DataFrame): data
        Examples:
            收盤價是否高於10日前股價
            ```py
            from finlab import data
            data.get('price:收盤價').rise(10)
            ```
        """
        return self > self.shift(n)

    def fall(self, n: int = 1) -> FinlabDataFrame:
        """數值下降中

        取是否比前第n筆低，若符合條件的值則為True，反之為False。
        <img src="https://i.ibb.co/Y72bN5v/Screen-Shot-2021-10-26-at-6-43-41-AM.png" alt="Screen-Shot-2021-10-26-at-6-43-41-AM">
        Args:
          n (positive-int): 設定比較前第n筆低。
        Returns:
          (pd.DataFrame): data
        Examples:
            收盤價是否低於10日前股價
            ```py
            from finlab import data
            data.get('price:收盤價').fall(10)
            ```
        """
        return self < self.shift(n)

    def rebalance(self, freq: str | pd.Index | list) -> FinlabDataFrame:
        """Downsample to keep only the last observation per period.

        Equivalent to ``self.resample(freq).last()``.

        Args:
            freq: Pandas frequency string, e.g. ``'ME'`` (month-end),
                ``'W'`` (weekly), ``'QE'`` (quarter-end), or explicit dates
                to select with ``reindex``.
        """
        if not isinstance(freq, str):
            return FinlabDataFrame(self.reindex(pd.DatetimeIndex(freq)))
        return FinlabDataFrame(self.resample(freq).last())

    def lazy(self) -> LazyWide:
        """Wrap this DataFrame into a lazy computation handle.

        Returns a ``LazyWide`` proxy that records operations without
        executing them.  Call ``.rebalance(freq)`` or ``.collect()``
        on the result to trigger execution at specific dates only.

        Example::

            close = data.get('price:收盤價')
            position = (
                close.lazy()
                .rolling(60).mean()
                .rank(axis=1, pct=True)
                .is_largest(10)
                .rebalance('M')
            )
        """
        from finlab.dataframe.lazy import lazy

        return lazy(self)

    def quantile_row(self, c: float) -> pd.Series:
        """股票當天數值分位數

        取得每列c定分位數的值。
        Args:
          c (positive-int): 設定每列 n 定分位數的值。
        Returns:
          (pd.DataFrame): data
        Examples:
            取每日股價前90％分位數
            ```py
            from finlab import data
            data.get('price:收盤價').quantile_row(0.9)
            ```
        """
        return self.index_str_to_date().quantile(c, axis=1)


def _top_n(df: FinlabDataFrame, n: int, *, largest: bool) -> FinlabDataFrame:
    """Vectorised top-/bottom-n row selector for is_largest/is_smallest.

    Uses ``np.argpartition`` (``O(ncols)`` per row) instead of a full
    ``argsort`` to find the top/bottom threshold without a full sort.
    Values tied at the threshold are selected in their original column
    order, matching stable sort semantics.
    """

    vals = df.to_numpy(dtype="float64", na_value=np.nan, copy=True)
    nrows, ncols = vals.shape

    if nrows == 0 or ncols == 0 or n <= 0:
        return FinlabDataFrame(
            np.zeros((nrows, ncols), dtype=bool),
            index=df.index,
            columns=df.columns,
        )

    valid = ~np.isnan(vals)
    if n >= ncols:
        return FinlabDataFrame(valid, index=df.index, columns=df.columns)

    if largest:
        np.negative(vals, out=vals)
    vals[~valid] = np.inf

    result = np.zeros((nrows, ncols), dtype=bool)
    valid_count = valid.sum(axis=1)
    select_all = valid_count <= n
    result[select_all] = valid[select_all]

    rows = np.flatnonzero(~select_all)
    if rows.size:
        partition_idx = np.argpartition(vals, n - 1, axis=1)
        thresholds = vals[rows, partition_idx[rows, n - 1]].copy()
        del partition_idx

        better = vals[rows] < thresholds[:, None]
        result[rows] = better

        for row, threshold in zip(rows, thresholds, strict=True):
            need = n - int(result[row].sum())
            if need <= 0:
                continue
            ties = valid[row] & (vals[row] == threshold)
            tie_idx = np.flatnonzero(ties)
            result[row, tie_idx[:need]] = True

    return FinlabDataFrame(result, index=df.index, columns=df.columns)
