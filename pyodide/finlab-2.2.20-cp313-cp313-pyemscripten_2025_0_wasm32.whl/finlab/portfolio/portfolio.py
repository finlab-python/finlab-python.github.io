from __future__ import annotations

import logging
from functools import reduce
from typing import TYPE_CHECKING, TypeAlias, TypeGuard, cast

__all__ = ["Portfolio"]

if TYPE_CHECKING:
    from collections.abc import Callable

import pandas as pd

from finlab.core.report import UPLOAD_TRADES_LIMIT, Report, ReportExecution

logger = logging.getLogger(__name__)

PositionScheduler: TypeAlias = ReportExecution
POSITION_SCHEDULER_CLASS: type[ReportExecution] = ReportExecution


def is_position_scheduler(value: object) -> TypeGuard[PositionScheduler]:
    return isinstance(value, POSITION_SCHEDULER_CLASS)


def _daily_returns(reports: dict[str, Report]) -> pd.DataFrame:
    """Daily returns of each report on the union of their dates.

    A report without a row on a date (its market was closed, or it had not
    started yet) earns 0 that day.
    """
    return pd.DataFrame(
        {k: report.creturn.pct_change() for k, report in reports.items()}
    ).fillna(0)


def _compound(pct: pd.DataFrame, weight: pd.Series | pd.DataFrame) -> pd.Series:
    return (pct * weight).sum(axis=1).add(1).cumprod()


def _compute_returns(reports: dict[str, tuple[Report, float]]) -> pd.Series:
    """Cumulative returns over the period every report covers, starting from 1."""
    start = max(report.creturn.index[0] for report, _ in reports.values())
    end = min(report.creturn.index[-1] for report, _ in reports.values())
    pct = _daily_returns({k: report for k, (report, _) in reports.items()}).loc[
        start:end
    ]
    pct.iloc[0] = 0
    return _compound(pct, pd.Series({k: w for k, (_, w) in reports.items()}))


def _compute_position(reports: dict[str, tuple[Report, float]]) -> pd.DataFrame:
    """Blend sub-report positions on the union of their rebalance dates."""
    union_cols: list[str] = sorted(
        {col for report, _ in reports.values() for col in report.position.columns}
    )
    union_dates = reduce(
        pd.Index.union, (report.position.index for report, _ in reports.values())
    )
    return sum(
        report.position.reindex(columns=union_cols)
        .fillna(0)
        .reindex(index=union_dates, method="ffill", fill_value=0)
        * w
        for report, w in reports.values()
    )


def _merge_trades(reports: dict[str, tuple[Report, float]]) -> pd.DataFrame:
    """Merge trades from all sub-reports, sorted by entry date."""
    parts = []
    for report, weight in reports.values():
        trades = report.trades
        # Futures trades have no position column.
        if "position" in trades.columns:
            trades = trades.assign(position=trades["position"] * weight)
        parts.append(trades)

    trades = pd.concat(parts).sort_values("entry_sig_date").reset_index(drop=True)
    trades.index.name = "trade_index"
    return trades


def _merge_mae_mfe(reports: dict[str, tuple[Report, float]]) -> pd.DataFrame:
    """Merge MAE/MFE data from sub-reports."""
    parts = [
        v[0].mae_mfe
        for v in reports.values()
        if hasattr(v[0], "mae_mfe") and len(v[0].mae_mfe) > 0
    ]
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def _get_source_execution(report: Report) -> object | None:
    """Extract the execution source from a report."""
    if hasattr(report, "execution"):
        return report.execution
    if hasattr(report, "position_schedulers"):
        return report.position_schedulers
    return None


def _build_position_schedulers(
    reports: dict[str, tuple[Report, float]],
) -> dict[str, PositionScheduler]:
    """Build the position_schedulers dict from sub-reports."""
    schedulers: dict[str, PositionScheduler] = {}
    for name, (report, weight) in reports.items():
        if "|" in name:
            raise ValueError('name should not contain "|"')

        source_execution = _get_source_execution(report)

        if isinstance(source_execution, dict):
            for sub_name, sub_exec in source_execution.items():
                if not is_position_scheduler(sub_exec):
                    raise ValueError(
                        f"position_schedulers[{sub_name}] should be a PositionScheduler"
                    )
                schedulers[f"{name}|{sub_name}"] = sub_exec._replace(
                    total_weight=sub_exec.total_weight * weight
                )
        elif is_position_scheduler(source_execution):
            schedulers[name] = source_execution._replace(
                total_weight=source_execution.total_weight * weight
            )
        elif isinstance(report, Report):
            execution = report.execution
            if is_position_scheduler(execution):
                schedulers[name] = execution._replace(total_weight=weight)

    return schedulers


def _validate_schedulers(schedulers: dict[str, PositionScheduler]) -> None:
    """Validate that all schedulers have correct types."""
    for name, scheduler in schedulers.items():
        if not is_position_scheduler(scheduler):
            raise ValueError(
                "position_schedulers should be a dict of PositionScheduler"
            )
        if not isinstance(scheduler.weights, pd.Series):
            raise ValueError(f"weights should be a pd.Series for scheduler '{name}'")
        if not isinstance(scheduler.next_weights, pd.Series):
            raise ValueError(
                f"next_weights should be a pd.Series for scheduler '{name}'"
            )


class Portfolio(Report):
    def __init__(
        self,
        reports: dict[str, tuple[Report, float]] | Report,
        *,
        _creturn: pd.Series | None = None,
    ) -> None:
        """建構 Portfolio 物件。

        Parameters:
            - reports (dict[str, tuple[Report, float]]): 代表投資組合的字典，key 為資產名稱，value 是回測報告與部位。
            A dictionary representing the portfolio, where the keys are the names of the assets and the values are tuples containing the asset's report and weight.

        Notes:
            部位採各子報告換股日期的聯集，延用最近一次目標；尚未開始的策略權重留作現金。
            組合報酬從所有非零權重策略都開始的那天起算（基準 1），到最早結束的策略為止，可能比部位期間短；
            期間內某策略沒有資料的日子（例如該市場休市）報酬為 0，其他策略照常計入。
            Positions use the union of rebalance dates, carrying each strategy's latest
            target forward with cash before its first target. Cumulative returns start
            at 1 on the first date every nonzero-weight strategy covers and end on the
            earliest last date, so their period may be shorter than the position
            history; a strategy with no row on a date in between (its market was
            closed) earns 0 that day while the others still count.


        Example:
            **組合多個策略**
            ```
            from finlab import sim
            from finlab.portfolio import Portfolio

            # 請參閱 sim 函數的文件以獲取更多信息
            # https://doc.finlab.tw/getting-start/

            report_strategy1 = sim(...)
            report_strategy2 = sim(...)
            report_strategy3 = sim(...)

            portfolio = Portfolio({
                'strategy1': (report_strategy1, 0.3),
                'strategy2': (report_strategy2, 0.4),
                'strategy3': (report_strategy3, 0.3),
            })
            ```
        """

        # mind user about this is the beta version
        logger.info(
            "Portfolio is in beta version, please report any issue to FinLab Team at https://discord.gg/tAr4ysPqvR"
        )

        if isinstance(reports, Report):
            reports = {"strategy": (reports, 1.0)}

        # Filter out strategies with zero weight to ensure consistency
        active_reports = {k: v for k, v in reports.items() if v[1] != 0}
        if not active_reports:
            raise ValueError(
                "All strategies have zero weight. At least one strategy must have non-zero weight."
            )

        self.portfolio: dict[str, tuple[Report, float]] = reports
        creturn = _compute_returns(active_reports) if _creturn is None else _creturn
        self.creturn: pd.Series = creturn
        self.position: pd.DataFrame = _compute_position(reports)

        sample_report = next(iter(reports.values()))[0]
        next_trading_date = min(v[0].next_trading_date for v in reports.values())

        super().__init__(
            creturn,
            self.position,
            sample_report.fee_ratio,
            sample_report.tax_ratio,
            sample_report.trade_at,
            next_trading_date,
            sample_report.market,
        )

        self.trades: pd.DataFrame = _merge_trades(reports)
        # Uploads keep only the latest trades; live performance starts at the first of them.
        self.live_performance_start: pd.Timestamp = self.trades.entry_sig_date.tail(
            UPLOAD_TRADES_LIMIT
        ).min()
        self.stop_loss: float | None = None
        self.take_profit: float | None = None
        self.trail_stop: float | None = None
        self.resample: str | None = None
        self.mae_mfe: pd.DataFrame = _merge_mae_mfe(reports)

        self.position_schedulers = _build_position_schedulers(reports)
        _validate_schedulers(self.position_schedulers)
        self.execution: dict[str, PositionScheduler] = self.position_schedulers

    @classmethod
    def from_weight_function(
        cls, reports: dict[str, Report], weight_function: Callable[[], pd.DataFrame]
    ) -> Portfolio:
        weight = weight_function()
        if not set(reports).issubset(weight.columns):
            raise ValueError("Report names must be a subset of weight columns")
        if not weight.iloc[-1].notna().all():
            raise ValueError("Latest weight row contains NaN values")

        pct = _daily_returns(reports)
        # Rebalance at the first close on or after each weight date; the new
        # weights earn from the next trading day, so a weight never sees its own day.
        effective = weight[pct.columns].reindex(pct.index, method="ffill").shift(1)
        current_weight = weight.iloc[-1]
        return cls(
            {k: (r, current_weight[k]) for k, r in reports.items()},
            _creturn=_compound(pct, effective),
        )

    def position_info2(self) -> dict[str, object]:
        # get position info for all reports in self.portfolio
        position: dict[str, object] = {}

        for name, (report, weight) in self.portfolio.items():
            pinfo = report.position_info2()

            if "positionConfig" in pinfo:
                config = cast("dict[str, float]", pinfo["positionConfig"])
                config["weight"] = weight
                position[name] = pinfo

            # handle recursive position
            else:
                for sub_name, sub_position in pinfo.items():
                    sub_position = cast("dict[str, object]", sub_position)
                    config = cast("dict[str, float]", sub_position["positionConfig"])
                    config["weight"] *= weight
                    position[f"{name}|{sub_name}"] = sub_position

        return position

    def is_stop_triggered(self) -> bool:
        position_schedulers = self.position_schedulers
        if not isinstance(position_schedulers, dict):
            position_schedulers = {"strategy": position_schedulers}

        for scheduler in position_schedulers.values():
            if scheduler.actions.isin(["sl", "tp"]).any():
                return True

        return False
