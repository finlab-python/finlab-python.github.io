"""Read-only plans and provider receipts for ordinary whole-dataset reads."""

from collections.abc import Callable, Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any

from . import auth

_active: ContextVar[tuple] = ContextVar("download_receipts", default=())


def record(dataset: str, event: str = "fallback", **fields: Any) -> dict:
    row = dict(dataset=dataset, event=event, **fields)
    for collector in _active.get():
        collector.append(row)
    return row


@contextmanager
def download_usage() -> Iterator[list[dict]]:
    """Collect rows for pandas CSV/JSON export, including before an error."""
    rows: list[dict] = []
    token = _active.set((*_active.get(), rows))
    try:
        yield rows
    finally:
        _active.reset(token)


def signing_receipts(items: list[dict]) -> Callable[[dict], dict]:
    """Open each attempt before sending; immediately acknowledge its response."""
    if not _active.get():
        return lambda reply: reply
    pending = []
    for item in items:
        payload = auth._blob_to_dataset(item["blob_name"])
        pending.append(
            record(
                payload.removesuffix(".recent").removesuffix(".delta"),
                "provider",
                payload=payload,
                billed_bytes=None,
                error="signing_reply_unavailable",
            )
        )

    def received(reply: dict) -> dict:
        for raw in reply.get("results", [reply]):
            if raw is None:
                continue
            key = auth._dataset_key_from_raw_result(raw)
            row = next(
                (row for row in pending if key is None or row["payload"] == key), None
            )
            if row is not None:
                pending.remove(row)
                row.update({k: raw.get(k) for k in ("billed_bytes", "quota", "error")})
        return reply

    return received
