"""Readiness of the exact datasets loaded in the current data context."""

from __future__ import annotations

import datetime as dt
import json
import weakref
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from finlab.market import Market
    from finlab.session_calendar import SessionCalendar

    from .context import DataContext
    from .storage import CacheStorage, FileStorage

from finlab.session_calendar import UTC

from .calendar import get_calendar
from .context import _default_context
from .publication import METADATA_KEY, DatasetSnapshot, evaluate_readiness
from .revisions import publication, published, published_delta
from .table_delta import DELTA_SUFFIX

# Hashes computed for caches without an embedded one: storage -> name -> (version, hash).
_computed: weakref.WeakKeyDictionary[
    CacheStorage | FileStorage, dict[str, tuple[object, str | None]]
] = weakref.WeakKeyDictionary()


def _content_hash(
    storage: CacheStorage | FileStorage, name: str, version: object
) -> str | None:
    """Hash of the cached *version*: embedded in the cache, else computed once.

    None when the cache no longer holds that version.
    """
    if storage.cache_version(name) != version:
        return None
    digest = storage.published_hash(name)
    if digest is not None:
        return digest
    computed = _computed.setdefault(storage, {})
    if name in computed and computed[name][0] == version:
        return computed[name][1]
    frame = storage.get_dataframe(name)
    if frame is None or storage.cache_version(name) != version:
        return None
    from .get import hash as frame_hash

    try:
        digest = frame_hash(frame)
    except (ValueError, TypeError):  # unhashable cells: no evidence for this one
        digest = None
    computed[name] = (version, digest)
    return digest


def _snapshot(ctx: DataContext, name: str) -> DatasetSnapshot:
    """The index's evidence for the version the strategy read, of its table or delta.

    A hash binds it to those bytes; nothing is asked of the signing service.
    Without a valid index, or for other bytes, there is none.
    """
    refresh = not ctx.use_local_data_only
    table = publication(name, refresh=refresh)
    # A delta counts only while it extends the published base, as for data.get.
    extended = published_delta(name, published(name, refresh=False)) is not None
    delta = publication(name + DELTA_SUFFIX, refresh=False) if extended else None
    candidates = [  # the delta, when current, is the latest publication
        found
        for found in (delta, table)
        if found is not None and found.profile is not None
    ]
    if not candidates:
        return DatasetSnapshot("", {})
    digest = _content_hash(ctx._storage, name, _read_version(ctx, name))
    for found in candidates:
        if found.content_hash == digest and found.profile is not None:
            return DatasetSnapshot(
                found.content_hash,
                {
                    "hash": found.content_hash,
                    METADATA_KEY: json.dumps(found.profile.get("evidence")),
                    "refresh_policy": found.profile.get("refresh_policy"),
                    "data_period": found.profile.get("data_period"),
                    "observed_at": dt.datetime.fromtimestamp(
                        found.observed_at, UTC
                    ).isoformat(),
                },
            )
    return DatasetSnapshot("", {})


def _read_version(ctx: DataContext, name: str) -> object:
    """The cache version the strategy read: recorded at load, else the current one."""
    record = ctx._loaded_versions.get(name)
    return ctx._storage.cache_version(name) if record is None else record[0]


def _selection_reason(ctx: DataContext, market: Market | None) -> str | None:
    if market is not None and (
        market.get_name() != "tw_stock" or market.get_freq() not in {"D", "1D"}
    ):
        return "unsupported_market"
    if not ctx._loaded_datasets:
        return "no_loaded_data"
    if (
        ctx.truncate_start is not None
        or ctx.truncate_end is not None
        or ctx._loaded_datasets.intersection(ctx._projected_datasets)
    ):
        # Hashes describe raw cached objects, not data.get's projected frames.
        return "historical_data_selection"
    return None


def readiness(
    market: Market | None = None,
    *,
    execution_session: str | dt.date | None = None,
    now: dt.datetime | None = None,
    calendar: SessionCalendar | None = None,
) -> dict[str, Any]:
    """Describe whether all loaded data is current by its pre-open schedule.

    Scheduled checks are not guaranteed delivery deadlines. Unknown evidence,
    unsupported markets, stale calendars and unavailable sources return false.
    Calling this never silently replaces data already used by a strategy.
    """
    live_clock = now is None
    now = now or dt.datetime.now(UTC)
    ctx = _default_context
    base: dict[str, Any] = {
        "schema_version": 1,
        "validation_version": 2,
        "scope": "execution_session" if execution_session else "next_market_open",
        "checked_at": now.isoformat(),
        "final_ready": False,
        "datasets": {},
        "reason": None,
    }
    selection_reason = _selection_reason(ctx, market)
    if selection_reason:
        return {**base, "reason": selection_reason}
    try:
        calendar = calendar or get_calendar(now=now)
        calendar.require_usable(now)
        session = (
            dt.date.fromisoformat(str(execution_session))
            if execution_session
            else calendar.next_open(now).date()
        )
        datasets = {name: _snapshot(ctx, name) for name in sorted(ctx._loaded_datasets)}
        # Reading the index or hashing a cache may finish after the initial
        # timestamp. Evaluate at completion, keeping the original execution
        # session so a check crossing opening cannot certify the closed window.
        now = dt.datetime.now(UTC) if live_clock else now
        base["checked_at"] = now.isoformat()
        evaluation = evaluate_readiness(calendar, session, datasets, now=now)
        return {**base, **evaluation}
    except Exception as exc:  # noqa: BLE001 -- optional readiness must fail closed, never break data access
        return {
            **base,
            "reason": "readiness_unavailable",
            "error_type": type(exc).__name__,
        }


def snapshot_is_ready(snapshot: dict | None, *, now: dt.datetime | None = None) -> bool:
    """A saved True is applicable only before its original execution cutoff."""
    now = now or dt.datetime.now(UTC)
    try:
        return bool(
            snapshot
            and type(snapshot.get("validation_version")) is int
            and snapshot.get("validation_version") == 2
            and snapshot.get("final_ready") is True
            and dt.datetime.fromisoformat(snapshot["checked_at"])
            <= now
            < dt.datetime.fromisoformat(snapshot["update_end_at"])
        )
    except (KeyError, TypeError, ValueError):
        return False
