"""Published revision of each dataset, from a shared index read at most every five minutes.

fdata republishes ``data-revisions/v1/<bucket>.json`` whenever an item bucket
changes. Each blob maps to ``[revision, full_refresh_before, expiry]`` in UTC
epoch seconds. A cache stamped at or after ``revision`` is current; an older one
updates through ``.recent`` unless it predates ``full_refresh_before``. The
revision never postdates the published bytes, so stamping it after a download
can at worst make the next check fetch again; it never hides a change.

A large full table also has a ``<dataset>.delta`` entry (see
:mod:`.table_delta`): published no earlier than its base, it is the dataset's
latest revision, and caches dated from its ``full_refresh_before`` on merge it.

``publications`` maps the same blobs to ``[hash, profile index or null]``, the
table hash and an index into the deduplicated ``publication_profiles``: the
refresh policy, readiness evidence and data period the signing service would
report, observed when the index was generated (``generated_at``).

Every process on the machine shares one check: the index is kept in the
default data directory (``get_tmp_dir()``) with the time it was checked, so a
script started within five minutes of another reads it from disk instead of
the network.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Any, NamedTuple

from finlab.utils import atomic_replace, get_tmp_dir

from .auth import _dataset_to_blob, get_public_json
from .market import _get_bucket_for_dataset
from .table_delta import DELTA_SUFFIX

logger = logging.getLogger(__name__)

INDEX_URL = "https://r2.finlab.finance/data-revisions/v1/{bucket}.json"
CHECK_SECONDS = 5 * 60


class Published(NamedTuple):
    revision: float
    full_refresh_before: float
    expiry: int | None


class Publication(NamedTuple):
    """A blob's table hash and readiness profile, observed at *observed_at* (epoch seconds)."""

    content_hash: str
    profile: dict | None  # refresh_policy, evidence, data_period; None: no evidence
    observed_at: float


class _Index(NamedTuple):
    entries: dict[str, Published]  # by blob name
    expires_at: float  # epoch seconds the index stops being valid
    checked_at: float
    publications: dict[str, Publication]  # by blob name


_EMPTY_INDEX = _Index({}, 0.0, 0.0, {})
_indexes: dict[str, _Index] = {}
_bucket_locks: dict[str, threading.Lock] = {}
# dataset -> (entry the signing service vouched for, when vouched)
_confirmed: dict[str, tuple[Published, float]] = {}


def _within_check(at: float) -> bool:
    """Whether *at* (epoch seconds) is inside the current check interval.

    A clock set back puts *at* in the future, which counts as outside.
    """
    return 0 <= time.time() - at < CHECK_SECONDS


def _parse(payload: Any, checked_at: float) -> _Index:
    if payload["version"] != 1:
        raise ValueError("Unsupported revision index version")
    entries = {blob: Published(*entry) for blob, entry in payload["datasets"].items()}
    return _Index(
        entries,
        float(payload["expires_at"]),
        checked_at,
        _publications(payload),
    )


def _publications(payload: Any) -> dict[str, Publication]:
    """The index's publications by blob; none when absent or malformed, never an error."""
    try:
        generated_at = float(payload["generated_at"])
        profiles = payload["publication_profiles"]
        publications = {}
        for blob, (digest, at) in payload["publications"].items():
            profile = None if at is None else profiles[at]
            if at is not None and (
                type(at) is not int or at < 0 or not isinstance(profile, dict)
            ):
                raise ValueError("Invalid publication profile")
            if isinstance(digest, str) and digest:
                publications[blob] = Publication(digest, profile, generated_at)
        return publications
    except (KeyError, TypeError, ValueError, IndexError, AttributeError):
        return {}


def _check(bucket: str) -> _Index:
    """The bucket's index and when it was checked, by any process on this machine."""
    path = os.path.join(get_tmp_dir(), f"data-revisions#{bucket}.json")
    try:
        with open(path, encoding="utf-8") as f:
            shared = json.load(f)
        if _within_check(shared["checked_at"]):
            return _parse(shared["index"], shared["checked_at"])
    except Exception:  # noqa: BLE001 -- a missing or unreadable copy is checked online
        pass
    checked_at = time.time()
    payload = get_public_json(INDEX_URL.format(bucket=bucket))
    index = _parse(payload, checked_at)

    def write(tmp_path: str) -> None:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump({"checked_at": checked_at, "index": payload}, f)

    try:
        atomic_replace(path, write)
    except OSError as exc:
        logger.debug("Revision index for %s not shared: %s", bucket, exc)
    return index


def _valid_index(dataset: str, refresh: bool) -> _Index:
    """The index of *dataset*'s bucket, empty once it has expired.

    A failed check keeps the previous index until it expires. ``refresh=False``
    never goes online and answers from the index already read.
    """
    bucket = _get_bucket_for_dataset(dataset)
    with _bucket_locks.setdefault(bucket, threading.Lock()):
        index = _indexes.get(bucket, _EMPTY_INDEX)
        if refresh and not _within_check(index.checked_at):
            try:
                index = _check(bucket)
            except Exception as exc:  # noqa: BLE001 -- the index is optional; data.get falls back to the server
                logger.debug("Revision index for %s unavailable: %s", bucket, exc)
                index = index._replace(checked_at=time.time())
            _indexes[bucket] = index
    return index if time.time() < index.expires_at else _EMPTY_INDEX


def published(dataset: str, *, refresh: bool = True) -> Published | None:
    """The dataset's published revision, or None to ask the signing service.

    A missing index costs speed, not freshness. ``refresh=False`` never goes
    online and answers from the index already read.
    """
    entry = _valid_index(dataset, refresh).entries.get(_dataset_to_blob(dataset))
    if entry is None:
        entry, confirmed_at = _confirmed.get(dataset, (None, 0.0))
        if not _within_check(confirmed_at):
            return None
    return entry


def publication(dataset: str, *, refresh: bool = True) -> Publication | None:
    """The dataset's table hash and readiness profile, or None when unknown.

    Unlike :func:`published`, nothing else vouches for it: without a valid
    index there is none. ``refresh=False`` never goes online.
    """
    return _valid_index(dataset, refresh).publications.get(_dataset_to_blob(dataset))


def published_delta(dataset: str, base: Published | None) -> Published | None:
    """The table delta extending *base*, from the index *base* was read from.

    A delta older than its base (the base was republished without it) is none.
    """
    if base is None:
        return None
    delta = published(dataset + DELTA_SUFFIX, refresh=False)
    return delta if delta is not None and delta.revision >= base.revision else None


def confirm(dataset: str, revision: float) -> None:
    """Vouch for a cache the signing service just brought up to date.

    Covers datasets the index cannot vouch for (it is unreachable, or the name
    is an alias the service resolves) until the next check, instead of asking
    on every read.
    """
    _confirmed[dataset] = (Published(revision, 0, None), time.time())
