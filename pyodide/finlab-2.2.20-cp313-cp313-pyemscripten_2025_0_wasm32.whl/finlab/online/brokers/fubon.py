"""
FubonAccount 模組

實現與富邦證券 API 交互的 Account 類
"""

from __future__ import annotations

import datetime
import logging
import os
import time
from decimal import Decimal
from typing import Any

from fubon_neo.constant import BSAction, MarketType, OrderType, PriceType, TimeInForce
from fubon_neo.sdk import FubonSDK
from fubon_neo.sdk import Order as FBOrder

from finlab import data
from finlab.markets.tw import TWMarket
from finlab.online.core.account import Account, Order, Stock
from finlab.online.core.enums import *
from finlab.online.core.position import Position
from finlab.online.core.realtime_helpers import (
    build_bidask_from_quote,
    build_ticks_from_intraday_trade_rows,
)
from finlab.online.core.realtime_models import (
    BalanceUpdate,
    BidAsk,
    ConnectionState,
    Fill,
    OrderUpdate,
    Tick,
)
from finlab.online.core.realtime_normalizers import (
    get_field_value,
    get_first_valid_float,
    to_optional_float,
)
from finlab.online.core.realtime_provider import RealtimeProvider

# 常數定義
STOCK_LOT_SIZE = 1000  # 一張股票的股數
ODD_LOT_THRESHOLD = STOCK_LOT_SIZE  # 零股判斷閾值


class FubonAccount(Account, RealtimeProvider):
    """
    富邦證券賬戶類
    實現與富邦證券 API 的交互
    """

    required_module = "fubon_neo"  # 需要的 Python 包名稱
    module_version = "1.0.0"  # 需要的版本號

    def __init__(
        self,
        base_url: str | None = None,
        national_id: str | None = None,
        account: str | None = None,
        account_pass: str | None = None,
        cert_path: str | None = None,
        cert_pass: str | None = None,
    ) -> None:
        """
        初始化富邦證券賬戶

        Args:
            national_id (str, optional): 身分證字號。預設從環境變數獲取。
            account (str, optional): 帳號。預設從環境變數獲取。
            account_pass (str, optional): 登入密碼。預設從環境變數獲取。
            cert_path (str, optional): 憑證路徑。預設從環境變數獲取。
            cert_pass (str, optional): 憑證密碼。預設從環境變數獲取。
        """
        # 從參數或環境變數獲取登錄信息
        self.base_url = base_url or os.environ.get("FUBON_BASE_URL")
        self.national_id = national_id or os.environ.get("FUBON_NATIONAL_ID")
        self.account = account or os.environ.get("FUBON_ACCOUNT")
        self.account_pass = account_pass or os.environ.get("FUBON_ACCOUNT_PASS")
        self.cert_path = cert_path or os.environ.get("FUBON_CERT_PATH")
        self.cert_pass = cert_pass or os.environ.get("FUBON_CERT_PASS")

        if not all([self.national_id, self.account_pass, self.cert_path]):
            raise ValueError(
                "缺少必要的登錄信息。請確保設置了 FUBON_NATIONAL_ID, FUBON_ACCOUNT_PASS, FUBON_CERT_PATH 環境變數或直接提供參數"
            )

        # 初始化市場和時間戳
        self.market = "tw_stock"
        self.order_records = {}
        self.timestamp_for_get_position = datetime.datetime(2021, 1, 1)
        self._tick_pct_change_cache = {}

        # 初始化 SDK 和帳戶
        logging.info("初始化富邦 SDK...")
        self.sdk = FubonSDK(30, 2, self.base_url)

        # 登入
        try:
            self.accounts = self.sdk.login(
                self.national_id, self.account_pass, self.cert_path, self.cert_pass
            )
        except Exception as e:
            logging.exception(f"登入失敗: {e}")
            raise Exception(f"無法登入富邦證券: {e}") from e

        # 選擇帳戶：指定的帳號找不到就報錯，不改用別的帳號（可能是另一個證券或期貨帳號）
        if self.account:
            self.target_account = next(
                (acc for acc in self.accounts.data if acc.account == self.account), None
            )
            if not self.target_account:
                raise ValueError(
                    f"未找到指定帳號 {self.account}，可用帳號："
                    f"{[acc.account for acc in self.accounts.data]}"
                )
        else:
            self.target_account = next(
                (
                    acc
                    for acc in self.accounts.data or []
                    if getattr(acc, "account_type", "stock") == "stock"
                ),
                None,
            )

        if not self.target_account:
            raise ValueError("無法獲取有效的富邦證券帳戶")

        print(self.target_account)
        logging.info(f"成功登入帳號: {self.target_account.account}")

        # 初始化行情連線
        try:
            self.sdk.init_realtime()
            logging.info("初始化行情元件成功")
        except Exception as e:
            logging.warning(f"初始化行情元件失敗: {e}")

        self._init_realtime()

    # ── RealtimeProvider implementation ──────────────────────────────

    @staticmethod
    def _parse_market_event_time(payload: Any) -> datetime.datetime:
        raw = get_field_value(payload, "time")
        if isinstance(raw, datetime.datetime):
            return raw
        ts = to_optional_float(raw)
        if ts is None:
            return datetime.datetime.now()
        try:
            if ts >= 10**14:  # microseconds
                return datetime.datetime.fromtimestamp(ts / 1_000_000)
            if ts >= 10**11:  # milliseconds
                return datetime.datetime.fromtimestamp(ts / 1_000)
            return datetime.datetime.fromtimestamp(ts)
        except (OSError, OverflowError, ValueError):
            return datetime.datetime.now()

    @staticmethod
    def _parse_realtime_action(value: Any) -> Action:
        text = str(value).upper()
        return Action.BUY if text in ("B", "BUY", "BSACTION.BUY") else Action.SELL

    @staticmethod
    def _parse_realtime_order_condition(value: Any) -> OrderCondition:
        text = str(value).upper()
        if "MARGIN" in text:
            return OrderCondition.MARGIN_TRADING
        if "SHORT" in text:
            return OrderCondition.SHORT_SELLING
        if "DAYTRADE" in text:
            return OrderCondition.DAY_TRADING_SHORT
        return OrderCondition.CASH

    @staticmethod
    def _quantity_divisor(payload: Any) -> float:
        market_type = str(
            get_field_value(payload, "market_type")
            or get_field_value(payload, "marketType")
            or ""
        ).upper()
        if market_type in {"INTRADAYODD", "ODD", "EMGODD"}:
            return 1.0
        return float(STOCK_LOT_SIZE)

    def _parse_realtime_order_time(self, payload: Any) -> datetime.datetime:
        date_value = get_field_value(payload, "date")
        time_value = get_field_value(payload, "last_time") or get_field_value(
            payload, "filled_time"
        )
        if date_value and time_value:
            try:
                year, month, day = self._parse_date(str(date_value))
                hour, minute, second, microsecond = self._parse_time(str(time_value))
                return datetime.datetime(
                    year, month, day, hour, minute, second, microsecond
                )
            except Exception:
                pass
        return datetime.datetime.now()

    @staticmethod
    def _map_realtime_operation(payload: Any) -> str:
        function_type = int(get_first_valid_float(payload, "function_type") or -1)
        mapping = {
            0: "new",
            10: "new",
            15: "update_price",
            20: "update_qty",
            30: "cancel",
            50: "fill",
            90: "failed",
        }
        return mapping.get(function_type, "")

    def _map_realtime_status(self, payload: Any) -> OrderStatus:
        status_code = int(get_first_valid_float(payload, "status") or -1)
        status_map = {
            0: OrderStatus.NEW,
            4: OrderStatus.NEW,
            8: OrderStatus.NEW,
            9: OrderStatus.CANCEL,
            10: OrderStatus.NEW,
            14: OrderStatus.NEW,
            15: OrderStatus.NEW,
            19: OrderStatus.CANCEL,
            20: OrderStatus.NEW,
            24: OrderStatus.NEW,
            29: OrderStatus.CANCEL,
            30: OrderStatus.CANCEL,
            34: OrderStatus.CANCEL,
            39: OrderStatus.CANCEL,
            40: OrderStatus.PARTIALLY_FILLED,
            50: OrderStatus.FILLED,
            90: OrderStatus.CANCEL,
        }
        status = status_map.get(status_code, OrderStatus.NEW)

        divisor = self._quantity_divisor(payload)
        filled_qty = (
            get_first_valid_float(payload, "filled_qty", "mat_qty") or 0.0
        ) / divisor
        after_qty = (
            get_first_valid_float(payload, "after_qty", "quantity", "org_qty") or 0.0
        ) / divisor

        if status == OrderStatus.NEW and filled_qty > 0:
            if after_qty > 0 and filled_qty >= after_qty:
                return OrderStatus.FILLED
            return OrderStatus.PARTIALLY_FILLED
        if status == OrderStatus.CANCEL and filled_qty > 0:
            return OrderStatus.PARTIALLY_FILLED
        return status

    def _build_realtime_order_update(self, payload: Any) -> OrderUpdate:
        divisor = self._quantity_divisor(payload)
        quantity = (
            get_first_valid_float(payload, "after_qty", "quantity", "org_qty") or 0.0
        ) / divisor
        filled_quantity = (
            get_first_valid_float(payload, "filled_qty", "mat_qty") or 0.0
        ) / divisor
        price = (
            get_first_valid_float(
                payload, "after_price", "price", "od_price", "order_price"
            )
            or 0.0
        )

        return OrderUpdate(
            order_id=str(
                get_field_value(payload, "order_no")
                or get_field_value(payload, "seq_no")
                or ""
            ),
            stock_id=str(get_field_value(payload, "stock_no") or ""),
            action=self._parse_realtime_action(get_field_value(payload, "buy_sell")),
            price=price,
            quantity=quantity,
            filled_quantity=filled_quantity,
            status=self._map_realtime_status(payload),
            order_condition=self._parse_realtime_order_condition(
                get_field_value(payload, "order_type")
            ),
            time=self._parse_realtime_order_time(payload),
            operation=self._map_realtime_operation(payload),
            org_event=payload,
        )

    def _build_realtime_fill(self, payload: Any) -> Fill:
        divisor = self._quantity_divisor(payload)
        quantity = (
            get_first_valid_float(payload, "filled_qty", "mat_qty") or 0.0
        ) / divisor
        return Fill(
            order_id=str(
                get_field_value(payload, "order_no")
                or get_field_value(payload, "seq_no")
                or ""
            ),
            stock_id=str(get_field_value(payload, "stock_no") or ""),
            action=self._parse_realtime_action(get_field_value(payload, "buy_sell")),
            price=get_first_valid_float(payload, "filled_price", "mat_price", "price")
            or 0.0,
            quantity=quantity,
            time=self._parse_realtime_order_time(payload),
            org_event=payload,
        )

    def _get_realtime_balance(self) -> BalanceUpdate | None:
        result = self.sdk.accounting.bank_remain(self.target_account)
        if not result or not result.is_success or not result.data:
            return None

        payload = result.data
        available_balance = get_first_valid_float(
            payload, "available_balance", "availableBalance"
        )
        reserved_amount = get_first_valid_float(
            payload, "reserved_amount", "reservedAmount"
        )
        dedicated_account_balance = get_first_valid_float(
            payload, "dedicated_account_balance", "dedicatedAccountBalance"
        )
        # 子查詢失敗時該欄位留空，現金照常推送
        settlement = self._safe_call_number("get_settlement")
        total_balance = self._safe_call_number("get_total_balance")

        return BalanceUpdate(
            account_id=str(getattr(self.target_account, "account", "")),
            broker=self.__class__.__name__,
            available_balance=available_balance,
            reserved_amount=reserved_amount,
            dedicated_account_balance=dedicated_account_balance,
            cash=available_balance,
            settlement=settlement,
            total_balance=total_balance,
            time=datetime.datetime.now(),
            org_event=payload,
        )

    def connect_realtime(self) -> None:
        if self._realtime_connected:
            return

        # Quote websocket: tick (trades channel)
        def _on_message(message: Any) -> None:
            try:
                payload = message
                nested_data = get_field_value(message, "data")
                if (
                    nested_data is not None
                    and get_field_value(message, "symbol") is None
                ):
                    payload = nested_data

                symbol = get_field_value(payload, "symbol")
                if symbol:
                    symbol = str(symbol)
                    native_pct_change = get_first_valid_float(
                        payload,
                        "pct_change",
                        "pctChange",
                        "change_percent",
                        "changePercent",
                        "change_rate",
                    )
                    if native_pct_change is not None:
                        self._tick_pct_change_cache[symbol] = native_pct_change

                    trade_like = (
                        get_field_value(payload, "price") is not None
                        or get_field_value(payload, "size") is not None
                    )
                    if not trade_like:
                        return

                    price = get_first_valid_float(
                        payload,
                        "price",
                        "close",
                        "close_price",
                        "closePrice",
                        "lastPrice",
                    )
                    volume = int(
                        to_optional_float(get_field_value(payload, "size")) or 0
                    )
                    total_volume_value = get_field_value(payload, "total_volume")
                    if total_volume_value is None:
                        total_volume_value = get_field_value(payload, "totalVolume")
                    total_volume = int(to_optional_float(total_volume_value) or 0)
                    open_price = get_first_valid_float(
                        payload, "open", "open_price", "openPrice"
                    )
                    high_price = get_first_valid_float(
                        payload, "high", "high_price", "highPrice"
                    )
                    low_price = get_first_valid_float(
                        payload, "low", "low_price", "lowPrice"
                    )
                    if native_pct_change is None:
                        native_pct_change = self._tick_pct_change_cache.get(symbol)
                    self._emit_tick(
                        Tick(
                            stock_id=symbol,
                            price=price if price is not None else 0.0,
                            volume=volume,
                            total_volume=total_volume,
                            time=self._parse_market_event_time(payload),
                            open=open_price if open_price is not None else 0.0,
                            high=high_price if high_price is not None else 0.0,
                            low=low_price if low_price is not None else 0.0,
                            pct_change=native_pct_change,
                            source="trade",
                        )
                    )
            except Exception:
                logging.exception("Error in Fubon tick handler")

        def _on_book_message(message: Any) -> None:
            try:
                payload = message
                nested_data = get_field_value(message, "data")
                if (
                    nested_data is not None
                    and get_field_value(message, "symbol") is None
                ):
                    payload = nested_data

                stock_id = get_field_value(payload, "symbol")
                if not stock_id:
                    return

                bids = get_field_value(payload, "bids") or []
                asks = get_field_value(payload, "asks") or []
                self._emit_bidask(
                    BidAsk(
                        stock_id=str(stock_id),
                        bid_prices=[get_field_value(b, "price") or 0.0 for b in bids],
                        bid_volumes=[get_field_value(b, "size") or 0 for b in bids],
                        ask_prices=[get_field_value(a, "price") or 0.0 for a in asks],
                        ask_volumes=[get_field_value(a, "size") or 0 for a in asks],
                        time=self._parse_market_event_time(payload),
                    )
                )
            except Exception:
                logging.exception("Error in Fubon bidask handler")

        ws_client = self.sdk.marketdata.websocket_client.stock
        ws_client.on("message", _on_message)
        ws_client.on("book", _on_book_message)

        # Order/fill callbacks
        def _on_order(data: Any) -> None:
            try:
                self._emit_order_update(self._build_realtime_order_update(data))
            except Exception:
                logging.exception("Error in Fubon order handler")

        def _on_filled(data: Any) -> None:
            try:
                self._emit_fill(self._build_realtime_fill(data))
            except Exception:
                logging.exception("Error in Fubon fill handler")

        def _on_event(data: Any, event_type: Any) -> None:
            event_key = str(event_type).lower()
            if event_key in {"disconnect", "disconnected", "close"}:
                self._emit_connection(ConnectionState.DISCONNECTED, str(data))
            elif event_key in {"connect", "connected", "open"}:
                self._emit_connection(ConnectionState.CONNECTED, str(data))
            else:
                self._emit_connection(ConnectionState.ERROR, f"{event_type}: {data}")

        self.sdk.set_on_order(_on_order)
        if hasattr(self.sdk, "set_on_order_changed"):
            self.sdk.set_on_order_changed(_on_order)
        self.sdk.set_on_filled(_on_filled)
        if hasattr(self.sdk, "set_on_event"):
            self.sdk.set_on_event(_on_event)

        self._realtime_connected = True
        self._emit_connection(ConnectionState.CONNECTED)
        logging.info("Fubon realtime connected")

    def disconnect_realtime(self) -> None:
        if not self._realtime_connected:
            return
        try:
            ws_client = self.sdk.marketdata.websocket_client.stock
            ws_client.disconnect()
        except Exception:
            logging.exception("Error disconnecting Fubon websocket")
        self.unsubscribe_balances()
        self._realtime_connected = False
        self._emit_connection(ConnectionState.DISCONNECTED)
        logging.info("Fubon realtime disconnected")

    def subscribe_ticks(self, stock_ids: list[str]) -> None:
        ws_client = self.sdk.marketdata.websocket_client.stock
        for sid in stock_ids:
            ws_client.subscribe({"channel": "trades", "symbol": sid})
            # Fubon stock pct change is documented in aggregates.changePercent.
            ws_client.subscribe({"channel": "aggregates", "symbol": sid})

    def unsubscribe_ticks(self, stock_ids: list[str]) -> None:
        ws_client = self.sdk.marketdata.websocket_client.stock
        for sid in stock_ids:
            ws_client.unsubscribe({"channel": "trades", "symbol": sid})
            ws_client.unsubscribe({"channel": "aggregates", "symbol": sid})
            self._tick_pct_change_cache.pop(sid, None)

    def subscribe_bidask(self, stock_ids: list[str]) -> None:
        ws_client = self.sdk.marketdata.websocket_client.stock
        for sid in stock_ids:
            ws_client.subscribe({"channel": "books", "symbol": sid})

    def unsubscribe_bidask(self, stock_ids: list[str]) -> None:
        ws_client = self.sdk.marketdata.websocket_client.stock
        for sid in stock_ids:
            ws_client.unsubscribe({"channel": "books", "symbol": sid})

    def backfill_ticks(
        self,
        stock_ids: list[str],
        start_time: Any = None,
        end_time: Any = None,
        emit: bool = True,
    ) -> dict[str, list[Tick]]:
        if not self._ensure_marketdata_connection():
            return {}

        rest_stock = self.sdk.marketdata.rest_client.stock
        intraday = getattr(rest_stock, "intraday", None)
        if intraday is None or not hasattr(intraday, "trades"):
            raise NotImplementedError("Fubon SDK does not expose intraday.trades")

        backfilled = {}
        session_date = datetime.datetime.now().date()

        for stock_id in stock_ids:
            rows = []
            try:
                quote = self._get_stock_quote(stock_id) or {}
                prev_close = get_first_valid_float(
                    quote,
                    "previousClose",
                    "referencePrice",
                    "reference_price",
                )
                pct_change = get_first_valid_float(
                    quote,
                    "changePercent",
                    "pct_change",
                    "pctChange",
                )

                offset = 0
                limit = 500
                seen_pages = set()
                while True:
                    payload = intraday.trades(
                        symbol=stock_id, limit=limit, offset=offset
                    )
                    page_rows = (
                        payload.get("data", []) if isinstance(payload, dict) else []
                    )
                    if not page_rows:
                        break

                    page_marker = (
                        len(page_rows),
                        get_field_value(page_rows[0], "serial"),
                        get_field_value(page_rows[-1], "serial"),
                    )
                    if page_marker in seen_pages:
                        break
                    seen_pages.add(page_marker)

                    rows.extend(page_rows)

                    if len(page_rows) < limit:
                        break
                    offset += len(page_rows)

                ticks = build_ticks_from_intraday_trade_rows(
                    stock_id=stock_id,
                    rows=rows,
                    session_date=session_date,
                    prev_close=prev_close,
                    pct_change=pct_change,
                    start_time=start_time,
                    end_time=end_time,
                )

            except Exception:
                logging.exception(
                    "backfill_ticks: 無法回補股票 %s 的盤中 ticks", stock_id
                )
                ticks = []

            backfilled[stock_id] = ticks
            if emit:
                for tick in ticks:
                    self._emit_tick(tick)

        return backfilled

    def get_bidask_snapshot(
        self, stock_ids: list[str], emit: bool = True
    ) -> dict[str, BidAsk]:
        if not self._ensure_marketdata_connection():
            return {}

        snapshots = {}
        for stock_id in stock_ids:
            try:
                quote = self._get_stock_quote(stock_id)
                if not quote:
                    continue
                bidask = build_bidask_from_quote(stock_id, quote)
                snapshots[stock_id] = bidask
                if emit:
                    self._emit_bidask(bidask)
            except Exception:
                logging.exception(
                    "get_bidask_snapshot: 無法取得股票 %s 的五檔快照", stock_id
                )

        return snapshots

    # ── End RealtimeProvider ──────────────────────────────────────

    def __del__(self) -> None:
        """
        當物件被刪除時，確保登出
        """
        try:
            if hasattr(self, "sdk") and hasattr(self.sdk, "logout"):
                self.sdk.logout()
        except Exception as e:
            logging.warning(f"登出時發生錯誤: {e}")

    def get_cash(self) -> float:
        """
        獲取可用資金

        Returns:
            float: 可用資金

        Raises:
            ValueError: 查詢失敗時，不回傳 0，避免總淨值少算現金
        """
        result = self.sdk.accounting.bank_remain(self.target_account)
        if result and result.is_success and result.data:
            return float(getattr(result.data, "available_balance", 0))
        raise ValueError(
            "無法獲取可用資金（富邦只支援交割銀行為台北富邦銀行或 LINE Bank 的帳戶查詢）: "
            f"{getattr(result, 'message', '未知錯誤')}"
        )

    def get_orders(self) -> dict[str, Order]:
        """
        獲取所有委託單

        Returns:
            dict: 委託單字典，以委託單編號為鍵

        Raises:
            ValueError: 查詢失敗（例如限流、逾時）時，不回傳空委託，避免舊單沒被取消
        """
        result = self.sdk.stock.get_order_results(self.target_account)
        if not result or not result.is_success:
            raise ValueError(
                f"get_orders: 獲取委託單失敗: {getattr(result, 'message', '未知錯誤')}"
            )

        order_dict = {}
        for order in result.data or []:
            finlab_order = self._create_finlab_order(order)
            order_dict[finlab_order.order_id] = finlab_order

        return order_dict

    def _map_order_action(self, order: Any) -> Action:
        """
        將富邦買賣別映射到 finlab Action

        Args:
            order: 富邦 API 返回的委託單對象

        Returns:
            Action: finlab 買賣操作
        """
        buy_sell = getattr(order, "buy_sell", None)
        if buy_sell == BSAction.Buy:
            return Action.BUY
        if buy_sell == BSAction.Sell:
            return Action.SELL
        # 無法識別買賣別時，嘗試從其他欄位判斷
        if hasattr(order, "buy_sell") and isinstance(order.buy_sell, str):
            if order.buy_sell.upper() in ["B", "BUY"]:
                return Action.BUY
            if order.buy_sell.upper() in ["S", "SELL"]:
                return Action.SELL

        raise ValueError(f"無法識別買賣別: {buy_sell}")

    def _map_order_condition(self, order: Any) -> OrderCondition:
        """
        將富邦委託類型映射到 finlab OrderCondition

        Args:
            order: 富邦 API 返回的委託單對象

        Returns:
            OrderCondition: finlab 委託條件
        """
        order_type = getattr(order, "order_type", None)

        if order_type == OrderType.Stock:
            return OrderCondition.CASH
        if order_type == OrderType.Margin:
            return OrderCondition.MARGIN_TRADING
        if order_type == OrderType.Short:
            return OrderCondition.SHORT_SELLING
        if order_type == OrderType.DayTrade:
            return OrderCondition.DAY_TRADING_SHORT
        # 嘗試從字串類型判斷
        if isinstance(order_type, str):
            order_type = order_type.upper()
            if "現股" in order_type or "STOCK" in order_type:
                return OrderCondition.CASH
            if "融資" in order_type or "MARGIN" in order_type:
                return OrderCondition.MARGIN_TRADING
            if "融券" in order_type or "SHORT" in order_type:
                return OrderCondition.SHORT_SELLING
            if "當沖" in order_type or "DAYTRADE" in order_type:
                return OrderCondition.DAY_TRADING_SHORT

        # 默認為現股
        return OrderCondition.CASH

    def _create_finlab_order(self, order: Any) -> Order:
        """
        將富邦委託單轉換為 finlab Order 格式

        Args:
            order: 富邦委託單

        Returns:
            Order: finlab 格式的委託單
        """
        order_id = getattr(order, "seq_no", "")
        stock_id = getattr(order, "stock_no", "")
        price = float(getattr(order, "price", 0) or 0)

        status = self._parse_order_status(order)
        quantity, filled_quantity = self._parse_quantities(order)
        order_time = self._parse_order_time(order)
        action = self._map_order_action(order)
        order_condition = self._map_order_condition(order)

        return Order(
            order_id=order_id,
            stock_id=stock_id,
            action=action,
            price=price,
            quantity=quantity,
            filled_quantity=filled_quantity,
            status=status,
            order_condition=order_condition,
            time=order_time,
            org_order=order,
        )

    def _parse_order_status(self, order: Any) -> OrderStatus:
        """解析委託狀態"""
        status_code = getattr(order, "status", 0)
        status_map = {
            10: OrderStatus.NEW,  # 委託成功
            30: OrderStatus.CANCEL,  # 刪單成功
            50: OrderStatus.FILLED,  # 完全成交
            90: OrderStatus.CANCEL,  # 失敗
        }
        status = status_map.get(status_code, OrderStatus.NEW)

        # 檢查部分成交
        filled_qty = float(getattr(order, "filled_qty", 0) or 0)
        after_qty = float(getattr(order, "after_qty", 0) or 0)

        if filled_qty > 0 and filled_qty < after_qty and status != OrderStatus.CANCEL:
            status = OrderStatus.PARTIALLY_FILLED

        return status

    def _parse_quantities(self, order: Any) -> tuple[float, float]:
        """解析委託數量和成交數量"""
        after_qty = float(getattr(order, "after_qty", 0) or 0)
        filled_qty = float(getattr(order, "filled_qty", 0) or 0)

        return after_qty / STOCK_LOT_SIZE, filled_qty / STOCK_LOT_SIZE

    def _parse_order_time(self, order: Any) -> datetime.datetime:
        """解析委託時間"""
        date_str = getattr(order, "date", "")
        time_str = getattr(order, "last_time", "")

        if not date_str or not time_str:
            return datetime.datetime.now()

        try:
            year, month, day = self._parse_date(date_str)
            hour, minute, second, microsecond = self._parse_time(time_str)
            return datetime.datetime(
                year, month, day, hour, minute, second, microsecond
            )
        except Exception as e:
            logging.warning(f"_parse_order_time: 解析委託時間失敗: {e}, 使用當前時間")
            return datetime.datetime.now()

    def _parse_date(self, date_str: str) -> tuple[int, int, int]:
        """解析日期字串"""
        if "/" in date_str:
            date_parts = date_str.split("/")
            if len(date_parts) == 3:
                return int(date_parts[0]), int(date_parts[1]), int(date_parts[2])
            return datetime.datetime.now().year, int(date_parts[0]), int(date_parts[1])
        # 格式: YYYYMMDD  # noqa: ERA001
        return int(date_str[:4]), int(date_str[4:6]), int(date_str[6:8])

    def _parse_time(self, time_str: str) -> tuple[int, int, int, int]:
        """解析時間字串"""
        time_parts = time_str.split(":")
        hour = int(time_parts[0])
        minute = int(time_parts[1])

        second_parts = time_parts[2].split(".")
        second = int(second_parts[0])
        microsecond = int(second_parts[1]) * 1000 if len(second_parts) > 1 else 0

        return hour, minute, second, microsecond

    def get_stocks(self, stock_ids: list[str]) -> dict[str, Stock]:
        """
        獲取股票即時報價

        Args:
            stock_ids (list): 股票代碼列表

        Returns:
            dict: 股票報價字典，以股票代碼為鍵
        """
        if not self._ensure_marketdata_connection():
            return {}

        ret = {}
        for stock_id in stock_ids:
            try:
                quote = self._get_stock_quote(stock_id)
                if quote:
                    ret[stock_id] = self._create_finlab_stock(quote, stock_id)
                else:
                    logging.warning(f"get_stocks: 無法獲取股票 {stock_id} 的報價")
            except Exception as e:
                logging.warning(f"get_stocks: 獲取股票 {stock_id} 報價時發生錯誤: {e}")

        return ret

    def _ensure_marketdata_connection(self) -> bool:
        """確保行情連線已初始化"""
        if not hasattr(self.sdk, "marketdata") or not hasattr(
            self.sdk.marketdata, "rest_client"
        ):
            logging.warning("get_stocks: 行情連線尚未初始化，嘗試重新初始化")
            try:
                self.sdk.init_realtime()
                return True
            except Exception as e:
                logging.exception(f"get_stocks: 無法初始化行情連線: {e}")
                return False
        return True

    def _get_stock_quote(self, stock_id: str) -> Any:
        """獲取單一股票報價"""
        rest_stock = self.sdk.marketdata.rest_client.stock
        if not hasattr(rest_stock, "intraday") or not hasattr(
            rest_stock.intraday, "quote"
        ):
            logging.warning("get_stocks: SDK 無法存取 intraday.quote 方法")
            return None

        quote = rest_stock.intraday.quote(symbol=stock_id)
        logging.debug(quote)
        return quote

    def _create_finlab_stock(
        self, quote: Any, original_stock_id: str | None = None
    ) -> Stock:
        """
        將富邦行情轉換為 finlab Stock 格式

        Args:
            quote: 富邦行情數據
            original_stock_id (str, optional): 原始股票代碼，用於備份

        Returns:
            Stock: finlab 格式的股票數據
        """
        try:
            # 提取基本價格信息
            stock_id, price_data = self._extract_price_data(quote, original_stock_id)

            # 提取委買委賣信息
            bid_ask_data = self._extract_bid_ask_data(quote)

            # 提取漲跌幅
            pct_change = get_first_valid_float(quote, "changePercent", "change_rate")

            return Stock(
                stock_id=stock_id,
                **price_data,
                **bid_ask_data,
                pct_change=pct_change,
            )
        except Exception as e:
            logging.warning(f"_create_finlab_stock: 轉換時發生錯誤: {e}")
            return self._create_empty_stock(original_stock_id)

    def _extract_price_data(
        self, quote: Any, original_stock_id: str | None
    ) -> tuple[str | None, dict[str, float]]:
        """提取價格數據"""
        if isinstance(quote, dict):
            stock_id = quote.get("symbol", original_stock_id)
            price_data = {
                "open": float(quote.get("openPrice", 0) or 0),
                "high": float(quote.get("highPrice", 0) or 0),
                "low": float(quote.get("lowPrice", 0) or 0),
                "close": float(quote.get("closePrice", 0) or 0),
            }
        else:
            stock_id = getattr(quote, "symbol", original_stock_id or "")
            price_data = {
                "open": float(
                    getattr(quote, "open_price", getattr(quote, "openPrice", 0)) or 0
                ),
                "high": float(
                    getattr(quote, "high_price", getattr(quote, "highPrice", 0)) or 0
                ),
                "low": float(
                    getattr(quote, "low_price", getattr(quote, "lowPrice", 0)) or 0
                ),
                "close": float(
                    getattr(
                        quote,
                        "close_price",
                        getattr(quote, "closePrice", getattr(quote, "lastPrice", 0)),
                    )
                    or 0
                ),
            }

        # 今天還沒成交時 closePrice 沒有值，改用今日參考價，避免以 0 當限價
        if not price_data["close"]:
            price_data["close"] = (
                get_first_valid_float(quote, "referencePrice", "previousClose") or 0
            )

        return stock_id or original_stock_id, price_data

    def _extract_bid_ask_data(self, quote: Any) -> dict[str, float]:
        """提取委買委賣數據"""
        if isinstance(quote, dict):
            bids = quote.get("bids", [])
            asks = quote.get("asks", [])
        else:
            bids = getattr(quote, "bids", [])
            asks = getattr(quote, "asks", [])

        bid_data = self._extract_first_bid_ask(bids[0] if bids else None)
        ask_data = self._extract_first_bid_ask(asks[0] if asks else None)

        return {
            "bid_price": bid_data["price"],
            "bid_volume": bid_data["volume"],
            "ask_price": ask_data["price"],
            "ask_volume": ask_data["volume"],
        }

    def _extract_first_bid_ask(self, item: Any) -> dict[str, float]:
        """提取第一檔委買或委賣數據"""
        if not item:
            return {"price": 0, "volume": 0}

        if isinstance(item, dict):
            return {
                "price": float(item.get("price", 0) or 0),
                "volume": float(item.get("size", 0) or 0),
            }
        return {
            "price": float(getattr(item, "price", 0) or 0),
            "volume": float(getattr(item, "size", 0) or 0),
        }

    def _create_empty_stock(self, stock_id: str | None) -> Stock:
        """創建空的股票數據"""
        return Stock(
            stock_id=stock_id,
            open=0,
            high=0,
            low=0,
            close=0,
            bid_price=0,
            ask_price=0,
            bid_volume=0,
            ask_volume=0,
        )

    def get_position(self) -> Position:
        """
        獲取當前持有部位

        Returns:
            Position: 持有部位對象
        """
        # 獲取未實現損益（包含持倉資訊）
        result = self.sdk.accounting.unrealized_gains_and_loses(self.target_account)
        if not result or not result.is_success:
            # 查不到持倉不能當成空部位，否則 executor 會把整個目標部位再買一次
            raise ValueError(
                f"無法獲取持倉資訊: {getattr(result, 'message', '未知錯誤')}"
            )

        unrealized_data = result.data or []
        logging.debug(f"get_position: unrealized_gains_and_loses API 回傳: {result}")

        positions = []

        for position_data in unrealized_data:
            try:
                # 處理每個持倉項目
                stock_id = getattr(position_data, "stock_no", "")
                if not stock_id:
                    continue

                # 判斷委託類型
                order_type = getattr(position_data, "order_type", None)
                order_condition = OrderCondition.CASH  # 默認為現股

                if order_type == OrderType.Margin:
                    order_condition = OrderCondition.MARGIN_TRADING
                elif order_type == OrderType.Short:
                    order_condition = OrderCondition.SHORT_SELLING
                elif order_type == OrderType.DayTrade:
                    order_condition = OrderCondition.DAY_TRADING_SHORT

                # 獲取持倉數量 - 使用 today_qty 作為目前持倉
                today_qty = getattr(position_data, "today_qty", 0)
                if today_qty and float(today_qty) != 0:
                    # 根據買賣別和委託類型決定數量正負號
                    buy_sell = getattr(position_data, "buy_sell", None)
                    quantity_sign = 1

                    # 融券或賣出部位為負數
                    if (
                        order_condition == OrderCondition.SHORT_SELLING
                        or buy_sell == BSAction.Sell
                    ):
                        quantity_sign = -1

                    # today_qty 是股數，需要轉換為張
                    quantity = Decimal(str(today_qty)) / STOCK_LOT_SIZE * quantity_sign

                    positions.append(
                        {
                            "stock_id": stock_id,
                            "quantity": float(quantity),
                            "order_condition": order_condition,
                        }
                    )

            except Exception as e:
                logging.warning(
                    f"get_position: 處理持倉項目 {getattr(position_data, 'stock_no', '未知')} 時發生錯誤: {e}"
                )

        logging.info(f"get_position: 成功獲取持倉，共 {len(positions)} 筆")
        return Position.from_list(positions)

    def get_settlement(self) -> float:
        """
        獲取未交割款項（過去 3 天）

        Returns:
            float: 未交割款項

        Raises:
            ValueError: 查詢失敗時，不回傳 0，避免總淨值少算交割款
        """
        result = self.sdk.accounting.query_settlement(self.target_account, "3d")
        logging.debug(result)
        if not result or not result.is_success:
            raise ValueError(
                f"get_settlement: 無法獲取交割資訊: {getattr(result, 'message', '未知錯誤')}"
            )

        total_settlement = 0.0
        for detail in getattr(result.data, "details", None) or []:
            # 交割日為空時表示無交割資訊
            amount = getattr(detail, "total_settlement_amount", None)
            if getattr(detail, "settlement_date", None) and amount is not None:
                total_settlement += float(amount)

        logging.info(f"get_settlement: 總交割款 = {total_settlement}")
        return total_settlement

    def get_total_balance(self) -> float:
        """
        計算帳戶總淨值

        總淨值 = 現股與融資市值 - 融券市值 - 融資金額 + 融券擔保品 + 融券保證金 + 現金 + 未交割款項

        Returns:
            float: 總淨值

        Raises:
            ValueError: 任一查詢失敗時，不回傳少算的淨值，避免 executor 依偏小的資金賣出持股
        """
        cash = self.get_cash()
        settlements = self.get_settlement()

        result = self.sdk.accounting.unrealized_gains_and_loses(self.target_account)
        if not result or not result.is_success:
            raise ValueError(
                f"get_total_balance: 無法獲取持倉資訊: {getattr(result, 'message', '未知錯誤')}"
            )
        holdings = [
            p
            for p in result.data or []
            if getattr(p, "stock_no", "") and float(getattr(p, "today_qty", 0) or 0)
        ]

        stocks = (
            self.get_stocks(list({p.stock_no for p in holdings})) if holdings else {}
        )
        total_position_value = 0.0
        for p in holdings:
            price = getattr(stocks.get(p.stock_no), "close", 0)
            if not price:
                raise ValueError(f"get_total_balance: 無法獲取 {p.stock_no} 的股價")
            value = abs(float(p.today_qty)) * price
            # 融券是借來賣出的股票，市值要還給券商
            total_position_value += -value if p.order_type == OrderType.Short else value

        # 有信用部位時，扣回融資借款、加回融券擔保品與保證金
        credit_value = 0.0
        if any(p.order_type in (OrderType.Margin, OrderType.Short) for p in holdings):
            maint = self.sdk.accounting.maintenance(self.target_account)
            if not maint or not maint.is_success or not maint.data:
                raise ValueError(
                    f"get_total_balance: 無法獲取融資融券資訊: {getattr(maint, 'message', '未知錯誤')}"
                )
            summary = maint.data.maintenance_summary
            credit_value = (
                float(summary.collateral)
                + float(summary.shortsell_margin)
                - float(summary.margin_loan_amt)
            )

        total_balance = total_position_value + credit_value + cash + settlements
        logging.info(
            f"總淨值計算: 持倉市值={total_position_value}, 融資融券調整={credit_value}, 現金={cash}, 未交割款項={settlements}, 總淨值={total_balance}"
        )
        return total_balance

    def create_order(
        self,
        action: Action,
        stock_id: str,
        quantity: float,
        price: float | None = None,
        odd_lot: bool = False,
        best_price_limit: bool = False,
        market_order: bool = False,
        order_cond: OrderCondition = OrderCondition.CASH,
    ) -> str | None:
        """
        創建委託單

        Args:
            action (Action): 操作類型，買或賣
            stock_id (str): 股票代碼
            quantity (float): 數量，以張為單位
            price (float, optional): 價格
            odd_lot (bool): 是否為零股
            best_price_limit (bool): 是否使用最優價格限制
            market_order (bool): 是否為市價單
            order_cond (OrderCondition): 交易條件

        Returns:
            str: 委託單編號
        """
        if quantity <= 0:
            raise ValueError("委託數量必須大於零")

        # 將 finlab Action 轉換為富邦 BSAction
        buy_sell = BSAction.Buy if action == Action.BUY else BSAction.Sell

        # 確定市場類型
        market_type = self._determine_market_type(odd_lot)

        # 確定價格類型
        price_type = PriceType.Limit
        if market_type == MarketType.Fixing:
            # 盤後定價只接受參考價（定盤價）委託，以收盤價成交；
            # 掛芭樂價或限價比收盤價差的單原本就不想以收盤價成交，不送
            if best_price_limit:
                logging.error(
                    f"create_order: 定盤時段不送 best_price_limit 委託 {stock_id}"
                )
                return None
            if price is not None and not market_order:
                close = getattr(self.get_stocks([stock_id]).get(stock_id), "close", 0)
                worse = (
                    float(price) < close
                    if action == Action.BUY
                    else float(price) > close
                )
                if not close or worse:
                    logging.error(
                        f"create_order: 定盤時段以收盤價 {close} 成交，不送限價 {price} 的委託 {stock_id}"
                    )
                    return None
            price = None
            price_type = PriceType.Reference
        elif best_price_limit:
            price = None
            if action == Action.BUY:
                price_type = PriceType.LimitDown
            elif action == Action.SELL:
                price_type = PriceType.LimitUp
        elif market_order:
            price = None
            if action == Action.BUY:
                price_type = PriceType.LimitUp
            elif action == Action.SELL:
                price_type = PriceType.LimitDown

        # 確定交易條件
        order_type = OrderType.Stock  # 預設為現股交易
        if order_cond == OrderCondition.MARGIN_TRADING:
            order_type = OrderType.Margin
        elif order_cond == OrderCondition.SHORT_SELLING:
            order_type = OrderType.Short
        elif order_cond == OrderCondition.DAY_TRADING_SHORT and action == Action.SELL:
            # 現沖先賣只有盤中整股賣出送 DayTrade，回補買進送現股
            if market_type != MarketType.Common:
                logging.error(
                    f"create_order: 現沖先賣只能盤中整股賣出，不送 {stock_id} {quantity} 的 {market_type} 委託"
                )
                return None
            order_type = OrderType.DayTrade

        # 設定委託時效
        time_in_force = TimeInForce.ROD

        # 建立委託單物件
        try:
            # 根據市場類型確定數量單位
            qty = int(quantity) if odd_lot else int(quantity * STOCK_LOT_SIZE)

            # 建立委託單
            order = FBOrder(
                buy_sell=buy_sell,
                symbol=stock_id,
                price=str(price) if price is not None else None,
                quantity=qty,
                market_type=market_type,
                price_type=price_type,
                time_in_force=time_in_force,
                order_type=order_type,
            )

            # 送出委託單
            result = self.sdk.stock.place_order(self.target_account, order)
            if not result or not result.is_success:
                logging.warning(
                    f"create_order: 送出委託單失敗: {result.message if result else '未知錯誤'}"
                )
                return None

            order_id = self._get_order_id(result.data)
            logging.debug(f"#create_order order({order_id}): {order}")
            # 返回委託單號碼
            return order_id
        except Exception as e:
            logging.warning(f"create_order: 無法創建委託單: {e}")
            return None

    def _determine_market_type(self, odd_lot: bool) -> MarketType:
        """確定市場類型"""
        # 交易時段以台北時間為準，主機時區可能不是台灣（例如 Colab、雲端 VM）
        current_time = datetime.datetime.now(TWMarket.tzinfo()).time()

        if odd_lot:
            # 盤後零股處理 (13:40-14:30)
            if datetime.time(13, 40) <= current_time < datetime.time(14, 30):
                return MarketType.Odd
            return MarketType.IntradayOdd
        # 定盤處理 (14:00-14:30)
        if datetime.time(14, 0) <= current_time < datetime.time(14, 30):
            return MarketType.Fixing
        return MarketType.Common

    def _get_order_id(self, order: Any) -> str:
        """
        從委託單對象中獲取委託單編號

        Args:
            order (object): 富邦 API 返回的委託單對象

        Returns:
            str: 委託單編號
        """
        # 對於物件式資料，假設有 order_no 屬性
        if hasattr(order, "seq_no"):
            return order.seq_no

        # 無法找到委託單編號
        logging.warning(f"無法從委託單中獲取編號: {order}")
        return f"unknown_{int(time.time())}"

    def update_order(
        self,
        order_id: str,
        price: float | None = None,
        quantity: float | None = None,
    ) -> None:
        """
        更新委託單

        Args:
            order_id (str): 委託單編號
            price (float, optional): 新價格
            quantity (float, optional): 新數量
        """
        reorder_failed = False
        try:
            # 獲取委託單
            order = self.get_orders()[order_id]
            logging.debug(
                f"#update_order price: {price}, qty: {quantity}, order({order_id}): {order}"
            )

            # 更新價格
            if price:
                order_record = order.org_order
                # 判斷是否為零股
                if getattr(order_record, "market_type", "") in [
                    MarketType.IntradayOdd,
                    MarketType.Odd,
                    MarketType.EmgOdd,
                ]:
                    # 零股模式需要特別處理：取消原委託單並重新創建
                    action = order.action
                    stock_id = order.stock_id
                    # 依有效委託量（減過量的委託不是原始委託量）扣掉已成交，換回股數
                    qty = round(
                        (order.quantity - order.filled_quantity) * STOCK_LOT_SIZE
                    )

                    modify_qty_obj = self.sdk.stock.make_modify_quantity_obj(
                        order_record, 0
                    )
                    cancel_result = self.sdk.stock.modify_quantity(
                        self.target_account, modify_qty_obj
                    )
                    if cancel_result and cancel_result.is_success:
                        logging.info(f"已將零股委託單 {order_id} 數量修改為0以進行取消")
                    else:
                        message = cancel_result.message if cancel_result else "未知錯誤"
                        logging.warning(
                            f"update_order: 無法取消零股委託單 {order_id}: {message}"
                        )
                        return

                    # 創建新委託單
                    if qty > 0:
                        new_order_id = self.create_order(
                            action=action,
                            stock_id=stock_id,
                            quantity=qty,
                            price=price,
                            odd_lot=True,
                        )
                        reorder_failed = new_order_id is None
                        if not reorder_failed:
                            logging.info(
                                f"已以新價格 {price} 重新創建零股委託單 {stock_id}"
                            )
                else:
                    # 整股模式使用 make_modify_price_obj 及 modify_price
                    try:
                        # 使用 make_modify_price_obj 建立修改價格物件
                        modify_price_obj = self.sdk.stock.make_modify_price_obj(
                            order_record, str(price)
                        )
                        # 呼叫 modify_price 方法
                        result = self.sdk.stock.modify_price(
                            self.target_account, modify_price_obj
                        )
                        if not result or not result.is_success:
                            logging.warning(
                                f"update_order: 無法更新委託單 {order_id} 的價格: {result.message if result else '未知錯誤'}"
                            )
                        else:
                            logging.info(
                                f"已成功更新委託單 {order_id} 的價格為 {price}"
                            )
                    except Exception as e:
                        logging.warning(f"update_order: 修改價格時發生錯誤: {e}")

            # 更新數量
            if quantity:
                try:
                    order_record = order.org_order
                    # 根據市場類型確定數量單位
                    market_type = getattr(order_record, "market_type", None)
                    is_odd_lot = market_type in [
                        MarketType.IntradayOdd,
                        MarketType.Odd,
                        MarketType.EmgOdd,
                    ]
                    filled_qty = float(getattr(order_record, "filled_qty", 0))

                    # 計算新的委託數量 - 注意文檔中說明「修改後數量包含此委託單已成交部份」
                    if is_odd_lot:
                        # 零股利用原本的單位
                        new_qty = int(quantity) + int(filled_qty)
                    else:
                        # 整股需要乘以股票張數
                        new_qty = int(quantity * STOCK_LOT_SIZE) + int(filled_qty)

                    # 使用 make_modify_quantity_obj 建立修改數量物件
                    modify_qty_obj = self.sdk.stock.make_modify_quantity_obj(
                        order_record, new_qty
                    )
                    # 呼叫 modify_quantity 方法
                    result = self.sdk.stock.modify_quantity(
                        self.target_account, modify_qty_obj
                    )
                    if not result or not result.is_success:
                        logging.warning(
                            f"update_order: 無法更新委託單 {order_id} 的數量: {result.message if result else '未知錯誤'}"
                        )
                    else:
                        logging.info(
                            f"已成功更新委託單 {order_id} 的數量為 {quantity} (總數量為 {new_qty})"
                        )
                except Exception as e:
                    logging.warning(f"update_order: 修改數量時發生錯誤: {e}")

        except Exception as e:
            logging.warning(f"update_order: 更新委託單 {order_id} 時發生錯誤: {e}")

        if reorder_failed:
            # 原委託已刪除，不能只記 log 讓人以為改價成功
            raise ValueError(
                f"update_order: 零股委託單 {order_id} 已刪除，以新價格 {price} 重下失敗"
            )

    def cancel_order(self, order_id: str) -> None:
        """
        取消委託單

        Args:
            order_id (str): 委託單編號

        Raises:
            ValueError: 查詢委託或刪單失敗時，避免 executor 在舊單還有效時再下新單
        """
        # 獲取所有委託單
        orders = self.get_orders()
        if order_id not in orders:
            logging.warning(f"cancel_order: 找不到委託單 {order_id}")
            return

        order = orders[order_id]
        org_order = order.org_order

        logging.debug(f"#cancel_order order({order_id}): {order}")

        # 檢查是否可以取消
        can_cancel = getattr(org_order, "can_cancel", True)  # 預設可取消

        if can_cancel:
            result = self.sdk.stock.cancel_order(self.target_account, org_order)
            if not result or not result.is_success:
                raise ValueError(
                    f"cancel_order: 無法取消委託單 {order_id}: {result.message if result else '未知錯誤'}"
                )
            logging.info(f"已取消委託單 {order_id}")
        else:
            logging.warning(f"cancel_order: 委託單 {order_id} 不可取消")

    def _get_order_timestamp(self, order: Any) -> datetime.datetime:
        """
        從委託單對象中獲取時間戳

        Args:
            order (object): 富邦 API 返回的委託單對象

        Returns:
            datetime: 委託單時間戳
        """
        try:
            # 嘗試獲取日期和時間
            date_str = getattr(order, "date", "")
            time_str = getattr(order, "last_time", getattr(order, "order_time", ""))

            if not date_str or not time_str:
                return datetime.datetime.now()

            # 解析日期
            if "/" in date_str:
                # 假設格式為 MM/DD 或 YYYY/MM/DD
                date_parts = date_str.split("/")
                if len(date_parts) == 3:
                    year, month, day = (
                        int(date_parts[0]),
                        int(date_parts[1]),
                        int(date_parts[2]),
                    )
                else:
                    year = datetime.datetime.now().year
                    month, day = int(date_parts[0]), int(date_parts[1])
            elif len(date_str) == 8 and date_str.isdigit():
                # 假設格式為 YYYYMMDD
                year = int(date_str[:4])
                month = int(date_str[4:6])
                day = int(date_str[6:8])
            else:
                # 預設使用當前日期
                now = datetime.datetime.now()
                year, month, day = now.year, now.month, now.day

            # 解析時間
            if ":" in time_str:
                # 假設格式為 HH:MM:SS 或 HH:MM:SS.mmm
                time_parts = time_str.split(":")
                hour = int(time_parts[0])
                minute = int(time_parts[1])

                if len(time_parts) > 2:
                    second_parts = time_parts[2].split(".")
                    second = int(second_parts[0])
                    microsecond = (
                        int(second_parts[1]) * 1000 if len(second_parts) > 1 else 0
                    )
                else:
                    second, microsecond = 0, 0
            else:
                # 預設時間
                hour, minute, second, microsecond = 0, 0, 0, 0

            return datetime.datetime(
                year, month, day, hour, minute, second, microsecond
            )
        except Exception as e:
            logging.warning(f"_get_order_timestamp: 解析時間戳失敗: {e}")
            return datetime.datetime.now()

    def _get_buy_orders(self) -> list[Order]:
        """
        獲取買入記錄

        Returns:
            list: 買入記錄列表
        """
        buy_orders = []

        try:
            # 獲取持倉
            result = self.sdk.accounting.inventories(self.target_account)
            if not result or not result.is_success or not result.data:
                logging.warning("_get_buy_orders: 無法獲取持倉資訊")
                return buy_orders

            positions = result.data
            market = self.get_market()

            for i, position in enumerate(positions):
                try:
                    # 獲取庫存明細
                    stock_id = getattr(position, "stock_no", "")
                    if not stock_id:
                        continue

                    # 查詢持倉明細
                    detail_result = self.sdk.accounting.inventory_details(
                        self.target_account, getattr(position, "id", ""), stock_id
                    )
                    if (
                        not detail_result
                        or not detail_result.is_success
                        or not detail_result.data
                    ):
                        continue

                    position_details = detail_result.data

                    for detail in position_details:
                        # 判斷數量
                        quantity = getattr(detail, "qty", 0)
                        if not quantity or float(quantity) == 0:
                            continue

                        # 交易條件
                        order_condition = OrderCondition.CASH
                        trade_type = getattr(position, "order_type", "")
                        if trade_type == OrderType.Margin:
                            order_condition = OrderCondition.MARGIN_TRADING
                        elif trade_type == OrderType.Short:
                            order_condition = OrderCondition.SHORT_SELLING
                        elif trade_type == OrderType.DayTrade:
                            order_condition = OrderCondition.DAY_TRADING_SHORT

                        # 交易日期
                        date_str = getattr(
                            detail, "order_date", getattr(detail, "date", "")
                        )
                        trade_date = datetime.datetime.now()
                        if date_str:
                            try:
                                if (
                                    len(date_str) == 8 and date_str.isdigit()
                                ):  # YYYYMMDD
                                    trade_date = datetime.datetime.strptime(
                                        date_str, "%Y%m%d"
                                    )
                                else:
                                    trade_date = datetime.datetime.strptime(
                                        date_str, "%Y/%m/%d"
                                    )
                            except (ValueError, TypeError):
                                pass

                        # 產生買入單的續碼
                        order_id = getattr(
                            detail,
                            "order_no",
                            getattr(detail, "seq_no", f"fb_buy_{int(time.time())}_{i}"),
                        )

                        # 判斷是否為零股
                        is_odd_lot = (
                            getattr(detail, "odd_lot", False)
                            or quantity < STOCK_LOT_SIZE
                        )
                        divisor = 1 if is_odd_lot else STOCK_LOT_SIZE

                        # 轉換為 finlab Order 格式
                        buy_orders.append(
                            Order(
                                order_id=order_id,
                                stock_id=stock_id,
                                action=Action.BUY,
                                price=float(getattr(detail, "price", 0)),
                                quantity=float(quantity) / divisor,  # 轉換為張
                                filled_quantity=float(quantity) / divisor,  # 轉換為張
                                status=OrderStatus.FILLED,
                                order_condition=order_condition,
                                time=market.market_close_at_timestamp(trade_date)
                                .to_pydatetime()
                                .replace(hour=13, minute=30),
                                org_order=detail,
                            )
                        )
                except Exception as e:
                    logging.warning(f"_get_buy_orders: 處理持倉明細時發生錯誤: {e}")

                # 每處理 10 筆後休息一下，避免請求過於頻繁
                if i % 10 == 9 and i != len(positions) - 1:
                    time.sleep(1)

            return buy_orders
        except Exception as e:
            logging.warning(f"_get_buy_orders: 獲取買入記錄失敗: {e}")
            return []

    def _get_sell_orders(
        self,
        start: datetime.datetime | str | None = None,
        end: datetime.datetime | str | None = None,
    ) -> list[Order]:
        """
        獲取賣出記錄

        Args:
            start (datetime, optional): 開始時間
            end (datetime, optional): 結束時間

        Returns:
            list: 賣出記錄列表
        """
        if start is None:
            start = datetime.datetime.now() - datetime.timedelta(
                days=90
            )  # 預設查詢過去 90 天

        if end is None:
            end = datetime.datetime.now()

        # 轉換日期格式為 YYYYMMDD
        if hasattr(start, "strftime"):
            start_str = start.strftime("%Y%m%d")
        else:
            start_str = start

        if hasattr(end, "strftime"):
            end_str = end.strftime("%Y%m%d")
        else:
            end_str = end

        try:
            # 獲取已實現損益
            result = self.sdk.accounting.realized_pnl_detail(
                self.target_account, start_str, end_str
            )
            if not result or not result.is_success or not result.data:
                logging.warning("_get_sell_orders: 無法獲取已實現損益資訊")
                return []

            profit_loss = result.data
            market = self.get_market()

            sell_orders = []
            for i, record in enumerate(profit_loss):
                try:
                    # 取得日期和代碼
                    date_str = getattr(
                        record, "date", getattr(record, "trade_date", "")
                    )
                    if not date_str:
                        continue

                    stock_id = getattr(
                        record, "stock_no", getattr(record, "symbol", "")
                    )
                    if not stock_id:
                        continue

                    # 交易條件
                    order_condition = OrderCondition.CASH
                    trade_type = getattr(
                        record, "trade_type", getattr(record, "cond", "")
                    )
                    if trade_type == OrderType.Margin:
                        order_condition = OrderCondition.MARGIN_TRADING
                    elif trade_type == OrderType.Short:
                        order_condition = OrderCondition.SHORT_SELLING
                    elif trade_type == OrderType.DayTrade:
                        order_condition = OrderCondition.DAY_TRADING_SHORT

                    # 判斷交易日期
                    trade_date = datetime.datetime.now()
                    try:
                        if len(date_str) == 8 and date_str.isdigit():  # YYYYMMDD
                            trade_date = datetime.datetime.strptime(date_str, "%Y%m%d")
                        else:  # 假設為 YYYY/MM/DD
                            trade_date = datetime.datetime.strptime(
                                date_str, "%Y/%m/%d"
                            )
                    except (ValueError, TypeError):
                        pass

                    # 判斷是否為零股
                    quantity = getattr(record, "qty", getattr(record, "quantity", 0))
                    is_odd_lot = (
                        getattr(record, "odd_lot", False) or quantity < STOCK_LOT_SIZE
                    )
                    divisor = 1 if is_odd_lot else STOCK_LOT_SIZE

                    # 產生賣出單的續碼
                    order_id = getattr(
                        record,
                        "order_no",
                        getattr(record, "seq_no", f"fb_sell_{int(time.time())}_{i}"),
                    )

                    # 轉換為 finlab Order 格式
                    sell_orders.append(
                        Order(
                            order_id=order_id,
                            stock_id=stock_id,
                            action=Action.SELL,
                            price=float(getattr(record, "price", 0)),
                            quantity=float(quantity) / divisor,  # 轉換為張
                            filled_quantity=float(quantity) / divisor,  # 轉換為張
                            status=OrderStatus.FILLED,
                            order_condition=order_condition,
                            time=market.market_close_at_timestamp(trade_date)
                            .to_pydatetime()
                            .replace(hour=13, minute=30),
                            org_order=record,
                        )
                    )
                except Exception as e:
                    logging.warning(
                        f"_get_sell_orders: 處理已實現損益紀錄時發生錯誤: {e}"
                    )

                # 每處理 20 筆後休息一下，避免請求過於頻繁
                if i % 20 == 19 and i != len(profit_loss) - 1:
                    time.sleep(1)

            return sell_orders
        except Exception as e:
            logging.warning(f"_get_sell_orders: 獲取賣出記錄失敗: {e}")
            return []

    def get_trades(
        self, start: datetime.datetime | str, end: datetime.datetime | str
    ) -> list[Order]:
        """
        獲取歷史交易記錄

        Args:
            start (datetime): 開始時間
            end (datetime): 結束時間

        Returns:
            list: 交易記錄列表
        """
        if isinstance(start, str):
            start = datetime.datetime.fromisoformat(start)

        if isinstance(end, str):
            end = datetime.datetime.fromisoformat(end)

        # 調整日期範圍以符合市場時間
        market = self.get_market()
        start = market.market_close_at_timestamp(start - datetime.timedelta(days=1))
        end = market.market_close_at_timestamp(end)

        # 調整時間範圍為整天
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        end = end.replace(hour=23, minute=59, second=59, microsecond=999999)

        try:
            # 獲取買入記錄
            buy_orders = self._get_buy_orders()

            # 獲取賣出記錄
            sell_orders = self._get_sell_orders(start, end)

            # 合併所有訂單
            orders = buy_orders + sell_orders

            # 過濾時間範圍內的交易
            return [o for o in orders if start <= o.time <= end]
        except Exception as e:
            logging.warning(f"get_trades: 獲取交易記錄失敗: {e}")
            return []

    def support_day_trade_condition(self) -> bool:
        """
        是否支援當沖交易

        Returns:
            bool: 是否支援當沖交易
        """
        return True

    def sep_odd_lot_order(self) -> bool:
        """
        是否支援零股交易

        Returns:
            bool: 是否支援零股交易
        """
        # 富邦證券支援零股交易
        return True

    def get_price_info(self) -> dict[str, Any]:
        """
        獲取價格信息

        Returns:
            dict: 價格信息字典
        """
        try:
            # 從 finlab 導入參考價格資料
            ref = data.get("reference_price")
            return ref.set_index("stock_id").to_dict(orient="index")
        except Exception as e:
            logging.warning(f"get_price_info: 獲取價格信息失敗: {e}")
            # 如果失敗，返回空字典
            return {}

    def get_market(self) -> TWMarket:
        """
        獲取市場信息

        Returns:
            TWMarket: 台灣市場對象
        """
        # 返回台灣市場對象
        return TWMarket()
