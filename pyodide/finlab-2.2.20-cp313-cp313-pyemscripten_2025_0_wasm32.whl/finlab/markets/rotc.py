from __future__ import annotations

import datetime
from typing import ClassVar

import numpy as np
import pandas as pd

from finlab import data
from finlab.market import Market

__all__ = ["ROTCMarket"]


class ROTCMarket(Market):
    """興櫃股票市場類別

    興櫃股票的特性：
    - 沒有還原價（無除權息、增減資等公司行為調整）
    - 交易時間與上市櫃相同
    - 資料來源為 rotc_price 系列

    使用方式：
        from finlab.markets.rotc import ROTCMarket
        from finlab.backtest import sim

        close = data.get('rotc_price:收盤價')
        position = ...  # 計算持倉

        report = sim(position=position, market=ROTCMarket(), ...)
    """

    _ALWAYS_PREFETCH_TABLES: ClassVar[frozenset[str]] = frozenset(
        {
            "benchmark_return:發行量加權股價報酬指數",
            "rotc_price:成交股數",
        }
    )

    _TRADE_AT_PRICE_TABLES: ClassVar[dict[str, frozenset[str]]] = {
        "close": frozenset({"rotc_price:收盤價"}),
        "open": frozenset({"rotc_price:開盤價"}),
        "high": frozenset({"rotc_price:最高價"}),
        "low": frozenset({"rotc_price:最低價"}),
        "open_close_avg": frozenset({"rotc_price:開盤價", "rotc_price:收盤價"}),
        "close_open_avg": frozenset({"rotc_price:開盤價", "rotc_price:收盤價"}),
        "high_low_avg": frozenset({"rotc_price:最高價", "rotc_price:最低價"}),
        "low_high_avg": frozenset({"rotc_price:最高價", "rotc_price:最低價"}),
        "price_avg": frozenset(
            {
                "rotc_price:開盤價",
                "rotc_price:收盤價",
                "rotc_price:最高價",
                "rotc_price:最低價",
            }
        ),
    }

    @staticmethod
    def get_freq() -> str:
        return "1D"

    @staticmethod
    def get_name() -> str:
        return "rotc_stock"

    @staticmethod
    def get_benchmark() -> pd.Series:
        return data.get("benchmark_return:發行量加權股價報酬指數").squeeze()

    @staticmethod
    def get_asset_id_to_name() -> dict[str, str]:
        """取得興櫃股票代碼對應名稱

        注意：興櫃股票可能沒有在 security_categories 中，
        此方法會嘗試從 rotc_price 的欄位名稱推斷
        """
        try:
            from finlab.compat import resolve_id_column

            # 先嘗試從 security_categories 取得
            categories = data.get("security_categories")
            _reset = categories.reset_index()
            return dict(
                zip(_reset[resolve_id_column(_reset)], categories["name"], strict=True)
            )
        except (ImportError, KeyError, ValueError, RuntimeError):
            return {}

    @staticmethod
    def get_industry() -> dict[str, str]:
        """取得興櫃股票產業分類"""
        try:
            from finlab.compat import resolve_id_column

            categories = data.get("security_categories")
            _reset = categories.reset_index()
            return dict(
                zip(
                    _reset[resolve_id_column(_reset)],
                    categories["category"],
                    strict=True,
                )
            )
        except (ImportError, KeyError, ValueError, RuntimeError):
            return {}

    def get_price(
        self, trade_at_price: str | pd.Series | pd.DataFrame, adj: bool = True
    ) -> pd.DataFrame:
        """取得興櫃股票價格

        Args:
            trade_at_price: 價格類型 ('open', 'close', 'high', 'low', 'volume')
                           或 pd.DataFrame/pd.Series
            adj: 是否使用還原價（興櫃股票無還原價，此參數會被忽略）

        Returns:
            pd.DataFrame: 興櫃股票價格資料

        Note:
            興櫃股票沒有還原價，因此 adj 參數會被忽略，
            永遠返回原始價格。轉上市櫃的股票在興櫃最後一天的下一個交易日
            補上上市櫃價格，回測會在掛牌第一天以這個價格出場。
        """
        if isinstance(trade_at_price, pd.Series):
            return trade_at_price.to_frame()

        if isinstance(trade_at_price, pd.DataFrame):
            return trade_at_price

        if isinstance(trade_at_price, str):
            if trade_at_price == "volume":
                return data.get("rotc_price:成交股數")

            # 興櫃股票沒有還原價，永遠使用原始價格
            price_name = {
                "open": "開盤價",
                "close": "收盤價",
                "high": "最高價",
                "low": "最低價",
            }[trade_at_price]

            rotc = data.get(f"rotc_price:{price_name}")
            with data.market("tw"):
                listed = data.get(f"price:{price_name}")
            return _with_first_listed_price(rotc, listed)

        raise ValueError(
            "trade_at_price is not allowed (accepted types: pd.DataFrame, pd.Series, str)."
        )

    @staticmethod
    def get_market_value() -> pd.DataFrame:
        """興櫃股票市值"""
        return pd.DataFrame()

    def market_close_at_timestamp(
        self, timestamp: pd.Timestamp | None = None
    ) -> pd.Timestamp:
        """取得市場收盤時間"""
        timestamp = self._normalize_market_timestamp(timestamp, "Asia/Taipei")

        market_close = pd.Timestamp(timestamp.date()) + pd.Timedelta("15:00:00")
        return market_close.tz_localize("Asia/Taipei")

    @staticmethod
    def tzinfo() -> datetime.timezone:
        return datetime.timezone(datetime.timedelta(hours=8))

    def get_reference_price(self) -> dict[str, float]:
        """取得興櫃股票參考價"""
        try:
            # 使用最近一日的收盤價作為參考價
            close = data.get("rotc_price:收盤價")
            if close is not None and not close.empty:
                return close.iloc[-1].dropna().to_dict()
        except (KeyError, ValueError, RuntimeError):
            pass
        return {}

    @staticmethod
    def get_odd_lot() -> int:
        return 1000

    @staticmethod
    def get_board_lot_size() -> int:
        return 1000

    @classmethod
    def sim_datasets(
        cls,
        *,
        trade_at_price: str | None = "close",
        touched_exit: bool = False,
    ) -> list[str]:
        datasets = set(cls._ALWAYS_PREFETCH_TABLES)
        datasets.add("rotc_price:收盤價")

        if touched_exit:
            datasets.update(
                {
                    "rotc_price:開盤價",
                    "rotc_price:最高價",
                    "rotc_price:最低價",
                }
            )

        if isinstance(trade_at_price, str):
            datasets.update(cls._TRADE_AT_PRICE_TABLES.get(trade_at_price, set()))

        return sorted(datasets)


def _with_first_listed_price(rotc: pd.DataFrame, listed: pd.DataFrame) -> pd.DataFrame:
    """Add the first TWSE/TPEx price of stocks that moved there from ROTC.

    A stock's ROTC prices end the trading day before it lists. Without its first
    listed price the backtest sells it at the last ROTC price, which holders
    never got: the shares carried over to the listed board.
    """
    values = rotc.to_numpy(dtype=float, copy=True)
    has_price = ~np.isnan(values)
    next_bar = len(rotc) - np.argmax(has_price[::-1], axis=0)
    ended = np.flatnonzero(next_bar < len(rotc))
    first_listed = listed.reindex(
        index=rotc.index, columns=rotc.columns[ended]
    ).to_numpy(dtype=float)[next_bar[ended], np.arange(len(ended))]
    if np.isnan(first_listed).all():
        return rotc
    values[next_bar[ended], ended] = first_listed
    return type(rotc)(values, index=rotc.index, columns=rotc.columns)
