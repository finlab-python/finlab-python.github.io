"""Local-only subscription guidance; never refresh a token to show a notice."""

from __future__ import annotations

import base64
import hashlib
import json
import locale
import os
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from finlab.archive import ARCHIVE_DIR

_PAYMENT_URL = "https://studio.finlab.finance/payment?merchant=vip_m"
_TAIPEI = timezone(timedelta(hours=8))
_seen: set[str] = set()


def _today(now: datetime | None = None) -> date:
    return (now or datetime.now(_TAIPEI)).astimezone(_TAIPEI).date()


def _english() -> bool:
    language = next(
        (
            os.environ[key]
            for key in ("LC_ALL", "LC_MESSAGES", "LANGUAGE", "LANG")
            if os.environ.get(key)
        ),
        locale.getlocale()[0] or "",
    ).lower()
    return language.startswith("en") or language in {"c", "c.utf-8", "posix"}


def _notice_dir() -> Path:
    return Path.home() / ".finlab" / "notices"


def _once(key: str) -> bool:
    if key in _seen:
        return False
    _seen.add(key)
    if ARCHIVE_DIR:
        return True
    try:
        directory = _notice_dir()
        directory.mkdir(parents=True, exist_ok=True)
        with (directory / hashlib.sha256(key.encode()).hexdigest()).open("x"):
            pass
    except FileExistsError:
        return False
    except OSError:
        pass  # A read-only home must not prevent login or data access.
    return True


def show_trial_notice(id_token: str) -> None:
    """Read claims solely for messaging; they do not grant data access."""
    try:
        payload = id_token.split(".")[1]
        claims = json.loads(
            base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4))
        )
        if not isinstance(claims, dict):
            return
        merchants = claims.get("merchant_ids")
        if isinstance(merchants, list):
            if "taiwan_data" in merchants:
                return
        elif claims.get("role") not in (None, "", "free", "vip_t"):
            return
        trial = claims.get("trial")
        if not isinstance(trial, str) or len(trial) != 8:
            return
        end = datetime.strptime(trial, "%Y%m%d").date()
    except (IndexError, ValueError, TypeError):
        return
    today = _today()
    uid = claims.get("sub") or claims.get("user_id")
    if not uid or not 0 <= (end - today).days <= 1:
        return
    if not _once(f"trial:{uid}:{trial}:{today}"):
        return
    if _english():
        print(
            f"Your VIP trial ends on {end.isoformat()} at 11:59 PM Taipei time. "
            "After that, Taiwan historical data is available only through 2023-12-31. "
            f"Subscribe during your trial for NT$749/month (NT$888 afterward): {_PAYMENT_URL}"
        )
    else:
        print(
            f"VIP 試用到 {end.month}/{end.day} 晚上 11:59（台北時間）。"
            "之後台股歷史資料只到 2023-12-31。"
            f"試用期間訂閱 749／月（之後 888）：{_PAYMENT_URL}"
        )


def show_cached_trial_notice() -> None:
    """Cover a data.get served entirely from disk, without refreshing auth."""
    from finlab import auth

    token = auth._cached_id_token
    if not token:
        token = (auth.get_session() or {}).get("id_token")
    if token := token or os.environ.get("FINLAB_ID_TOKEN"):
        show_trial_notice(token)


def free_data_notice() -> str:
    """Explain the actual free tier reported by the data signing service."""
    if _english():
        return (
            "You are now receiving free-plan Taiwan historical data, available only through "
            "2023-12-31 (last trading day: 2023-12-29). VIP-only datasets are unavailable "
            "after the trial ends unless you subscribe. "
            "Check data.search(..., details=True) for dataset permissions; "
            "US public-beta data and open reference tables have separate coverage. "
            f"Subscribe to VIP: {_PAYMENT_URL}"
        )
    return (
        "目前取得的是免費版台股歷史資料，只到 2023-12-31（最後交易日：2023-12-29）。"
        "試用到期後需訂閱才能取得 VIP 專屬資料。"
        "各資料權限可用 data.search(..., details=True) 查詢；美股公測與公開參考表的範圍另計。"
        f"訂閱 VIP：{_PAYMENT_URL}"
    )
