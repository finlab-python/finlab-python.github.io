"""Pre-import settings for reading an explicitly selected research archive."""

from __future__ import annotations

import errno
import os

ARCHIVE_DIR = os.environ.get("FINLAB_ARCHIVE_DIR")


def require_online() -> None:
    if ARCHIVE_DIR:
        raise RuntimeError(
            "Archive research needs local dependencies and valid cached authorization; network access is disabled."
        )


def require_write() -> None:
    if ARCHIVE_DIR:
        raise PermissionError(errno.EROFS, "Archive research is read-only")
