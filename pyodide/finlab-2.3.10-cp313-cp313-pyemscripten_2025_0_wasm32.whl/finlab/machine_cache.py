"""Small JSON records that every process on this machine shares.

A record lives in the default data directory (``get_tmp_dir()``) with the time it
was stored, so a script started shortly after another reuses what that script
fetched instead of asking the network again. Each caller decides how old a record
may be. A missing, unreadable or expired record reads as ``None``, never an error.
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

from finlab.archive import ARCHIVE_DIR
from finlab.utils import atomic_replace, get_tmp_dir

logger = logging.getLogger(__name__)


def _path(name: str, fallback: Callable[[], str] | None = None) -> str | None:
    directory = os.environ.get("FINLAB_SHARED_CACHE_DIR")
    if os.environ.get("FINLAB_SHARED_CACHE") == "0" or (ARCHIVE_DIR and not directory):
        return None
    return os.path.join(
        os.path.expanduser(directory or (fallback or get_tmp_dir)()), name
    )


def load(name: str, max_age: float) -> tuple[Any, float] | None:
    """The payload stored under *name* and its age in seconds, if younger than *max_age*.

    A clock set back makes a record look stored in the future; it counts as expired.
    """
    path = _path(name)
    if path is None:
        return None
    try:
        with open(path, encoding="utf-8") as f:
            record = json.load(f)
        age = time.time() - float(record["stored_at"])
        if 0 <= age < max_age:
            return record["payload"], age
    except Exception:  # noqa: BLE001 -- an unusable record is fetched again
        pass
    return None


def store(name: str, payload: Any) -> None:
    """Share *payload* under *name*; failing to share only costs the next process a fetch."""

    path = None if ARCHIVE_DIR else _path(name)
    if path is None:
        return

    def write(tmp_path: str) -> None:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump({"stored_at": time.time(), "payload": payload}, f)

    try:
        if os.environ.get("FINLAB_SHARED_CACHE_DIR"):
            os.makedirs(os.path.dirname(path), exist_ok=True)
        atomic_replace(path, write)
    except OSError as exc:
        logger.debug("%s not shared: %s", name, exc)
