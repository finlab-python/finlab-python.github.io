from __future__ import annotations

import datetime
import importlib.util
import logging
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass
from decimal import Decimal
from enum import Enum as _Enum
from typing import Any

from finlab.config import get_default_market
from finlab.market import Market
from finlab.markets.tw import TWMarket
from finlab.online.core.enums import *
from finlab.online.core.position import Position
from finlab.online.core.realtime_normalizers import to_optional_float

logger = logging.getLogger(__name__)

Number = int | float | Decimal


class TWSession(_Enum):
    """台股委託時段"""

    COMMON = "common"  # 盤中整股
    INTRADAY_ODD = "intraday_odd"  # 盤中零股
    AFTER_HOURS_ODD = "after_hours_odd"  # 盤後零股，13:40～14:30
    FIXING = "fixing"  # 盤後定價，14:00～14:30，只以收盤價成交


def tw_session(odd_lot: bool, now: datetime.datetime) -> TWSession:
    """依台北時間判斷委託時段；時段從開始那一分鐘起算，now 必須帶時區"""
    if now.tzinfo is None:
        raise ValueError("tw_session 需要帶時區的時間，避免用到主機時區")
    current = now.astimezone(TWMarket.tzinfo()).time()
    if odd_lot:
        after_hours = datetime.time(13, 40) <= current < datetime.time(14, 30)
        return TWSession.AFTER_HOURS_ODD if after_hours else TWSession.INTRADAY_ODD
    fixing = datetime.time(14, 0) <= current < datetime.time(14, 30)
    return TWSession.FIXING if fixing else TWSession.COMMON


def typesafe_op(a: Number, b: Number, op: str) -> Number:
    if (isinstance(a, Decimal) and isinstance(b, Decimal)) or (
        isinstance(a, (int, float)) and isinstance(b, (int, float))
    ):
        if op == "+":
            return a + b
        if op == "-":
            return a - b
    raise TypeError(f"Unsupported types for operation {op}: {type(a)}, {type(b)}")


@dataclass
class Order:
    """
    Order status

    委託單的狀態

    Attributes:
        order_id (str): 委託單的 id，與券商 API 所提供的 id 一致
        stock_id (str): 股票代號 ex: '2330' (亦可透過 symbol 屬性存取)
        action (Action): 買賣方向，通常為 'BUY' 或是 'SELL'
        price (Number): 股票買賣的價格(限價單)
        quantity (Number): 委託股票的總數量（張數），允許小數點
        filled_quantity (Number): 以成交股票的數量（張數），允許小數點
        status (OrderStatus): 委託狀態，可以設定為：'NEW', 'PARTIALLY_FILLED', 'FILLED', 'CANCEL'
        time (datetime.datetime): 委託時間
        org_order (Any = None): 券商所提供的委託物件格式
    """

    order_id: str
    stock_id: str
    action: Action
    price: Number
    quantity: Number
    filled_quantity: Number
    status: OrderStatus
    order_condition: OrderCondition
    time: datetime.datetime
    org_order: Any = None

    @property
    def symbol(self) -> str:
        return self.stock_id

    @symbol.setter
    def symbol(self, value: str) -> None:
        self.stock_id = value


@dataclass
class Stock:
    """
    Stock

    即時股票資料

    Attributes:
        stock_id (str): 股票代號 (亦可透過 symbol 屬性存取)
        open (Number): 開盤價
        high (Number): 最高價
        low (Number): 最低價
        close (Number): 收盤價
        bid_price (Number): 買方第一檔價格
        bid_volume (Number): 買方第一檔量
        ask_price (Number): 賣方第一檔價格
        ask_volume (Number): 賣方第一檔量
        pct_change (Optional[float]): 今日漲跌幅 (vs 前日收盤)
    """

    stock_id: str
    open: Number
    high: Number
    low: Number
    close: Number
    bid_price: Number
    bid_volume: Number
    ask_price: Number
    ask_volume: Number
    pct_change: float | None = None

    @property
    def symbol(self) -> str:
        return self.stock_id

    @symbol.setter
    def symbol(self, value: str) -> None:
        self.stock_id = value

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class Account(ABC):
    # Required module name and version for the account implementation
    required_module: str = ""
    module_version: str = ""

    """股票帳戶的 abstract class
    可以繼承此 Account，來實做券商的帳戶買賣動作，目前已經實做 SinopacAccount (永豐證券) 以及 EsunAccount (玉山證券)，來進行交易。可以用以下方式建構物件並用來交易：

    永豐證券
    ```py
    import os
    from finlab.online.sinopac_account import SinopacAccount


    # 舊版請使用
    # shioaji < 1.0.0 and finlab < 0.3.18
    os.environ['SHIOAJI_ACCOUNT']= '永豐證券帳號'
    os.environ['SHIOAJI_PASSWORD']= '永豐證券密碼'

    # 新版請使用
    # shioaji >= 1.0.0 and finlab >= 0.3.18
    os.environ['SHIOAJI_API_KEY'] = '永豐證券API_KEY'
    os.environ['SHIOAJI_SECRET_KEY'] = '永豐證券SECRET_KEY'
    os.environ['SHIOAJI_CERT_PERSON_ID']= '身份證字號'

    # shioaji
    os.environ['SHIOAJI_CERT_PATH']= '永豐證券憑證路徑'
    os.environ['SHIOAJI_CERT_PASSWORD'] = '永豐證券憑證密碼' # 預設與身份證字號

    acc = SinopacAccount()
    ```
    玉山證券:
    ```py
    from finlab.online.esun_account import EsunAccount
    import os
    os.environ['ESUN_CONFIG_PATH'] = '玉山證券交易設定檔(config.ini.example)路徑'
    os.environ['ESUN_MARKET_API_KEY'] = '玉山證券的行情API Token'

    acc = EsunAccount()
    ```

    """

    @classmethod
    def check_version(cls) -> None:

        m = cls.required_module

        # check module installed
        if importlib.util.find_spec(m) is None:
            logger.error(f"Module {m} is not installed. Please install it using pip.")

    @abstractmethod
    def create_order(
        self,
        action: Action,
        stock_id: str,
        quantity: Number,
        price: Number | None = None,
        odd_lot: bool = False,
        market_order: bool = False,
        best_price_limit: Number | None = None,
        order_cond: OrderCondition = OrderCondition.CASH,
    ) -> str:
        """產生新的委託單

        Args:
            action (Action): 買賣方向，通常為 'BUY' 或是 'SELL'

            stock_id (str): 股票代號 ex: '2330'

            quantity (Number): 委託股票的總數量（張數），允許小數點

            price (Number, optional): 股票買賣的價格(限價單)

            force (bool): 是否用最差之價格（長跌停）強制成交? 當成交量足夠時，可以比較快成交，然而當成交量低時，容易有大的滑價

            wait_for_best_price (bool): 是否用最佳之價格（長跌停），無限時間等待？當今天要出場時，可以開啟等漲停價來購買，當今天要買入時，可以掛跌停價等待買入時機。

        Returns:
            (str): order id 券商提供的委託單編號
        """

    @abstractmethod
    def update_order(
        self,
        order_id: str,
        price: Number | None = None,
        quantity: Number | None = None,
    ) -> None:
        """產生新的委託單

        Attributes:
            order_id (str): 券商所提供的委託單 ID
            price (Number, optional): 更新的限價
            quantity (Number, optional): 更新的待成交量

        Returns:
            (None): 無跳出 erorr 代表成功更新委託單
        """

    @abstractmethod
    def cancel_order(self, order_id: str) -> None:
        """刪除委託單

        建議使用 刪除委託單此功能前，先使用 update_order() 來更新委託單的狀況！如下
        ```py
        acc.update_order()
        acc.cancel_order('ORDER_ID')
        ```

        Attributes:
            order_id (str): 券商所提供的委託單 ID

        Returns:
            (None): 代表成功更新委託單
        """

    @abstractmethod
    def get_orders(self) -> dict[str, Order]:
        """拿到現在所有委託單

        Returns:
            (Dict[str, Order]): 所有委託單 id 與委託單資料
                !!! example
                    `{'12345A': Order(order_id='12345A', stock_id='5410',...),...}`
        """

    @abstractmethod
    def get_stocks(self, stock_ids: list[str]) -> dict[str, Stock]:
        """拿到現在股票報價

        Attributes:
            stock_ids (`list` of `str`): 一次拿取所有股票的報價，ex: ['1101', '2330']

        Returns:
            (dict): 報價資料，
                !!! example
                    `{'1101': Stock(stock_id='1101', open=31.15, high=31.85, low=31.1, close=31.65, bid_price=31.6, bid_volume=728.0, ask_price=31.65, ask_volume=202)}`
        """

    @abstractmethod
    def get_position(self) -> Position:
        """拿到當前帳戶的股票部位

        Returns:
            (Position): 當前股票部位
        """

    @abstractmethod
    def get_total_balance(self) -> int:
        """拿到當前帳戶的股票部位淨值"""

    @abstractmethod
    def get_cash(self) -> int:
        """拿到當前帳戶的現金"""

    @abstractmethod
    def get_settlement(self) -> int:
        """拿到當前帳戶的結算資料"""

    def sep_odd_lot_order(self) -> bool:
        return True

    def support_best_price_limit(self) -> bool:
        """是否能以漲跌停價掛單（best_price_limit）"""
        return True

    def get_price(self, stock_ids: list[str]) -> dict[str, Number]:

        s = self.get_stocks(stock_ids)

        price = {pname: s[pname].close for pname in s}

        for sid, p in price.items():
            if p == 0:
                bid_price = (
                    s[sid].bid_price if s[sid].bid_price != 0 else s[sid].ask_price
                )
                ask_price = (
                    s[sid].ask_price if s[sid].ask_price != 0 else s[sid].bid_price
                )

                price[sid] = typesafe_op(bid_price, ask_price, "+") / 2

            if price[sid] == 0:
                raise Exception(
                    f"Stock {sid} has no price to reference. Use latest close of previous trading day"
                )

        return price

    def get_market(self) -> Market:
        """拿到當前帳戶的市場"""
        return get_default_market()


@dataclass(frozen=True)
class TWOrderPlan:
    """通過共同檢查、可以送出的委託

    Attributes:
        session (TWSession): 委託時段
        session_param (Any): adapter 宣告的該時段 SDK 參數
        fixing_price (float | None): 定盤要送出的收盤價；其他時段、或用參考價旗標的券商是 None
    """

    session: TWSession
    session_param: Any
    fixing_price: float | None = None


class TWStockAccount(Account):
    """台股券商的共同下單規則

    adapter 只要宣告 session_params()，並在下單前呼叫 _plan_order()；
    時段判斷與定盤要不要送、送什麼價都在這裡，adapter 不自己判斷。
    """

    # SDK 定盤用參考價旗標、不必帶價格的券商設為 True：不需要比價時就不查報價
    fixing_uses_reference_price: bool = False

    @abstractmethod
    def session_params(self) -> dict[TWSession, Any]:
        """宣告各委託時段對應的 SDK 參數"""

    def _close_price(self, stock_id: str) -> float | None:
        """今日收盤價，查不到回傳 None"""
        stock = self.get_stocks([stock_id]).get(stock_id)
        return to_optional_float(getattr(stock, "close", None)) or None

    def _plan_order(
        self,
        action: Action,
        stock_id: str,
        price: Number | None,
        *,
        odd_lot: bool,
        market_order: bool,
        best_price_limit: bool,
    ) -> TWOrderPlan | None:
        """決定委託時段與定盤價；回傳 None 表示這筆不送、也不報錯

        定盤只以收盤價成交：芭樂價、比收盤價差的限價不會照原意成交，不送也不中斷，
        呼叫端可能已先撤單，後面的單要照常下。
        """
        session = tw_session(odd_lot, datetime.datetime.now(TWMarket.tzinfo()))
        session_param = self.session_params()[session]
        if session is not TWSession.FIXING:
            return TWOrderPlan(session, session_param)
        if best_price_limit:
            logger.warning(f"create_order: 定盤時段不送 {stock_id} 的芭樂價委託")
            return None
        compare = price is not None and not market_order
        close = None
        if compare or not self.fixing_uses_reference_price:
            close = self._close_price(stock_id)
            if close is None:
                logger.warning(
                    f"create_order: 查不到 {stock_id} 的收盤價，定盤時段不送單"
                )
                return None
        if compare and (
            float(price) < close if action == Action.BUY else float(price) > close
        ):
            logger.warning(
                f"create_order: 定盤以收盤價 {close} 成交，{stock_id} 比收盤價差的限價 {price} 不送單"
            )
            return None
        fixing_price = None if self.fixing_uses_reference_price else close
        return TWOrderPlan(session, session_param, fixing_price)
