"""Discover published Factor Forge histories without downloading their matrices."""

from __future__ import annotations

import hashlib
import json
import re
from copy import deepcopy
from functools import lru_cache
from typing import Any

from . import catalog
from .auth import get_public_json

_ROOT = "https://r2.finlab.finance/"
_INDEX = "factor-forge/v1/etl/manifest.json"
_PAGES = "factor-forge/v1/etl/pages/"


@lru_cache(maxsize=64)
def _page(digest: str) -> dict[str, Any]:
    if re.fullmatch(r"[0-9a-f]{64}", digest) is None:
        raise ValueError("Invalid Factor Forge page digest")
    page = get_public_json(f"{_ROOT}{_PAGES}{digest}.json")
    raw = json.dumps(
        page, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")
    if hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError("Factor Forge research page hash mismatch")
    if page.get("schema_version") != 1 or page.get("market") != "tw":
        raise ValueError("Unsupported Factor Forge research page")
    return page


def research(keyword: str = "", *, market: str | None = None) -> list[dict[str, Any]]:
    """Find approved factors with downloadable histories and their definitions.

    Args:
        keyword: Match the factor id, bilingual name, formula or research summary.
            Empty lists all published histories, sorted by stable factor id.
        market: Defaults to the active market (Taiwan when unset). Factor Forge
            currently covers Taiwan; other supported markets return an empty list.

    Returns:
        Independent dictionaries with ``id``, ``name``, ``name_en``, ``dataset``
        (the exact data.get key), ``definition``, ``summary``, ``signal_as_of``
        and ``evaluated_through``. ``history`` contains the published matrix's
        ``date_range``, ``matrix_end``, historical ``signal_as_of``, ``format``
        and ``availability_companion``. The research signal can be newer than
        the matrix; missing metadata remains None. Larger matrix values already
        include the approved direction. Missing cells are never filled.

    Notes:
        Each call refreshes discovery and the normal public data catalog;
        immutable definition pages are reused by content hash. No matrix is
        downloaded and no formula is executed. Login and normal VIP access are
        required when subsequently calling data.get. Research validation is
        not a return promise or proof of historical first-release availability.

    Examples:
        >>> from finlab import data
        >>> factors = data.research("投信", market="tw")
        >>> signal = data.get(factors[0]["dataset"])
    """
    market = catalog._resolve_market(market, catalog._MARKET_TO_FIRESTORE_DOC)
    if market != "tw":
        return []
    # Explicit discovery refreshes without changing search/get's shared cache.
    document = get_public_json(f"{catalog._FIRESTORE_CATALOG_URL}/finlab_tw_stock")
    categories = catalog._build_catalog(document.get("fields", {})).categories
    if not categories:
        raise RuntimeError("Dataset catalog unavailable or empty for market 'tw'")
    published = {
        info["alias"]: info
        for category in categories
        if catalog._category_alias(category) == "factor_forge"
        for info in catalog._dict_list(category.get("data_info"))
    }
    if not published:
        return []
    index = get_public_json(f"{_ROOT}{_INDEX}")
    if (
        index.get("schema_version") != 1
        or index.get("market") != "tw"
        or index.get("approved_only") is not True
    ):
        raise ValueError("Unsupported Factor Forge research index")
    needle = catalog.normalize_search_text(keyword)
    result = []
    for pointer in index["pages"]:
        digest = pointer["sha256"]
        if pointer["key"] != f"{_PAGES}{digest}.json":
            raise ValueError("Factor Forge research page escapes namespace")
        for row in _page(digest)["factors"]:
            definition = row["definition"]
            dataset = f"factor_forge:{definition['name']}"
            info = published.get(dataset, {})
            history = info.get("research") or {}
            if (
                row.get("approved_for_fdata") is not True
                or row.get("status") != "validated"
                or history.get("id") != row["id"]
                or history.get("definition_sha256")
                != row["review"]["definition_sha256"]
            ):
                continue
            if needle not in catalog.normalize_search_text(
                json.dumps([row, info], ensure_ascii=False)
            ):
                continue
            result.append(
                {
                    "id": row["id"],
                    "name": info["name"],
                    "name_en": info.get("name_en"),
                    "dataset": dataset,
                    "definition": definition,
                    "summary": definition.get("hypothesis"),
                    "family": row.get("family"),
                    "signal_as_of": row.get("signal_as_of") or row["latest"]["date"],
                    "evaluated_through": row.get("evaluated_through"),
                    "refreshed_at": row.get("refreshed_at"),
                    "artifact": row["artifact"],
                    "history": history,
                }
            )
    return deepcopy(sorted(result, key=lambda factor: factor["id"]))
