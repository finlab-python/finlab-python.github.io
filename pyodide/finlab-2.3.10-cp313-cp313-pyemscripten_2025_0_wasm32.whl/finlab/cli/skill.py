"""`python -m finlab skill install`: give AI coding tools the FinLab skill."""

from __future__ import annotations

import io
import shutil
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path, PurePosixPath
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import argparse

_SKILL_ARCHIVE_URL = (
    "https://codeload.github.com/koreal6803/finlab-ai/tar.gz/refs/heads/main"
)
_SKILL_DIR_IN_ARCHIVE = ("skills", "finlab")
# Installing here also reaches Codex and Cursor; Claude Code only reads ~/.claude/skills.
_SHARED_SKILLS_DIR = ".agents/skills"
_CLAUDE_SKILLS_DIR = ".claude/skills"
_TOOL_HOMES = {".claude": "Claude Code", ".codex": "Codex", ".cursor": "Cursor"}


def _detected_tools() -> list[str]:
    home = Path.home()
    return [name for folder, name in _TOOL_HOMES.items() if (home / folder).is_dir()]


def _skill_installed() -> bool:
    home = Path.home()
    plugins = home / ".claude/plugins/installed_plugins.json"
    if plugins.is_file() and "finlab-plugin" in plugins.read_text(encoding="utf-8"):
        return True
    return any(
        (home / folder / "skills/finlab/SKILL.md").is_file()
        for folder in (".agents", *_TOOL_HOMES)
    )


def print_skill_hint() -> None:
    """Point people who already use an AI coding tool at the skill."""
    tools = _detected_tools()
    if tools and not _skill_installed():
        print(
            f"讓 {'、'.join(tools)} 也會用 FinLab 回測 /"
            " Teach your AI tool FinLab: python -m finlab skill install"
        )


def _read_skill_files(archive: bytes) -> dict[PurePosixPath, bytes]:
    files = {}
    with tarfile.open(fileobj=io.BytesIO(archive), mode="r:gz") as tar:
        for member in tar:
            parts = PurePosixPath(member.name).parts
            if member.isfile() and parts[1:3] == _SKILL_DIR_IN_ARCHIVE:
                relative = PurePosixPath(*parts[3:])
                if ".." not in relative.parts:
                    files[relative] = tar.extractfile(member).read()  # type: ignore[union-attr]
    return files


def _write_skill(target: Path, files: dict[PurePosixPath, bytes]) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(dir=target.parent, prefix=".finlab-"))
    for relative, content in files.items():
        path = staging / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
    staging.chmod(0o755)
    if target.exists():
        shutil.rmtree(target)
    staging.rename(target)


def cmd_skill_install() -> None:
    from finlab.auth import https_context

    try:
        with urllib.request.urlopen(
            _SKILL_ARCHIVE_URL, timeout=30, context=https_context()
        ) as response:
            files = _read_skill_files(response.read())
    except (OSError, tarfile.TarError) as exc:
        files = {}
        print(f"Download failed: {exc}", file=sys.stderr)
    if PurePosixPath("SKILL.md") not in files:
        print(
            "FinLab skill 下載失敗，請稍後再試，或改用 /"
            " Install failed, retry or use:"
            " npx skills add koreal6803/finlab-ai --skill finlab -g -y",
            file=sys.stderr,
        )
        sys.exit(1)

    home = Path.home()
    targets = [home / _SHARED_SKILLS_DIR / "finlab"]
    if (home / ".claude").is_dir():
        targets.append(home / _CLAUDE_SKILLS_DIR / "finlab")
    for target in targets:
        # A link belongs to `npx skills` or a local checkout; it already has the skill.
        if not target.is_symlink():
            _write_skill(target, files)
        print(f"已安裝 / Installed: {target}")
    print(
        "重新開啟 AI 工具後，問「幫我回測台股策略」就會用上。 /"
        " Restart your AI tool, then ask it to backtest a stock strategy."
    )


def cmd_skill(args: argparse.Namespace) -> None:
    if args.skill_command == "install":
        cmd_skill_install()
    else:
        print("Run: python -m finlab skill install", file=sys.stderr)
        sys.exit(1)


def register_skill_commands(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    parser = subparsers.add_parser(
        "skill", help="Install the FinLab skill for Claude Code, Codex and Cursor"
    )
    skill_sub = parser.add_subparsers(dest="skill_command")
    skill_sub.add_parser(
        "install",
        help="Download the latest skill to ~/.agents/skills and ~/.claude/skills",
    )
