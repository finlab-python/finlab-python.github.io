from __future__ import annotations

import math
from typing import TYPE_CHECKING, cast

__all__ = ["AlphaBetaAnalysis"]

import pandas as pd

from finlab.analysis import Analysis
from finlab.ffn_core import (
    _alpha_beta,
    _returns_cagr,
    _safe_division,
)

if TYPE_CHECKING:
    from IPython.display import HTML

    from finlab.core.report import Report
    from finlab.market import Market


# Preserve the historical module-level imports as aliases.
calc_cagr = _returns_cagr
safe_division = _safe_division


class AlphaBetaAnalysis(Analysis):
    def __init__(self) -> None:
        super().__init__()
        self._result: dict[str, object] | None = None

    def is_market_supported(self, market: Market) -> bool:
        return "TWMarket" in str(market)

    @staticmethod
    def calculate_alpha_beta(
        creturn: pd.Series, benchmark: pd.Series
    ) -> tuple[float, float]:
        return _alpha_beta(creturn, benchmark)

    def analyze(self, report: Report) -> dict[str, object]:
        creturn_pct = report.daily_creturn.pct_change()
        benchmark_pct = (
            report.daily_benchmark.pct_change()
            .fillna(0)
            .reindex(creturn_pct.index, method="ffill")
        )

        # recent metrics
        recent: dict[str, list[float | int]] = {"alpha": [], "beta": [], "ndays": []}
        for n in [0, 20, 60, 120, 252]:
            a = creturn_pct.iloc[-n:]
            b = benchmark_pct.loc[a.index[0] :].reindex(a.index)

            alpha, beta = self.calculate_alpha_beta(a, b)
            recent["alpha"].append(0 if math.isnan(alpha) else alpha)
            recent["beta"].append(1 if math.isnan(beta) else beta)
            recent["ndays"].append(n)

        # yearly metrics
        yearly: dict[str, list[float | int]] = {"alpha": [], "beta": [], "year": []}
        for year in range(creturn_pct.index[0].year, creturn_pct.index[-1].year + 1):
            a = creturn_pct.loc[str(year)]
            b = benchmark_pct.loc[str(year)]
            alpha, beta = self.calculate_alpha_beta(a, b)
            yearly["alpha"].append(0 if math.isnan(alpha) else alpha)
            yearly["beta"].append(1 if math.isnan(beta) else beta)
            yearly["year"].append(year)

        # overall metrics
        alpha, beta = self.calculate_alpha_beta(creturn_pct, benchmark_pct)

        self._result = {
            "yearly": yearly,
            "recent": recent,
            "overall": {"alpha": alpha, "beta": beta},
        }

        return self._result

    def display(self) -> HTML | None:
        if self._result is None:
            return None

        from IPython.display import HTML

        result = cast("dict[str, dict[str, object]]", self._result)

        # overall summary
        overall = result["overall"]
        alpha_pct = f"{overall['alpha']:.2%}"
        beta_val = f"{overall['beta']:.2f}"

        t = "<h4>Alpha/Beta 分析</h4>"
        t += '<table border="1" style="border-collapse:collapse;text-align:center;">'
        t += "<tr><th>指標</th><th>數值</th><th>說明</th></tr>"
        t += f"<tr><td><b>Alpha</b></td><td>{alpha_pct}</td><td>年化超額報酬</td></tr>"
        t += f"<tr><td><b>Beta</b></td><td>{beta_val}</td><td>市場敏感度</td></tr>"
        t += "</table><br/>"

        def fmt_alpha(v: float) -> str:
            return f"{v:.2%}"

        def fmt_beta(v: float) -> str:
            return f"{v:.2f}"

        # yearly table
        yearly_df = pd.DataFrame(
            {
                "Alpha": result["yearly"]["alpha"],
                "Beta": result["yearly"]["beta"],
            },
            index=result["yearly"]["year"],
        )
        yearly_df.index.name = "年度"

        t += (
            yearly_df.style.format({"Alpha": fmt_alpha, "Beta": fmt_beta})
            .set_caption("年度 Alpha/Beta")
            .background_gradient(subset=["Alpha"], cmap="RdYlGn", vmin=-0.2, vmax=0.2)
            .background_gradient(subset=["Beta"], cmap="YlOrBr", vmin=0, vmax=2)
            .to_html()
        )
        t += "<br/>"

        # recent table
        ndays_labels = {0: "全期", 20: "近1月", 60: "近3月", 120: "近6月", 252: "近1年"}
        recent_df = pd.DataFrame(
            {
                "Alpha": result["recent"]["alpha"],
                "Beta": result["recent"]["beta"],
            },
            index=[
                ndays_labels.get(n, f"{n}天")
                for n in cast("list[int]", result["recent"]["ndays"])
            ],
        )
        recent_df.index.name = "期間"

        t += (
            recent_df.style.format({"Alpha": fmt_alpha, "Beta": fmt_beta})
            .set_caption("近期 Alpha/Beta")
            .background_gradient(subset=["Alpha"], cmap="RdYlGn", vmin=-0.2, vmax=0.2)
            .background_gradient(subset=["Beta"], cmap="YlOrBr", vmin=0, vmax=2)
            .to_html()
        )

        return HTML(t)
