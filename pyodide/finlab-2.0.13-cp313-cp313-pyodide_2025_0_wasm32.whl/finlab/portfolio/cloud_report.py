from __future__ import annotations

import base64
import datetime
import gzip
import json
import logging
from typing import TYPE_CHECKING, Any, ClassVar, NoReturn, cast

__all__ = ["CloudReport", "create_report_from_cloud"]

import pandas as pd
import requests

import finlab
from finlab.core import firestore_rest
from finlab.core.report import Report, ReportExecution
from finlab.markets.tw import TWMarket
from finlab.portfolio.portfolio import PositionScheduler

from .utils import validate_structure

if TYPE_CHECKING:
    from finlab.market import Market

logger = logging.getLogger(__name__)


def create_report_from_cloud(
    strategy_id: str, user_id: str | None = None, market: Market | None = None
) -> CloudReport:
    """根據提供的用戶ID和策略ID創建在線報告。
    Create an online report based on the user id and strategy id provided.


    Args:
        user_id (str): The user id.
        strategy_id (str): The
    """

    return CloudReport.from_cloud(strategy_id, user_id, market)


class CloudReport(Report):
    @staticmethod
    def _empty_benchmark() -> pd.Series:
        return pd.Series(
            [], index=pd.Index([], dtype="datetime64[ns]"), dtype="float64"
        )

    @classmethod
    def _get_report_init_market(
        cls, resolved_market: Market, market_arg: Market | None
    ) -> Market:
        """Use a benchmarkless proxy for implicit cloud market resolution.

        ``Report.__init__`` eagerly calls ``market.get_benchmark()``, which can
        trigger remote data fetches for built-in markets like ``TWMarket``.
        Cloud report reconstruction already has the full return series, so that
        fetch is unnecessary and makes canonical loading fragile in offline
        tests and adapter code.
        """
        if market_arg is not None:
            return resolved_market

        class _BenchmarklessMarketProxy:
            def __init__(self, market: Market) -> None:
                self._market = market

            def get_benchmark(self) -> pd.Series:
                return CloudReport._empty_benchmark()

            def __getattr__(self, name: str) -> Any:
                return getattr(self._market, name)

        return cast("Market", _BenchmarklessMarketProxy(resolved_market))

    @staticmethod
    def _extract_report_data(sdata: Any) -> dict[str, Any]:
        if not isinstance(sdata, dict):
            return sdata

        if all(k in sdata for k in ("returns", "metrics", "trades")):
            return sdata

        if "report" in sdata and isinstance(sdata["report"], dict):
            report_payload = sdata["report"]
            if all(
                k in report_payload
                for k in ("timestamps", "strategy", "metrics", "trades")
            ):
                return {
                    "returns": {
                        "time": report_payload["timestamps"],
                        "value": report_payload["strategy"],
                    },
                    "metrics": report_payload["metrics"],
                    "trades": report_payload["trades"],
                }
        return sdata

    @staticmethod
    def _extract_execution_data(
        pdata: dict[str, Any] | list[Any],
    ) -> dict[str, Any] | list[Any]:
        if isinstance(pdata, dict):
            if "execution" in pdata:
                return pdata["execution"]
            if "payload_v1" in pdata and isinstance(pdata["payload_v1"], dict):
                payload_execution = pdata["payload_v1"].get("execution")
                if payload_execution is not None:
                    return payload_execution
            if "position2" in pdata:
                return pdata["position2"]
            if "position" in pdata:
                return pdata["position"]
        return pdata

    @staticmethod
    def _extract_legacy_position_data(
        pdata: dict[str, Any], execution_data: dict[str, Any] | list[Any]
    ) -> dict[str, Any]:
        if isinstance(pdata, dict):
            if "position2" in pdata:
                return pdata["position2"]
            if (
                "position" in pdata
                and isinstance(pdata["position"], dict)
                and "positionConfig" in pdata["position"]
            ):
                return pdata["position"]
            if "positionConfig" in pdata:
                return pdata
        execution = ReportExecution.from_json(execution_data)
        if execution is None:
            return {"positions": [], "positionConfig": {}}
        legacy_position = ReportExecution.to_legacy_position_info2_collection(execution)
        return (
            legacy_position
            if legacy_position is not None
            else {"positions": [], "positionConfig": {}}
        )

    @property
    def position_schedulers(self) -> PositionScheduler | dict[str, PositionScheduler]:
        return self.execution

    @position_schedulers.setter
    def position_schedulers(
        self, value: PositionScheduler | dict[str, PositionScheduler]
    ) -> None:
        self.execution = value

    _REQUIRED_SDATA_STRUCTURE: ClassVar[dict[str, Any]] = {
        "returns": {"value": [int, float], "time": [str]},
        "metrics": {
            "backtest": {
                "feeRatio": (int, float),
                "taxRatio": (int, float),
                "tradeAt": str,
                "nextTradingDate": (int, float),
                "market": str,
                "livePerformanceStart": (int, float),
                "stopLoss": (int, float, type(None)),
                "takeProfit": (int, float, type(None)),
                "trailStop": (int, float, type(None)),
                "freq": str,
            }
        },
        "trades": str,
    }

    @staticmethod
    def _resolve_market(sdata: dict[str, Any], market: Market | None) -> Market:
        """Resolve the market from sdata metadata or raise if unknown."""
        if market is not None:
            return market
        cloud_market = sdata["metrics"]["backtest"].get("market")
        if cloud_market in {"tw_stock", "auto", None}:
            return TWMarket()
        raise ValueError("Market is not provided. Please provide a market object.")

    @staticmethod
    def _parse_trades(sdata: dict[str, Any]) -> pd.DataFrame:
        """Decompress trades and convert timestamp columns to datetime."""
        gzip_bytes = base64.b64decode(sdata["trades"])
        json_bytes = gzip.decompress(gzip_bytes)
        trades = pd.DataFrame(json.loads(json_bytes.decode("utf-8")))

        def _ts_to_dt(t: float | None) -> datetime.datetime | pd.NaTType:
            if t is None or pd.isna(t):
                return pd.NaT
            return datetime.datetime.fromtimestamp(t / 1000)

        for col in ("entry_date", "entry_sig_date", "exit_date", "exit_sig_date"):
            trades[col] = pd.to_datetime(trades[col].map(_ts_to_dt))
        trades.index.name = "trade_index"
        return trades

    @staticmethod
    def _inject_updated_at(pdata: dict[str, Any], target: dict[str, Any]) -> None:
        """Propagate updated_at into positionConfig.created if missing."""
        updated_at = pdata.get("updated_at") if isinstance(pdata, dict) else None
        if updated_at is None or not isinstance(target, dict):
            return
        pc = target.get("positionConfig")
        if isinstance(pc, dict) and "created" not in pc:
            pc["created"] = updated_at

    @staticmethod
    def _inject_last_timestamp(creturn: pd.Series, target: dict[str, Any]) -> None:
        """Inject ``lastTimestamp`` into position(2) positionConfig when absent.

        The canonical ``ReportExecution.to_legacy_position_info2`` path has no
        access to ``creturn`` and cannot populate this field, but
        ``Report.position_info2`` and the Firestore projection both emit it.
        Backfilling here keeps CloudReport.position_info2() output symmetrical
        regardless of whether ``pdata`` came from the legacy position2 doc or
        was reconstructed from ``execution``.
        """
        if not isinstance(target, dict) or len(creturn) == 0:
            return
        last = creturn.index.astype(str)[-1]

        def _set(container: dict[str, Any]) -> None:
            pc = container.get("positionConfig")
            if isinstance(pc, dict) and "lastTimestamp" not in pc:
                pc["lastTimestamp"] = last

        if "positionConfig" in target:
            _set(target)
            return
        for value in target.values():
            if isinstance(value, dict):
                _set(value)

    @staticmethod
    def _raw_trade_rows(trades_blob: Any) -> list[dict[str, Any]]:
        """Decode the gzip'd trades blob to raw rows with UTC-ms timestamps.

        ``self.trades`` runs every timestamp column through
        ``datetime.fromtimestamp`` which applies the system's local timezone,
        so round-tripping back to UNIX epoch is unreliable.  The raw payload
        is the single source of truth we can compare against UTC-seconds
        fields in the position config.
        """
        if not isinstance(trades_blob, str) or not trades_blob:
            return []
        try:
            raw = base64.b64decode(trades_blob)
            decoded = json.loads(gzip.decompress(raw).decode("utf-8"))
        except (ValueError, OSError, json.JSONDecodeError):
            return []
        return decoded if isinstance(decoded, list) else []

    @staticmethod
    def _ms_to_iso_utc(ms: Any) -> str:
        if not isinstance(ms, (int, float)):
            return ""
        try:
            return datetime.datetime.fromtimestamp(
                ms / 1000, tz=datetime.timezone.utc
            ).isoformat()
        except (ValueError, OSError, OverflowError):
            return ""

    @staticmethod
    def _latest_exit_per_ticker(
        trade_rows: list[dict[str, Any]],
        skip: set[str],
    ) -> dict[str, dict[str, Any]]:
        latest: dict[str, dict[str, Any]] = {}
        for row in trade_rows:
            if not isinstance(row, dict):
                continue
            raw_sid = row.get("stock_id") or row.get("symbol") or ""
            ticker = str(raw_sid).split(" ", maxsplit=1)[0]
            if not ticker or ticker in skip:
                continue
            exit_ms = row.get("exit_sig_date")
            if not isinstance(exit_ms, (int, float)):
                continue
            prior = latest.get(ticker)
            if prior is None or exit_ms > prior.get("exit_sig_date", float("-inf")):
                latest[ticker] = row
        return latest

    @classmethod
    def _build_recently_exited_entry(
        cls,
        ticker: str,
        row: dict[str, Any],
        scheduled: Any,
    ) -> dict[str, Any]:
        raw_sid = row.get("stock_id") or row.get("symbol") or ticker
        name_parts = str(raw_sid).split(" ", maxsplit=1)
        asset_name = name_parts[1] if len(name_parts) > 1 else ""
        entry_price = row.get("trade_price@entry_date") or 0
        entry_adj_price = row.get("adj_close@entry_date") or 0
        exit_price = row.get("trade_price@exit_date") or 0
        profit = row.get("return") or 0
        entry_iso = cls._ms_to_iso_utc(row.get("entry_sig_date"))
        exit_iso = cls._ms_to_iso_utc(row.get("exit_sig_date"))
        return {
            "assetId": ticker,
            "assetName": asset_name,
            "entryDate": entry_iso,
            "entrySigDate": entry_iso or scheduled,
            "exitDate": exit_iso,
            "exitSigDate": exit_iso or scheduled,
            "entryPrice": entry_price,
            "entryAdjPrice": entry_adj_price,
            "exitPrice": exit_price,
            "currentPrice": exit_price or entry_price,
            "profit": profit,
            "currentWeight": 0,
            "nextWeight": 0,
            "industry": "",
            "action": {
                "type": "exit_p",
                "reason": "_",
                "date": exit_iso or scheduled,
                "profit": profit,
            },
        }

    @classmethod
    def _augment_recently_exited_leaf(
        cls,
        target: dict[str, Any],
        trade_rows: list[dict[str, Any]],
    ) -> None:
        pc = target.get("positionConfig")
        if not isinstance(pc, dict):
            return
        rebalance_s = pc.get("currentRebalanceDate")
        if not isinstance(rebalance_s, (int, float)):
            return
        rebalance_ms = float(rebalance_s) * 1000.0

        positions = target.setdefault("positions", [])
        existing = {
            str(p.get("assetId", "")).split(" ", maxsplit=1)[0]
            for p in positions
            if isinstance(p, dict)
        }
        scheduled = pc.get("scheduled")

        for ticker, row in cls._latest_exit_per_ticker(trade_rows, existing).items():
            exit_ms = row.get("exit_sig_date")
            if not isinstance(exit_ms, (int, float)):
                continue
            if abs(float(exit_ms) - rebalance_ms) >= 1.0:
                continue
            positions.append(cls._build_recently_exited_entry(ticker, row, scheduled))

    @classmethod
    def _augment_recently_exited(
        cls,
        target: dict[str, Any],
        trade_rows: list[dict[str, Any]],
    ) -> None:
        """Append synthetic recently-exited positions to a position2 leaf.

        Mirrors the projection's ``_recently_exited_trades`` logic.  When the
        canonical execution payload loses tickers that exited on the current
        rebalance day, reconstruct them from the trades payload so that
        ``CloudReport.position_info2()`` stays in parity with the Firestore
        legacy projection.
        """
        if not isinstance(target, dict):
            return
        if "positionConfig" in target:
            cls._augment_recently_exited_leaf(target, trade_rows)
            return
        for value in target.values():
            if isinstance(value, dict):
                cls._augment_recently_exited(value, trade_rows)

    def __init__(
        self, sdata: dict[str, Any], pdata: dict[str, Any], market: Market | None = None
    ) -> None:
        """
        sdata: dict
        pdata: dict
        """

        sdata = self._extract_report_data(sdata)
        execution_data = self._extract_execution_data(pdata)

        logger.info(
            "OnlineReport is in beta version, please report any issue to FinLab Team at https://discord.gg/tAr4ysPqvR"
        )

        validate_structure(sdata, self._REQUIRED_SDATA_STRUCTURE)

        bt = sdata["metrics"]["backtest"]
        self.creturn: pd.Series = pd.Series(
            sdata["returns"]["value"], pd.to_datetime(sdata["returns"]["time"])
        )
        self.fee_ratio: int | float = bt["feeRatio"]
        self.tax_ratio: int | float = bt["taxRatio"]
        self.trade_at: str = bt["tradeAt"]
        self.last_trading_date: datetime.datetime = datetime.datetime.fromtimestamp(
            bt["nextTradingDate"]
        )
        self.market: Market = self._resolve_market(sdata, market)
        init_market = self._get_report_init_market(self.market, market)
        trades = self._parse_trades(sdata)

        super().__init__(
            self.creturn,
            pd.DataFrame(0, index=self.creturn.index, columns=["1", "2"]),
            self.fee_ratio,
            self.tax_ratio,
            self.trade_at,
            self.last_trading_date,
            init_market,
        )
        self.market = self._resolve_market(sdata, market)

        self.trades: pd.DataFrame = trades

        lps = bt.get("livePerformanceStart")
        self.live_performance_start: datetime.datetime | None = (
            datetime.datetime.fromtimestamp(lps) if lps is not None else None
        )
        self.stop_loss: int | float | None = bt["stopLoss"]
        self.take_profit: int | float | None = bt["takeProfit"]
        self.trail_stop: int | float | None = bt["trailStop"]
        self.resample: str = bt["freq"]
        self.pdata: dict[str, Any] = self._extract_legacy_position_data(
            pdata, execution_data
        )
        self._inject_updated_at(pdata, self.pdata)
        self._inject_last_timestamp(self.creturn, self.pdata)
        self._augment_recently_exited(
            self.pdata, self._raw_trade_rows(sdata.get("trades"))
        )
        self.sdata: dict[str, Any] = sdata
        execution = PositionScheduler.from_json(execution_data)
        if execution is None:
            execution = ReportExecution.from_report(self, total_weight=1.0)
        self.position_schedulers = execution

    def contains_multiple_strategies(self) -> bool:
        return isinstance(self.execution, dict)

    def is_rebalance_due(self) -> bool:
        execution = self.position_schedulers
        if isinstance(execution, dict):
            return any(v.is_rebalance_due() for v in execution.values())

        return execution.is_rebalance_due()

    def is_stop_triggered(self) -> bool:
        execution = self.position_schedulers
        if isinstance(execution, dict):
            return any(v.is_stop_triggered() for v in execution.values())

        return execution.is_stop_triggered()

    def get_metrics(self) -> dict[str, Any]:
        return self.sdata["metrics"]

    def position_info2(self) -> dict[str, Any]:
        return self.pdata

    def reverse_trades(self, gzip_b64_str: str) -> pd.DataFrame:
        """Reverse trades from gzip_b64_str"""

        # Decode base64 string to gzip bytes
        gzip_bytes = base64.b64decode(gzip_b64_str)

        # Decompress gzip bytes to JSON bytes
        json_bytes = gzip.decompress(gzip_bytes)

        # Decode JSON bytes to JSON string
        json_str = json_bytes.decode("utf-8")

        # Convert JSON string to DataFrame
        return pd.DataFrame(json.loads(json_str))

    @classmethod
    def _try_canonical_load(
        cls,
        strategy_id: str,
        token: str,
        user_id: str | None,
        market: Market | None,
    ) -> CloudReport | None:
        """Attempt to load report from Firestore canonical format. Return None on failure."""
        resolved_uid = user_id or firestore_rest.extract_uid_from_id_token(token)
        if not resolved_uid:
            return None

        try:
            canonical = firestore_rest.get_document(
                f"users/{resolved_uid}/reports/{strategy_id}",
                token,
            )
        except Exception as e:  # noqa: BLE001
            logger.debug(f"Canonical report lookup failed for {strategy_id}: {e}")
            return None

        if not canonical:
            return None

        payload = Report.from_payload_dict(canonical)
        report_payload = payload.get("report")
        execution_payload = payload.get("execution")
        if report_payload is None or execution_payload is None:
            logger.debug(
                f"Canonical report payload incomplete for {strategy_id}; falling back to legacy"
            )
            return None

        report = cls(
            {"report": report_payload},
            {"execution": execution_payload},
            market,
        )
        cls._inject_updated_at(canonical, report.pdata)
        return report

    @classmethod
    def _load_from_legacy_api(
        cls,
        strategy_id: str,
        token: str,
        token_type: str,
        user_id: str | None,
        market: Market | None,
    ) -> CloudReport:
        """Load report from the legacy cloud function API."""
        url = "https://asia-east2-fdata-299302.cloudfunctions.net/auth_get_strategy"
        params: dict[str, str] = {token_type: token, "sid": strategy_id}
        if user_id is not None:
            params["uid"] = user_id

        res = requests.get(url, params)
        if res.status_code != 200:
            raise RuntimeError(res.text)

        data = json.loads(res.text)
        if not data:
            raise ValueError("No strategy found")

        pdata = data["position"]
        if pdata is None:
            raise ValueError(f"No strategy {strategy_id} found")

        return cls(data["strategy"], pdata, market)

    @classmethod
    def from_cloud(
        cls, strategy_id: str, user_id: str | None = None, market: Market | None = None
    ) -> CloudReport:
        token, token_type = finlab.get_token()

        if token_type == "id_token":
            report = cls._try_canonical_load(strategy_id, token, user_id, market)
            if report is not None:
                return report

        return cls._load_from_legacy_api(
            strategy_id, token, token_type, user_id, market
        )

    def upload(self, *args: Any, **kwargs: Any) -> NoReturn:
        raise NotImplementedError(
            "This method is not implemented (since it is not needed)"
        )
