"""Entry point for `python -m finlab` commands.

Usage:
    python -m finlab login     # Browser-based login
    python -m finlab logout    # Clear credentials + remove server session
    python -m finlab status    # Show active sessions and plan info
    python -m finlab token --env  # Export credentials as env vars
    python -m finlab migrate   # Migration guide from FINLAB_API_TOKEN
"""

from __future__ import annotations

import argparse
import sys
from typing import NoReturn, cast


def cmd_login(args: argparse.Namespace) -> NoReturn:
    from finlab.auth import browser_login

    success = browser_login()
    sys.exit(0 if success else 1)


def cmd_logout(args: argparse.Namespace) -> None:
    from finlab.auth import clear_session, logout_session

    success = logout_session()
    if success:
        print("Logged out successfully.")
    else:
        # At least clear local
        clear_session()
        print("Local credentials cleared.")


def cmd_token(args: argparse.Namespace) -> None:
    from finlab.auth import get_session

    session = get_session()
    if not session:
        print("Not logged in. Run: python -m finlab login", file=sys.stderr)
        sys.exit(1)

    if session.get("source") == "env":
        print("Credentials are already from env vars.", file=sys.stderr)
        sys.exit(1)

    refresh_token = session.get("refresh_token")
    session_id = session.get("session_id")
    api_key = session.get("api_key")

    if not refresh_token or not session_id or not api_key:
        print("Incomplete credentials. Run: python -m finlab login", file=sys.stderr)
        sys.exit(1)

    if args.env:
        print(f'export FINLAB_REFRESH_TOKEN="{refresh_token}"')
        print(f'export FINLAB_SESSION_ID="{session_id}"')
        print(f'export FINLAB_API_KEY="{api_key}"')
    else:
        print(f"FINLAB_REFRESH_TOKEN={refresh_token}")
        print(f"FINLAB_SESSION_ID={session_id}")
        print(f"FINLAB_API_KEY={api_key}")


def cmd_migrate(args: argparse.Namespace) -> None:
    import os

    from finlab import _detect_environment
    from finlab.auth import get_session

    env = _detect_environment()
    has_new_creds = get_session() is not None
    has_old_token = bool(os.environ.get("FINLAB_API_TOKEN"))

    if has_new_creds and has_old_token:
        print("Already migrated to new auth system!")
        print("Remove FINLAB_API_TOKEN from your environment to complete migration.")
        if env == "desktop":
            print("Check your shell profile (~/.bashrc, ~/.zshrc) or .env files.")
        elif env == "cloud_functions":
            print(
                "Remove FINLAB_API_TOKEN from your Cloud Functions environment variables."
            )
    elif has_new_creds and not has_old_token:
        print("Already migrated! No action needed.")
    elif env == "colab":
        print("Migration guide for Google Colab:")
        print('  1. Replace finlab.login("YOUR_API_TOKEN") with finlab.login()')
        print("  2. Follow the browser login flow")
        print("  3. Remove any FINLAB_API_TOKEN references from your notebook")
    elif env == "cloud_functions":
        print("Migration guide for Cloud Functions:")
        print("  1. On your local machine, run: python -m finlab login")
        print("  2. Then run: python -m finlab token --env")
        print("  3. Set these 3 env vars in your Cloud Functions config:")
        print("       FINLAB_REFRESH_TOKEN")
        print("       FINLAB_SESSION_ID")
        print("       FINLAB_API_KEY")
        print("  4. Remove FINLAB_API_TOKEN from your config")
    else:
        print("Migration guide:")
        print("  1. Run: python -m finlab login")
        print("  2. Remove FINLAB_API_TOKEN from your shell profile")
        print("     (check ~/.bashrc, ~/.zshrc, or .env files)")


_AI_PLAN_NAMES: dict[int, str] = {2: "AI MAX", 1: "AI"}


def _resolve_plan_name(plan: dict[str, object]) -> str:
    """Derive human-readable plan name from plan dict."""
    role = plan.get("role", "unknown")
    if role != "vip_m":
        return "Free"
    ai_level = plan.get("ai", 0)
    return _AI_PLAN_NAMES.get(ai_level, "VIP") if isinstance(ai_level, int) else "VIP"


def _print_active_sessions(
    sessions: dict[str, dict[str, str]], current_session_id: str | None
) -> None:
    """Print active session list."""
    print("\nActive sessions:")
    for sid, info in sessions.items():
        device = info.get("device_name", "Unknown")
        sname = info.get("session_name", "")
        current = " (this device)" if sid == current_session_id else ""
        label = device
        if sname:
            label += f" [{sname}]"
        print(f"  {sid[:8]}... - {label}{current}")


def cmd_status(args: argparse.Namespace) -> None:
    from finlab.auth import get_session, get_status

    session = get_session()
    if not session:
        print("Not logged in.")
        print("Run: python -m finlab login")
        sys.exit(1)

    session_id = session.get("session_id")
    session_label = session_id[:8] if isinstance(session_id, str) else "n/a"
    print(f"Local session: {session_label}...")
    print(f'API key: {"configured" if session.get("api_key") else "not configured"}')
    if session.get("session_name"):
        print(f'Session name: {session["session_name"]}')
    if session.get("source") == "env":
        print("Source: environment variables")

    status = get_status()
    if not status:
        print("Could not fetch server status (token may have expired).")
        print("Try: python -m finlab login")
        return

    plan = status.get("plan", {})
    print(f"Plan: {_resolve_plan_name(plan if isinstance(plan, dict) else {})}")
    print(f"Sessions: {status.get('count', 0)}/{status.get('max_sessions', 0)}")

    sessions = status.get("sessions", {})
    if isinstance(sessions, dict) and sessions:
        _print_active_sessions(
            cast("dict[str, dict[str, str]]", sessions),
            session_id if isinstance(session_id, str) else None,
        )


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="python -m finlab",
        description="FinLab CLI - Login and session management",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("login", help="Login via browser")
    sub.add_parser("logout", help="Logout and clear credentials")
    sub.add_parser("status", help="Show session info")
    sub.add_parser("migrate", help="Migration guide from FINLAB_API_TOKEN")

    token_parser = sub.add_parser(
        "token", help="Export credentials for headless environments"
    )
    token_parser.add_argument(
        "--env", action="store_true", help="Output as export commands for shell"
    )

    # Cloud strategy scheduling
    from finlab.cli.cloud_schedule import dispatch_cloud, register_cloud_commands

    register_cloud_commands(sub)

    args = parser.parse_args()

    commands = {
        "login": cmd_login,
        "logout": cmd_logout,
        "status": cmd_status,
        "token": cmd_token,
        "migrate": cmd_migrate,
        "cloud": dispatch_cloud,
    }

    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
