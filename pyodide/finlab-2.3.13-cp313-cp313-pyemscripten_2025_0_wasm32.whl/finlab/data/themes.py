"""Taiwan classification snapshots, and the theme memberships observed over time."""

from __future__ import annotations

import warnings
from copy import deepcopy
from typing import TYPE_CHECKING, Any

import pandas as pd

from finlab.dataframe.core import LookaheadWarning
from finlab.exceptions import DataError

from .dataset_versions import _as_of_timestamp

if TYPE_CHECKING:
    from collections.abc import Iterable

# One published classification applied to every date. ``history`` is the
# dataset of memberships observed since fdata began saving them; the other
# company_basic_info columns are current values too, but not classifications.
CLASSIFICATION_SNAPSHOTS: dict[str, dict[str, Any]] = {
    "security_industry_themes": {
        "columns": ["category"],
        "history": "security_industry_themes_history",
    },
    "security_concept_themes": {
        "columns": ["slug", "theme"],
        "history": "security_concept_themes_history",
    },
    "company_basic_info": {"columns": ["產業類別"], "history": None},
}
_HISTORIES = {
    name: note["history"]
    for name, note in CLASSIFICATION_SNAPSHOTS.items()
    if note["history"]
}


def mark_snapshot(dataset: str, frame: pd.DataFrame) -> pd.DataFrame:
    note = CLASSIFICATION_SNAPSHOTS.get(dataset)
    if note is not None:
        frame.attrs["classification_snapshot"] = deepcopy(note)
    return frame


def warn_theme_snapshots(loaded: Iterable[str]) -> None:
    """Name the theme lists this session read; sim cannot tell which ones a position used."""
    names = ", ".join(sorted(name for name in loaded if name in _HISTORIES))
    if names:
        from .get import _stacklevel_outside

        warnings.warn(
            f"This session read {names}, today's membership lists. A position "
            "built from them applies today's members to every past date, so the backtest "
            "may include look-ahead. Use data.theme_members(dataset, at) for the members "
            f"observed at a time.（本次讀過現況名單 {names}；用它選股的回測會把今天的"
            "成分套到每個過去日期，可能含前視。某時點觀測到的成分用 data.theme_members。）",
            LookaheadWarning,
            # Past finlab and sim's contextlib decorators, to the sim() call.
            stacklevel=_stacklevel_outside(("finlab.", "contextlib")),
        )


def theme_members(dataset: str, at: Any) -> pd.DataFrame:
    """Theme memberships of ``dataset`` as observed at ``at``.

    Args:
        dataset: ``'security_concept_themes'`` or ``'security_industry_themes'``.
        at: Cutoff time. Naive values are Asia/Taipei, as in ``data.get(as_of=...)``;
            a bare date means 00:00 that day.

    Returns:
        One row per ``(stock, theme_id)`` whose last event observed by ``at``
        (``<_history>.observed_at``, UTC) is not ``remove``. An empty frame means
        no member was known; it is not an unknown period.

    Raises:
        DataError: ``at`` precedes the first saved observation. Memberships
            before it are unknown and are never filled from today's list.

    Observation times are when fdata saved a list, not when a stock actually
    joined or left a theme. Industry stocks are rechecked in rotation, so a
    change can be observed up to a month late.
    """
    from . import data as data_module

    history = _HISTORIES.get(dataset)
    if history is None:
        raise ValueError(
            f"No observed membership history for {dataset!r}; supported: "
            f"{', '.join(map(repr, sorted(_HISTORIES)))}"
        )
    cutoff = _as_of_timestamp(at).tz_convert("UTC").tz_localize(None)
    events = data_module.get(history)
    events = events.assign(observed_at=pd.to_datetime(events["observed_at"]))
    first = events["observed_at"].min()
    if events.empty or cutoff < first:
        start = "none saved" if events.empty else f"{first} UTC"
        raise DataError(
            f"{dataset} memberships at {cutoff} UTC are unknown: observations start "
            f"at {start}. Earlier members cannot be rebuilt from today's list."
        )
    # data.get gives every table both symbol and its stock_id alias.
    key = ["symbol", "theme_id"]
    known = events[events["observed_at"] <= cutoff]
    last = known.sort_values("observed_at", kind="stable").drop_duplicates(
        key, keep="last"
    )
    columns = ["symbol", "stock_id", "theme_id", "theme"]
    members = last.loc[last["event"] != "remove", columns]
    return members.sort_values(key).reset_index(drop=True)
