"""Backtest simulation orchestrator.

This is the main entry point for running backtests via ``sim()``.
Configuration, validation, report building, and notifications are
delegated to focused package modules:

- ``finlab.backtest.config`` -- SimConfig, input validation
- ``finlab.backtest.report`` -- trades, MAE/MFE, report assembly
- ``finlab.backtest.notify`` -- Line notification delivery
"""

from __future__ import annotations

import contextlib
import datetime
import functools
import inspect
import json
from dataclasses import dataclass
from typing import TYPE_CHECKING, cast

__all__ = ["SimConfig", "sim"]

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Iterator

    from finlab.core import report
    from finlab.market import Market

import logging

import numpy as np
import pandas as pd

import finlab

logger = logging.getLogger(__name__)
from finlab import data as _data_module
from finlab.core.backtest_core import backtest_, get_trade_stocks
from finlab.dataframe import FinlabDataFrame
from finlab.utils import requests

from .config import OperationAndWeight, SimConfig, _resolve_market_config
from .config import validate_sim_inputs as _validate_sim_inputs
from .helpers import (
    compute_trade_return_bounds,
    filter_position_by_change,
    generate_string_rebalance_dates,
    normalize_position_weights,
    validate_position_columns,
)
from .report import build_sim_report as _build_sim_report
from .report import build_trades_df as _build_trades_df
from .report import refine_mae_mfe as _refine_mae_mfe

# Type alias for the positional arguments passed to backtest_()
BacktestArgs = list[np.ndarray]

_suppress_upload: bool = False


def columns_to_numpy(df: pd.DataFrame) -> np.ndarray:
    """Convert DataFrame columns to numpy array for pandas 3.0+ compatibility."""
    return np.asarray(df.columns.astype(str), dtype=object)


def download_backtest_encryption_function_factory() -> Callable[[], str]:
    encryption_time = datetime.datetime.now(tz=datetime.timezone.utc)
    encryption = ""

    def ret() -> str:
        nonlocal encryption_time
        nonlocal encryption

        if (
            datetime.datetime.now(tz=datetime.timezone.utc)
            < encryption_time + datetime.timedelta(days=1)
            and encryption
        ):
            return encryption

        token_result = finlab.get_token()
        if isinstance(token_result, tuple):
            token, token_type = token_result
        else:
            token, token_type = token_result, "api_token"

        params = {
            token_type: token,
            "time": str(datetime.datetime.now(tz=datetime.timezone.utc)),
        }
        res = requests.get(
            "https://asia-east2-fdata-299302.cloudfunctions.net/auth_backtest", params
        )

        if not res.ok:
            try:
                result = res.json()
            except (ValueError, json.JSONDecodeError):
                result = None

            print(result)
            return ""

        d = res.json()

        if "v" in d and "v_msg" in d and finlab.__version__ < d["v"]:
            print(d["v_msg"])

        if "msg" in d:
            print(d["msg"])

        encryption_time = datetime.datetime.now(tz=datetime.timezone.utc)
        encryption = d["encryption"]

        return encryption

    return ret


download_backtest_encryption: Callable[[], str] = (
    download_backtest_encryption_function_factory()
)


def calc_essential_price(
    price: pd.DataFrame, dates: Iterable[pd.Timestamp]
) -> pd.DataFrame:
    dt = min(price.index.values[1:] - price.index.values[:-1])
    date_index = pd.DatetimeIndex(dates)

    indexer = price.index.get_indexer(date_index + dt)

    valid_idx = np.where(
        indexer == -1, np.searchsorted(price.index, date_index, side="right"), indexer
    )
    valid_idx = np.where(valid_idx >= len(price), len(price) - 1, valid_idx)

    return price.iloc[valid_idx]


def arguments(
    price: pd.DataFrame,
    close: pd.DataFrame,
    high: pd.DataFrame,
    low: pd.DataFrame,
    open_: pd.DataFrame,
    position: pd.DataFrame,
    resample_dates: Iterable[pd.Timestamp] | None = None,
    fast_mode: bool = False,
) -> BacktestArgs:
    resample_index = pd.DatetimeIndex(
        price.index if resample_dates is None else resample_dates
    )
    if resample_index.dtype != price.index.dtype:
        resample_index = resample_index.astype(price.index.dtype)

    position = position.astype(float).fillna(0)

    if fast_mode:
        position = position.reindex(resample_index, method="ffill")
        price = calc_essential_price(price, resample_index)
        close = calc_essential_price(close, resample_index)
        high = calc_essential_price(high, resample_index)
        low = calc_essential_price(low, resample_index)
        open_ = calc_essential_price(open_, resample_index)

    if pd.__version__ >= "2.2.0":
        resample_dates_array = pd.Series(resample_index).astype(np.int64).values
    else:
        resample_dates_array = pd.Series(resample_index).view(np.int64).values

    position_index = position.index
    if position_index.dtype != price.index.dtype:
        position_index = position_index.astype(price.index.dtype)

    return [
        price.values,
        close.values,
        high.values,
        low.values,
        open_.values,
        price.index.view(np.int64),
        columns_to_numpy(price),
        position.values,
        position_index.view(np.int64),
        columns_to_numpy(position),
        resample_dates_array,
    ]


def _reindex_if_needed(df: pd.DataFrame, ref_df: pd.DataFrame) -> pd.DataFrame:
    if df.shape != ref_df.shape:
        df = df.reindex_like(ref_df)
    return df


def _require_market(cfg: SimConfig) -> Market:
    if cfg.market is None:
        raise RuntimeError("market must be resolved before simulation")
    return cfg.market


def _compute_resample_dates(
    position: pd.DataFrame,
    resample: str
    | pd.DataFrame
    | pd.Series
    | pd.DatetimeIndex
    | list[datetime.datetime]
    | None,
    resample_offset: str | None,
    present_data_date: pd.Timestamp | datetime.datetime,
    price: pd.DataFrame,
    tz: datetime.tzinfo | None,
) -> tuple[list[pd.Timestamp] | None, pd.Timestamp, pd.DataFrame]:
    """Compute rebalance dates from the resample parameter.

    Returns (dates, next_trading_date, position) where dates may be None.
    """
    dates = None
    next_trading_date = position.index[-1]

    if isinstance(resample, (pd.DataFrame, pd.Series)):
        if isinstance(resample.index, pd.DatetimeIndex):
            dates = resample.index.tolist()
        elif isinstance(resample, FinlabDataFrame):
            dates = resample.index_str_to_date().index.tolist()
        if dates is None:
            raise TypeError("resample dataframe must have a DatetimeIndex")
        dates = [d for d in dates if position.index[0] <= d <= present_data_date]
        next_trading_date = dates[-1]

    elif isinstance(resample, pd.DatetimeIndex):
        dates = resample.tolist()
        dates = [d for d in dates if position.index[0] <= d <= present_data_date]
        next_trading_date = dates[-1]

    elif isinstance(resample, list):
        if not isinstance(resample[0], datetime.datetime):
            raise TypeError(
                "resample list elements must be datetime.datetime instances"
            )
        dates = [d for d in resample if position.index[0] <= d <= present_data_date]
        next_trading_date = dates[-1]

    elif isinstance(resample, str):
        dates = generate_string_rebalance_dates(
            position.index[0],
            present_data_date,
            price.index[-1],
            resample,
            resample_offset,
            tz,
        )
        next_trading_date = dates[-1]

    elif resample is None:
        position = filter_position_by_change(position)
        next_trading_date = position.index[-1]

    return dates, next_trading_date, position


def _prepare_price_data(
    cfg: SimConfig,
    price: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Fetch and align price data (close, high, low, open) for the backtest.

    Emits warnings when using a DataFrame as trade_at_price with touched_exit.
    Parses live_performance_start if provided as a string.
    Returns (close, high, low, open_).
    """
    if isinstance(cfg.trade_at_price, pd.DataFrame) and cfg.touched_exit:
        print(
            "**WARNING: Using trade_at_price as dataframe without high, and low price. Candle information is not completed."
        )
        print("           The backtest result can be incorrect when touched_exit=True.")
        print(
            "           If the complete backtest result is required, please implement Market Class with get_price function."
        )
        print("           Market details: https://doc.finlab.tw/reference/market_info/")
        print(
            "           And use backtest.sim(..., market=Market) during backtest, so that the correct information is accessable from backtest.sim()."
        )

    try:
        if isinstance(cfg.live_performance_start, str):
            cfg.live_performance_start = datetime.datetime.fromisoformat(
                cfg.live_performance_start
            )
    except ValueError as e:
        raise ValueError(
            "**ERROR: live_performance_start string format not valid. It should be ISO format, i.e. YYYY-MM-DD."
        ) from e

    close = price
    high = price
    low = price
    open_ = price
    market = _require_market(cfg)
    if cfg.touched_exit:
        high = _reindex_if_needed(market.get_price("high", adj=True), price)
        low = _reindex_if_needed(market.get_price("low", adj=True), price)
        open_ = _reindex_if_needed(market.get_price("open", adj=True), price)

    if not isinstance(cfg.trade_at_price, str) or cfg.trade_at_price != "close":
        close = _reindex_if_needed(
            market.get_price("close", adj=True).reindex_like(price), price
        )

    return close, high, low, open_


@dataclass(slots=True)
class _PreparedSimulationInputs:
    """Configuration and price inputs prepared before scheduling/execution."""

    cfg: SimConfig
    position: pd.DataFrame | pd.Series
    price: pd.DataFrame
    close: pd.DataFrame
    high: pd.DataFrame
    low: pd.DataFrame
    open_: pd.DataFrame


@dataclass(slots=True)
class _SimulationSchedule:
    """Derived execution schedule and normalized position state."""

    position: pd.DataFrame
    dates: list[pd.Timestamp] | None
    next_trading_date: pd.Timestamp
    tz: datetime.tzinfo | None
    backtest_end_date: pd.Timestamp


@dataclass(slots=True)
class _EngineRun:
    """Raw output from the backtest engine plus execution metadata."""

    creturn_value: np.ndarray
    args: BacktestArgs
    org_position_index: pd.DatetimeIndex


def _prefetch_market_datasets(cfg: SimConfig) -> None:
    market = _require_market(cfg)
    if not hasattr(market, "sim_datasets"):
        return

    trade_at_price = cfg.trade_at_price if isinstance(cfg.trade_at_price, str) else None
    fn = market.sim_datasets
    kwargs: dict[str, object] = {}
    params = _sim_datasets_params(fn)
    if params is None or "trade_at_price" in params:
        kwargs["trade_at_price"] = trade_at_price
    if params is None or "touched_exit" in params:
        kwargs["touched_exit"] = cfg.touched_exit
    if params is not None and not params:
        # Pre-kwarg zero-arg shape from third-party Market subclasses.
        kwargs = {}

    datasets = fn(**kwargs)
    if not datasets:
        return

    with contextlib.suppress(ImportError):
        _data_module.gets(*datasets)


@functools.lru_cache(maxsize=16)
def _sim_datasets_params(fn: Callable[..., object]) -> frozenset[str] | None:
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        return None
    accepts_var_kw = any(
        p.kind is inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()
    )
    if accepts_var_kw:
        return None
    return frozenset(
        name
        for name, p in sig.parameters.items()
        if p.kind
        in (inspect.Parameter.KEYWORD_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
    )


def _resolve_trade_price_frame(cfg: SimConfig) -> pd.DataFrame:
    price = cfg.trade_at_price
    if isinstance(cfg.trade_at_price, str):
        price = _require_market(cfg).get_trading_price(cfg.trade_at_price, adj=True)

    if not isinstance(price, pd.DataFrame):
        raise TypeError("trade_at_price must resolve to a pd.DataFrame")

    return price


def _prepare_simulation_inputs(
    position: pd.DataFrame | pd.Series,
    cfg: SimConfig,
) -> _PreparedSimulationInputs:
    position, cfg = _validate_sim_inputs(position, cfg)
    _prefetch_market_datasets(cfg)
    price = _resolve_trade_price_frame(cfg)
    close, high, low, open_ = _prepare_price_data(cfg, price)
    return _PreparedSimulationInputs(
        cfg=cfg,
        position=position,
        price=price,
        close=close,
        high=high,
        low=low,
        open_=open_,
    )


def _authorize_backtest() -> str:
    encryption = download_backtest_encryption()
    if encryption == "":
        raise PermissionError("Cannot perform backtest, permission denied.")
    return encryption


def _align_position_with_market(
    position: pd.DataFrame,
    price: pd.DataFrame,
) -> pd.DataFrame:
    matched_columns = validate_position_columns(position.columns, price.columns)
    return position[matched_columns]


def _derive_simulation_schedule(
    position: pd.DataFrame | pd.Series,
    cfg: SimConfig,
    price: pd.DataFrame,
) -> _SimulationSchedule:
    """Derive runtime schedule, rebalance dates, and aligned position state.

    Converts Series to DataFrame, computes rebalance dates, aligns the
    position columns to the market price frame, and returns the schedule
    state needed by subsequent phases.

    Precondition: ``_validate_sim_inputs`` has already run, so the position
    has a DatetimeIndex and Series inputs have a valid name.
    """
    if isinstance(position, pd.Series):
        position = position.to_frame()

    if len(position.shape) < 2:
        raise ValueError("position must be a 2D DataFrame")
    delta_time_rebalance = position.index[-1] - position.index[-3]
    backtest_to_end = position.index[-1] + delta_time_rebalance > price.index[-1]

    tz = position.index.tz
    now = datetime.datetime.now(tz=tz)

    is_daily = (
        (position.index.hour == 0).all()
        and (position.index.minute == 0).all()
        and (position.index.second == 0).all()
    )

    if (
        is_daily
        and datetime.datetime.now(tz=_require_market(cfg).tzinfo())
        < _require_market(cfg).market_close_at_timestamp()
    ):
        now = now.replace(
            hour=23, minute=59, second=0, microsecond=0
        ) - datetime.timedelta(days=1)

    present_data_date = (
        max(price.index[-1], now) if backtest_to_end else position.index[-1]
    )
    position = position.loc[(position.index <= present_data_date)]
    backtest_end_date = price.index[-1] if backtest_to_end else position.index[-1]

    dates, next_trading_date, position = _compute_resample_dates(
        position, cfg.resample, cfg.resample_offset, present_data_date, price, tz
    )

    if dates is not None:
        position = position.reindex(dates, method="ffill")

    return _SimulationSchedule(
        position=_align_position_with_market(position, price),
        dates=dates,
        next_trading_date=next_trading_date,
        tz=tz,
        backtest_end_date=backtest_end_date,
    )


@dataclass(slots=True)
class _SimulationResult:
    """Container for raw results from the backtest core execution."""

    creturn: pd.Series
    position: pd.DataFrame
    org_position_index: pd.DatetimeIndex
    trades: pd.DataFrame
    mae_mfe: pd.DataFrame
    operation_and_weight: OperationAndWeight
    price: pd.DataFrame


def _execute_backtest_engine(
    cfg: SimConfig,
    prepared: _PreparedSimulationInputs,
    schedule: _SimulationSchedule,
    encryption: str,
) -> _EngineRun:
    """Run the Cython backtest core only and return raw execution artifacts.

    Post-processing and report assembly are intentionally handled in later
    phases so the engine boundary stays explicit.
    """
    position = schedule.position
    dates = schedule.dates
    stop_loss = cast("float", cfg.stop_loss)
    take_profit = cast("float", cfg.take_profit)
    trail_stop = cast("float", cfg.trail_stop)

    args = arguments(
        prepared.price,
        prepared.close,
        prepared.high,
        prepared.low,
        prepared.open_,
        position,
        dates,
        fast_mode=cfg.fast_mode,
    )

    return _EngineRun(
        creturn_value=backtest_(
            *args,
            encryption=encryption,
            fee_ratio=cfg.fee_ratio,
            tax_ratio=cfg.tax_ratio,
            stop_loss=stop_loss,
            take_profit=take_profit,
            trail_stop=trail_stop,
            touched_exit=cfg.touched_exit,
            position_limit=cfg.position_limit,
            retain_cost_when_rebalance=cfg.retain_cost_when_rebalance,
            stop_trading_next_period=cfg.stop_trading_next_period,
            mae_mfe_window=cfg.mae_mfe_window,
            mae_mfe_window_step=cfg.mae_mfe_window_step,
            periodically_rebalance=cfg.resample is not None,
        ),
        args=args,
        org_position_index=position.index,
    )


def _finalize_simulation_result(
    cfg: SimConfig,
    prepared: _PreparedSimulationInputs,
    schedule: _SimulationSchedule,
    engine_run: _EngineRun,
) -> _SimulationResult:
    """Transform raw engine output into the data required for report building."""
    position = schedule.position
    dates = schedule.dates

    position = pd.DataFrame(
        normalize_position_weights(position.values, cfg.position_limit),
        index=position.index,
        columns=position.columns,
    )

    creturn_dates = dates if dates and cfg.fast_mode else prepared.price.index

    creturn = (
        pd.Series(engine_run.creturn_value, creturn_dates)
        .pipe(lambda df: df[(df != 1).cumsum().shift(-1, fill_value=1) != 0])
        .loc[: schedule.backtest_end_date]
        .pipe(lambda df: df if len(df) != 0 else pd.Series(1, position.index))
    )

    position = position.loc[creturn.index[0] :]

    price_index = engine_run.args[5]
    position_columns = engine_run.args[9]
    trades_raw, operation_and_weight = get_trade_stocks(
        position_columns, price_index, touched_exit=cfg.touched_exit
    )

    stop_loss = cast("float", cfg.stop_loss)
    take_profit = cast("float", cfg.take_profit)
    m = _refine_mae_mfe(
        cfg.mae_mfe_window_step, cfg.touched_exit, stop_loss, take_profit
    )
    price_index_dtype = prepared.price.index.dtype
    if getattr(prepared.price.index, "tz", None) is not None:
        price_index_dtype = prepared.price.index.tz_localize(None).dtype

    datetime_unit = np.datetime_data(price_index_dtype)[0]
    trades = _build_trades_df(trades_raw, schedule.tz, datetime_unit)

    if len(trades) != 0:
        trades = trades.assign(**{"return": (m.iloc[:, -1])})

        if cfg.touched_exit:
            if cfg.fee_ratio is None or cfg.tax_ratio is None:
                raise RuntimeError("fee_ratio and tax_ratio must be resolved")
            min_return, max_return = compute_trade_return_bounds(
                cfg.fee_ratio,
                cfg.tax_ratio,
                stop_loss,
                take_profit,
            )
            trades["return"] = trades["return"].clip(min_return, max_return)

    return _SimulationResult(
        creturn=creturn,
        position=position,
        org_position_index=engine_run.org_position_index,
        trades=trades,
        mae_mfe=m,
        operation_and_weight=operation_and_weight,
        price=prepared.price,
    )


def _build_simulation_report(
    cfg: SimConfig,
    prepared: _PreparedSimulationInputs,
    schedule: _SimulationSchedule,
    engine_run: _EngineRun,
) -> report.Report:
    result = _finalize_simulation_result(cfg, prepared, schedule, engine_run)
    return _build_sim_report(
        cfg,
        result,
        schedule.next_trading_date,
        _suppress_upload,
    )


def _restore_backtest_context() -> None:
    from finlab.markets.tw import TWMarket as _TW

    _TW._categories_cache = None


@contextlib.contextmanager
def _backtest_context() -> Iterator[None]:
    with _data_module._default_context.override(prefer_local_if_exists=True):
        try:
            yield
        finally:
            _restore_backtest_context()


def _collect_lazy_position_for_sim(
    position: object,
    cfg: SimConfig,
) -> pd.DataFrame:
    """Collect LazyWide positions on the same calendar dates sim will use."""
    from finlab.dataframe.lazy_execution import (
        _build_execution_cache,
    )
    from finlab.dataframe.lazy_nodes import _collect_full_index

    if not isinstance(cfg.resample, str):
        return position.collect()  # type: ignore[attr-defined]

    _resolve_market_config(cfg)
    price = _resolve_trade_price_frame(cfg)
    cache = _build_execution_cache(position._node)  # type: ignore[attr-defined]
    full_index = _collect_full_index(position._node, cache)  # type: ignore[attr-defined]
    if not isinstance(full_index, pd.DatetimeIndex) or len(full_index) < 3:
        return position.collect()  # type: ignore[attr-defined]

    delta_time_rebalance = full_index[-1] - full_index[-3]
    backtest_to_end = full_index[-1] + delta_time_rebalance > price.index[-1]
    tz = full_index.tz
    now = datetime.datetime.now(tz=tz)

    is_daily = (
        (full_index.hour == 0).all()
        and (full_index.minute == 0).all()
        and (full_index.second == 0).all()
    )

    if (
        is_daily
        and datetime.datetime.now(tz=_require_market(cfg).tzinfo())
        < _require_market(cfg).market_close_at_timestamp()
    ):
        now = now.replace(
            hour=23, minute=59, second=0, microsecond=0
        ) - datetime.timedelta(days=1)

    present_data_date = max(price.index[-1], now) if backtest_to_end else full_index[-1]
    position_start = max(price.index[0], full_index[0])
    dates = generate_string_rebalance_dates(
        position_start,
        present_data_date,
        price.index[-1],
        cfg.resample,
        cfg.resample_offset,
        tz,
    )

    collect_dates = pd.DatetimeIndex(dates)
    last_signal_pos = full_index.searchsorted(present_data_date, side="right") - 1
    if last_signal_pos >= 0:
        collect_dates = collect_dates.union(
            pd.DatetimeIndex([full_index[last_signal_pos]])
        )

    collected = position.collect(collect_dates)  # type: ignore[attr-defined]
    collected = collected.reindex(collect_dates, method="ffill")
    valid_rows = collected.notna().any(axis=1)
    if valid_rows.any():
        collected = collected.loc[valid_rows.idxmax() :]
    if len(collected) < 3:
        return position.collect()  # type: ignore[attr-defined]

    return collected


def sim(
    position: pd.DataFrame | pd.Series,
    resample: str | None = None,
    resample_offset: str | None = None,
    trade_at_price: str | pd.DataFrame = "close",
    position_limit: float = 1,
    fee_ratio: float | None = None,
    tax_ratio: float | None = None,
    name: str = "未命名",
    stop_loss: float | None = None,
    take_profit: float | None = None,
    trail_stop: float | None = None,
    touched_exit: bool = False,
    retain_cost_when_rebalance: bool = False,
    stop_trading_next_period: bool = True,
    live_performance_start: str | None = None,
    mae_mfe_window: int = 0,
    mae_mfe_window_step: int = 1,
    market: None | Market = None,
    upload: bool | None = None,
    fast_mode: bool = False,
    notification_enable: bool = False,
    line_access_token: str = "",
) -> report.Report:
    """Simulate the equity given the stock position history.

    See the module-level docstring and the parameter docs below for full details.

    Args:
        position: Buy/sell signal history. True = hold, False = flat.
            Can also be a ``LazyWide`` — it will be auto-collected at
            the rebalance dates determined by *resample*.
        resample: Trading period frequency (e.g. 'W', 'M', 'Q').
        resample_offset: Time offset for the resample period.
        trade_at_price: Price type for trade execution ('close', 'open', etc.).
        position_limit: Maximum single-stock weight (0-1).
        fee_ratio: Trading fee ratio.
        tax_ratio: Trading tax ratio.
        name: Strategy name.
        stop_loss: Stop-loss threshold.
        take_profit: Take-profit threshold.
        trail_stop: Trailing stop threshold.
        touched_exit: Use intraday touched stop-loss/take-profit.
        retain_cost_when_rebalance: Keep original cost basis on rebalance.
        stop_trading_next_period: Skip next period after stop-loss/take-profit.
        live_performance_start: ISO date string marking live trading start.
        mae_mfe_window: Window size for MAE/MFE calculation.
        mae_mfe_window_step: Step size for MAE/MFE window.
        market: Market instance or name string ('TW_STOCK', 'US_STOCK').
        upload: Whether to upload the strategy report. When omitted,
            FINLAB_STRATEGY_NAME/FINLAB_FORCED_STRATEGY_NAME enables upload.
        fast_mode: Use fast simulation mode (no stop-loss/take-profit).
        notification_enable: Send Line notifications on completion.
        line_access_token: Line Notify access token.

    Returns:
        Report object with backtest results and analytics.
    """
    cfg = SimConfig(
        resample=resample,
        resample_offset=resample_offset,
        trade_at_price=trade_at_price,
        position_limit=position_limit,
        fee_ratio=fee_ratio,
        tax_ratio=tax_ratio,
        name=name,
        stop_loss=stop_loss,
        take_profit=take_profit,
        trail_stop=trail_stop,
        touched_exit=touched_exit,
        retain_cost_when_rebalance=retain_cost_when_rebalance,
        stop_trading_next_period=stop_trading_next_period,
        live_performance_start=live_performance_start,
        mae_mfe_window=mae_mfe_window,
        mae_mfe_window_step=mae_mfe_window_step,
        market=market,
        upload=upload,
        fast_mode=fast_mode,
        notification_enable=notification_enable,
        line_access_token=line_access_token,
    )

    # Auto-collect LazyWide at rebalance dates for optimal performance.
    from finlab.dataframe.lazy import LazyWide

    if isinstance(position, LazyWide):
        position = _collect_lazy_position_for_sim(position, cfg)

    # Suggest lazy() when position is large and resampled.
    if (
        isinstance(position, pd.DataFrame)
        and cfg.resample is not None
        and len(position) > 500
    ):
        logger.info(
            "Tip: wrap your computation with .lazy() for faster rebalanced "
            "strategies. Example: close.lazy().rolling(60).mean().is_largest(10)"
        )

    with _backtest_context():
        prepared = _prepare_simulation_inputs(position, cfg)
        schedule = _derive_simulation_schedule(
            prepared.position,
            prepared.cfg,
            prepared.price,
        )
        engine_run = _execute_backtest_engine(
            prepared.cfg,
            prepared,
            schedule,
            _authorize_backtest(),
        )
        return _build_simulation_report(
            prepared.cfg,
            prepared,
            schedule,
            engine_run,
        )
