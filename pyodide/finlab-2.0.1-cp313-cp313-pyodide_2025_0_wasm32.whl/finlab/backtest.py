from __future__ import annotations

import datetime
import functools
import json
import operator
import sys
import threading
import warnings
from dataclasses import dataclass
from typing import TYPE_CHECKING, TypedDict

__all__ = ["SimConfig", "sim"]

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable

import numpy as np
import pandas as pd
from pandas.tseries.frequencies import to_offset
from pandas.tseries.offsets import DateOffset

import finlab
from finlab import config
from finlab import data as _data_module
from finlab.core import mae_mfe as maemfe
from finlab.core import report
from finlab.core.backtest_core import backtest_, get_trade_stocks
from finlab.dataframe import FinlabDataFrame
from finlab.market import Market
from finlab.markets import get_market_by_name
from finlab.utils import check_version, requests

# Type alias for the positional arguments passed to backtest_()
BacktestArgs = list[np.ndarray]


class _OperationAndWeight(TypedDict):
    weights: list[float]
    next_weights: list[float]
    weight_time: int
    next_weight_time: int
    actions: list[str]


_suppress_upload: bool = False


@dataclass(slots=True)
class SimConfig:
    """Configuration for backtest simulation parameters.

    Groups the many sim() parameters into a single config object
    for cleaner internal passing between phases.
    """

    resample: (
        str
        | pd.DataFrame
        | pd.Series
        | pd.DatetimeIndex
        | list[datetime.datetime]
        | None
    ) = None
    resample_offset: str | None = None
    trade_at_price: str | pd.DataFrame = "close"
    position_limit: float = 1
    fee_ratio: float | None = None
    tax_ratio: float | None = None
    name: str = "未命名"
    stop_loss: float | None = None
    take_profit: float | None = None
    trail_stop: float | None = None
    touched_exit: bool = False
    retain_cost_when_rebalance: bool = False
    stop_trading_next_period: bool = True
    live_performance_start: str | None = None
    mae_mfe_window: int = 0
    mae_mfe_window_step: int = 1
    market: Market | None = None
    upload: bool = True
    fast_mode: bool = False
    notification_enable: bool = False
    line_access_token: str = ""


def columns_to_numpy(df: pd.DataFrame) -> np.ndarray:
    """Convert DataFrame columns to numpy array for pandas 3.0+ compatibility."""
    return np.asarray(df.columns.astype(str), dtype=object)


def warning_resample(resample: str) -> None:
    if "+" not in resample and "-" not in resample:
        return

    if "-" in resample and not resample.rsplit("-", maxsplit=1)[-1].isdigit():
        return

    if "+" in resample:
        r, o = resample.split("+")
    else:
        r, o = resample.split("-")

    warnings.warn(
        f"The argument sim(..., resample = '{resample}') will no longer support after 0.1.37.dev1.\n"
        f"please use sim(..., resample='{r}', offset='{o}d')",
        DeprecationWarning,
        stacklevel=2,
    )


def download_backtest_encryption_function_factory() -> Callable[[], str]:
    encryption_time = datetime.datetime.now(tz=datetime.timezone.utc)
    encryption = ""

    def ret() -> str:
        nonlocal encryption_time
        nonlocal encryption

        if (
            datetime.datetime.now(tz=datetime.timezone.utc)
            < encryption_time + datetime.timedelta(days=1)
            and encryption
        ):
            return encryption

        token_result = finlab.get_token()
        if isinstance(token_result, tuple):
            token, token_type = token_result
        else:
            token, token_type = token_result, "api_token"

        params = {
            token_type: token,
            "time": str(datetime.datetime.now(tz=datetime.timezone.utc)),
        }
        res = requests.get(
            "https://asia-east2-fdata-299302.cloudfunctions.net/auth_backtest", params
        )

        if not res.ok:
            try:
                result = res.json()
            except (ValueError, json.JSONDecodeError):
                result = None

            print(result)
            return ""

        d = res.json()

        if "v" in d and "v_msg" in d and finlab.__version__ < d["v"]:
            print(d["v_msg"])

        if "msg" in d:
            print(d["msg"])

        encryption_time = datetime.datetime.now(tz=datetime.timezone.utc)
        encryption = d["encryption"]

        return encryption

    return ret


download_backtest_encryption: Callable[[], str] = (
    download_backtest_encryption_function_factory()
)


def calc_essential_price(
    price: pd.DataFrame, dates: Iterable[pd.Timestamp]
) -> pd.DataFrame:
    dt = min(price.index.values[1:] - price.index.values[:-1])

    indexer = price.index.get_indexer(dates + dt)

    valid_idx = np.where(
        indexer == -1, np.searchsorted(price.index, dates, side="right"), indexer
    )
    valid_idx = np.where(valid_idx >= len(price), len(price) - 1, valid_idx)

    return price.iloc[valid_idx]


def arguments(
    price: pd.DataFrame,
    close: pd.DataFrame,
    high: pd.DataFrame,
    low: pd.DataFrame,
    open_: pd.DataFrame,
    position: pd.DataFrame,
    resample_dates: Iterable[pd.Timestamp] | None = None,
    fast_mode: bool = False,
) -> BacktestArgs:
    resample_dates = price.index if resample_dates is None else resample_dates

    if resample_dates is not None:
        resample_dates = pd.to_datetime(resample_dates)
        if resample_dates.dtype != price.index.dtype:
            resample_dates = resample_dates.astype(price.index.dtype)

    position = position.astype(float).fillna(0)

    if fast_mode:
        position = position.reindex(resample_dates, method="ffill")
        price = calc_essential_price(price, resample_dates)
        close = calc_essential_price(close, resample_dates)
        high = calc_essential_price(high, resample_dates)
        low = calc_essential_price(low, resample_dates)
        open_ = calc_essential_price(open_, resample_dates)

    if pd.__version__ >= "2.2.0":
        resample_dates = pd.Series(resample_dates).astype(np.int64).values
    else:
        resample_dates = pd.Series(resample_dates).view(np.int64).values

    position_index = position.index
    if position_index.dtype != resample_dates.dtype:
        position_index = position_index.astype(resample_dates.dtype)

    return [
        price.values,
        close.values,
        high.values,
        low.values,
        open_.values,
        price.index.view(np.int64),
        columns_to_numpy(price),
        position.values,
        position_index.view(np.int64),
        columns_to_numpy(position),
        resample_dates,
    ]


def line_notify(
    report: report.Report | None = None,
    line_access_token: str = "",
    test: bool = False,
    name: str = "",
) -> None:
    """傳送回測結果之目前部位、近期換股訊息至Line聊天室。

    Args:
        report (Report):
            回測完的結果報告。

        line_access_token (str):
            於Line Notify取得的access_token(權杖)。至[Line Notify](https://notify-bot.line.me/zh_TW/ )登入Line帳號後，點選個人頁面，點選「發行權杖」，選擇欲接收訊息的聊天室(可選擇1對1接收Line Notify通知、或是選擇其他群組聊天室)，即可取得權杖。
        test (bool):
            是否進行傳送訊息測試。

        name (str):
            策略名稱，預設為空字串。

    Examples:
        欲進行測試，則設定`test`參數為True。

        ``` py
        from finlab import backtest

        line_access_token = 'xxxxxxxxxxxx'
        backtest.line_notify(line_access_token=line_access_token, test=True)
        ```

        若成功收到通知，則權杖設定已完畢，可直接在`sim`回測模組中開啟使用，或單獨調用此函式發送回測換股訊息。
        於sim中使用:

        ``` py
        from finlab import backtest

        line_access_token = 'xxxxxxxxxxxx'
        position = ...
        report = backtest.sim(position, notification_enable =True, line_access_token = line_access_token)
        ```

        已回測完，單獨傳訊息用:

        ``` py
        from finlab import backtest

        line_access_token = 'xxxxxxxxxxxx'
        report = backtest.sim(position)
        backtest.line_notify(report, line_access_token=line_access_token)
        ```

    """
    if test:
        message = "Finlab line_notify 測試成功"
    else:
        if not isinstance(report, finlab.core.report.Report):
            raise TypeError("Please provide a valid backtest report.")
        hold: list[str] = []
        enter: list[str] = []
        exit: list[str] = []
        for i, p in report.position_info().items():
            if isinstance(p, dict) and i[:4].isdigit():
                if p["status"] == "exit" and pd.isnull(
                    report.current_trades.loc[i].exit_date
                ):
                    hold.append(f"{i}: {p['entry_date'][:10]}, {p['entry_price']!s}")
                if p["status"] in {"hold", "sl", "tp"}:
                    hold.append(f"{i}: {p['entry_date'][:10]}, {p['entry_price']!s}")
                if p["status"] == "enter":
                    enter.append(f"{i}: {p['entry_date'][:10]}的下個交易日進場")
                if p["status"] in {"exit", "sl", "tp", "sl_enter", "tp_enter"}:
                    exit.append(f"{i}: {p['exit_date'][:10]}的下個交易日出場")
        message_lines = [f"目前策略{name} 進場日及進場價格："]
        message_lines.extend(hold)
        message_lines.append("------------------------------")
        message_lines.append("近期操作：")
        message_lines.append("-策略新增")
        if enter:
            message_lines.extend(enter)
        else:
            message_lines.append("尚無")
        message_lines.append("-策略移除")
        if exit:
            message_lines.extend(exit)
        else:
            message_lines.append("尚無")
        message = "\n".join(message_lines)

    headers = {
        "Authorization": "Bearer " + line_access_token,
        "Content-Type": "application/x-www-form-urlencoded",
    }
    r = requests.post(
        "https://notify-api.line.me/api/notify",
        headers=headers,
        params={"message": message},
    )
    if test:
        resp = json.loads(r.text)
        if resp["status"] == 401:
            print(f"測試失敗。{r.text}")
        elif resp["status"] == 200:
            print("測試成功，可開始使用finlab line_notify")


def _reindex_if_needed(df: pd.DataFrame, ref_df: pd.DataFrame) -> pd.DataFrame:
    if df.shape != ref_df.shape:
        df = df.reindex_like(ref_df)
    return df


def _compute_resample_dates(
    position: pd.DataFrame,
    resample: str
    | pd.DataFrame
    | pd.Series
    | pd.DatetimeIndex
    | list[datetime.datetime]
    | None,
    resample_offset: str | None,
    present_data_date: pd.Timestamp | datetime.datetime,
    price: pd.DataFrame,
    tz: datetime.tzinfo | None,
) -> tuple[list[pd.Timestamp] | None, pd.Timestamp, pd.DataFrame]:
    """Compute rebalance dates from the resample parameter.

    Returns (dates, next_trading_date, position) where dates may be None.
    """
    dates = None
    next_trading_date = position.index[-1]

    if isinstance(resample, (pd.DataFrame, pd.Series)):
        if isinstance(resample.index, pd.DatetimeIndex):
            dates = resample.index.tolist()
        elif isinstance(resample, FinlabDataFrame):
            dates = resample.index_str_to_date().index.tolist()
        dates = [d for d in dates if position.index[0] <= d <= present_data_date]
        next_trading_date = dates[-1]

    elif isinstance(resample, pd.DatetimeIndex):
        dates = resample.tolist()
        dates = [d for d in dates if position.index[0] <= d <= present_data_date]
        next_trading_date = dates[-1]

    elif isinstance(resample, list):
        if not isinstance(resample[0], datetime.datetime):
            raise TypeError(
                "resample list elements must be datetime.datetime instances"
            )
        dates = [d for d in resample if position.index[0] <= d <= present_data_date]
        next_trading_date = dates[-1]

    elif isinstance(resample, str):
        if pd.__version__ >= "2.2.0":
            old_resample_strings = ["M", "BM", "SM", "CBM", "Q", "BQ", "A", "Y", "BY"]
            if resample in old_resample_strings:
                resample += "E"

        offset_days = 0
        if "+" in resample:
            resample, offset_str = resample.rsplit("+", 1)
            offset_days = int(offset_str)
        elif "-" in resample:
            parts = resample.rsplit("-", 1)
            if parts[-1].isdigit():
                resample = parts[0]
                offset_days = -int(parts[-1])

        alldates = pd.date_range(
            position.index[0],
            present_data_date + datetime.timedelta(days=360),
            freq=resample,
            tz=tz,
        )
        alldates += DateOffset(days=offset_days)

        if resample_offset is not None:
            alldates += to_offset(resample_offset)

        dates = [d for d in alldates if position.index[0] <= d <= present_data_date]

        if price.index[-1] > dates[-1]:
            remain_dates = set(alldates) - set(dates)
            if remain_dates:
                dates += [min(remain_dates)]

        next_trading_date = dates[-1]

    elif resample is None:
        change = (position.diff().abs().sum(axis=1) != 0) | (
            (position.index == position.index[0]) & position.iloc[0].notna().any()
        )
        position = position.loc[change]
        next_trading_date = position.index[-1]

    return dates, next_trading_date, position


def _refine_mae_mfe(
    mae_mfe_window_step: int,
    touched_exit: bool,
    stop_loss: float,
    take_profit: float,
) -> pd.DataFrame:
    """Process raw mae_mfe data into a structured MultiIndex DataFrame."""
    if len(maemfe.mae_mfe) == 0:
        return pd.DataFrame()

    m = pd.DataFrame(maemfe.mae_mfe)
    nsets = int((m.shape[1] - 1) / 6)
    metrics = ["mae", "gmfe", "bmfe", "mdd", "pdays", "return"]

    tuples = functools.reduce(
        operator.iadd,
        [
            [
                (n, metric) if n == "exit" else (n * mae_mfe_window_step, metric)
                for metric in metrics
            ]
            for n in [*range(nsets), "exit"]
        ],
        [],
    )

    m.columns = pd.MultiIndex.from_tuples(tuples, names=["window", "metric"])
    m.index.name = "trade_index"
    m[m == -1] = np.nan

    exit_data = m.exit.copy()
    if touched_exit and len(m) > 0 and "exit" in m.columns:
        m["exit"] = (
            exit_data.assign(
                gmfe=exit_data.gmfe.clip(-abs(stop_loss), abs(take_profit))
            )
            .assign(bmfe=exit_data.bmfe.clip(-abs(stop_loss), abs(take_profit)))
            .assign(mae=exit_data.mae.clip(-abs(stop_loss), abs(take_profit)))
            .assign(mdd=exit_data.mdd.clip(-abs(stop_loss), abs(take_profit)))
        )

    return m


def _build_trades_df(
    trades_raw: list[list[object]], tz: datetime.tzinfo | None
) -> pd.DataFrame:
    """Convert raw trade data from the Cython core into a DataFrame."""

    def convert_datetime_series(df: pd.DataFrame) -> pd.DataFrame:
        cols = ["entry_date", "exit_date", "entry_sig_date", "exit_sig_date"]
        df[cols] = df[cols].apply(lambda s: pd.to_datetime(s).dt.tz_localize(tz))
        return df

    def assign_exit_nat(df: pd.DataFrame) -> pd.DataFrame:
        cols = ["exit_date", "exit_sig_date"]
        df[cols] = df[cols].loc[df.exit_index != -1]
        return df

    return (
        pd.DataFrame(
            trades_raw,
            columns=[
                "symbol",
                "entry_date",
                "exit_date",
                "entry_sig_date",
                "exit_sig_date",
                "position",
                "period",
                "entry_index",
                "exit_index",
            ],
        )
        .rename_axis("trade_index")
        .pipe(convert_datetime_series)
        .pipe(assign_exit_nat)
    )


def _populate_report(
    r: report.Report,
    cfg: SimConfig,
    trades: pd.DataFrame,
    m: pd.DataFrame,
    operation_and_weight: _OperationAndWeight,
    org_position_index: pd.DatetimeIndex,
    price: pd.DataFrame,
    market: Market,
) -> report.Report:
    """Attach weights, actions, trade metadata, and analyses to the report."""
    r.resample = cfg.resample
    r.stop_loss = cfg.stop_loss
    r.take_profit = cfg.take_profit
    r.trail_stop = cfg.trail_stop
    r.live_performance_start = cfg.live_performance_start
    r.mae_mfe = m
    r.trades = trades

    # weights
    if len(operation_and_weight["weights"]) != 0:
        r.weights = pd.Series(operation_and_weight["weights"])
        r.weights.index = r.position.columns[r.weights.index]
    else:
        r.weights = pd.Series(dtype="float64")

    if len(operation_and_weight["next_weights"]) != 0:
        r.next_weights = pd.Series(operation_and_weight["next_weights"])
        r.next_weights.index = r.position.columns[r.next_weights.index]
    else:
        r.next_weights = pd.Series(dtype="float64")

    r.weights.name = org_position_index[operation_and_weight["weight_time"]]
    r.next_weights.name = org_position_index[operation_and_weight["next_weight_time"]]

    # actions
    if len(operation_and_weight["actions"]) != 0:
        r.actions = pd.Series(operation_and_weight["actions"])
        r.actions.index = r.position.columns[r.actions.index]
    else:
        r.actions = pd.Series(dtype=object)

    # map stock IDs to names and industries
    snames = market.get_asset_id_to_name()
    industry = market.get_industry()

    def f_id_to_name(sid: str) -> str:
        return f"{sid + ' ' + snames[sid] if sid in snames else sid}"

    def f_id_to_industry(sid: str) -> str:
        return industry.get(sid, "")

    if len(r.actions) != 0:
        actions = r.actions
        sell_sids = actions[actions == "exit"].index
        sell_instant_sids = actions[
            (actions == "sl")
            | (actions == "tp")
            | (actions == "sl_enter")
            | (actions == "tp_enter")
        ].index
        buy_sids = actions[actions == "enter"].index

        if len(sell_instant_sids):
            r.next_trading_date = price.index[-1]

        if len(trades):
            if set(sell_sids) - set(trades.symbol[trades.exit_sig_date.isnull()]):
                raise ValueError(
                    "Sell signals contain symbols not found in open trades"
                )

            temp = trades.loc[trades.symbol.isin(sell_sids), "exit_sig_date"].fillna(
                r.position.index[-1]
            )
            trades.loc[trades.symbol.isin(sell_sids), "exit_sig_date"] = temp

            temp = trades.loc[
                trades.symbol.isin(sell_instant_sids), "exit_sig_date"
            ].fillna(price.index[-1])
            trades.loc[trades.symbol.isin(sell_instant_sids), "exit_sig_date"] = (
                temp.to_numpy()
            )

            r.trades = pd.concat(
                [
                    r.trades,
                    pd.DataFrame(
                        {
                            "symbol": buy_sids,
                            "entry_date": pd.NaT,
                            "entry_sig_date": r.position.index[-1],
                            "exit_date": pd.NaT,
                            "exit_sig_date": pd.NaT,
                        }
                    ),
                ],
                ignore_index=True,
            )

            r.trades["exit_sig_date"] = pd.to_datetime(r.trades.exit_sig_date)

    if len(trades) != 0:
        r.trades["industry"] = r.trades.symbol.map(f_id_to_industry)
        r.trades["symbol"] = r.trades.symbol.map(f_id_to_name)
        r.trades["stock_id"] = r.trades["symbol"]

    if hasattr(r, "actions") and len(r.actions) != 0:
        r.actions.index = r.actions.index.map(f_id_to_name)

    r.weights.index = r.weights.index.map(f_id_to_name)
    r.next_weights.index = r.next_weights.index.map(f_id_to_name)

    trade_at_price = cfg.trade_at_price
    if isinstance(trade_at_price, str):
        trade_price_data = market.get_trading_price(trade_at_price, adj=False)
    else:
        trade_price_data = trade_at_price
    r.add_trade_info("trade_price", trade_price_data, ["entry_date", "exit_date"])
    r.add_trade_info("adj_close", market.get_price("close", adj=True), ["entry_date"])

    if len(r.trades) != 0 and not cfg.fast_mode and market.get_name() == "tw_stock":
        r.run_analysis("Liquidity", display=False)

    # merge mae_mfe exit data into trades
    if len(trades) != 0:
        trades = r.trades
        mae_mfe = r.mae_mfe
        exit_mae_mfe = mae_mfe["exit"].copy().drop(columns=["return"])
        r.trades = pd.concat([trades, exit_mae_mfe], axis=1)
        r.trades.index.name = "trade_index"
        r.calculate_current_trades()

    return r


def sim(
    position: pd.DataFrame | pd.Series,
    resample: str | None = None,
    resample_offset: str | None = None,
    trade_at_price: str | pd.DataFrame = "close",
    position_limit: float = 1,
    fee_ratio: float | None = None,
    tax_ratio: float | None = None,
    name: str = "未命名",
    stop_loss: float | None = None,
    take_profit: float | None = None,
    trail_stop: float | None = None,
    touched_exit: bool = False,
    retain_cost_when_rebalance: bool = False,
    stop_trading_next_period: bool = True,
    live_performance_start: str | None = None,
    mae_mfe_window: int = 0,
    mae_mfe_window_step: int = 1,
    market: None | Market = None,
    upload: bool = True,
    fast_mode: bool = False,
    notification_enable: bool = False,
    line_access_token: str = "",
) -> report.Report:
    """Simulate the equity given the stock position history. 回測模擬股票部位所產生的淨值報酬率。

    Args:
        position (pd.DataFrame or pd.Series):
            買賣訊號紀錄。True 為持有， False 為空手。 若選擇做空position，只要將 sim(position) 改成負的 sim(-position.astype(float))即可做空。

        resample (str, None, pd.DataFrame, pd.Series, finlab.dataframe.FinlabDataFrame):
            交易週期。將 position 的訊號以週期性的方式論動股票，預設為每天換股。其他常用數值為 W、 M 、 Q （每週、每月、每季換股一次），也可以使用 W-Fri 在週五的時候產生新的股票清單，並且於下週交易日下單。

            * `D`: Daily
            * `W`: Weekly
            * `W-Wed`: Every Wednesday
            * `M`: Monthly
            * `MS`: Start of every month
            * `Q`: Quarterly
            * `QS`: Start of every quarter

            !!!note
                'D'與'None'的差別？
                resample='D' 的意義為每天隨股價變化做再平衡，就算當天股票清單沒變，但股票漲跌後，部位大小會變化，而 resample='D' 會強制再平衡，平均分散風險。

                但是當 resample=None 的話，假如清單不變，則不會強制再平衡，只有清單改變時，才做再平衡。適用情境在較常選到大波段標的的趨勢策略，較有機會將強勢股留下，而不會汰強留弱做再平衡。

            另外 `resample` 也接受 pd.DataFrame 以及 pd.Series，並且將其 index 用來當成換股的時間點，例如以下的範例：

            ``` py
            from finlab import backtest, data

            rev = data.get('monthly_revenue:當月營收')
            position = ...

            # 月營收發布時才換股
            backtest.sim(position, resample=rev)
            ```



        resample_offset (str or None):
            交易週期的時間位移，例如。

            - '1D': 位移一天
            - '1H': 位移一小時

        trade_at_price (str or pd.DataFrame):
            選擇回測之還原股價以收盤價或開盤價計算，預設為'close'。可選'close'、'open'、'open_close_avg'、'high_low_avg'或 'price_avg'。

        position_limit (float): maximum amount of investing a stock.
            單檔標的持股比例上限，控制倉位風險。預設為None。範例：0.2，代表單檔標的最多持有 20 % 部位。

        fee_ratio (float): fee ratio of buying or selling a stock.
            交易手續費率。預設值依 market 參數自動調整：台股為 0.001425（台灣無打折手續費），美股為 0（免佣金）。可視個人使用的券商優惠調整費率。

        tax_ratio (float): tax ratio of selling a stock.
            交易稅率。預設值依 market 參數自動調整：台股為 0.003（台灣普通股一般交易稅率），美股為 0。若台股交易策略的標的皆為ETF，記得設成 0.001。

        name (str): name of the strategy.
            策略名稱，預設為 未指名。策略名稱。相同名稱之策略上傳會覆寫。命名規則:全英文或開頭中文，不接受開頭英文接中文。

        stop_loss (float):
            停損基準，預設為None，不執行停損。範例：0.1，代表從再平衡開始，虧損 10% 時產生出場訊號。

        take_profit (float):
            停利基準，預設為None，不執行停利。範例：0.1，代表從再平衡開始， 10% 時產生出場訊號。

        trail_stop (float):
            移動停損停利基準，預設為None，不執行。範例：0.1，代表從最高點開始下跌，跌至 10% 時產生出場訊號。

        touched_exit (bool):
            是否在回測時，使用觸價停損停利？預設為 False。

        retain_cost_when_rebalance (bool):
            當持股再平衡時，如有股票繼續持有，是否保留原本進場的成本，當成停損停利的參考？預設為 False。

        stop_trading_next_period (bool):
            當期已經停損停利，則下一期不買入，預設為 True。

        live_performance_start (str):
            策略建構的日期，例如 `2022-01-01` 此日期之前，策略未撰寫，此日期之後則視為與實單有類似效果，實際不影響回測的結果，單純紀錄而已。

        mae_mfe_window (int):
            計算mae_mfe於進場後於不同持有天數下的數據變化，主要應用為edge_ratio (優勢比率)計算。預設為0，則Report.display_mae_mfe_analysis(...)中的edge_ratio不會顯現。

        mae_mfe_window_step (int):
            與mae_mfe_window參數做搭配，為時間間隔設定，預設為1。若mae_mfe_window設20，mae_mfe_window_step設定為2，相當於python的range(0,20,2)，以2日為間距計算mae_mfe。

        market (str or Market):
            可選擇`'TW_STOCK', 'US_STOCK'`，分別為台股或加密貨幣，
            或繼承 finlab.market.Market 開發回測市場類別。

        upload (bool):
            上傳策略，預設為True，上傳策略。
            範例： False，不上傳，可用 finlab.backtest.sim(position, upload=False, ...).display() 快速檢視策略績效。

        fast_mode (bool):
            預設為False，若設定為True，則會使用快速模式，快速模式會忽略所有的停利停損設定，並且只有換股日進行報酬率模擬，因此會有一些誤差，當持有較多檔股票時，可以大幅加速回測速度。

    Returns:
        (Report):回測數據報告

    Examples:
        Assume the history of portfolio is construct as follows: When market close on 2021-12-31, the portfolio {B: 0.2, C: 0.4} is calculated. When market close on 2022-03-31, the portfolio {A:1} is calculated.


        |            | Stock 2330 | Stock 1101 | Stock 2454 |
        |------------|------------|------------|------------|
        | 2021-12-31 | 0%         | 20%        | 40%        |
        | 2022-03-31 | 100%       | 0%         | 0%         |
        | 2022-06-30 | 100%       | 0%         | 0%         |


        With the portfolio, one could backtest the equity history as follows:

        ``` py
        import pandas as pd
        from finlab import backtest

        position = pd.DataFrame({
            '2330': [0, 1, 1],
            '1101': [0.2, 0, 0],
            '2454': [0.4, 0, 0]
        }, index=pd.to_datetime(['2021-12-31', '2022-03-31', '2022-06-30']))

        report = backtest.sim(position)
        ```

    """
    cfg = SimConfig(
        resample=resample,
        resample_offset=resample_offset,
        trade_at_price=trade_at_price,
        position_limit=position_limit,
        fee_ratio=fee_ratio,
        tax_ratio=tax_ratio,
        name=name,
        stop_loss=stop_loss,
        take_profit=take_profit,
        trail_stop=trail_stop,
        touched_exit=touched_exit,
        retain_cost_when_rebalance=retain_cost_when_rebalance,
        stop_trading_next_period=stop_trading_next_period,
        live_performance_start=live_performance_start,
        mae_mfe_window=mae_mfe_window,
        mae_mfe_window_step=mae_mfe_window_step,
        market=market,
        upload=upload,
        fast_mode=fast_mode,
        notification_enable=notification_enable,
        line_access_token=line_access_token,
    )

    # ── Phase 1: Validate inputs ──────────────────────────────────
    check_version()

    if cfg.notification_enable and cfg.line_access_token == "":
        raise ValueError(
            "line_access_token is required when enabling notifications. Please provide a valid token."
        )

    if isinstance(position, FinlabDataFrame):
        position = position.index_str_to_date()

    if (
        cfg.trail_stop is not None
        or cfg.stop_loss is not None
        or cfg.take_profit is not None
    ) and cfg.fast_mode:
        raise ValueError(
            "fast_mode cannot be used with trail_stop, stop_loss or take_profit."
        )

    if not isinstance(position.index, pd.DatetimeIndex):
        raise TypeError("Expected the dataframe to have a DatetimeIndex")

    if isinstance(position, pd.Series) and position.name is None:
        raise ValueError(
            'Asset name not found. Please asign asset name by "position.name = \'2330\'".'
        )

    if cfg.market is None:
        cfg.market = config.get_market()
    elif isinstance(cfg.market, str):
        cfg.market = get_market_by_name(cfg.market)

    if cfg.fee_ratio is None:
        cfg.fee_ratio = cfg.market.default_fee_ratio()
    if cfg.tax_ratio is None:
        cfg.tax_ratio = cfg.market.default_tax_ratio()

    symbol = (
        position.columns[0] if isinstance(position, pd.DataFrame) else position.name
    )
    if not str(symbol)[0].isdigit() and cfg.market.get_name() == "tw_stock":
        raise ValueError(
            "Stock ID should be a number. Please check the stock ID in the position dataframe.\n"
            "If you are backtesting US stocks, please set market='US_STOCK'"
        )

    if not isinstance(cfg.market, Market):
        raise TypeError(
            "It seems like the market has "
            "not been specified well when using the hold_until"
            " function. Please provide the market='TW', "
            "market='US' or market=Market"
        )

    # ── Phase 2: Prepare price data ───────────────────────────────
    price = cfg.trade_at_price
    if isinstance(cfg.trade_at_price, str):
        price = cfg.market.get_trading_price(cfg.trade_at_price, adj=True)

    if not isinstance(price, pd.DataFrame):
        raise TypeError("trade_at_price must resolve to a pd.DataFrame")

    _orig_prefer_local = getattr(_data_module, "prefer_local_if_exists", False)
    _data_module.prefer_local_if_exists = True

    try:
        if isinstance(cfg.trade_at_price, pd.DataFrame) and cfg.touched_exit:
            print(
                "**WARNING: Using trade_at_price as dataframe without high, and low price. Candle information is not completed."
            )
            print(
                "           The backtest result can be incorrect when touched_exit=True."
            )
            print(
                "           If the complete backtest result is required, please implement Market Class with get_price function."
            )
            print(
                "           Market details: https://doc.finlab.tw/reference/market_info/"
            )
            print(
                "           And use backtest.sim(..., market=Market) during backtest, so that the correct information is accessable from backtest.sim()."
            )

        try:
            if isinstance(cfg.live_performance_start, str):
                cfg.live_performance_start = datetime.datetime.fromisoformat(
                    cfg.live_performance_start
                )
        except ValueError as e:
            raise ValueError(
                "**ERROR: live_performance_start string format not valid. It should be ISO format, i.e. YYYY-MM-DD."
            ) from e

        close = price
        high = price
        low = price
        open_ = price
        if cfg.touched_exit:
            high = _reindex_if_needed(cfg.market.get_price("high", adj=True), price)
            low = _reindex_if_needed(cfg.market.get_price("low", adj=True), price)
            open_ = _reindex_if_needed(cfg.market.get_price("open", adj=True), price)

        if not isinstance(cfg.trade_at_price, str) or cfg.trade_at_price != "close":
            close = _reindex_if_needed(
                cfg.market.get_price("close", adj=True).reindex_like(price), price
            )

        # ── Phase 3: Normalize position ───────────────────────────────
        if isinstance(position, pd.Series):
            if position.name in price.columns:
                position = position.to_frame()
            else:
                raise ValueError(
                    'Asset name not found. Please asign asset name by "position.name = \'2330\'".'
                )

        if isinstance(position.index[0], str):
            position = FinlabDataFrame(position).index_str_to_date()

        if not isinstance(position.index, pd.DatetimeIndex):
            raise TypeError("The DataFrame index is not of type DatetimeIndex!")

        if len(position.shape) < 2:
            raise ValueError("position must be a 2D DataFrame")
        delta_time_rebalance = position.index[-1] - position.index[-3]
        backtest_to_end = position.index[-1] + delta_time_rebalance > price.index[-1]

        tz = position.index.tz
        now = datetime.datetime.now(tz=tz)

        is_daily = (
            (position.index.hour == 0).all()
            and (position.index.minute == 0).all()
            and (position.index.second == 0).all()
        )

        if (
            is_daily
            and datetime.datetime.now(tz=cfg.market.tzinfo())
            < cfg.market.market_close_at_timestamp()
        ):
            now = now.replace(
                hour=23, minute=59, second=0, microsecond=0
            ) - datetime.timedelta(days=1)

        present_data_date = (
            max(price.index[-1], now) if backtest_to_end else position.index[-1]
        )
        position = position.loc[(position.index <= present_data_date)]
        backtest_end_date = price.index[-1] if backtest_to_end else position.index[-1]

        # ── Phase 4: Compute resample dates ───────────────────────────
        dates, next_trading_date, position = _compute_resample_dates(
            position, cfg.resample, cfg.resample_offset, present_data_date, price, tz
        )

        # Normalize stop/take/trail defaults for the core engine
        stop_loss = (
            cfg.stop_loss if (cfg.stop_loss is not None and cfg.stop_loss != 0) else 1
        )
        take_profit = (
            cfg.take_profit
            if (cfg.take_profit is not None and cfg.take_profit != 0)
            else np.inf
        )
        trail_stop = (
            cfg.trail_stop
            if (cfg.trail_stop is not None and cfg.trail_stop != 0)
            else np.inf
        )

        if dates is not None:
            position = position.reindex(dates, method="ffill")

        encryption = download_backtest_encryption()
        if encryption == "":
            raise PermissionError("Cannot perform backtest, permission denied.")

        orig_ncols = len(position.columns)
        position = position[position.columns.intersection(price.columns)]
        matched_ncols = len(position.columns)

        if orig_ncols > 0 and matched_ncols == 0:
            raise ValueError(
                f"No position columns match the market price columns "
                f"(0 out of {orig_ncols} matched). "
                f"Check that the position data source matches the market's price data."
            )
        if orig_ncols > 0 and matched_ncols / orig_ncols < 0.1:
            warnings.warn(
                f"Only {matched_ncols} out of {orig_ncols} position columns "
                f"matched the market price columns "
                f"({matched_ncols / orig_ncols:.1%} overlap). "
                f"The backtest result may be unreliable. "
                f"Check that the position data source matches the market.",
                stacklevel=2,
            )

        # ── Phase 5: Execute backtest core ────────────────────────────
        args = arguments(
            price, close, high, low, open_, position, dates, fast_mode=cfg.fast_mode
        )

        creturn_value = backtest_(
            *args,
            encryption=encryption,
            fee_ratio=cfg.fee_ratio,
            tax_ratio=cfg.tax_ratio,
            stop_loss=stop_loss,
            take_profit=take_profit,
            trail_stop=trail_stop,
            touched_exit=cfg.touched_exit,
            position_limit=cfg.position_limit,
            retain_cost_when_rebalance=cfg.retain_cost_when_rebalance,
            stop_trading_next_period=cfg.stop_trading_next_period,
            mae_mfe_window=cfg.mae_mfe_window,
            mae_mfe_window_step=cfg.mae_mfe_window_step,
            periodically_rebalance=cfg.resample is not None,
        )

        # ── Phase 6: Post-process results ─────────────────────────────
        org_position_index = position.index

        pos_vals = position.values.astype(float)
        total_weight = np.abs(pos_vals).sum(axis=1)
        np.clip(total_weight, 1, None, out=total_weight)
        mask = total_weight != 0
        pos_vals[mask] = pos_vals[mask] / total_weight[mask, np.newaxis]
        pos_vals[~mask] = 0
        if cfg.position_limit < 1:
            np.clip(
                pos_vals,
                -abs(cfg.position_limit),
                abs(cfg.position_limit),
                out=pos_vals,
            )
        position = pd.DataFrame(
            pos_vals, index=position.index, columns=position.columns
        )

        creturn_dates = dates if dates and cfg.fast_mode else price.index

        creturn = (
            pd.Series(creturn_value, creturn_dates)
            .pipe(lambda df: df[(df != 1).cumsum().shift(-1, fill_value=1) != 0])
            .loc[:backtest_end_date]
            .pipe(lambda df: df if len(df) != 0 else pd.Series(1, position.index))
        )

        position = position.loc[creturn.index[0] :]

        price_index = args[5]
        position_columns = args[9]
        trades_raw, operation_and_weight = get_trade_stocks(
            position_columns, price_index, touched_exit=cfg.touched_exit
        )

        m = _refine_mae_mfe(
            cfg.mae_mfe_window_step, cfg.touched_exit, stop_loss, take_profit
        )
        trades = _build_trades_df(trades_raw, tz)

        if len(trades) != 0:
            trades = trades.assign(**{"return": (m.iloc[:, -1])})

            if cfg.touched_exit:
                min_return = (1 - cfg.fee_ratio) * (1 - abs(stop_loss)) * (
                    1 - cfg.tax_ratio - cfg.fee_ratio
                ) - 1
                max_return = (1 - cfg.fee_ratio) * (1 + abs(take_profit)) * (
                    1 - cfg.tax_ratio - cfg.fee_ratio
                ) - 1
                trades["return"] = trades["return"].clip(min_return, max_return)

        # ── Phase 7: Build report ─────────────────────────────────────
        # Update cfg with resolved stop values for _populate_report
        cfg.stop_loss = stop_loss
        cfg.take_profit = take_profit
        cfg.trail_stop = trail_stop

        r = report.Report(
            creturn=creturn,
            position=position,
            fee_ratio=cfg.fee_ratio,
            tax_ratio=cfg.tax_ratio,
            trade_at=cfg.trade_at_price,
            next_trading_date=next_trading_date,
            market=cfg.market,
        )

        r = _populate_report(
            r,
            cfg,
            trades,
            m,
            operation_and_weight,
            org_position_index,
            price,
            cfg.market,
        )

        # ── Phase 8: Finalize ─────────────────────────────────────────
        if cfg.notification_enable:
            line_notify(r, cfg.line_access_token, name=cfg.name)

        if cfg.upload and not _suppress_upload:
            if "pyodide" in sys.modules:
                r.upload(cfg.name)
            else:
                threading.Thread(
                    target=r.upload, args=(cfg.name,), daemon=False
                ).start()

        return r
    finally:
        _data_module.prefer_local_if_exists = _orig_prefer_local
        from finlab.markets.tw import TWMarket as _TW

        _TW._categories_cache = None
