"""DataFrame processing: index normalisation, stock-column cleanup, truncation."""

from __future__ import annotations

from typing import Any, Final

import numpy as np
import pandas as pd

import finlab.dataframe

from .context import _default_context

__all__ = [
    "process_data",
]

# ---------------------------------------------------------------------------
# Index helpers
# ---------------------------------------------------------------------------


def has_index_name(df: pd.DataFrame, name: str) -> bool:
    """Check if the DataFrame has a specific index name (single or MultiIndex)."""
    if df.index.name == name:
        return True
    return bool(isinstance(df.index, pd.MultiIndex) and name in df.index.names)


# Table index transformations for special data types
TABLE_INDEX_TRANSFORMERS: Final[dict[str, Any]] = {
    "monthly_revenue": lambda df: df._index_to_business_day(),
    "rotc_monthly_revenue": lambda df: df._index_to_business_day(),
    "financial_statement": lambda df: df._index_date_to_str_season(),
    "fundamental_features": lambda df: df._index_date_to_str_season(),
    "us_fundamental": lambda df: df._index_date_to_str_season("-US"),
    "us_fundamental_ART": lambda df: df._index_date_to_str_season("-US"),
    "us_fundamental_all": lambda df: df._index_date_to_str_season("-US-ALL"),
    "us_fundamental_all_ART": lambda df: df._index_date_to_str_season("-US-ALL"),
    **{
        f"{r}_{t}": lambda df, postfix=f"-{r.upper()}": df._index_date_to_str_season(  # noqa: B008
            postfix
        )
        for r in ("us", "jp", "hk", "kr", "uk")
        for t in ("income_statement", "balance_sheet", "cash_flow")
    },
}

_TW_QUARTERLY_TABLES: Final[frozenset[str]] = frozenset(
    {"financial_statement", "fundamental_features"}
)


def _should_mask_quarterly(table_name: str, effective_truncate_end: str | None) -> bool:
    """Check if TW quarterly disclosure-date masking should be applied."""
    return table_name in _TW_QUARTERLY_TABLES and effective_truncate_end is not None


# ---------------------------------------------------------------------------
# Column / index normalisation
# ---------------------------------------------------------------------------


def _set_dataframe_index(df: pd.DataFrame) -> pd.DataFrame:
    """Set appropriate index based on available columns."""
    from finlab.compat import CANONICAL_NAME, LEGACY_NAME, validate_no_dual_columns

    # Accept either 'symbol' or 'stock_id'
    id_col = next((c for c in (CANONICAL_NAME, LEGACY_NAME) if c in df.columns), None)

    if id_col is not None and "date" in df.columns:
        df.set_index([id_col, "date"], inplace=True)
    elif "date" in df.columns:
        df.set_index("date", inplace=True)
    elif id_col is not None:
        df.set_index(id_col, inplace=True)

    # Normalize index name from 'stock_id' -> 'symbol'
    if isinstance(df.index, pd.MultiIndex):
        new_names = [CANONICAL_NAME if n == LEGACY_NAME else n for n in df.index.names]
        df.index.names = new_names
    elif df.index.name == LEGACY_NAME:
        df.index.name = CANONICAL_NAME

    validate_no_dual_columns(df)
    return df


def _normalize_stock_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Remove stock names from columns and combine duplicate stock histories."""
    if not (df.columns.str.find(" ") != -1).all():
        return df

    df.columns = df.columns.str.split(" ").str[0]

    if pd.api.types.is_numeric_dtype(df.values):
        return df.transpose().groupby(level=0).mean().transpose()
    return df.fillna(np.nan).transpose().groupby(level=0).last().transpose()


# ---------------------------------------------------------------------------
# Truncation
# ---------------------------------------------------------------------------


def _apply_truncate_if_any(df: pd.DataFrame, skip_end: bool = False) -> pd.DataFrame:
    """Truncate DataFrame to context date range if DatetimeIndex."""
    ctx = _default_context
    if isinstance(df.index, pd.DatetimeIndex):
        end = None if skip_end else ctx.truncate_end
        return df.loc[slice(ctx.truncate_start, end)]
    return df


def _mask_undisclosed_quarterly(
    df: pd.DataFrame, truncate_end_str: str
) -> pd.DataFrame:
    """NaN out cells where stock had not disclosed at truncate_end. Drop all-NaN rows."""
    from .get import get

    disclosure_dates = get("etl:financial_statements_disclosure_dates")
    end_ts = pd.Timestamp(truncate_end_str)

    common_cols = df.columns.intersection(disclosure_dates.columns)
    if common_cols.empty:
        return df

    aligned = disclosure_dates.reindex(index=df.index, columns=common_cols)

    # True where stock disclosed AFTER cutoff -> should be NaN
    # NaT comparison returns False -> NaT cells are kept (no info = assume disclosed)
    undisclosed = aligned > end_ts

    result = df.copy()
    result.loc[:, common_cols] = df[common_cols].where(~undisclosed)
    result = result.dropna(how="all")
    return finlab.dataframe.FinlabDataFrame(result)


# ---------------------------------------------------------------------------
# process_data -- main processing entry point
# ---------------------------------------------------------------------------


def process_data(dataset: str, df: pd.DataFrame) -> pd.DataFrame:
    """Process raw data into standardized format."""
    df = _set_dataframe_index(df)

    # Special case (to align with tutorial)
    if dataset == "broker_transactions":
        df = df.reset_index().set_index("date")

    if ":" in dataset:
        df.columns.name = "symbol"
    else:
        # Table format
        df = df.reset_index()
        if "stock_id" in df.columns and "symbol" not in df.columns:
            df = df.rename(columns={"stock_id": "symbol"})
        # Backward compat: add 'stock_id' alias column for table format
        if "symbol" in df.columns and "stock_id" not in df.columns:
            df["stock_id"] = df["symbol"]

    if not has_index_name(df, "date"):
        return df

    table_name = dataset.split(":", maxsplit=1)[0]

    # Align PMI/NMI data to trading dates
    if table_name in {
        "tw_total_pmi",
        "tw_total_nmi",
        "tw_industry_nmi",
        "tw_industry_pmi",
    } and isinstance(df.index[0], pd.Timestamp):
        from .get import get

        close = get("price:\u53ce\u76e4\u50f9")
        df.index = df.index.map(
            lambda d: (
                d
                if len(close.loc[d:]) == 0 or d < close.index[0]
                else close.loc[d:].index[0]
            )
        )

    df = _normalize_stock_columns(df)
    df = finlab.dataframe.FinlabDataFrame(df)

    effective_truncate_end = _default_context.truncate_end
    needs_quarterly_masking = _should_mask_quarterly(table_name, effective_truncate_end)

    df = _apply_truncate_if_any(df, skip_end=needs_quarterly_masking)

    # Apply table-specific index transformations
    if table_name in TABLE_INDEX_TRANSFORMERS:
        df = TABLE_INDEX_TRANSFORMERS[table_name](df)

    # For TW quarterly tables: disclosure-date-aware masking after string index conversion
    if needs_quarterly_masking:
        if effective_truncate_end is None:
            raise RuntimeError("truncate_end is required for quarterly masking")
        df = _mask_undisclosed_quarterly(df, effective_truncate_end)

    return df
