"""Market context management and dataset resolution."""

from __future__ import annotations

from typing import TYPE_CHECKING, Final

if TYPE_CHECKING:
    import types

    from typing_extensions import Self

    from finlab.market import Market

from .catalog import (
    _MARKET_TO_FIRESTORE_DOC,
    _fetch_data_catalog_from_firestore,
    search,
)
from .context import _default_context

__all__ = [
    "market",
    "search",
    "set_market",
]

_DATASET_PREFIX_TO_BUCKET: Final[dict[str, str]] = {
    "us_": "finlab_us_stock_item",
    "hk_": "fdata-hk-stock-item",
    "jp_": "fdata-jp-stock-item",
    "kr_": "fdata-kr-stock-item",
    "uk_": "fdata-uk-stock-item",
}
DEFAULT_BUCKET: Final[str] = "finlab_tw_stock_item"
_KNOWN_MARKET_PREFIXES: Final[frozenset[str]] = frozenset(
    prefix.rstrip("_") for prefix in _DATASET_PREFIX_TO_BUCKET
)
_EXTRA_MARKET_CODES: Final[frozenset[str]] = frozenset(("us_fund",))
_VALID_MARKETS: Final[frozenset[str]] = frozenset(
    ("tw", *_KNOWN_MARKET_PREFIXES, *_EXTRA_MARKET_CODES)
)


def _sync_config_market(market_code: str) -> None:
    """Sync finlab.config market with the given market code."""
    from finlab import config
    from finlab.markets import MARKET_CODE_TO_CLASS

    cls = MARKET_CODE_TO_CLASS.get(market_code)
    if cls is not None:
        config.set_market(cls)


class market:
    """Context manager to set a market prefix for dataset resolution and backtesting."""

    def __init__(self, market_code: str) -> None:
        market_code = market_code.lower()
        if market_code not in _VALID_MARKETS:
            raise ValueError(
                f"Invalid market: {market_code!r}. "
                f"Must be one of {sorted(_VALID_MARKETS)}"
            )
        self._market_code: str = market_code
        self._previous_market: str | None = None
        self._previous_config_market: Market | None = None

    def __enter__(self) -> Self:
        from finlab import config

        self._previous_market = _default_context._current_market
        self._previous_config_market = config.get_market()
        _default_context._current_market = self._market_code
        _sync_config_market(self._market_code)
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        value: BaseException | None,
        traceback: types.TracebackType | None,
    ) -> None:
        from finlab import config

        _default_context._current_market = self._previous_market
        if self._previous_config_market is not None:
            config.set_market(self._previous_config_market)
        else:
            config.reset_market()


def set_market(market_code: str) -> None:
    """Set the global market context for dataset resolution and backtesting."""
    market_code = market_code.lower()
    if market_code not in _VALID_MARKETS:
        raise ValueError(
            f"Invalid market: {market_code!r}. Must be one of {sorted(_VALID_MARKETS)}"
        )
    _default_context._current_market = market_code
    _sync_config_market(market_code)


def _resolve_dataset(dataset: str) -> str:
    """Prepend market prefix when the prefixed dataset exists in the catalog."""
    current_market = _default_context._current_market
    if current_market is None or current_market == "tw":
        return dataset

    table = dataset.split(":", maxsplit=1)[0] if ":" in dataset else dataset
    if any(table.startswith(prefix) for prefix in _DATASET_PREFIX_TO_BUCKET):
        return dataset

    prefixed = f"{current_market}_{dataset}"
    doc_id = _MARKET_TO_FIRESTORE_DOC.get(current_market)
    if doc_id is None:
        return dataset

    catalog = _fetch_data_catalog_from_firestore(doc_id)
    return prefixed if prefixed in catalog else dataset


def _get_bucket_for_dataset(dataset: str) -> str:
    """Return the GCS bucket name for a dataset based on its market prefix."""
    table = dataset.split(":", maxsplit=1)[0] if ":" in dataset else dataset
    for prefix, bucket in _DATASET_PREFIX_TO_BUCKET.items():
        if table.startswith(prefix):
            return bucket

    if table == "etl" and ":" in dataset:
        etl_name = dataset.split(":", maxsplit=2)[1]
        for prefix, bucket in _DATASET_PREFIX_TO_BUCKET.items():
            if etl_name.startswith(prefix):
                return bucket

    return DEFAULT_BUCKET
