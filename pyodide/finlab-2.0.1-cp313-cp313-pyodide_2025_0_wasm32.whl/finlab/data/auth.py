"""Authentication, cloud fetch helpers, and batch request building."""

from __future__ import annotations

import datetime
import sys
import time
from collections import OrderedDict
from dataclasses import dataclass
from io import BytesIO
from typing import TYPE_CHECKING, Any, Final

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

import pandas as pd
import requests

import finlab
import finlab.utils

from .context import _default_context
from .market import _get_bucket_for_dataset

__all__ = [
    "FetchMetadata",
    "MetadataRequestMap",
    "MetadataResultMap",
    "fetch_metadata_batch",
]


@dataclass(slots=True)
class FetchMetadata:
    """Typed metadata payload returned by auth URL signing endpoint."""

    expiry: datetime.datetime | None
    url: str | None = None
    data: pd.DataFrame | None = None
    hash: str | None = None
    error: str | None = None
    role: str | None = None
    quota: float | None = None
    limit_size: float | None = None
    market: str | None = None


MetadataRequestMap = OrderedDict[str, datetime.datetime | None]
MetadataResultMap = OrderedDict[str, FetchMetadata | None]

_DEFAULT_HEADERS: Final[dict[str, str]] = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/68.0.3440.106 Safari/537.36"
    ),
}
_AUTH_URL: Final[str] = (
    "https://asia-east2-fdata-299302.cloudfunctions.net/auth_generate_data_url"
)
_AUTH_ERRORS: Final[list[str]] = [
    "request not valid",
    "User not found",
    "api_token not valid",
    "api_token not match",
]


def _dataset_to_blob(dataset: str) -> str:
    """Convert dataset name to GCS blob name."""
    return dataset.replace(":", "#") + ".feather"


def _blob_to_dataset(blob_name: str) -> str:
    """Convert a GCS blob name back to dataset name."""
    for suffix in (".feather", ".pickle"):
        if blob_name.endswith(suffix):
            blob_name = blob_name[: -len(suffix)]
            break
    return blob_name.replace("#", ":")


def _parse_expiry(time_scheduled: str | None) -> datetime.datetime | None:
    """Parse ``time_scheduled`` into a UTC datetime."""
    if time_scheduled is None:
        return None
    return datetime.datetime.strptime(time_scheduled, "%Y%m%d%H%M%S").replace(
        tzinfo=datetime.timezone.utc
    )


def _classify_fetch_error(error: str, last_token_type: str | None) -> str:
    """Classify the auth endpoint error string."""
    if error == "token_expired" and last_token_type == "id_token":
        return "token_expired"
    if error in _AUTH_ERRORS:
        return "auth"
    if error == "Usage exceed 500 MB/day. Please consider upgrade to VIP program.":
        return "quota_500"
    if error == "Usage exceed 5000 MB/day. Please consider upgrade to VIP program.":
        return "quota_5000"
    return "unknown"


def _resolve_auth_params() -> dict[str, str]:
    """Resolve auth token and return params dict with token + optional session_id."""
    token_result = finlab.get_token()
    if isinstance(token_result, tuple):
        token, token_type = token_result
    else:
        token, token_type = token_result, "api_token"

    _default_context._last_token_type = token_type

    params: dict[str, str] = {}
    if token_type == "id_token":
        params["id_token"] = token
        try:
            from finlab.auth import get_session

            session = get_session()
            if session and session.get("session_id"):
                params["session_id"] = session["session_id"]
        except ImportError:
            pass
    else:
        params["api_token"] = token
    return params


def _build_batch_items(request_map: MetadataRequestMap) -> dict[str, Any]:
    """Build the POST body for a batch auth_generate_data_url request."""
    body: dict[str, Any] = {**_resolve_auth_params()}
    items: list[dict[str, str]] = []
    for dataset, time_saved in request_map.items():
        item: dict[str, str] = {
            "bucket_name": _get_bucket_for_dataset(dataset),
            "blob_name": _dataset_to_blob(dataset),
        }
        if time_saved is not None:
            item["time_saved"] = time_saved.strftime("%Y%m%d%H%M%S")
        items.append(item)
    body["items"] = items
    return body


def _to_fetch_metadata(raw_result: Mapping[str, Any]) -> FetchMetadata:
    """Convert untyped auth response payload into a typed metadata object."""
    quota = raw_result.get("quota")
    limit_size = raw_result.get("limit_size")
    error = raw_result.get("error")
    return FetchMetadata(
        expiry=_parse_expiry(raw_result.get("time_scheduled")),
        url=raw_result.get("url"),
        data=raw_result.get("data"),
        hash=raw_result.get("hash"),
        error=error if isinstance(error, str) else None,
        role=raw_result.get("role"),
        quota=float(quota) if quota is not None else None,
        limit_size=float(limit_size) if limit_size is not None else None,
        market=raw_result.get("market"),
    )


def _dataset_key_from_raw_result(raw_result: Mapping[str, Any]) -> str | None:
    """Extract dataset key from batch item payload."""
    dataset = raw_result.get("dataset")
    if isinstance(dataset, str) and dataset:
        return dataset

    blob_name = raw_result.get("blob_name")
    if isinstance(blob_name, str) and blob_name:
        return _blob_to_dataset(blob_name)

    return None


def _refresh_id_token() -> None:
    """Invalidate cached id_token and force a refresh on next call."""
    from finlab.auth import get_session, invalidate_token_cache, save_session

    invalidate_token_cache()
    session = get_session()
    if session:
        session.pop("id_token", None)
        session.pop("id_token_expiry", None)
        save_session(session)


def _download_dataframe(
    url: str,
    headers: dict[str, str],
    on_progress: Callable[[int, int], None] | None = None,
) -> pd.DataFrame:
    """Download DataFrame from URL, handling pyodide environment."""
    if "pyodide" in sys.modules:
        if hasattr(finlab.utils.requests, "getBytes"):
            res = finlab.utils.requests.getBytes(url)
            if on_progress is not None:
                on_progress(len(res), len(res))
            return pd.read_feather(BytesIO(res))
        res = finlab.utils.requests.get(url, timeout=300)
        if hasattr(res, "raise_for_status"):
            res.raise_for_status()
        if on_progress is not None:
            on_progress(len(res.content), len(res.content))
        return pd.read_feather(BytesIO(res.content))

    if on_progress is not None:
        raw = _download_ipc_bytes(url, on_progress=on_progress, headers=headers)
        return pd.read_feather(BytesIO(raw))

    res = finlab.utils.requests.get(url, headers=headers, timeout=300)
    res.raise_for_status()
    return pd.read_feather(BytesIO(res.content))


def _download_ipc_bytes(
    url: str,
    on_progress: Callable[[int, int], None] | None = None,
    headers: dict[str, str] | None = None,
) -> bytes:
    """Download raw IPC/feather bytes, streaming with progress when available."""
    req_headers = headers or _DEFAULT_HEADERS
    if on_progress is None:
        res = finlab.utils.requests.get(url, headers=req_headers, timeout=300)
        res.raise_for_status()
        return res.content

    res = finlab.utils.requests.get(url, headers=req_headers, timeout=300, stream=True)
    res.raise_for_status()
    total = int(res.headers.get("content-length", 0))
    buf = BytesIO()
    received = 0
    for chunk in res.iter_content(chunk_size=65_536):
        buf.write(chunk)
        received += len(chunk)
        on_progress(received, total)
    return buf.getvalue()


def _download_ipc_file(
    url: str,
    file_path: str,
    on_progress: Callable[[int, int], None] | None = None,
    headers: dict[str, str] | None = None,
) -> int:
    """Stream raw IPC/feather bytes to *file_path* and return bytes written."""
    req_headers = headers or _DEFAULT_HEADERS
    res = finlab.utils.requests.get(url, headers=req_headers, timeout=300, stream=True)
    res.raise_for_status()
    total = int(res.headers.get("content-length", 0))
    received = 0
    with open(file_path, "wb") as f:
        for chunk in res.iter_content(chunk_size=65_536):
            if not chunk:
                continue
            f.write(chunk)
            received += len(chunk)
            if on_progress is not None:
                on_progress(received, total)
    return received


def _print_batch_user_warnings(result_map: MetadataResultMap) -> None:
    """Print free-user and quota warnings for batch metadata fetch."""
    ctx = _default_context
    finalized_results = [result for result in result_map.values() if result is not None]
    if finalized_results:
        first = finalized_results[0]
        ctx._role = first.role
        if not ctx._has_print_free_user_warning and ctx._role == "free":
            print(
                "Due to your status as a free user, "
                "the most recent data has been shortened or limited."
            )
            ctx._has_print_free_user_warning = True

    non_recent_items = [
        (dataset, result)
        for dataset, result in result_map.items()
        if result is not None and ".recent" not in dataset
    ]
    if not non_recent_items:
        return

    total_quota = max((result.quota or 0.0) for _, result in non_recent_items)
    limit_size = non_recent_items[0][1].limit_size or 0.0
    if total_quota <= 0 or limit_size <= 0:
        return

    if (
        not ctx._has_shown_quota_warning
        and ctx._role == "free"
        and total_quota / limit_size >= 0.8
    ):
        print(
            f"\n⚠️ 今日用量已達 80%（{total_quota:.0f}/{limit_size:g} MB）\n"
            f"繼續使用可能會中斷，升級 VIP 可享 10 倍額度\n"
            f"👉 https://www.finlab.finance/payment\n"
        )
        ctx._has_shown_quota_warning = True

    if len(non_recent_items) == 1:
        dataset, _ = non_recent_items[0]
        print(f"Daily usage: {total_quota:.1f} / {limit_size:g} MB - {dataset}")
    else:
        print(
            f"Daily usage: {total_quota:.1f} / {limit_size:g} MB - gets({len(non_recent_items)} items)"
        )


def _handle_fetch_batch_error(
    error: str,
    request_map: MetadataRequestMap,
) -> MetadataResultMap:
    """Handle auth endpoint errors for batch metadata fetch."""
    error_type = _classify_fetch_error(error, _default_context._last_token_type)
    if error_type == "token_expired":
        try:
            _refresh_id_token()
            return fetch_metadata_batch(request_map)
        except Exception as e:
            raise RuntimeError(
                "Token expired and refresh failed. "
                "Run `python -m finlab login` to re-authenticate."
            ) from e
    if error_type == "auth":
        finlab.login()
        return fetch_metadata_batch(request_map)
    if error_type == "quota_500":
        raise RuntimeError(f"**Error: {error}")
    if error_type == "quota_5000":
        raise RuntimeError(
            "**Error: Usage exceed 5000 MB/day. "
            "Please consider reaching out to us at "
            "https://discord.gg/tAr4ysPqvR to reset your usage."
        )
    raise RuntimeError(f"Batch fetch error: {error}")


def fetch_metadata_batch(request_map: MetadataRequestMap) -> MetadataResultMap:
    """Fetch per-dataset auth metadata through a single batch request."""
    body = _build_batch_items(request_map)

    try:
        res = finlab.utils.requests.post(
            _AUTH_URL, json=body, headers=_DEFAULT_HEADERS, timeout=300
        )
    except requests.RequestException:
        time.sleep(3)
        res = finlab.utils.requests.post(
            _AUTH_URL, json=body, headers=_DEFAULT_HEADERS, timeout=300
        )

    ret = res.json()
    if "error" in ret:
        return _handle_fetch_batch_error(ret["error"], request_map)

    raw_results: list[dict[str, Any] | None] = ret.get("results", [])
    mapped_results: dict[str, FetchMetadata] = {}
    unkeyed_results: list[FetchMetadata] = []

    for raw in raw_results:
        if raw is None:
            continue
        metadata = _to_fetch_metadata(raw)
        dataset_key = _dataset_key_from_raw_result(raw)
        if dataset_key is None:
            # Keep a positional fallback for old payload shapes with no key fields.
            unkeyed_results.append(metadata)
            continue
        mapped_results[dataset_key] = metadata

    ordered_results: MetadataResultMap = OrderedDict()
    for dataset in request_map:
        dataset_metadata = mapped_results.get(dataset)
        if dataset_metadata is None and unkeyed_results:
            dataset_metadata = unkeyed_results.pop(0)
        ordered_results[dataset] = dataset_metadata

    _print_batch_user_warnings(ordered_results)
    return ordered_results
