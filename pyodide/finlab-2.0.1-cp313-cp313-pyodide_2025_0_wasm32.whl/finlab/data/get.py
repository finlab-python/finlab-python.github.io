"""Shared fetch pipeline plus ``data.get()`` single-dataset wrapper."""

from __future__ import annotations

import asyncio
import functools
import gc
import hashlib
import importlib.util
import logging
import sys
import threading
from collections import OrderedDict
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from io import BytesIO
from typing import TYPE_CHECKING, TypeAlias, cast

import pandas as pd
from pyarrow import feather
from requests.exceptions import HTTPError

import finlab.dataframe
import finlab.utils
from finlab.dataframe.lazy import LazyWide, lazy_from_storage

from . import universe as universe_module

# Re-exports for backward compat: data.py imports these from get.py
from .auth import (
    _AUTH_ERRORS,  # noqa: F401
    _AUTH_URL,  # noqa: F401
    _DEFAULT_HEADERS,
    FetchMetadata,
    MetadataRequestMap,
    MetadataResultMap,
    _dataset_to_blob,  # noqa: F401
    _download_dataframe,
    _download_ipc_file,
    _refresh_id_token,  # noqa: F401
    _resolve_auth_params,  # noqa: F401
    fetch_metadata_batch,
)
from .context import _default_context
from .freshness import (
    _get_expiry_dict,  # noqa: F401
    is_tradable,
    next_future_expiry,
    suggested_tradable_time,
)
from .market import _resolve_dataset
from .progress import DownloadProgress
from .storage import CacheStorage, FileStorage
from .transform import (
    TABLE_INDEX_TRANSFORMERS,  # noqa: F401
    _apply_truncate_if_any,
    _mask_undisclosed_quarterly,  # noqa: F401
    _normalize_stock_columns,  # noqa: F401
    _set_dataframe_index,  # noqa: F401
    _should_mask_quarterly,
    has_index_name,  # noqa: F401
    process_data,
)

if TYPE_CHECKING:
    import datetime

    from .context import DataContext

logger = logging.getLogger(__name__)
_finalize_context_lock = threading.RLock()

StorageBackend: TypeAlias = CacheStorage | FileStorage

MetadataFetcher = Callable[
    [
        MetadataRequestMap,
    ],
    MetadataResultMap,
]


@dataclass(frozen=True)
class _FinalizeContextSnapshot:
    truncate_start: str | None
    truncate_end: str | None
    universe_stocks: frozenset[str] | None


__all__ = [
    "get",
    "get_role",
    "is_tradable",
    "is_vip",
    "next_future_expiry",
    "process_data",
    "suggested_tradable_time",
]


# ---------------------------------------------------------------------------
# Finalize / cache pipeline
# ---------------------------------------------------------------------------


def _finalize(dataset: str, df: pd.DataFrame, *, cache: bool = True) -> pd.DataFrame:
    with _finalize_context_lock:
        ctx = _default_context
        cache_key = (
            dataset,
            id(ctx._storage),
            id(df),
            (
                frozenset(universe_module.universe_stocks)
                if universe_module.universe_stocks
                else None
            ),
            ctx.truncate_start,
            ctx.truncate_end,
        )
        if cache:
            cached = ctx._finalized_cache.get(cache_key)
            if isinstance(cached, pd.DataFrame):
                return cached

        table_name = dataset.split(":", maxsplit=1)[0]
        skip_end = _should_mask_quarterly(table_name, ctx.truncate_end)
        df = _apply_truncate_if_any(df, skip_end=skip_end)

        if not isinstance(df, finlab.dataframe.FinlabDataFrame):
            df = finlab.dataframe.FinlabDataFrame(df)
        result = universe_module.refine_stock_id(dataset, df)
        if cache:
            ctx._finalized_cache[cache_key] = result
        return result


def _snapshot_finalize_context() -> _FinalizeContextSnapshot:
    ctx = _default_context
    with _finalize_context_lock:
        stocks = universe_module.universe_stocks
        return _FinalizeContextSnapshot(
            truncate_start=ctx.truncate_start,
            truncate_end=ctx.truncate_end,
            universe_stocks=frozenset(stocks) if stocks else None,
        )


def _finalize_with_context(
    dataset: str,
    df: pd.DataFrame,
    finalize_context: _FinalizeContextSnapshot,
) -> pd.DataFrame:
    ctx = _default_context

    with _finalize_context_lock:
        original_truncate_start = ctx.truncate_start
        original_truncate_end = ctx.truncate_end
        original_universe_stocks = universe_module.universe_stocks
        ctx.truncate_start = finalize_context.truncate_start
        ctx.truncate_end = finalize_context.truncate_end
        universe_module.universe_stocks = set(finalize_context.universe_stocks or ())
        try:
            return _finalize(dataset, df, cache=False)
        finally:
            ctx.truncate_start = original_truncate_start
            ctx.truncate_end = original_truncate_end
            universe_module.universe_stocks = original_universe_stocks


def hash(df: pd.DataFrame) -> str:
    return hashlib.md5(pd.util.hash_pandas_object(df, index=True).values).hexdigest()[
        :7
    ]


def _is_local_usable(dataset: str, df: pd.DataFrame | None) -> bool:
    """Return whether the local dataframe can satisfy the request immediately."""
    ctx = _default_context
    storage = ctx._storage
    time_expired = storage.get_time_expired(dataset)

    # Already loaded this session: skip server round-trip but still respect expiry
    if (
        dataset in ctx._loaded_datasets
        and time_expired
        and time_expired > CacheStorage.now()
        and df is not None
        and not df.empty
    ):
        logger.debug(f"{dataset} already loaded and not expired -> use cache")
        return True

    # Prefer local cache without checking expiry (user-set flag)
    if ctx.prefer_local_if_exists and df is not None and not df.empty:
        logger.debug(
            f"{dataset} prefer_local_if_exists enabled -> get data from local without update check"
        )
        return True

    if (
        time_expired
        and time_expired > CacheStorage.now()
        and df is not None
        and not df.empty
    ):
        logger.debug(f"{dataset} not expired -> get data from local")
        return True

    # Free user can only use historical data without merge
    return bool(ctx._role == "free" and df is not None)


_MERGE_DEDUP_COLS = ["symbol", "stock_id", "date", "\u6301\u80a1\u5206\u7d1a", "broker"]


def _merge_recent_df(df: pd.DataFrame, short_df: pd.DataFrame) -> pd.DataFrame:
    """Merge a recent delta into an existing DataFrame, deduplicating rows."""
    compare_cols = df.columns.intersection(_MERGE_DEDUP_COLS)
    return (
        pd.concat([df, short_df])
        .pipe(lambda d: d[~d.duplicated(subset=compare_cols, keep="last")])[
            short_df.columns
        ]
        .reset_index(drop=True)
    )


def _prepare_fetch(
    datasets: list[str],
    force_download: bool,
) -> tuple[DataContext, list[str], StorageBackend, bool]:
    """Apply shared preflight checks and resolve dataset aliases."""
    if not datasets:
        raise ValueError("at least one dataset name required")

    finlab.utils.check_version()
    ctx = _default_context
    force_download |= ctx.force_cloud_download

    if ctx.use_local_data_only and force_download:
        raise ValueError(
            "data.use_local_data_only and data.force_download cannot be both True"
        )

    resolved = [_resolve_dataset(dataset) for dataset in datasets]
    return ctx, resolved, ctx._storage, force_download


def _partition_datasets(
    resolved: list[str],
    storage: StorageBackend,
    force_download: bool,
    use_local_only: bool,
) -> tuple[
    dict[str, pd.DataFrame],
    list[str],
    list[str],
    dict[str, datetime.datetime | None],
    dict[str, pd.DataFrame | None],
]:
    """Split datasets into local hits, recent candidates, and full misses."""
    cache_hits: dict[str, pd.DataFrame] = {}
    recent_candidates: list[str] = []
    cache_misses: list[str] = []
    time_saved_map: dict[str, datetime.datetime | None] = {}
    local_frames: dict[str, pd.DataFrame | None] = {}

    if force_download:
        return (
            cache_hits,
            recent_candidates,
            list(resolved),
            time_saved_map,
            local_frames,
        )

    for dataset in resolved:
        df = storage.get_dataframe(dataset)
        local_frames[dataset] = df

        if _is_local_usable(dataset, df):
            cache_hits[dataset] = _finalize(dataset, df)
            continue

        if use_local_only:
            if df is not None and not df.empty:
                cache_hits[dataset] = _finalize(dataset, df)
                continue
            raise FileNotFoundError(
                f"**Error: {dataset} not in local storage. "
                "Set data.use_local_data_only = False to download."
            )

        if df is not None:
            recent_candidates.append(dataset)
            time_saved_map[dataset] = storage.get_time_created(dataset)
            continue

        cache_misses.append(dataset)

    return cache_hits, recent_candidates, cache_misses, time_saved_map, local_frames


def _download_result_dataframe(
    result: FetchMetadata | None,
    dataset: str,
    on_progress: Callable[[int, int], None] | None = None,
) -> pd.DataFrame:
    """Return dataframe payload from a remote fetch result."""
    if result is None:
        raise FileNotFoundError(f"**Error: {dataset} not exists")
    if result.data is not None:
        if on_progress is not None:
            on_progress(1, 1)
        return result.data

    url = result.url
    if not url:
        raise FileNotFoundError(f"**Error: {dataset} not exists")

    return _download_dataframe(url, _DEFAULT_HEADERS, on_progress=on_progress)


def _build_progress_callback(
    progress: DownloadProgress,
    dataset: str,
) -> tuple[Callable[[int, int], None], Callable[[], int]]:
    """Build per-dataset byte progress callback and final-size accessor."""
    state: dict[str, int] = {"downloaded": 0, "total": 0}

    def _on_progress(downloaded: int, total: int) -> None:
        total_effective = total if total > 0 else max(downloaded, 1)
        state["downloaded"] = downloaded
        state["total"] = total_effective
        progress.update(dataset, downloaded, total_effective)

    def _final_bytes() -> int:
        return state["total"] or state["downloaded"] or 1

    return _on_progress, _final_bytes


def _estimate_dataframe_bytes(df: pd.DataFrame) -> int:
    """Estimate display size for a downloaded dataframe."""
    try:
        return max(int(df.memory_usage(deep=True).sum()), 1)
    except (TypeError, ValueError):
        return 1


def _download_recent_delta(
    dataset: str,
    result: FetchMetadata,
    progress: DownloadProgress | None,
) -> tuple[pd.DataFrame, int | None]:
    """Download one ``.recent`` payload with optional progress updates."""
    if progress is None:
        return _download_result_dataframe(result, f"{dataset}.recent"), None

    on_progress, final_bytes = _build_progress_callback(progress, dataset)
    short_df = _download_result_dataframe(
        result,
        f"{dataset}.recent",
        on_progress=on_progress,
    )
    nbytes = final_bytes()
    if nbytes <= 1:
        nbytes = _estimate_dataframe_bytes(short_df)
    return short_df, nbytes


def _resolve_recent_hit(
    dataset: str,
    df: pd.DataFrame,
    result: FetchMetadata,
    storage: StorageBackend,
    progress: DownloadProgress | None,
) -> pd.DataFrame | None:
    """Return finalized dataframe when recent-merge succeeds, else ``None``."""
    if result.error:
        logger.debug("Recent metadata error for %s: %s", dataset, result.error)
        return None

    # .recent may return metadata-only payload to indicate local cache is still valid.
    if result.data is None and not result.url:
        if result.expiry is not None:
            storage.set_time_expired(dataset, result.expiry)
        if progress is not None:
            progress.mark_cached(dataset)
        return _finalize(dataset, df)

    try:
        short_df, recent_nbytes = _download_recent_delta(dataset, result, progress)
        merged_df = _merge_recent_df(df, short_df)
    except HTTPError:
        logger.debug("HTTP error while downloading recent delta for %s", dataset)
        raise
    except (FileNotFoundError, KeyError, ValueError, TypeError):
        logger.debug("Failed to merge recent data for %s", dataset)
        return None

    hash_df = hash(merged_df)
    logger.debug(f"hash df: {hash_df} url: {result.hash}")
    if result.hash != hash_df or merged_df.empty:
        return None

    if progress is not None and recent_nbytes is not None:
        progress.complete(dataset, recent_nbytes)
    storage.set_dataframe(dataset, merged_df, expiry=result.expiry)
    logger.debug("get recent, is valid -> and merge recent to local data")
    return _finalize(dataset, merged_df)


def _resolve_recent_candidates(
    recent_candidates: list[str],
    time_saved_map: dict[str, datetime.datetime | None],
    storage: StorageBackend,
    local_frames: dict[str, pd.DataFrame | None],
    metadata_fetcher: MetadataFetcher,
    progress: DownloadProgress | None = None,
) -> tuple[dict[str, pd.DataFrame], list[str]]:
    """Try to satisfy stale local datasets through ``.recent`` fetches."""
    if not recent_candidates:
        return {}, []

    recent_requests: MetadataRequestMap = OrderedDict(
        (f"{dataset}.recent", time_saved_map.get(dataset))
        for dataset in recent_candidates
    )
    if progress is not None:
        progress.set_stage(
            "Fetching recent metadata",
            done=0,
            total=1,
        )
    result_map = metadata_fetcher(recent_requests)
    if progress is not None:
        progress.set_stage(
            "Fetching recent metadata",
            done=1,
            total=1,
        )

    if progress is not None:
        progress.set_stage(
            "Downloading recent deltas",
            done=0,
            total=len(recent_candidates),
            datasets=recent_candidates,
        )

    cache_hits: dict[str, pd.DataFrame] = {}
    full_misses: list[str] = []

    for dataset in recent_candidates:
        df = local_frames.get(dataset)
        result = result_map.get(f"{dataset}.recent")
        if result is None or df is None or df.empty:
            full_misses.append(dataset)
            continue

        recent_hit = _resolve_recent_hit(dataset, df, result, storage, progress)
        if recent_hit is None:
            full_misses.append(dataset)
            continue
        cache_hits[dataset] = recent_hit

    return cache_hits, full_misses


def _materialize_full_misses(
    cache_misses: list[str],
    storage: StorageBackend,
    metadata_fetcher: MetadataFetcher,
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full datasets for the remaining remote misses."""
    if not cache_misses:
        return {}

    gc.collect()
    request_map: MetadataRequestMap = OrderedDict(
        (dataset, None) for dataset in cache_misses
    )
    if progress is not None:
        progress.set_stage(
            "Fetching full metadata",
            done=0,
            total=1,
        )
    result_map = metadata_fetcher(request_map)
    if progress is not None:
        progress.set_stage(
            "Fetching full metadata",
            done=1,
            total=1,
        )
    target_storage = _resolve_full_miss_target_storage(storage, result_map)
    validated_results = _validate_full_miss_results(cache_misses, result_map)
    if isinstance(target_storage, FileStorage) and "pyodide" not in sys.modules:
        return _download_persist_file_storage_misses(
            cache_misses,
            validated_results,
            target_storage,
            progress=progress,
        )
    downloaded_frames = _download_full_miss_frames(
        cache_misses,
        validated_results,
        progress=progress,
    )
    return _persist_full_miss_frames(
        cache_misses,
        downloaded_frames,
        validated_results,
        target_storage,
    )


def _resolve_full_miss_target_storage(
    storage: StorageBackend,
    result_map: MetadataResultMap,
) -> StorageBackend:
    """Resolve storage backend for full misses, switching free users to cache storage."""
    if isinstance(storage, CacheStorage):
        return storage

    has_free_role = any(
        result is not None and result.role == "free" for result in result_map.values()
    )
    if not has_free_role:
        return storage

    if not isinstance(_default_context._storage, CacheStorage):
        _default_context._storage = CacheStorage()
    return _default_context._storage


def _validate_full_miss_results(
    cache_misses: list[str],
    result_map: MetadataResultMap,
) -> OrderedDict[str, FetchMetadata]:
    """Validate full-miss metadata and raise actionable per-item errors."""
    validated_results: OrderedDict[str, FetchMetadata] = OrderedDict()
    for dataset in cache_misses:
        result = result_map.get(dataset)
        if result is None:
            raise FileNotFoundError(f"**Error: {dataset} not exists")
        if result.error:
            raise RuntimeError(f"**Error: {result.error}")
        validated_results[dataset] = result
    return validated_results


@functools.lru_cache(maxsize=1)
def _use_pyodide_async_fetch() -> bool:
    """Return True when pyodide async parallel fetch is available."""
    if "pyodide" not in sys.modules:
        return False
    try:
        return importlib.util.find_spec("pyodide.http") is not None and (
            importlib.util.find_spec("pyodide.ffi") is not None
            or importlib.util.find_spec("pyodide.code") is not None
        )
    except (ImportError, ValueError):
        return False


def _download_full_miss_frames_threaded(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full-miss dataframes via ThreadPoolExecutor."""

    max_workers = min(8, len(cache_misses))
    if max_workers <= 1:
        return _download_full_miss_frames_sequential(
            cache_misses,
            validated_results,
            progress,
        )

    downloaded_frames: dict[str, pd.DataFrame] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(
                _download_one_full_miss_frame,
                dataset,
                validated_results,
                progress,
            ): dataset
            for dataset in cache_misses
        }
        for future in as_completed(future_map):
            dataset = future_map[future]
            df, nbytes = future.result()
            downloaded_frames[dataset] = df
            if progress is not None and nbytes is not None:
                progress.complete(dataset, nbytes)
    return downloaded_frames


def _download_one_full_miss_frame(
    dataset: str,
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> tuple[pd.DataFrame, int | None]:
    """Download one full-miss dataframe and return its display byte count."""
    if progress is None:
        df = _download_result_dataframe(validated_results[dataset], dataset)
        return df, None

    on_progress, final_bytes = _build_progress_callback(progress, dataset)
    df = _download_result_dataframe(
        validated_results[dataset],
        dataset,
        on_progress=on_progress,
    )
    nbytes = final_bytes()
    if nbytes <= 1:
        nbytes = _estimate_dataframe_bytes(df)
    return df, nbytes


def _download_full_miss_frames_sequential(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full-miss dataframes without threads or async stack switching."""
    downloaded_frames: dict[str, pd.DataFrame] = {}
    for dataset in cache_misses:
        df, nbytes = _download_one_full_miss_frame(
            dataset,
            validated_results,
            progress,
        )
        downloaded_frames[dataset] = df
        if progress is not None and nbytes is not None:
            progress.complete(dataset, nbytes)
    return downloaded_frames


def _is_pyodide_stack_switch_error(exc: RuntimeError) -> bool:
    """Return True for Pyodide's sync-entrypoint async bridge failure."""
    message = str(exc)
    return "Cannot stack switch" in message and "callPromising" in message


def _get_pyodide_run_sync() -> Callable[[object], object]:
    """Return Pyodide's async-to-sync bridge."""
    try:
        from pyodide.ffi import run_sync
    except ImportError:
        from pyodide.code import run_sync
    return run_sync


def _can_run_pyodide_sync(run_sync: Callable[[object], object]) -> bool:
    """Return whether Pyodide run_sync is usable from this Python entrypoint."""

    async def _noop() -> None:
        return None

    awaitable = _noop()
    try:
        run_sync(awaitable)
    except RuntimeError as exc:
        if _is_pyodide_stack_switch_error(exc):
            return False
        awaitable.close()
        raise
    return True


def _run_pyodide_sync(
    run_sync: Callable[[object], object], awaitable: object
) -> object:
    """Run a Pyodide awaitable synchronously, closing it if the bridge rejects it."""
    try:
        return run_sync(awaitable)
    except RuntimeError as exc:
        if not _is_pyodide_stack_switch_error(exc):
            close = getattr(awaitable, "close", None)
            if callable(close):
                close()
        raise


def _download_full_miss_frames(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full-miss dataframes concurrently when beneficial."""
    if progress is not None:
        progress.set_stage(
            "Downloading full datasets",
            done=0,
            total=len(cache_misses),
            datasets=cache_misses,
        )

    if _use_pyodide_async_fetch():
        run_sync = _get_pyodide_run_sync()
        if not _can_run_pyodide_sync(run_sync):
            logger.debug(
                "Pyodide async fetch unavailable from a synchronous entrypoint; "
                "falling back to sequential download."
            )
            return _download_full_miss_frames_sequential(
                cache_misses,
                validated_results,
                progress,
            )
        return _download_full_miss_frames_pyodide(
            cache_misses, validated_results, run_sync, progress
        )

    if "pyodide" in sys.modules:
        return _download_full_miss_frames_sequential(
            cache_misses,
            validated_results,
            progress,
        )

    return _download_full_miss_frames_threaded(
        cache_misses, validated_results, progress
    )


def _download_persist_file_storage_misses(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    storage: FileStorage,
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full misses directly to FileStorage, then load finalized frames."""
    _download_file_storage_misses_to_storage(
        cache_misses,
        validated_results,
        storage,
        progress=progress,
    )

    cache_hits: dict[str, pd.DataFrame] = {}
    for dataset in cache_misses:
        df = storage.get_dataframe(dataset)
        if df is None or df.empty:
            raise RuntimeError(f"**Error: {dataset} download fail")
        logger.debug(f"{dataset} downloaded full data from cloud")
        cache_hits[dataset] = _finalize(dataset, df)
    return cache_hits


def _download_file_storage_misses_to_storage(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    storage: FileStorage,
    progress: DownloadProgress | None = None,
) -> None:
    """Download full misses directly to FileStorage without reading them back."""
    if progress is not None:
        progress.set_stage(
            "Downloading full datasets",
            done=0,
            total=len(cache_misses),
            datasets=cache_misses,
        )

    max_workers = min(8, len(cache_misses))
    if max_workers <= 1:
        for dataset in cache_misses:
            _download_persist_one_file_storage_miss(
                dataset,
                validated_results[dataset],
                storage,
                progress,
            )
    else:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_map = {
                executor.submit(
                    _download_persist_one_file_storage_miss,
                    dataset,
                    validated_results[dataset],
                    storage,
                    progress,
                ): dataset
                for dataset in cache_misses
            }
            for future in as_completed(future_map):
                future.result()


def _download_persist_one_file_storage_miss(
    dataset: str,
    result: FetchMetadata,
    storage: FileStorage,
    progress: DownloadProgress | None = None,
) -> None:
    if result.data is not None:
        storage.set_dataframe(dataset, result.data, expiry=result.expiry)
        nbytes = _estimate_dataframe_bytes(result.data)
        if progress is not None:
            progress.update(dataset, nbytes, nbytes)
            progress.complete(dataset, nbytes)
        return

    url = result.url
    if not url:
        raise FileNotFoundError(f"**Error: {dataset} not exists")

    on_progress: Callable[[int, int], None] | None = None
    final_bytes: Callable[[], int] | None = None
    if progress is not None:
        on_progress, final_bytes = _build_progress_callback(progress, dataset)

    def write_feather(tmp_path: str) -> None:
        _download_ipc_file(
            url,
            tmp_path,
            on_progress=on_progress,
            headers=_DEFAULT_HEADERS,
        )

    storage.set_feather_file(
        dataset,
        write_feather,
        expiry=result.expiry,
        validate_fn=_validate_feather_file,
    )
    if progress is not None and final_bytes is not None:
        progress.complete(dataset, final_bytes())


def _validate_feather_file(file_path: str) -> None:
    """Validate feather metadata without materializing the dataframe."""
    feather.read_table(file_path, columns=[])


def _download_full_miss_frames_pyodide(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    run_sync: Callable[[object], object],
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full-miss dataframes in parallel using pyodide's async fetch."""
    from pyodide.http import pyfetch

    semaphore = asyncio.Semaphore(8)

    async def _fetch_one(dataset: str) -> tuple[str, pd.DataFrame, int | None]:
        result = validated_results[dataset]
        if result.data is not None:
            if progress is not None:
                progress.update(dataset, 1, 1)
            return dataset, result.data, 1

        url = result.url
        if not url:
            raise FileNotFoundError(f"**Error: {dataset} not exists")

        async with semaphore:
            response = await pyfetch(url)
            raw = await response.bytes()
        nbytes = len(raw)
        if progress is not None:
            progress.update(dataset, nbytes, nbytes)
        df = pd.read_feather(BytesIO(raw))
        del raw
        return dataset, df, nbytes

    async def _fetch_all() -> list[tuple[str, pd.DataFrame, int | None]]:
        return await asyncio.gather(*[_fetch_one(ds) for ds in cache_misses])

    results = cast(
        "list[tuple[str, pd.DataFrame, int | None]]",
        _run_pyodide_sync(run_sync, _fetch_all()),
    )

    downloaded_frames: dict[str, pd.DataFrame] = {}
    for dataset, df, nbytes in results:
        downloaded_frames[dataset] = df
        if progress is not None and nbytes is not None:
            progress.complete(dataset, nbytes)
    return downloaded_frames


def _persist_full_miss_frames(
    cache_misses: list[str],
    downloaded_frames: dict[str, pd.DataFrame],
    validated_results: OrderedDict[str, FetchMetadata],
    target_storage: StorageBackend,
) -> dict[str, pd.DataFrame]:
    """Persist downloaded full misses and return finalized cache hits."""
    cache_hits: dict[str, pd.DataFrame] = {}
    for dataset in cache_misses:
        df = downloaded_frames[dataset]
        if df.empty:
            raise RuntimeError(f"**Error: {dataset} download fail")
        result = validated_results[dataset]
        target_storage.set_dataframe(dataset, df, expiry=result.expiry)
        logger.debug(f"{dataset} downloaded full data from cloud")
        cache_hits[dataset] = _finalize(dataset, df)
    return cache_hits


def _is_file_storage_lazy_local_usable(
    dataset: str,
    storage: FileStorage,
    *,
    row_count: int | None,
) -> bool:
    """Return whether lazy mode can use an existing FileStorage feather file."""
    if row_count is None:
        return False

    ctx = _default_context
    time_expired = storage.get_time_expired(dataset)
    has_rows = row_count > 0
    if (
        dataset in ctx._loaded_datasets
        and time_expired
        and time_expired > CacheStorage.now()
        and has_rows
    ):
        return True
    if ctx.prefer_local_if_exists and has_rows:
        return True
    if time_expired and time_expired > CacheStorage.now() and has_rows:
        return True
    return ctx._role == "free"


def _partition_file_storage_lazy_datasets(
    resolved: list[str],
    storage: FileStorage,
    force_download: bool,
    use_local_only: bool,
) -> tuple[list[str], list[str]]:
    """Split lazy FileStorage requests without loading dataframes."""
    local_hits: list[str] = []
    cache_misses: list[str] = []

    if force_download:
        return local_hits, list(resolved)

    for dataset in resolved:
        has_local = storage.has_dataframe(dataset)
        row_count = storage.get_dataframe_row_count(dataset) if has_local else None
        if _is_file_storage_lazy_local_usable(
            dataset,
            storage,
            row_count=row_count,
        ):
            local_hits.append(dataset)
            continue

        if use_local_only:
            if row_count is not None and row_count > 0:
                local_hits.append(dataset)
                continue
            raise FileNotFoundError(
                f"**Error: {dataset} not in local storage. "
                "Set data.use_local_data_only = False to download."
            )

        cache_misses.append(dataset)

    return local_hits, cache_misses


def _download_file_storage_lazy_misses(
    cache_misses: list[str],
    storage: FileStorage,
    metadata_fetcher: MetadataFetcher,
    progress: DownloadProgress | None = None,
) -> bool:
    """Download lazy FileStorage misses without reading them back."""
    if not cache_misses:
        return True

    gc.collect()
    request_map: MetadataRequestMap = OrderedDict(
        (dataset, None) for dataset in cache_misses
    )
    if progress is not None:
        progress.set_stage("Fetching full metadata", done=0, total=1)
    result_map = metadata_fetcher(request_map)
    if progress is not None:
        progress.set_stage("Fetching full metadata", done=1, total=1)

    if any(
        result is not None and result.role == "free" for result in result_map.values()
    ):
        return False

    validated_results = _validate_full_miss_results(cache_misses, result_map)
    _download_file_storage_misses_to_storage(
        cache_misses,
        validated_results,
        storage,
        progress=progress,
    )
    for dataset in cache_misses:
        logger.debug(f"{dataset} downloaded full data from cloud")
    return True


def _load_storage_lazy_dataframe(
    dataset: str,
    storage: FileStorage,
    finalize_context: _FinalizeContextSnapshot,
) -> pd.DataFrame:
    df = storage.get_dataframe(dataset, use_cache=False)
    if df is None or df.empty:
        raise RuntimeError(f"**Error: {dataset} not in local storage")
    return _finalize_with_context(dataset, df, finalize_context)


def _load_storage_lazy_index(
    dataset: str,
    storage: FileStorage,
    finalize_context: _FinalizeContextSnapshot,
) -> pd.Index:
    index = storage.get_dataframe_index(dataset)
    if index is None or len(index) == 0:
        raise RuntimeError(f"**Error: {dataset} not in local storage")
    probe = pd.DataFrame(index=index, columns=pd.Index([], dtype="str"))
    return _finalize_with_context(dataset, probe, finalize_context).index


def _make_storage_lazy_wide(
    dataset: str,
    storage: FileStorage,
    finalize_context: _FinalizeContextSnapshot,
) -> LazyWide:
    table_name = dataset.split(":", maxsplit=1)[0]
    index_loader = None
    is_table_dataset = ":" not in dataset
    if not is_table_dataset and not _should_mask_quarterly(
        table_name, finalize_context.truncate_end
    ):
        index_loader = functools.partial(
            _load_storage_lazy_index,
            dataset,
            storage,
            finalize_context,
        )

    return lazy_from_storage(
        dataset,
        storage,
        functools.partial(
            _load_storage_lazy_dataframe,
            dataset,
            storage,
            finalize_context,
        ),
        index_loader,
    )


def _fetch_many_lazy(
    datasets: list[str],
    force_download: bool,
    *,
    show_progress: bool = False,
) -> tuple[LazyWide, ...]:
    """Fetch metadata/storage updates and return storage-backed lazy handles."""
    ctx, resolved, storage, force_download = _prepare_fetch(datasets, force_download)
    finalize_context = _snapshot_finalize_context()
    if not isinstance(storage, FileStorage) or "pyodide" in sys.modules:
        return tuple(
            result.lazy()
            for result in _fetch_many(
                datasets,
                force_download,
                show_progress=show_progress,
            )
        )

    progress: DownloadProgress | None = None
    fallback_to_eager = False
    try:
        local_hits, cache_misses = _partition_file_storage_lazy_datasets(
            resolved,
            storage,
            force_download,
            ctx.use_local_data_only,
        )

        if show_progress and cache_misses:
            progress = DownloadProgress(to_download=cache_misses, cached=local_hits)
            progress.start()

        if cache_misses:
            fallback_to_eager = not _download_file_storage_lazy_misses(
                cache_misses,
                storage,
                fetch_metadata_batch,
                progress=progress,
            )
    finally:
        if progress is not None:
            progress.finish()

    if fallback_to_eager:
        return tuple(
            result.lazy()
            for result in _fetch_many(
                datasets,
                force_download,
                show_progress=show_progress,
            )
        )

    results: list[LazyWide] = []
    for dataset in resolved:
        results.append(_make_storage_lazy_wide(dataset, storage, finalize_context))
        ctx._loaded_datasets.add(dataset)

    return tuple(results)


def _fetch_many(
    datasets: list[str],
    force_download: bool,
    *,
    show_progress: bool = False,
) -> tuple[pd.DataFrame, ...]:
    """Fetch one or more datasets through shared cache and merge policy."""
    progress: DownloadProgress | None = None
    ctx, resolved, storage, force_download = _prepare_fetch(datasets, force_download)
    try:
        (
            cache_hits,
            recent_candidates,
            cache_misses,
            time_saved_map,
            local_frames,
        ) = _partition_datasets(
            resolved,
            storage,
            force_download,
            ctx.use_local_data_only,
        )

        pending = recent_candidates + cache_misses
        if show_progress and pending:
            progress = DownloadProgress(to_download=pending, cached=list(cache_hits))
            progress.start()

        if recent_candidates:
            if progress is not None:
                progress.set_stage("Fetching recent metadata")
            recent_hits, promoted_misses = _resolve_recent_candidates(
                recent_candidates,
                time_saved_map,
                storage,
                local_frames,
                fetch_metadata_batch,
                progress=progress,
            )
            cache_hits.update(recent_hits)
            cache_misses.extend(promoted_misses)

        if cache_misses:
            cache_hits.update(
                _materialize_full_misses(
                    cache_misses,
                    storage,
                    fetch_metadata_batch,
                    progress=progress,
                )
            )

        results: list[pd.DataFrame] = []
        for dataset in resolved:
            results.append(cache_hits[dataset])
            ctx._loaded_datasets.add(dataset)

        return tuple(results)
    finally:
        if progress is not None:
            progress.finish()


# ---------------------------------------------------------------------------
# Role helpers
# ---------------------------------------------------------------------------


def get_role() -> str | None:
    """Return the current user role (e.g. ``'free'`` or ``'vip'``)."""
    return _default_context._role


def is_vip() -> bool:
    """Return True if the current user is a VIP member."""
    role = _default_context._role
    return role is not None and role != "free"


# ---------------------------------------------------------------------------
# data.get() -- main entry point
# ---------------------------------------------------------------------------


def get(
    dataset: str,
    save_to_storage: bool = True,
    force_download: bool = False,
    lazy: bool = False,
) -> pd.DataFrame:
    """Download historical data.

    See https://ai.finlab.tw/database for the full data catalogue.

    Args:
        dataset: The name of dataset.
        save_to_storage: Whether to save the dataset to storage for later use.
        force_download: Whether to force download the dataset from cloud.
        lazy: Return a lazy computation wrapper after fetching the dataset.

    Returns:
        financial data as a DataFrame.
    """
    if not save_to_storage:
        logger.warning(
            "save_to_storage will be deprecated after 2024/06/01. "
            "Please use data.set_storage(CacheStorage()) to disable data saved to local storage"
        )
    if lazy:
        return _fetch_many_lazy([dataset], force_download)[0]
    return _fetch_many([dataset], force_download)[0]
