"""Firestore data catalog and dataset search for finlab."""

from __future__ import annotations

import json
import logging
from functools import lru_cache
from typing import Any, Final

import requests

import finlab.utils

from .context import _default_context

logger = logging.getLogger(__name__)

_MARKET_TO_FIRESTORE_DOC: Final[dict[str, str]] = {
    "tw": "finlab_tw_stock",
    "us": "finlab_us_stock",
    "us_fund": "finlab_us_stock",
    "hk": "fdata-hk-stock",
    "jp": "fdata-jp-stock",
    "kr": "fdata-kr-stock",
    "uk": "fdata-uk-stock",
}


def _parse_firestore_value(
    value: dict[str, Any],
) -> str | int | float | bool | list[Any] | dict[str, Any] | None:
    """Parse a Firestore REST API value into a native Python type."""
    if "stringValue" in value:
        return value["stringValue"]
    if "integerValue" in value:
        return int(value["integerValue"])
    if "doubleValue" in value:
        return float(value["doubleValue"])
    if "booleanValue" in value:
        return value["booleanValue"]
    if "nullValue" in value:
        return None
    if "arrayValue" in value:
        values = value["arrayValue"].get("values", [])
        return [_parse_firestore_value(v) for v in values]
    if "mapValue" in value:
        fields = value["mapValue"].get("fields", {})
        return {k: _parse_firestore_value(v) for k, v in fields.items()}
    if "timestampValue" in value:
        return value["timestampValue"]
    return None


@lru_cache(maxsize=8)
def _fetch_data_catalog_from_firestore(document_id: str) -> tuple[str, ...]:
    """Fetch data catalog entries from Firestore."""
    url = (
        f"https://firestore.googleapis.com/v1/projects/fdata-299302/"
        f"databases/(default)/documents/data_categories/{document_id}"
    )

    try:
        raw = finlab.utils.requests.get(url, timeout=30).json()
        fields = raw.get("fields", {})
        categories = _parse_firestore_value(fields.get("categories", {}))
        if not isinstance(categories, list):
            return ()

        result: list[str] = []
        for cat in categories:
            if not isinstance(cat, dict):
                continue
            table_alias = cat.get("alias", "")
            data_info = cat.get("data_info", [])
            if not isinstance(data_info, list):
                continue
            for info in data_info:
                if not isinstance(info, dict):
                    continue
                col_alias = info.get("alias", "")
                if col_alias:
                    result.append(col_alias)
                elif table_alias and info.get("name"):
                    result.append(f"{table_alias}:{info.get('name')}")

        return tuple(dict.fromkeys(result))
    except (requests.RequestException, json.JSONDecodeError, KeyError, ValueError) as e:
        logger.warning("Failed to fetch data catalog from %s: %s", document_id, e)
        return ()


def search(keyword: str | None = None, market: str | None = None) -> list[str]:
    """Search available data fields in the finlab database."""
    valid_market_names = set(_MARKET_TO_FIRESTORE_DOC) | {"all"}
    if keyword is not None and market is None and keyword.lower() in valid_market_names:
        market = keyword.lower()
        keyword = None

    if market is None:
        market = _default_context._current_market or "tw"
    market = market.lower()

    if market == "all":
        catalog: list[str] = []
        for doc_id in dict.fromkeys(_MARKET_TO_FIRESTORE_DOC.values()):
            catalog.extend(_fetch_data_catalog_from_firestore(doc_id))
    elif market in _MARKET_TO_FIRESTORE_DOC:
        catalog = list(
            _fetch_data_catalog_from_firestore(_MARKET_TO_FIRESTORE_DOC[market])
        )
    else:
        valid = ", ".join(sorted(_MARKET_TO_FIRESTORE_DOC)) + ", all"
        raise ValueError(f"Invalid market: '{market}'. Must be one of: {valid}")

    if keyword is None:
        return catalog

    keyword_lower = keyword.lower()
    return [item for item in catalog if keyword_lower in item.lower()]
