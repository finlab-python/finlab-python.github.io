from __future__ import annotations

import datetime
from typing import ClassVar

import pandas as pd

from finlab import data

__all__ = ["JPFundMarket", "JPMarket"]
from finlab.market import Market


class JPMarket(Market):
    """Japan stock market (TSE/JPX)."""

    _price_table: ClassVar[str] = "jp_price"
    _adj_prefix: ClassVar[str] = "etl:jp_adj_"

    @staticmethod
    def get_freq() -> str:
        return "1d"

    @staticmethod
    def get_name() -> str:
        return "jp_stock"

    @staticmethod
    def get_benchmark() -> pd.Series:
        return data.get("world_index:adj_close")["^N225"]

    @staticmethod
    def get_asset_id_to_name() -> dict[str, str]:
        try:
            from finlab.compat import resolve_id_column

            tickers = data.get("jp_tickers")
            return dict(
                zip(tickers[resolve_id_column(tickers)], tickers["name"], strict=True)
            )
        except (ImportError, KeyError, ValueError, RuntimeError):
            return {}

    def market_close_at_timestamp(
        self, timestamp: pd.Timestamp | None = None
    ) -> pd.Timestamp:
        if timestamp is None:
            timestamp = self.get_price("close").index[-1]

        timestamp = self._normalize_market_timestamp(timestamp, "Asia/Tokyo")

        market_close = pd.Timestamp(timestamp.date()) + pd.Timedelta("15:00:00")
        return market_close.tz_localize("Asia/Tokyo")

    @staticmethod
    def market_open_time() -> tuple[int, int]:
        return (9, 0)

    @staticmethod
    def default_fee_ratio() -> float:
        return 0.0

    @staticmethod
    def default_tax_ratio() -> float:
        return 0.0

    @staticmethod
    def tzinfo() -> datetime.timezone:
        return datetime.timezone(datetime.timedelta(hours=9))


class JPFundMarket(JPMarket):
    """Japan fund/ETF market using jp_fund_price data."""

    _price_table: ClassVar[str] = "jp_fund_price"
    _adj_prefix: ClassVar[str] = "etl:jp_fund_adj_"

    @staticmethod
    def get_name() -> str:
        return "jp_fund"
