from __future__ import annotations

from typing import TYPE_CHECKING, Final

from .hk import HKFundMarket, HKMarket
from .jp import JPFundMarket, JPMarket
from .kr import KRFundMarket, KRMarket
from .rotc import ROTCMarket
from .tw import TWMarket
from .tw_cb import TWCBMarket
from .uk import UKFundMarket, UKMarket
from .us import USFundMarket, USMarket

if TYPE_CHECKING:
    from finlab.market import Market

__all__ = [
    "MARKET_CODE_TO_CLASS",
    "HKFundMarket",
    "HKMarket",
    "JPFundMarket",
    "JPMarket",
    "KRFundMarket",
    "KRMarket",
    "ROTCMarket",
    "TWCBMarket",
    "TWMarket",
    "UKFundMarket",
    "UKMarket",
    "USFundMarket",
    "USMarket",
    "get_market_by_name",
]

_MARKET_NAME_TO_CLASS: Final[dict[str, type[Market]]] = {
    "tw_stock": TWMarket,
    "us_stock": USMarket,
    "us_fund": USFundMarket,
    "rotc_stock": ROTCMarket,
    "tw_cb": TWCBMarket,
    "hk_stock": HKMarket,
    "hk_fund": HKFundMarket,
    "jp_stock": JPMarket,
    "jp_fund": JPFundMarket,
    "kr_stock": KRMarket,
    "kr_fund": KRFundMarket,
    "uk_stock": UKMarket,
    "uk_fund": UKFundMarket,
}

# Mapping from short market code (used by data.set_market) to Market class
MARKET_CODE_TO_CLASS: Final[dict[str, type[Market]]] = {
    "tw": TWMarket,
    "us": USMarket,
    "us_fund": USFundMarket,
    "hk": HKMarket,
    "jp": JPMarket,
    "kr": KRMarket,
    "uk": UKMarket,
}


def get_market_by_name(name: str) -> Market:
    key = name.lower()
    cls = _MARKET_NAME_TO_CLASS.get(key)
    if cls is None:
        cls = MARKET_CODE_TO_CLASS.get(key)
    if cls is None:
        valid = sorted(set(list(_MARKET_NAME_TO_CLASS) + list(MARKET_CODE_TO_CLASS)))
        raise ValueError(f"Unknown market name: {name!r}. Valid names: {valid}")
    return cls()
