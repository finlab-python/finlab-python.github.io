from __future__ import annotations

import os
from configparser import ConfigParser
from typing import TYPE_CHECKING, Any

import click

from .data_encryptor import DataEncryptor
from .form_factory import create_user_form

if TYPE_CHECKING:
    from finlab.online.core.account import Account


def config_to_json(config_file: str) -> dict[str, dict[str, str]]:
    config = ConfigParser()
    config.read(config_file)

    return {section: dict(config.items(section)) for section in config.sections()}


def encode_file_to_string(file_path: str) -> str:
    with open(file_path, "rb") as file:
        file_content = file.read()
    return file_content.decode("latin1")


def decode_string_to_file(encoded_string: str, output_path: str) -> None:
    decoded_content = encoded_string.encode("latin1")
    with open(output_path, "wb") as file:
        file.write(decoded_content)


def check_and_fill_envs(broker_type: str) -> bool:
    if broker_type == "sinopac":
        env_names = {
            "SHIOAJI_API_KEY": "password",
            "SHIOAJI_SECRET_KEY": "password",
            "SHIOAJI_CERT_PERSON_ID": "password",
            "SHIOAJI_CERT_PASSWORD": "password",
            "SHIOAJI_CERT_PATH": "file",
        }
    elif broker_type == "fugle":
        env_names = {
            "FUGLE_CONFIG_PATH": "file",
            "FUGLE_MARKET_API_KEY": "password",
            "FUGLE_ACCOUNT_PASSWORD": "password",
            "FUGLE_CERT_PASSWORD": "password",
        }

    delisted = [env_name for env_name in env_names if env_name in os.environ]

    for env_name in delisted:
        env_names.pop(env_name)

    if env_names:
        form_data = create_user_form(env_names)

        if form_data["action"] == "save":
            for env_name, value in form_data.items():
                os.environ[env_name] = value
            return True
        return False

    return True


def add_broker(
    broker: str, WORKSPACE_PATH: str = ".", name: str = "default"
) -> bool | None:
    if broker == "fugle":
        try:
            from fugle_trade.sdk import SDK  # noqa: F401
        except ImportError:
            click.echo(
                "Failed to add broker: package not installed. Please run 'pip install fugle-trade'"
            )
            return False
        from finlab.online.fugle_account import FugleAccount

        constructor = FugleAccount
    elif broker == "sinopac":
        try:
            import shioaji  # noqa: F401
        except ImportError:
            click.echo(
                "Failed to add broker: package not installed. Please run 'pip install shioaji'"
            )
            return False
        from finlab.online.sinopac_account import SinopacAccount

        constructor = SinopacAccount
    else:
        raise ValueError(f"Broker {broker} is not supported")

    success = check_and_fill_envs(broker)
    if not success:
        return False

    try:
        constructor()
        click.echo(f"Broker {name} added successfully")
    except Exception as e:
        click.echo(f"Failed to add broker: {e}")
        return False

    # encrypt account login info

    if broker == "sinopac":
        from finlab.online.sinopac_account import SinopacAccount

        try:
            SinopacAccount()
        except Exception:
            click.echo(
                "Failed to add broker: Sinopac account cannot be initialized. Please check your environment variables."
            )
            return None
        env_names = [
            "SHIOAJI_API_KEY",
            "SHIOAJI_SECRET_KEY",
            "SHIOAJI_CERT_PERSON_ID",
            "SHIOAJI_CERT_PASSWORD",
        ]
        file_path = {"SHIOAJI_CERT_PATH": os.environ["SHIOAJI_CERT_PATH"]}
        config_data: dict[str, Any] = {}
    elif broker == "fugle":
        from configparser import ConfigParser

        from fugle_trade.util import ft_get_password

        from finlab.online.fugle_account import FugleAccount

        try:
            FugleAccount()
        except Exception:
            click.echo(
                "Failed to add broker: Fugle account cannot be initialized. Please check your environment variables."
            )
            return None

        config = ConfigParser()
        config.read(os.environ["FUGLE_CONFIG_PATH"])

        os.environ["FUGLE_ACCOUNT"] = config["User"]["Account"]
        os.environ["FUGLE_ACCOUNT_PASSWORD"] = ft_get_password(
            "fugle_trade_sdk:account", config["User"]["Account"]
        )
        os.environ["FUGLE_CERT_PASSWORD"] = ft_get_password(
            "fugle_trade_sdk:cert", config["User"]["Account"]
        )

        env_names = [
            "FUGLE_MARKET_API_KEY",
            "FUGLE_ACCOUNT",
            "FUGLE_ACCOUNT_PASSWORD",
            "FUGLE_CERT_PASSWORD",
        ]

        file_path = {"certificate": config.get("Cert", "Path")}

        config_data = {
            "Core": {
                "Entry": config.get("Core", "Entry"),
            },
            "Cert": {
                "Path": config.get("Cert", "Path"),
            },
            "Api": {
                "Key": config.get("Api", "Key"),
                "Secret": config.get("Api", "Secret"),
            },
            "User": {
                "Account": config.get("User", "Account"),
            },
        }

    broker_data = {
        "env": {env_name: os.environ[env_name] for env_name in env_names},
        "config": config_data,
        "files": {
            name: (path.split(".")[-1], encode_file_to_string(path))
            for name, path in file_path.items()
        },
        "broker_name": broker,
        "name": name,
    }

    user = DataEncryptor.from_file(os.path.join(WORKSPACE_PATH, "user.txt"))
    user.data.setdefault("broker", {})[broker_data["name"]] = broker_data
    user.to_file()
    return True


def create_account_from_broker_info(
    info: dict[str, Any], WORKSPACE_PATH: str = "."
) -> Account:

    name = info["name"]

    # setting env from info
    os.environ.update(info["env"])

    # setting file path
    if "files" in info:
        account_path = os.path.join(WORKSPACE_PATH, f"{name}_account")
        if not os.path.exists(account_path):
            os.mkdir(account_path)

        for name, (postfix, content) in info["files"].items():
            file_path = os.path.join(account_path, f"{name}.{postfix}")
            decode_string_to_file(content, file_path)
            os.environ[name] = file_path

    if info["broker_name"] == "fugle":
        # create ini file
        from configparser import ConfigParser

        config = ConfigParser()

        config["Core"] = info["config"]["Core"]
        config["Cert"] = info["config"]["Cert"]
        config["Api"] = info["config"]["Api"]
        config["User"] = info["config"]["User"]
        config["Cert"]["Path"] = os.path.join(account_path, "certificate.p12")

        with open(os.path.join(account_path, "config.ini"), "w", encoding="utf-8") as f:
            config.write(f)

        os.environ["FUGLE_CONFIG_PATH"] = os.path.join(account_path, "config.ini")

        from fugle_trade.util import set_password, setup_keyring

        from finlab.online.fugle_account import FugleAccount

        aid = config["User"]["Account"]
        setup_keyring(aid)
        set_password(
            "fugle_trade_sdk:account", aid, os.environ["FUGLE_ACCOUNT_PASSWORD"]
        )
        set_password("fugle_trade_sdk:cert", aid, os.environ["FUGLE_CERT_PASSWORD"])

        account = FugleAccount()
    else:
        from finlab.online.sinopac_account import SinopacAccount

        account = SinopacAccount()

    # remove all the files
    if "files" in info:
        for name, (postfix, _) in info["files"].items():
            file_path = os.path.join(account_path, f"{name}.{postfix}")
            os.remove(file_path)

    return account


def register_broker_commands(click: Any, broker: Any, WORKSPACE_PATH: str) -> None:

    from finlab.cli.login import _login

    @broker.command()
    @click.argument("name", default="default")
    @click.option("--broker", "broker_type")
    def add(name: str, broker_type: str) -> None:
        """Add a broker account."""

        if name == "default":
            name = broker_type

        _login(WORKSPACE_PATH)
        success = add_broker(broker_type, WORKSPACE_PATH, name)
        if not success:
            click.echo(f"Failed to add broker {name}")
        else:
            click.echo(f"Broker {name} added successfully")

    @broker.command()
    def list() -> None:
        """List all brokers."""
        user = _login(WORKSPACE_PATH)
        broker_names = user.data["broker"].keys()
        for broker_name in broker_names:
            click.echo(broker_name)

    @broker.command()
    def test() -> None:
        """Test all brokers."""
        user = _login(WORKSPACE_PATH)
        for name, broker_info in user.data["broker"].items():
            try:
                create_account_from_broker_info(broker_info)
                click.echo(f"Broker {name} tested successfully")
            except Exception as e:
                import traceback

                traceback.print_exc()
                click.echo(f"Failed to test broker {name}: {e}")

        click.echo(user.data["firebase_login_data"]["api_token"])

    @broker.command()
    @click.argument("name", default="default")
    @click.option("--broker")
    def remove(name: str) -> None:
        """Remove a broker account."""

        user = DataEncryptor.from_file(os.path.join(WORKSPACE_PATH, "user.txt"))
        if name in user.data["broker"]:
            user.data["broker"].pop(name, None)
            user.to_file()
            click.echo(f"Broker {name} removed successfully")
        else:
            click.echo(f"Broker {name} not found")
