"""Lightweight download-progress display for ``data.gets()``.

Renders pip-style progress bars in terminal (ANSI) and Jupyter (HTML),
using only stdlib + IPython (already a project dependency).
"""

from __future__ import annotations

import html as _html
import logging
import os
import shutil
import sys
import threading
import time
import unicodedata
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING, Literal, NamedTuple, TypedDict

if TYPE_CHECKING:
    from collections.abc import Callable

ProgressMode = Literal["display", "event", "silent"]


class ProgressEvent(TypedDict, total=False):
    phase: str
    dataset: str
    completed: int
    total: int
    cache_hit: bool
    download_bytes: int
    elapsed_ms: int
    timestamp: float


_BAR = "\u2501"  # ━
_CAP = "\u2578"  # ╸
_MARKET_PREFIXES = ("us_", "hk_", "jp_", "kr_", "uk_")
_MAX_LABEL_WIDTH = 32
logger = logging.getLogger(__name__)


def _in_notebook() -> bool:
    try:
        from IPython import get_ipython

        shell = get_ipython()
        if shell is None:
            return False

        # ipykernel-backed sessions (JupyterLab/Notebook/VSCode interactive)
        # usually expose a kernel object.
        if getattr(shell, "kernel", None) is not None:
            return True

        return type(shell).__name__ == "ZMQInteractiveShell"
    except (ImportError, NameError):
        return False


def _fmt_bytes(n: float) -> str:
    for unit in ("B", "kB", "MB", "GB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def _fmt_speed(bps: float) -> str:
    return f"{_fmt_bytes(bps)}/s" if bps > 0 else "-- kB/s"


def _display_width(s: str) -> int:
    w = 0
    for ch in s:
        w += 2 if unicodedata.east_asian_width(ch) in ("F", "W") else 1
    return w


def _pad_to_width(s: str, target: int) -> str:
    return s + " " * max(target - _display_width(s), 0)


def _truncate_to_width(s: str, target: int) -> str:
    if target <= 0:
        return ""
    if _display_width(s) <= target:
        return s

    ellipsis = "…"
    if target == 1:
        return ellipsis

    out: list[str] = []
    width = 0
    for ch in s:
        cw = 2 if unicodedata.east_asian_width(ch) in ("F", "W") else 1
        if width + cw > target - 1:
            break
        out.append(ch)
        width += cw
    out.append(ellipsis)
    return "".join(out)


def _display_name(ds: str) -> str:
    for p in _MARKET_PREFIXES:
        if ds.startswith(p):
            return ds[len(p) :]
    return ds


class _Status(Enum):
    CACHED = auto()
    WAITING = auto()
    ACTIVE = auto()
    DONE = auto()


class _RowInfo(NamedTuple):
    label: str
    padded: str
    status: _Status
    pct: float
    size_done: str
    size_total: str
    speed: str


@dataclass
class _Task:
    label: str
    padded: str
    total: int = 0
    downloaded: int = 0
    done: bool = False
    cached: bool = False
    t0: float = 0.0
    started: bool = False


class DownloadProgress:
    """Thread-safe multi-row download progress, pip-style."""

    def __init__(
        self,
        to_download: list[str],
        cached: list[str] | None = None,
        *,
        mode: ProgressMode = "display",
        callback: Callable[[ProgressEvent], None] | None = None,
    ) -> None:
        if mode not in {"display", "event", "silent"}:
            raise ValueError("progress must be 'display', 'event', or 'silent'")
        cached = cached or []
        self._mode = mode
        self._callback = callback
        self._order: list[str] = cached + to_download
        self._tasks: dict[str, _Task] = {}
        self._lock = threading.RLock()
        force_html = os.environ.get("FINLAB_PROGRESS_FORCE_HTML", "") == "1"
        self._notebook = force_html or _in_notebook()
        self._in_pytest = "PYTEST_CURRENT_TEST" in os.environ
        force_tty = os.environ.get("FINLAB_PROGRESS_FORCE_TTY", "") == "1"
        self._tty = (
            hasattr(sys.stderr, "isatty")
            and sys.stderr.isatty()
            and (force_tty or not self._in_pytest)
        )
        self._plain = not self._notebook and not self._tty
        self._handle = None
        self._rows = 0
        self._t0 = time.monotonic()
        self._last_draw = 0.0
        self._finished = False
        self._stage = "Preparing"
        self._stage_done: int | None = None
        self._stage_total: int | None = None
        self._stage_scope: set[str] | None = None
        self._last_plain_header = ""
        self._plain_finished_rows_printed = False

        lw = 8
        labels: dict[str, tuple[str, int]] = {}
        for ds in self._order:
            name = _truncate_to_width(_display_name(ds), _MAX_LABEL_WIDTH)
            w = _display_width(name)
            labels[ds] = (name, w)
            lw = max(lw, w)

        for ds in cached:
            name, _ = labels[ds]
            self._tasks[ds] = _Task(
                label=name,
                padded=_pad_to_width(name, lw),
                done=True,
                cached=True,
            )
        for ds in to_download:
            name, _ = labels[ds]
            self._tasks[ds] = _Task(
                label=name,
                padded=_pad_to_width(name, lw),
            )

        self._lw = lw

    def start(self) -> None:
        with self._lock:
            self._draw(force=True)
            cached = [dataset for dataset in self._order if self._tasks[dataset].cached]
        for dataset in cached:
            self._emit("cache", dataset=dataset, cache_hit=True)

    def set_stage(
        self,
        stage: str,
        *,
        done: int | None = None,
        total: int | None = None,
        datasets: list[str] | None = None,
    ) -> None:
        with self._lock:
            self._stage = stage
            self._stage_done = done
            self._stage_total = total
            self._stage_scope = set(datasets) if datasets is not None else None
            self._draw(force=True)
        self._emit(stage, completed=done, total=total)

    def mark_cached(self, ds: str) -> None:
        with self._lock:
            t = self._tasks[ds]
            t.cached = True
            t.done = True
            if not t.started:
                t.started = True
                t.t0 = time.monotonic()
            self._refresh_stage_done(ds)
            self._draw(force=True)
        self._emit("cache", dataset=ds, cache_hit=True)

    def update(self, ds: str, downloaded: int, total: int) -> None:
        with self._lock:
            t = self._tasks[ds]
            if not t.started:
                t.started = True
                t.t0 = time.monotonic()
            t.downloaded = downloaded
            t.total = total
            self._draw()
        self._emit("download", dataset=ds, download_bytes=downloaded, total=total)

    def complete(self, ds: str, nbytes: int) -> None:
        with self._lock:
            t = self._tasks[ds]
            t.downloaded = t.total = nbytes
            t.done = True
            self._refresh_stage_done(ds)
            self._draw(force=True)
        self._emit("complete", dataset=ds, download_bytes=nbytes, cache_hit=False)

    def finish(self) -> None:
        with self._lock:
            self._finished = True
            self._draw(force=True)
            if self._mode == "display" and self._tty and not self._notebook:
                sys.stderr.write("\n")
                sys.stderr.flush()
            total = len(self._tasks)
        self._emit("finish", completed=total, total=total)

    def _draw(self, force: bool = False) -> None:
        if self._mode != "display":
            return
        now = time.monotonic()
        if not force and now - self._last_draw < 0.08:
            return
        self._last_draw = now
        if self._notebook:
            self._draw_html()
        elif self._tty:
            self._draw_ansi()
        elif self._plain:
            self._draw_plain()

    def _emit(
        self,
        phase: str,
        *,
        dataset: str | None = None,
        completed: int | None = None,
        total: int | None = None,
        cache_hit: bool | None = None,
        download_bytes: int | None = None,
    ) -> None:
        if self._mode != "event" or self._callback is None:
            return
        event: ProgressEvent = {
            "phase": phase,
            "elapsed_ms": int((time.monotonic() - self._t0) * 1000),
            "timestamp": time.time(),
        }
        if dataset is not None:
            event["dataset"] = dataset
        if completed is not None:
            event["completed"] = completed
        if total is not None:
            event["total"] = total
        if cache_hit is not None:
            event["cache_hit"] = cache_hit
        if download_bytes is not None:
            event["download_bytes"] = download_bytes
        try:
            self._callback(event)
        except Exception:
            logger.warning("Progress callback failed", exc_info=True)

    def _header(self) -> tuple[int, int, float]:
        nd = sum(t.done for t in self._tasks.values())
        nt = len(self._tasks)
        return nd, nt, time.monotonic() - self._t0

    def _row_info(self, ds: str) -> _RowInfo:
        t = self._tasks[ds]
        if t.cached:
            return _RowInfo(t.label, t.padded, _Status.CACHED, 0, "", "", "")
        if not t.started:
            return _RowInfo(t.label, t.padded, _Status.WAITING, 0, "", "", "")
        pct = min(t.downloaded / t.total * 100, 100) if t.total else 0
        dt = time.monotonic() - t.t0
        spd = t.downloaded / dt if dt > 0 else 0
        status = _Status.DONE if t.done else _Status.ACTIVE
        return _RowInfo(
            t.label,
            t.padded,
            status,
            pct,
            _fmt_bytes(t.downloaded),
            _fmt_bytes(t.total),
            _fmt_speed(spd),
        )

    def _draw_ansi(self) -> None:
        out = sys.stderr
        cols = shutil.get_terminal_size((80, 24)).columns
        # Keep rows under terminal width so cursor-up redraw never desynchronizes.
        bar_w = max(8, min(cols - self._lw - 40, 30))
        lines: list[str] = []

        nd, nt, elapsed = self._header()
        if self._finished:
            lines.append(f"Fetched {nt} datasets in {elapsed:.1f}s")
        else:
            lines.append(f"Fetching datasets ({nd}/{nt})")

        for ds in self._order:
            ri = self._row_info(ds)
            lbl = ri.padded

            if ri.status is _Status.CACHED:
                lines.append(f"  {lbl}  ✓ cached")
            elif ri.status is _Status.WAITING:
                lines.append(f"  {lbl}  waiting…")
            elif ri.status is _Status.DONE:
                bar = _BAR * bar_w
                info = ri.size_total
                if not self._finished:
                    info += f"  {ri.speed}"
                lines.append(f"  {lbl}  {bar} {info}")
            else:
                filled = int(ri.pct / 100 * bar_w)
                fb = _BAR * max(filled - 1, 0) + (_CAP if filled else "")
                eb = " " * (bar_w - filled)
                bar = f"{fb}{eb}"
                lines.append(
                    f"  {lbl}  {bar} {ri.size_done}/{ri.size_total}  {ri.speed}"
                )

        max_w = max(cols - 1, 20)
        lines = [_truncate_to_width(line, max_w) for line in lines]

        if self._rows:
            out.write(f"\033[{self._rows}A")
        for ln in lines:
            out.write(f"\r{ln}\033[K\n")
        out.flush()
        self._rows = len(lines)

    def _draw_html(self) -> None:
        from IPython.display import HTML, display

        html = self._build_html()
        if self._handle is None:
            self._handle = display(HTML(html), display_id=True)
        else:
            self._handle.update(HTML(html))

    def _draw_plain(self) -> None:
        if not self._finished or self._plain_finished_rows_printed:
            return

        out = sys.stderr
        _, nt, elapsed = self._header()
        out.write(f"Fetched {nt} datasets in {elapsed:.1f}s\n")

        for ds in self._order:
            ri = self._row_info(ds)
            if ri.status is _Status.CACHED:
                status = "cached"
                detail = ""
            elif ri.status in (_Status.DONE, _Status.ACTIVE):
                status = "fetched"
                detail = ri.size_total or ri.size_done or "--"
            else:
                status = "loaded"
                detail = ""

            label = ri.padded if detail else ri.label
            suffix = f"  {detail}" if detail else ""
            out.write(f"  {status:<7} {label}{suffix}\n")

        out.flush()
        self._plain_finished_rows_printed = True

    def _refresh_stage_done(self, ds: str) -> None:
        if (
            self._stage_scope is None
            or ds not in self._stage_scope
            or self._stage_total is None
        ):
            return
        self._stage_done = sum(1 for d in self._stage_scope if self._tasks[d].done)

    def _build_html(self) -> str:
        nd, nt, elapsed = self._header()
        hdr = (
            f"Fetched {nt} datasets in {elapsed:.1f}s"
            if self._finished
            else f"Fetching datasets ({nd}/{nt})"
        )

        rows: list[str] = []
        for ds in self._order:
            ri = self._row_info(ds)
            nm = _html.escape(ri.label)

            if ri.status is _Status.CACHED:
                bar = '<span style="color:#22c55e;font-weight:600">\u2713 cached</span>'
                stat = ""
            elif ri.status is _Status.WAITING:
                bar = '<span style="color:#94a3b8">waiting\u2026</span>'
                stat = ""
            else:
                clr = "#22c55e" if ri.status is _Status.DONE else "#3b82f6"
                bar = (
                    '<div style="background:#e2e8f0;border-radius:4px;height:8px;'
                    f'width:200px;display:inline-block;vertical-align:middle">'
                    f'<div style="background:{clr};border-radius:4px;height:100%;'
                    f'width:{ri.pct:.1f}%;transition:width .15s"></div></div>'
                )
                stat = (
                    ri.size_total
                    if ri.status is _Status.DONE
                    else f"{ri.size_done}/{ri.size_total}  {ri.speed}"
                )

            rows.append(
                "<tr>"
                '<td style="padding:3px 10px 3px 0;font-family:ui-monospace,'
                f'SFMono-Regular,monospace;font-size:13px;white-space:nowrap">{nm}</td>'
                f'<td style="padding:3px 10px">{bar}</td>'
                '<td style="padding:3px 0;font-family:ui-monospace,'
                "SFMono-Regular,monospace;font-size:12px;"
                f'color:#64748b;white-space:nowrap">{stat}</td>'
                "</tr>"
            )

        return (
            '<div style="font-family:system-ui,-apple-system,sans-serif;'
            'font-size:13px;line-height:1.8">'
            f'<div style="font-weight:700;margin-bottom:2px">{hdr}</div>'
            f'<table style="border-collapse:collapse">{"".join(rows)}</table>'
            "</div>"
        )
