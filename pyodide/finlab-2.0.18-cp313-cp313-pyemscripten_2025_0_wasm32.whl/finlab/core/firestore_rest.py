from __future__ import annotations

import base64
import datetime
import json
import os
import re
from typing import Any

from finlab.utils import requests

DEFAULT_PROJECT_ID = os.environ.get("FINLAB_FIRESTORE_PROJECT", "fdata-299302")
DEFAULT_DATABASE = os.environ.get("FINLAB_FIRESTORE_DATABASE", "(default)")


def _get_firestore_url(
    document_path: str, project_id: str | None = None, database: str | None = None
) -> str:
    project = project_id or DEFAULT_PROJECT_ID
    db = database or DEFAULT_DATABASE
    return f"https://firestore.googleapis.com/v1/projects/{project}/databases/{db}/documents/{document_path}"


def decode_id_token_payload(id_token: Any) -> dict[str, Any]:
    if not isinstance(id_token, str):
        return {}
    parts = id_token.split(".")
    if len(parts) < 2:
        return {}

    payload_part = parts[1]
    payload_part += "=" * (-len(payload_part) % 4)
    try:
        payload_raw = base64.urlsafe_b64decode(payload_part.encode("ascii"))
        payload = json.loads(payload_raw.decode("utf-8"))
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def extract_uid_from_id_token(id_token: Any) -> str | None:
    payload = decode_id_token_payload(id_token)
    for key in ("uid", "user_id", "sub"):
        value = payload.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def _to_firestore_value(value: Any) -> dict[str, Any]:
    if value is None:
        return {"nullValue": None}
    if isinstance(value, bool):
        return {"booleanValue": value}
    if isinstance(value, int):
        return {"integerValue": str(value)}
    if isinstance(value, float):
        if value == float("inf"):
            return {"doubleValue": "Infinity"}
        if value == float("-inf"):
            return {"doubleValue": "-Infinity"}
        if value != value:
            return {"doubleValue": "NaN"}
        return {"doubleValue": value}
    if isinstance(value, datetime.datetime):
        iso = value.isoformat()
        if value.tzinfo is None:
            iso += "Z"
        return {"timestampValue": iso}
    if isinstance(value, list):
        return {"arrayValue": {"values": [_to_firestore_value(v) for v in value]}}
    if isinstance(value, dict):
        return {
            "mapValue": {
                "fields": {k: _to_firestore_value(v) for k, v in value.items()}
            }
        }
    return {"stringValue": str(value)}


def _from_firestore_value(value: Any) -> Any:
    if not isinstance(value, dict):
        return None

    if "stringValue" in value:
        return value["stringValue"]
    if "integerValue" in value:
        return int(value["integerValue"])
    if "doubleValue" in value:
        raw = value["doubleValue"]
        if isinstance(raw, str):
            if raw == "Infinity":
                return float("inf")
            if raw == "-Infinity":
                return float("-inf")
            if raw == "NaN":
                return float("nan")
        return float(raw)
    if "booleanValue" in value:
        return value["booleanValue"]
    if "nullValue" in value:
        return None
    if "timestampValue" in value:
        return value["timestampValue"]
    if "arrayValue" in value:
        arr = value["arrayValue"].get("values", [])
        return [_from_firestore_value(v) for v in arr]
    if "mapValue" in value:
        fields = value["mapValue"].get("fields", {})
        return {k: _from_firestore_value(v) for k, v in fields.items()}
    return None


def _to_firestore_document(payload: dict[str, Any]) -> dict[str, Any]:
    return {"fields": {k: _to_firestore_value(v) for k, v in payload.items()}}


def _from_firestore_document(payload: Any) -> dict[str, Any] | None:
    if not isinstance(payload, dict):
        return None
    fields = payload.get("fields", {})
    if not isinstance(fields, dict):
        return None
    return {k: _from_firestore_value(v) for k, v in fields.items()}


def get_document(
    document_path: str,
    id_token: str,
    project_id: str | None = None,
    database: str | None = None,
    timeout: int = 30,
) -> dict[str, Any] | None:
    url = _get_firestore_url(document_path, project_id=project_id, database=database)
    headers = {"Authorization": f"Bearer {id_token}"}
    res = requests.get(url, headers=headers, timeout=timeout)
    if res.status_code == 404:
        return None
    if res.status_code != 200:
        raise Exception(res.text)
    return _from_firestore_document(res.json())


_SIMPLE_FIELD_PATH = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _to_field_path(key: str) -> str:
    """Quote a top-level field name so Firestore reads it as a single segment."""
    if _SIMPLE_FIELD_PATH.match(key):
        return key
    escaped = key.replace("\\", "\\\\").replace("`", "\\`")
    return f"`{escaped}`"


def upsert_document(
    document_path: str,
    payload: dict[str, Any],
    id_token: str,
    project_id: str | None = None,
    database: str | None = None,
    timeout: int = 30,
) -> dict[str, Any] | None:
    """Merge ``payload`` into a Firestore document, leaving other fields intact.

    ``updateMask`` is required: a PATCH without it replaces the whole document,
    which would drop fields written by other producers (e.g. the cloud
    deployment tier and schedule stored alongside an uploaded report).
    """
    url = _get_firestore_url(document_path, project_id=project_id, database=database)
    headers = {"Authorization": f"Bearer {id_token}"}
    body = _to_firestore_document(payload)
    params = {"updateMask.fieldPaths": [_to_field_path(k) for k in payload]}
    res = requests.patch(
        url, headers=headers, json=body, params=params, timeout=timeout
    )
    if res.status_code not in (200, 201):
        raise Exception(res.text)
    return _from_firestore_document(res.json())
