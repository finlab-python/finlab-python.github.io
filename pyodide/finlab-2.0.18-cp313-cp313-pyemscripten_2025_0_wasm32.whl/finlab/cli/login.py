"""Legacy Firebase/Google OAuth login flow for the old `finlab auth` CLI.

New code should use :mod:`finlab.auth` (browser poll-based login) instead.
This module is kept for backward compatibility with existing workspaces.

The optional dependencies (``flask``, ``google-auth-oauthlib``, ``pywebview``)
are imported lazily so that importing this module — or any unrelated CLI
command — never fails when the ``finlab[cli]`` extra is not installed.
"""

from __future__ import annotations

import importlib.util
import json
import logging
import os
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from .data_encryptor import DataEncryptor
from .utils import read_resource_file

if TYPE_CHECKING:
    from google.oauth2.credentials import Credentials

logger = logging.getLogger(__name__)

os.environ["FLASK_DEBUG"] = "0"

_USER: DataEncryptor | None = None
_webview_process: subprocess.Popen[bytes] | None = None
_login_completed: bool = False
google_token: Any | None = None

# How long to wait for the user to finish the Firebase sign-in before
# giving up and cleaning up the helper processes.
LOGIN_TIMEOUT_SECONDS: int = 180

# Firebase configuration (public web-app config, not a secret)
firebase_config: dict[str, str] = {
    "apiKey": "AIzaSyB9Ogv6Vbwfy6_I0aLEfcpsPhqhlc4FSTw",
    "authDomain": "fdata-299302.firebaseapp.com",
    "projectId": "fdata-299302",
    "storageBucket": "fdata-299302.appspot.com",
    "messagingSenderId": "748308483506",
    "appId": "1:748308483506:web:7c78dd82b422cd4ea5a8ab",
}

_LOGIN_HTML = """
<!DOCTYPE html>
<html>
<head>
    <script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-auth-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore-compat.js"></script>
    <script>
        // Firebase configuration
        const firebaseConfig = {{ firebase_config | safe }};
        const googleToken = "{{ google_token }}";

        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);

        async function googleSignIn() {
            try {
                const credential = firebase.auth.GoogleAuthProvider.credential(googleToken);
                const result = await firebase.auth().signInWithCredential(credential);

                const user = result.user;
                const token = await user.getIdToken();

                // get user custom claims
                const idToken = await user.getIdTokenResult();

                const response = await fetch('/fetch-data', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ token, claims: idToken.claims })
                });

                if (response.ok) {
                    console.log("Data fetched successfully");
                } else {
                    console.error("Error fetching data");
                }
            } catch (error) {
                console.error("Error during sign-in:", error);
            }
        }

        window.onload = googleSignIn;
    </script>
</head>
<body>
    <h1>Signing in to FinLab...</h1>
    <p>You can close this window after the login completes.</p>
</body>
</html>
"""


class MissingCliDependencyError(RuntimeError):
    """Raised when an optional CLI dependency is not installed."""

    def __init__(self, package: str) -> None:
        super().__init__(
            f"The '{package}' package is required for this login flow. "
            "Install the CLI extras with: pip install 'finlab[cli]'"
        )


def _require(module_name: str, package: str) -> Any:
    """Import an optional dependency or raise a clear, actionable error."""
    try:
        return __import__(module_name)
    except ImportError as e:
        raise MissingCliDependencyError(package) from e


def _find_free_port() -> int:
    """Ask the OS for an available localhost port instead of hardcoding one."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def google_login() -> tuple[Credentials, bool]:
    _require("google_auth_oauthlib", "google-auth-oauthlib")
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow

    if not isinstance(_USER, DataEncryptor):
        raise TypeError("Expected DataEncryptor instance")

    creds = None
    if "google_login_data" in _USER.data:
        creds = Credentials.from_authorized_user_info(
            json.loads(_USER.data["google_login_data"])
        )

    is_refreshed = False
    if creds is not None and not creds.valid:
        creds.refresh(Request())
        is_refreshed = True

    if creds is None or not creds.valid:
        is_refreshed = True
        flow = InstalledAppFlow.from_client_config(
            json.loads(read_resource_file("finlab.cli", "oauth_google.json")),
            scopes=[
                "https://www.googleapis.com/auth/userinfo.profile",
                "openid",
                "https://www.googleapis.com/auth/userinfo.email",
            ],
        )
        # port=0 lets the OAuth helper pick an available port dynamically.
        creds = flow.run_local_server(port=0)

    _USER.data["google_login_data"] = creds.to_json()
    _USER.to_file()

    return creds, is_refreshed


def get_user_data_path(user_folder: str) -> str:
    return os.path.join(user_folder, "finlab.userdata.txt")


def write_user_data(claims: dict[str, Any]) -> None:
    if _USER is None:
        raise RuntimeError("User data store is not initialized")
    _USER.data["firebase_login_data"] = claims
    _USER.to_file()


def read_user_data() -> dict[str, Any] | None:
    if _USER is None:
        return None
    if "firebase_login_data" in _USER.data:
        return _USER.data["firebase_login_data"]
    return None


def _create_app() -> Any:
    """Build the Flask app serving the Firebase sign-in bridge page."""
    _require("flask", "flask")
    from flask import Flask, jsonify, render_template_string, request

    app = Flask(__name__)

    @app.route("/")
    def index() -> str:
        return render_template_string(
            _LOGIN_HTML,
            firebase_config=json.dumps(firebase_config),
            google_token=google_token,
        )

    @app.route("/fetch-data", methods=["POST"])
    def fetch_data() -> Any:
        payload = request.json or {}
        firebase_token = payload.get("token")
        claims = payload.get("claims") or {}

        claims["google_token"] = google_token
        claims["firebase_token"] = firebase_token
        write_user_data(claims)

        global _login_completed
        _login_completed = True
        _terminate_webview()

        print("User login firebase successfully", file=sys.stderr)

        return jsonify({"message": "Data fetched successfully"})

    return app


def _terminate_webview() -> None:
    """Stop the helper webview subprocess, escalating to kill if needed."""
    global _webview_process
    proc = _webview_process
    _webview_process = None
    if proc is None or proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)


def _open_login_window(url: str) -> None:
    """Show the sign-in page in a hidden webview, or the browser as fallback."""
    global _webview_process

    if importlib.util.find_spec("webview") is not None:
        _webview_process = subprocess.Popen(
            [
                sys.executable,
                "-c",
                (
                    "import sys, webview\n"
                    "window = webview.create_window("
                    "'Authenticate Firebase', sys.argv[1], hidden=True)\n"
                    "webview.start()"
                ),
                url,
            ],
            env=os.environ.copy(),
        )
        return

    print(
        "pywebview is not installed; opening the sign-in page in your browser.",
        file=sys.stderr,
    )
    print(f"If the browser does not open, visit: {url}", file=sys.stderr)
    webbrowser.open(url)


def with_firebase_token(timeout: int = LOGIN_TIMEOUT_SECONDS) -> bool:
    """Run the local Flask bridge and wait for the Firebase sign-in.

    Returns True when the sign-in completed, False on timeout or if the
    sign-in window was closed. Never hangs forever: the helper webview
    subprocess is always cleaned up.
    """
    from threading import Thread

    global _login_completed
    _login_completed = False

    app = _create_app()

    log = logging.getLogger("werkzeug")
    log.disabled = True
    cli = cast("Any", sys.modules.get("flask.cli"))
    if cli is not None:
        cli.show_server_banner = lambda *x: None

    port = _find_free_port()
    server = Thread(
        target=app.run,
        kwargs={"port": port, "debug": False},
        daemon=True,
    )
    server.start()

    url = f"http://127.0.0.1:{port}"
    try:
        _open_login_window(url)

        deadline = time.time() + timeout
        while not _login_completed:
            if time.time() > deadline:
                print(
                    "Login timed out. Please try again, or report the issue "
                    "to FinLab if it persists.",
                    file=sys.stderr,
                )
                return False
            proc = _webview_process
            if proc is not None and proc.poll() is not None:
                print(
                    "The sign-in window closed before login completed.",
                    file=sys.stderr,
                )
                return False
            time.sleep(0.5)
        return True
    finally:
        _terminate_webview()


def _load_user_store(workspace: str) -> DataEncryptor:
    """Load the workspace credential store, recovering from corruption."""
    path = os.path.join(workspace, "user.txt")
    try:
        return DataEncryptor.from_file(path)
    except Exception as e:  # noqa: BLE001 - any decrypt/parse failure means corrupt
        logger.warning(
            "Local user data is corrupted or from another machine; starting fresh"
        )
        logger.debug("User data load failed: %s", e)
        return DataEncryptor({}, "", path)


def _login(workspace: str, update_firebase_token: bool = False) -> DataEncryptor:
    global _USER

    _USER = _load_user_store(workspace)
    if "firebase_login_data" not in _USER.data and "google_login_data" in _USER.data:
        del _USER.data["google_login_data"]
        _USER.to_file()

    google_credential, is_refreshed = google_login()

    global google_token
    google_token = None
    if is_refreshed or update_firebase_token:
        google_token = google_credential.id_token

    if google_token:
        old_stdout = sys.stdout  # backup current stdout
        try:
            with open(os.devnull, "w", encoding="utf-8") as devnull:
                sys.stdout = devnull
                with_firebase_token()
        finally:
            sys.stdout = old_stdout  # always reset stdout

    return _USER


def _logout(workspace: str) -> bool:
    """Clear stored login data. Safe to call when never logged in."""
    if not os.path.exists(os.path.join(workspace, "user.txt")):
        return True

    user = _load_user_store(workspace)
    user.data.pop("firebase_login_data", None)
    user.data.pop("google_login_data", None)
    user.to_file()
    return True


def set_token(workspace: str) -> None:
    user = _load_user_store(workspace)
    if "firebase_login_data" in user.data:
        os.environ["FINLAB_API_TOKEN"] = user.data["firebase_login_data"]["api_token"]


def register_auth_commands(click: Any, auth: Any, WORKSPACE_PATH: str) -> None:
    @auth.command()
    def login() -> None:
        """Login to FinLab."""
        if not os.path.exists(WORKSPACE_PATH):
            click.echo("Creating workspace...")
            # create folder
            Path(WORKSPACE_PATH).mkdir(parents=True, exist_ok=True)

        try:
            _login(WORKSPACE_PATH)
        except MissingCliDependencyError as e:
            click.echo(str(e), err=True)
            raise SystemExit(1) from e
        click.echo("Login successful")

    @auth.command()
    def logout() -> None:
        """Logout from FinLab."""
        _logout(WORKSPACE_PATH)
        click.echo("Logout successful")
