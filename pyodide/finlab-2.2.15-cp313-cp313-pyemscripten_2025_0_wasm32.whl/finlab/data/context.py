"""DataContext singleton and module-level state management."""

from __future__ import annotations

import contextlib
import gc
from typing import TYPE_CHECKING, TypeAlias

if TYPE_CHECKING:
    import weakref
    from collections.abc import Generator

    import pandas as pd

FinalizedCacheKey: TypeAlias = tuple[
    str,
    int,
    int,
    frozenset[str] | None,
    bool,
    str | None,
    str | None,
]
# The frame a result was finalized from, and the result.
FinalizedCacheEntry: TypeAlias = "tuple[weakref.ref[pd.DataFrame], pd.DataFrame]"

from .category_cache import clear_category_cache
from .storage import CacheStorage, FileStorage

# The role the signing service reports for an account without a subscription.
FREE_ROLE = "free"

__all__ = [
    "FREE_ROLE",
    "_CONTEXT_ATTRS",
    "DataContext",
    "_default_context",
    "clear",
    "free_memory",
    "set_storage",
]


# ---------------------------------------------------------------------------
# DataContext — encapsulates all module-level mutable state
# ---------------------------------------------------------------------------


class DataContext:
    """Holds all mutable state that was previously scattered as module globals.

    A module-level singleton ``_default_context`` is the active context.
    Use ``override()`` to temporarily change values in a ``with`` block.
    """

    def __init__(self) -> None:
        self._has_print_free_user_warning: bool = False
        self._has_shown_quota_warning: bool = False
        self._role: str | None = None
        self.use_local_data_only: bool = False
        self.force_cloud_download: bool = False
        self.truncate_start: str | None = None
        self.truncate_end: str | None = None
        self.prefer_local_if_exists: bool = False
        self._storage: CacheStorage | FileStorage = FileStorage()
        self._finalized_cache: dict[FinalizedCacheKey, FinalizedCacheEntry] = {}
        self._loaded_datasets: set[str] = set()
        # Versions already checked during one backtest, keyed by storage and dataset.
        self._backtest_cache_versions: dict[tuple[int, str], object] | None = None
        # (cache version, published expiry in epoch seconds) each loaded dataset
        # was read at; see Storage.cache_version().
        self._loaded_versions: dict[str, tuple[object, int]] = {}
        self._projected_datasets: set[str] = set()
        self._last_token_type: str | None = None
        self._current_market: str | None = None

    @contextlib.contextmanager
    def override(self, **kwargs: object) -> Generator[DataContext, None, None]:
        """Temporarily override context attributes, restoring on exit.

        Example::

            with _default_context.override(prefer_local_if_exists=True):
                ...
        """
        if "_loaded_datasets" in kwargs:
            # A report's private price fetches must not contaminate the caller's
            # loaded-data selection or the versions it read.
            kwargs.setdefault("_loaded_versions", dict(self._loaded_versions))
        if "_loaded_datasets" in kwargs and "_projected_datasets" not in kwargs:
            loaded = kwargs["_loaded_datasets"]
            if isinstance(loaded, set):
                # Nor erase existing projections.
                kwargs["_projected_datasets"] = self._projected_datasets.intersection(
                    loaded
                )
        saved = {k: getattr(self, k) for k in kwargs}
        for k, v in kwargs.items():
            setattr(self, k, v)
        try:
            yield self
        finally:
            for k, v in saved.items():
                setattr(self, k, v)


_default_context = DataContext()

# Names that are proxied through __getattr__ / __setattr__ to the singleton.
_CONTEXT_ATTRS: frozenset[str] = frozenset(
    {
        "_has_print_free_user_warning",
        "_has_shown_quota_warning",
        "_role",
        "use_local_data_only",
        "force_cloud_download",
        "truncate_start",
        "truncate_end",
        "prefer_local_if_exists",
        "_storage",
        "_finalized_cache",
        "_loaded_datasets",
        "_loaded_versions",
        "_projected_datasets",
        "_last_token_type",
        "_current_market",
    }
)


def __getattr__(name: str) -> object:
    """Module-level __getattr__ (PEP 562) — proxy context attrs to singleton.

    Needed for code that imports ``finlab.data.context`` directly.
    """
    if name in _CONTEXT_ATTRS:
        return getattr(_default_context, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def free_memory() -> None:
    """Release data caches in RAM, keeping disk files and context settings.

    ``CacheStorage`` has no disk copy, so its cached data is discarded and must
    be downloaded again. DataFrames still referenced by the caller are kept.
    This does not guarantee that the Python allocator returns RAM to the OS.
    """
    ctx = _default_context
    ctx._finalized_cache.clear()
    clear_category_cache()
    ctx._storage.release_memory()
    gc.collect()


def clear() -> None:
    """清除本地端儲存的歷史資料，並還原初始設定。
    Examples:
        ``` py
        from finlab import data
        data.clear()
        ```
    """
    ctx = _default_context
    clear_category_cache()
    ctx._loaded_datasets = set()
    ctx._loaded_versions = {}
    ctx._projected_datasets = set()
    if isinstance(ctx._storage, FileStorage):
        ctx._storage.clear()
    ctx._storage = FileStorage()


def set_storage(storage: CacheStorage | FileStorage) -> None:
    """設定本地端儲存歷史資料的方式
    假設使用 `data.get` 獲取歷史資料則，在預設情況下，程式會自動在本地複製一份，以避免重複下載大量數據。
    storage 就是用來儲存歷史資料的接口。我們提供兩種 `storage` 接口，分別是 `finlab.data.CacheStorage` 以及
    `finlab.data.FileStorage` (預設)。前者是直接存在記憶體中，後者是存在檔案中。詳情請參考 `CacheStorage` 和 `FileStorage` 來獲得更詳細的資訊，
    包括資料存放的資料夾與讀取方式。

    Args:
        storage (data.Storage): The interface of storage

    Examples:
        欲切換成以檔案方式儲存，可以用以下之方式：

        ``` py
        from finlab import data
        data.set_storage(data.FileStorage())
        close = data.get('price:收盤價')
        ```
    """

    clear_category_cache()
    _default_context._storage = storage
