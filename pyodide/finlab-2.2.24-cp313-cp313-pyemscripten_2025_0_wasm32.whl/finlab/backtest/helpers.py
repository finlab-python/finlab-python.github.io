"""Pure helper functions extracted from ``finlab.backtest``.

Every function in this module is a *pure* transformation: it takes explicit
inputs, returns explicit outputs, and has no side-effects (no network, no
module-level state, no mutation of inputs).  This makes them independently
testable offline.
"""

from __future__ import annotations

import functools
import numbers
import operator
import warnings
from typing import TYPE_CHECKING, TypeVar

import numpy as np
import pandas as pd

from finlab.compat import normalize_rebalance_frequency
from finlab.dataframe.parallel import inf_is_value

if TYPE_CHECKING:
    import datetime


# ---------------------------------------------------------------------------
# Stop / take-profit / trail-stop sentinel defaults
# ---------------------------------------------------------------------------


_T = TypeVar("_T")

# Engine thresholds that never trigger.
NO_STOP_LOSS = np.inf
NO_TAKE_PROFIT = np.inf


def _or_unset(value: _T | None, unset: float) -> _T | float:
    """Keep a DataFrame or a nonzero number; ``None`` and ``0`` mean unset."""
    if isinstance(value, pd.DataFrame) or (value is not None and value != 0):
        return value
    return unset


def resolve_stop_defaults(
    stop_loss: float | pd.DataFrame | None,
    take_profit: float | pd.DataFrame | None,
    trail_stop: float | None,
    trail_stop_activation: float | None = None,
) -> tuple[float | pd.DataFrame, float | pd.DataFrame, float, float]:
    """Map user-facing ``None`` / ``0`` sentinels to engine-safe defaults.

    The backtest engine uses ``inf`` for disabled stop-loss, take-profit
    and trail-stop thresholds (i.e. never triggers). DataFrame
    stops are kept; the engine resolves their cells once their dates are
    aligned.

    Returns:
        ``(stop_loss, take_profit, trail_stop, trail_stop_activation)`` with
        sentinels resolved.
    """
    return (
        _or_unset(stop_loss, NO_STOP_LOSS),
        _or_unset(take_profit, NO_TAKE_PROFIT),
        _or_unset(trail_stop, np.inf),
        _or_unset(trail_stop_activation, 0),
    )


# ---------------------------------------------------------------------------
# Position weight normalisation
# ---------------------------------------------------------------------------


def normalize_position_weights(
    position_values: np.ndarray,
    position_limit: float,
) -> np.ndarray:
    """Normalise position weights so that total absolute weight <= 1.

    Each row is independently scaled so that ``sum(|w|) <= 1``.  If
    ``position_limit < 1``, individual weights are further clipped.
    ``NaN`` weights mean "not held" and become ``0``. ``sim()`` never passes
    NaN (it fills once at input), but ``Position.from_weight`` forwards raw
    user weights and ``df.weight`` methods pass unknown weights as NaN.

    Args:
        position_values: 2-D float array of raw position weights
            (rows = dates, cols = assets).  **A copy is made internally;
            the caller's array is never mutated.**
        position_limit: Per-asset cap (0 < limit <= 1).

    Returns:
        New 2-D float array with normalised weights.
    """
    pos = position_values.astype(float, copy=True)
    pos[np.isnan(pos)] = 0
    total_weight = np.abs(pos).sum(axis=1)
    np.clip(total_weight, 1, None, out=total_weight)
    mask = total_weight != 0
    pos[mask] = pos[mask] / total_weight[mask, np.newaxis]
    pos[~mask] = 0
    if position_limit < 1:
        np.clip(pos, -abs(position_limit), abs(position_limit), out=pos)
    return pos


# ``infer_dtype`` kinds that become float. An all-missing ("empty") column
# carries no type, so it stays float NaN for the all-NaN position check.
_FLOAT_KINDS = frozenset(
    {"empty", "integer", "floating", "mixed-integer-float", "decimal"}
)
# Kinds that may mix numbers with non-numbers and need a per-value check.
_MIXED_KINDS = frozenset({"mixed", "mixed-integer"})
_MAX_REPORTED_COLUMNS = 5


def _is_real_number(value: object) -> bool:
    return isinstance(value, (numbers.Real, np.bool_))


def _holds_python_objects(dtype: object) -> bool:
    return pd.api.types.is_object_dtype(dtype) or isinstance(dtype, pd.StringDtype)


def _coerce_object_column(column: pd.Series) -> pd.Series | None:
    """Coerce one ``object`` column, or return ``None`` if it cannot be."""
    kind = pd.api.types.infer_dtype(column, skipna=True)
    if kind == "boolean":
        return column.astype("boolean").fillna(False).astype(bool)
    if kind in _FLOAT_KINDS or (
        kind in _MIXED_KINDS and column.dropna().map(_is_real_number).all()
    ):
        return pd.to_numeric(column).astype(float)
    return None


def _coerce_boolean_frame(position: pd.DataFrame) -> pd.DataFrame | None:
    """``_coerce_object_column`` on every column at once, for boolean sleeves.

    When every value of an all-``object`` frame is a boolean or missing, each
    column is boolean (missing read as not held) or, all missing, float NaN,
    which is what the per-column rule gives; None for any other frame.
    """
    values = position.to_numpy(dtype=object)
    if pd.api.types.infer_dtype(values.ravel(), skipna=True) != "boolean":
        return None
    missing = pd.isna(values)
    result = position._constructor(
        np.where(missing, False, values).astype(bool),
        index=position.index,
        columns=position.columns,
    ).__finalize__(position)
    for column in position.columns[missing.all(axis=0)]:
        result[column] = np.nan
    return result


def coerce_object_position(
    position: pd.DataFrame | pd.Series,
) -> pd.DataFrame | pd.Series:
    """Give ``object`` position columns the dtype their values imply.

    Merging boolean sleeves whose dates or assets differ leaves ``NaN`` in the
    unmatched cells, so pandas stores those columns as ``object``. Boolean
    columns become plain ``bool`` with missing values read as not held;
    numeric columns become ``float``. Frames without ``object`` or string
    columns are returned untouched.

    Raises:
        ValueError: If an ``object`` or string column holds values that are
            neither booleans nor numbers.
    """
    if isinstance(position, pd.Series):
        if not _holds_python_objects(position.dtype):
            return position
        coerced = {position.name: _coerce_object_column(position)}
    else:
        object_columns = position.columns[position.dtypes.map(_holds_python_objects)]
        if object_columns.empty:
            return position
        if len(object_columns) == len(position.columns) and position.columns.is_unique:
            boolean = _coerce_boolean_frame(position)
            if boolean is not None:
                return boolean
        coerced = {col: _coerce_object_column(position[col]) for col in object_columns}

    invalid = [str(col) for col, values in coerced.items() if values is None]
    if invalid:
        shown = ", ".join(invalid[:_MAX_REPORTED_COLUMNS])
        more = len(invalid) - _MAX_REPORTED_COLUMNS
        suffix = f" and {more} more" if more > 0 else ""
        raise ValueError(
            f"position columns {shown}{suffix} hold values that are neither "
            "booleans nor numbers. Positions must be True/False signals or "
            "numeric weights."
        )

    if isinstance(position, pd.Series):
        return coerced[position.name]
    result = position.copy()
    for col, values in coerced.items():
        result[col] = values
    return result


# ---------------------------------------------------------------------------
# Rebalance-schedule helpers
# ---------------------------------------------------------------------------


def filter_position_by_change(position: pd.DataFrame) -> pd.DataFrame:
    """Return rows of *position* where the allocation actually changed.

    Used when ``resample is None`` – only the first row and dates where the
    signal differs from the previous row are kept. Expects NaN-free input,
    which ``sim()`` guarantees by filling missing values at input.

    Args:
        position: A DataFrame with ``DatetimeIndex`` rows and asset columns.

    Returns:
        Filtered copy (subset of rows).
    """
    change = _rows_changed(position)
    change[:1] = True
    return position.loc[change]


def _rows_changed(position: pd.DataFrame) -> np.ndarray:
    """``position.diff().abs().sum(axis=1) != 0`` without pandas' object detour.

    pandas diffs a bool frame into ``object`` (xor) and then sums Python objects.
    In numpy: a bool row changed when any value differs; a number row when any
    difference is non-zero, NaN differences (``inf - inf``) being skipped by the
    sum just as here. Every term of that sum is non-negative, so a frame mixing
    bools and numbers changed where any of its dtypes did. Frames with other
    dtypes keep the pandas route.
    """
    dtypes = position.dtypes
    unique = dtypes.unique()
    if not inf_is_value() or not all(
        isinstance(d, np.dtype) and d.kind in "biuf" for d in unique
    ):
        return position.diff().abs().sum(axis=1).to_numpy() != 0
    changed = np.zeros(len(position), dtype=bool)
    for dtype in unique:
        same = position if len(unique) == 1 else position.loc[:, dtypes == dtype]
        values = same.to_numpy()
        if dtype.kind == "b":
            changed[1:] |= (values[1:] != values[:-1]).any(axis=1)
        else:
            with np.errstate(invalid="ignore", over="ignore"):
                step = values[1:] - values[:-1]
            changed[1:] |= ((step != 0) & ~np.isnan(step)).any(axis=1)
    return changed


def generate_string_rebalance_dates(
    position_start: pd.Timestamp | datetime.datetime,
    present_data_date: pd.Timestamp | datetime.datetime,
    price_end: pd.Timestamp | datetime.datetime,
    resample: str,
    resample_offset: str | None,
    tz: object | None,
) -> list[pd.Timestamp]:
    """Build a list of rebalance timestamps from a frequency string.

    Handles pandas 2.2+ offset name changes (``"M"`` -> ``"ME"``),
    in-string ``+N`` / ``-N`` day offsets, and the optional
    ``resample_offset``.

    Args:
        position_start: Earliest date in the position DataFrame.
        present_data_date: Latest relevant date for filtering.
        price_end: Last date in the price DataFrame.
        resample: Frequency string (e.g. ``"M"``, ``"W-Fri"``).
        resample_offset: Additional pandas offset string (e.g. ``"1D"``).
        tz: Timezone for ``pd.date_range``.

    Returns:
        Ordered list of ``pd.Timestamp`` rebalance dates.
    """
    import datetime as _dt

    from pandas.tseries.frequencies import to_offset
    from pandas.tseries.offsets import DateOffset

    resample = normalize_rebalance_frequency(resample)

    # Pandas now expects weekly weekday suffixes in uppercase, e.g. W-SUN.
    if resample.startswith("W-"):
        head, tail = resample.split("-", 1)
        resample = f"{head}-{tail.upper()}"

    offset_days = 0
    if "+" in resample:
        resample, offset_str = resample.rsplit("+", 1)
        offset_days = int(offset_str)
    elif "-" in resample:
        parts = resample.rsplit("-", 1)
        if parts[-1].isdigit():
            resample = parts[0]
            offset_days = -int(parts[-1])

    alldates = pd.date_range(
        position_start,
        present_data_date + _dt.timedelta(days=360),
        freq=resample,
        tz=tz,
    )
    alldates += DateOffset(days=offset_days)

    if resample_offset is not None:
        alldates += to_offset(resample_offset)

    dates = [d for d in alldates if position_start <= d <= present_data_date]

    if price_end > dates[-1]:
        remain = set(alldates) - set(dates)
        if remain:
            dates.append(min(remain))

    return dates


# ---------------------------------------------------------------------------
# MAE / MFE column construction
# ---------------------------------------------------------------------------

_MAE_MFE_METRICS = ("mae", "gmfe", "bmfe", "mdd", "pdays", "return")


def build_mae_mfe_columns(
    n_columns: int,
    window_step: int,
) -> pd.MultiIndex:
    """Build the ``(window, metric)`` MultiIndex for an MAE/MFE DataFrame.

    The raw Cython core returns a flat array of columns.  This function
    computes the structured column index from the number of flat columns
    and the window step size.

    Args:
        n_columns: Total number of flat columns in the raw data.
        window_step: Step between consecutive windows.

    Returns:
        ``pd.MultiIndex`` with levels ``["window", "metric"]``.
    """
    nsets = int((n_columns - 1) / 6)

    tuples: list[tuple[int | str, str]] = functools.reduce(
        operator.iadd,
        [
            [
                (n, metric) if n == "exit" else (n * window_step, metric)
                for metric in _MAE_MFE_METRICS
            ]
            for n in [*range(nsets), "exit"]
        ],
        [],
    )

    return pd.MultiIndex.from_tuples(tuples, names=["window", "metric"])


def clip_mae_mfe_exit(
    exit_data: pd.DataFrame,
    stop_loss: float | np.ndarray,
    take_profit: float | np.ndarray,
) -> pd.DataFrame:
    """Clip MAE/MFE exit-window metrics to stop/take-profit bounds.

    Only the ``gmfe``, ``bmfe``, ``mae``, and ``mdd`` columns are clipped;
    other columns are left unchanged.

    Args:
        exit_data: DataFrame with columns ``gmfe``, ``bmfe``, ``mae``,
            ``mdd`` (and possibly others like ``pdays``, ``return``).
        stop_loss: Stop-loss threshold, or one per row of ``exit_data``.
        take_profit: Take-profit threshold, or one per row of ``exit_data``.

    Returns:
        New DataFrame with clipped values.
    """
    lo = -np.abs(stop_loss)
    hi = np.abs(take_profit)
    return (
        exit_data.assign(gmfe=exit_data.gmfe.clip(lo, hi))
        .assign(bmfe=exit_data.bmfe.clip(lo, hi))
        .assign(mae=exit_data.mae.clip(lo, hi))
        .assign(mdd=exit_data.mdd.clip(lo, hi))
    )


# ---------------------------------------------------------------------------
# Position-column overlap validation
# ---------------------------------------------------------------------------

MAX_LISTED_UNPRICED_COLUMNS = 10
# A data universe wider than the market (monthly revenue lists OTC companies)
# drops a few picks; only a larger share changes what the backtest measures.
MAX_UNPRICED_WEIGHT_SHARE = 0.1


def validate_position_columns(
    position: pd.DataFrame,
    price_columns: pd.Index,
) -> pd.Index:
    """Intersect position columns with price columns and warn on dropped weight.

    Columns without prices are left out of the backtest. When they hold more
    than ``MAX_UNPRICED_WEIGHT_SHARE`` of the position's weight, the held ones
    are listed in a ``UserWarning``.

    Args:
        position: Position DataFrame; NaN reads as no weight.
        price_columns: Column index from the price DataFrame.

    Returns:
        The matched columns, in position order.

    Raises:
        ValueError: If none of the position columns match.
    """
    priced = position.columns.isin(price_columns)
    matched = position.columns[priced]
    if priced.all():
        return matched

    if matched.empty:
        raise ValueError(
            f"No position columns match the market price columns "
            f"(0 out of {len(position.columns)} matched). "
            f"Check that the position data source matches the market's price data."
        )

    weights = position.abs().sum().astype(float)
    unpriced = weights[~priced]
    dropped, total = unpriced.sum(), weights.sum()
    if dropped > MAX_UNPRICED_WEIGHT_SHARE * total:
        held = unpriced.index[unpriced > 0]
        listed = held[:MAX_LISTED_UNPRICED_COLUMNS].tolist()
        more = len(held) - len(listed)
        warnings.warn(
            f"{dropped / total:.0%} of the position weight has no market "
            f"price and is dropped from the backtest: "
            f"{listed}{f' and {more} more' if more else ''}. "
            f"Backtest them with a market whose prices include them.",
            stacklevel=2,
        )

    return matched
