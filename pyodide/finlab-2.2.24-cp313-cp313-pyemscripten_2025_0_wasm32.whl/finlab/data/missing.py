"""Explain ``data.get()`` misses: equivalent-key redirects, did-you-mean hints
and VIP-only refusals."""

from __future__ import annotations

from typing import Final

from finlab.exceptions import DatasetNotFoundError

from .auth import _PAYMENT_URL, _PAYMENT_URL_EN
from .catalog import KeyAlias, find_key_alias, is_vip_only, suggest_similar_keys

# Prefix of the per-dataset metadata error for keys that have no stored file.
_NOT_FOUND_ERROR_PREFIX: Final = "Cannot find data"
_SEARCH_HINT: Final = "可用 data.search('關鍵字') 查詢可用的資料集。 / Use data.search('keyword') to find available datasets."
# Signing-service refusals for datasets the account's plan cannot download.
_VIP_ONLY_ERROR_MARKERS: Final = (
    "is only for VIP",
    "Permission denied. Please upgrade to VIP",
)
_VIP_LABEL: Final = "VIP 付費方案 / VIP paid plan"


def is_not_found_error(error: str) -> bool:
    """Whether a metadata error means the dataset key does not exist."""
    return error.startswith(_NOT_FOUND_ERROR_PREFIX)


def is_vip_only_error(error: str) -> bool:
    """Whether a metadata error means the account's plan cannot download it."""
    return any(marker in error for marker in _VIP_ONLY_ERROR_MARKERS)


def vip_only_error(dataset: str) -> RuntimeError:
    """Build the user-facing error for a VIP-only dataset refused to a free account."""
    return RuntimeError(
        f"{dataset} 是 VIP 付費方案的資料集，免費帳號（含試用期已結束）無法下載"
        f"（Dataset is only for VIP: {dataset}）。\n"
        f"訂閱方案：{_PAYMENT_URL}\n"
        "可用 data.search('關鍵字', details=True) 查看各資料集的權限。\n"
        "Free accounts, including expired trials, cannot download this VIP-only dataset.\n"
        f"Subscribe: {_PAYMENT_URL_EN}\n"
        "Use data.search('keyword', details=True) to check dataset permissions."
    )


def equivalent_key_alias(dataset: str) -> KeyAlias | None:
    """Return the alias entry when ``dataset`` is a published equivalent key."""
    key_alias = find_key_alias(dataset)
    return key_alias if key_alias is not None and key_alias.is_equivalent else None


def redirect_warning_message(key_alias: KeyAlias) -> str:
    """Warning shown when ``data.get`` fetches the equivalent target instead."""
    message = (
        f"找不到 {key_alias.alias}，已自動改用相同資料 {key_alias.target}。"
        f"請改寫為 data.get('{key_alias.target}')。\n"
        f"Cannot find {key_alias.alias}; using equivalent data {key_alias.target}. "
        f"Update your code to data.get('{key_alias.target}')."
    )
    return f"{message}{key_alias.note}" if key_alias.note else message


def dataset_not_found_error(dataset: str) -> DatasetNotFoundError:
    """Build the user-facing error for a missing dataset key."""
    key_alias = find_key_alias(dataset)
    related_notes: dict[str, str] = {}
    if key_alias is not None:
        related_notes[key_alias.target] = key_alias.note
    suggestions = tuple(dict.fromkeys([*related_notes, *suggest_similar_keys(dataset)]))

    lines = [f"找不到 {dataset}（Cannot find data: {dataset}）。"]
    if suggestions:
        lines.append("您是不是要找 / Did you mean:")
        for key in suggestions:
            vip_label = _VIP_LABEL if is_vip_only(key) else ""
            label = "；".join(filter(None, (related_notes.get(key), vip_label)))
            lines.append(f"  - {key}（{label}）" if label else f"  - {key}")
    lines.append(_SEARCH_HINT)
    return DatasetNotFoundError(dataset, "\n".join(lines), suggestions)
