"""Local, opt-in snapshots of the inputs returned by get/gets."""

from __future__ import annotations

import functools
import inspect
import json
import platform
import threading
from contextlib import contextmanager
from importlib.metadata import version
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator, Mapping

import pandas as pd

_active: _Snapshot | None = None
_session_lock = threading.Lock()


def _environment() -> dict[str, str]:
    return {
        "python": platform.python_version(),
        **{name: version(name) for name in ("finlab", "pandas", "numpy", "pyarrow")},
    }


def _key(dataset: str, options: Mapping[str, Any]) -> str:
    from .context import _default_context as ctx
    from .intraday import is_intraday
    from .universe import (
        _membership_read,
        _whitelist_active,
        not_available_universe_stocks,
        universe_stocks,
    )

    selection = {
        name: options.get(name) for name in ("start", "end", "as_of", "version")
    }
    filtering = not (
        _membership_read.get()
        or is_intraday(dataset)
        or dataset in not_available_universe_stocks
        or dataset.split(":", 1)[0] in not_available_universe_stocks
    )
    selection.update(
        market=ctx._current_market,
        truncate_start=ctx.truncate_start,
        truncate_end=ctx.truncate_end,
        stocks=sorted(universe_stocks) if filtering else [],
        whitelist=_whitelist_active if filtering else False,
    )
    return json.dumps(
        {"dataset": dataset, "selection": selection},
        sort_keys=True,
        ensure_ascii=False,
        default=lambda value: {
            "type": f"{type(value).__module__}.{type(value).__qualname__}",
            "value": str(value),
        },
    )


class _Snapshot:
    def __init__(self, path: str | Path, mode: str) -> None:
        self.path, self.mode = Path(path).resolve(), mode
        self.entries: dict[str, str] = {}
        self.failure: ValueError | None = None
        self.lock = threading.RLock()
        self.environment = _environment()
        if mode == "record":
            self.path.mkdir(parents=True, exist_ok=False)
        else:
            manifest = json.loads(
                (self.path / "manifest.json").read_text(encoding="utf-8")
            )
            if (
                manifest["schema_version"] != 1
                or manifest["environment"] != self.environment
            ):
                raise ValueError(
                    "Snapshot requires the same Python and package versions recorded in manifest.json"
                )
            self.entries = manifest["inputs"]

    def read(self, key: str) -> pd.DataFrame:
        try:
            return pd.read_pickle(self.path / self.entries[key])
        except Exception as exc:
            self.failure = ValueError(
                f"Snapshot input unavailable: {key}. Record the complete strategy in a new snapshot directory."
            )
            raise self.failure from exc

    def save(self, key: str, frame: pd.DataFrame) -> None:
        with self.lock:
            if key not in self.entries:
                filename = f"input-{len(self.entries)}.pkl"
                frame.to_pickle(self.path / filename)
                self.entries[key] = filename
                return
            saved = self.read(key)
            if not saved.equals(frame) or saved.attrs != frame.attrs:
                self.failure = ValueError(
                    f"Snapshot input changed during recording: {key}. Run again in a new directory."
                )
                raise self.failure


def _snapshot_read(fn: Callable[..., Any]) -> Callable[..., Any]:
    signature = inspect.signature(fn)
    batch = fn.__name__ == "gets"

    @functools.wraps(fn)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        state = _active
        if state is None:
            return fn(*args, **kwargs)
        bound = signature.bind(*args, **kwargs)
        bound.apply_defaults()
        datasets = (
            bound.arguments["datasets"] if batch else [bound.arguments["dataset"]]
        )
        from .intraday import is_intraday

        if any(is_intraday(dataset) for dataset in datasets) and (
            batch
            or bound.arguments["lazy"]
            or bound.arguments["progress"] != "silent"
            or bound.arguments["progress_callback"] is not None
            or bound.arguments.get("as_of") is not None
            or bound.arguments.get("version") is not None
        ):
            # Keep the existing rejection before any quota-counted transport.
            return fn(*args, **kwargs)
        keys = [_key(dataset, bound.arguments) for dataset in datasets]
        lazy = bound.arguments["lazy"]
        bound.arguments["lazy"] = False
        if state.mode == "replay":
            frames = tuple(state.read(key) for key in keys)
            from .context import _default_context as ctx

            ctx._loaded_datasets.update(datasets)
            ctx._projected_datasets.update(datasets)
        else:
            try:
                result = fn(*bound.args, **bound.kwargs)
                frames = result if batch else (result,)
                for key, frame in zip(keys, frames, strict=True):
                    state.save(key, frame)
            except Exception:
                state.failure = ValueError(
                    f"Snapshot recording failed for {', '.join(datasets)}. Run again in a new directory."
                )
                raise
        if lazy:
            frames = tuple(frame.lazy() for frame in frames)
        return frames if batch else frames[0]

    return wrapped


@contextmanager
def snapshot(path: str | Path, *, mode: str = "record") -> Iterator[Path]:
    """Save or strictly replay every get/gets input inside this block, including sim.

    ``record`` requires a new directory and commits manifest.json only after a
    successful block. ``replay`` reads only these trusted local pickle files;
    missing inputs, changed selections or environment versions raise an error.
    Wrap the entire strategy, sim(upload=False), and report computations; keep
    the code, parameters, explicit end_date and environment separately. Inputs
    fetched before this block and custom external sources are not captured.
    All threads in this Python process participate; finish their work before
    leaving the block. Only one snapshot may be active at a time.
    """
    from .category_cache import clear_category_cache
    from .context import _default_context as ctx

    global _active

    if mode not in {"record", "replay"}:
        raise ValueError("snapshot mode must be 'record' or 'replay'")
    with _session_lock:
        if _active is not None:
            raise ValueError(
                "Only one data.snapshot block may be active per Python process"
            )
        state = _Snapshot(path, mode)
        _active = state
    clear_category_cache()
    settings: dict[str, Any] = {
        "_loaded_datasets": set(),
        "_loaded_versions": {},
        "_projected_datasets": set(),
        "_finalized_cache": {},
    }
    if mode == "replay":
        settings.update(use_local_data_only=True, force_cloud_download=False)
    try:
        with ctx.override(**settings):
            yield state.path
        if state.failure is not None:
            raise state.failure
        if mode == "record":
            (state.path / "manifest.json").write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "environment": state.environment,
                        "inputs": state.entries,
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
    finally:
        with _session_lock:
            _active = None
        clear_category_cache()
