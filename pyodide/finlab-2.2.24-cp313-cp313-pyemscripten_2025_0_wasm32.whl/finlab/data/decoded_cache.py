"""Decoded copies of wide cached tables, read back with one sequential read.

A cached Feather is compressed column by column, so every ``data.get`` pays for
decompressing it and assembling thousands of Arrow columns into one pandas
block. Beside a wide table (an optional ``date`` column plus columns that all
share one numeric or datetime dtype) this keeps that block as pandas holds it,
cut into ranges of columns that are lz4-compressed separately, so reading it
back is one sequential read and a decompression spread over all cores.

The copy is derived data. It names the Feather it was decoded from (inode,
mtime, size) and the pandas and pyarrow that decoded it; with any of them
changed it is ignored and written again on the next read.

File layout: ``MAGIC``, the source identity (three int64), the length of a JSON
header, the header, padding to ``ALIGNMENT``, the ``date`` values as int64 if
present, then the compressed column ranges of the block (one row per value
column) back to back, as listed in the header.
"""

from __future__ import annotations

import contextlib
import json
import os
import struct
from typing import TYPE_CHECKING, Final

import lz4.block
import numpy as np
import pandas as pd
import pyarrow as pa

from finlab.threads import for_each_range
from finlab.utils import atomic_replace

if TYPE_CHECKING:
    import io

SUFFIX: Final = ".decoded"
MAGIC: Final = b"FLDECOD4"
# Uncompressed bytes per compressed range: enough ranges to keep every core busy.
CHUNK_BYTES: Final = 1 << 20
_IDENTITY: Final = struct.Struct("<3q")
_HEADER_LENGTH: Final = struct.Struct("<q")
_IDENTITY_OFFSET: Final = len(MAGIC)
_PREFIX: Final = len(MAGIC) + _IDENTITY.size + _HEADER_LENGTH.size
ALIGNMENT: Final = 64
DATE_COLUMN: Final = "date"


def _settings() -> dict:
    """What decoding depends on besides the bytes: the libraries, and the pandas
    options that pick string dtypes (a process may set them differently)."""
    from finlab.dataframe.parallel import pandas_option

    settings = {"pandas": pd.__version__, "pyarrow": pa.__version__}
    for name in ("future.infer_string", "mode.string_storage", "mode.data_manager"):
        settings[name] = pandas_option(name)
    return settings


def _layout(frame: pd.DataFrame) -> dict | None:
    """The header describing *frame*, or None when it is not a wide table."""
    columns = frame.columns
    index = frame.index
    if (
        frame.attrs
        or not isinstance(index, pd.RangeIndex)
        or index.start != 0
        or index.step != 1
        or index.name is not None
        or isinstance(columns, pd.MultiIndex)
        or not columns.is_unique
        or not all(isinstance(label, str) for label in columns)
    ):
        return None
    dtypes = frame.dtypes
    date = None
    if DATE_COLUMN in columns:
        date_dtype = dtypes[DATE_COLUMN]
        date = {"position": columns.get_loc(DATE_COLUMN), "dtype": str(date_dtype)}
        if not (isinstance(date_dtype, np.dtype) and date_dtype.kind == "M"):
            # Period labels such as 2013-Q1 are few; they travel in the header.
            labels = frame[DATE_COLUMN].tolist()
            if not (
                pd.api.types.is_string_dtype(date_dtype)
                and all(isinstance(label, str) for label in labels)
            ):
                return None
            date["labels"] = labels
        dtypes = dtypes.drop(DATE_COLUMN)
    if dtypes.empty:
        return None
    dtype = dtypes.iloc[0]
    if (
        not (isinstance(dtype, np.dtype) and dtype.kind in "biufM")
        or not (dtypes == dtype).all()
    ):
        return None
    return {
        **_settings(),
        "rows": len(frame),
        "dtype": str(dtype),
        "date": date,
        "labels": columns.tolist(),
        "columns_dtype": str(columns.dtype),
        "columns_name": columns.name,
    }


def _value_labels(layout: dict) -> list[str]:
    labels = layout["labels"]
    return (
        labels
        if layout["date"] is None
        else [label for label in labels if label != DATE_COLUMN]
    )


def _rebuild(layout: dict, dates: np.ndarray | None, block: np.ndarray) -> pd.DataFrame:
    labels = layout["labels"]
    date = layout["date"]
    if dates is not None and layout.get("date_in_block"):
        # A date column of the values' dtype shares their block.
        position = date["position"]
        block = np.insert(block, position, dates.view(block.dtype), axis=0)
        frame = pd.DataFrame(block.T, copy=False)
    else:
        frame = pd.DataFrame(block.T, columns=_value_labels(layout), copy=False)
        if dates is not None:
            frame.insert(date["position"], DATE_COLUMN, dates.view(date["dtype"]))
        elif date is not None:
            periods = pd.array(date["labels"], dtype=date["dtype"])
            frame.insert(date["position"], DATE_COLUMN, periods)
    frame.columns = pd.Index(
        labels, dtype=layout["columns_dtype"], name=layout["columns_name"]
    )
    return frame


def _blocks(frame: pd.DataFrame) -> list[tuple[list[int], str, bool | None]] | None:
    """Each block's columns, dtype and memory order: what reductions iterate over.

    Extension arrays without a memory order (Arrow strings) have None.
    """
    try:
        return sorted(
            (
                block.mgr_locs.as_array.tolist(),
                str(block.dtype),
                _c_order(getattr(block.values, "_ndarray", block.values)),
            )
            for block in frame._mgr.blocks
        )
    except AttributeError:  # another pandas' internals
        return None


def _c_order(values: object) -> bool | None:
    flags = getattr(values, "flags", None)
    return None if flags is None else flags.c_contiguous


def write(source: str, identity: tuple[int, int, int], frame: pd.DataFrame) -> None:
    """Keep *frame*, just read from *source*, decoded; skipped unless it is wide."""
    layout = _layout(frame)
    # Windows can number files beyond the header's 64 bits; such files stay Feather-only.
    if layout is None or not all(-(1 << 63) <= part < 1 << 63 for part in identity):
        return
    values = frame[_value_labels(layout)].to_numpy(dtype=layout["dtype"])
    block = np.ascontiguousarray(values.T)
    dates = None
    if layout["date"] is not None and "labels" not in layout["date"]:
        dates = np.ascontiguousarray(frame[DATE_COLUMN].to_numpy().view(np.int64))
    # Only a frame rebuilt with the very same labels, dtypes and blocks is worth
    # keeping; pandas 2 reads a date column of the values' dtype into their block.
    blocks = _blocks(frame)
    date = layout["date"]
    shares_block = date is not None and date["dtype"] == layout["dtype"]
    for layout["date_in_block"] in (False, True) if shares_block else (False,):
        rebuilt = _rebuild(layout, dates, block)
        if (
            blocks is not None
            and rebuilt.columns.equals(frame.columns)
            and rebuilt.columns.dtype == frame.columns.dtype
            and rebuilt.dtypes.equals(frame.dtypes)
            and _blocks(rebuilt) == blocks
        ):
            break
    else:
        return
    layout["chunks"] = _compress(block)
    payload = [chunk.pop() for chunk in layout["chunks"]]
    header = json.dumps(layout, ensure_ascii=False).encode()
    padding = -(_PREFIX + len(header)) % ALIGNMENT

    def write_file(tmp_path: str) -> None:
        with open(tmp_path, "wb") as f:
            f.write(
                MAGIC + _IDENTITY.pack(*identity) + _HEADER_LENGTH.pack(len(header))
            )
            f.write(header + b"\0" * padding)
            if dates is not None:
                f.write(_bytes(dates))
            f.writelines(payload)

    # Failing to keep it only costs decoding the Feather again next time.
    with contextlib.suppress(OSError):
        atomic_replace(source + SUFFIX, write_file)


def read(source: str, identity: tuple[int, int, int]) -> pd.DataFrame | None:
    """*source*'s table from its decoded copy, if that copy is of these very bytes."""
    try:
        with open(source + SUFFIX, "rb") as f:
            prefix = f.read(_PREFIX)
            if (
                len(prefix) != _PREFIX
                or not prefix.startswith(MAGIC)
                or _IDENTITY.unpack_from(prefix, _IDENTITY_OFFSET) != identity
            ):
                return None
            (length,) = _HEADER_LENGTH.unpack_from(
                prefix, _PREFIX - _HEADER_LENGTH.size
            )
            layout = json.loads(f.read(length))
            if any(layout.get(name) != value for name, value in _settings().items()):
                return None
            f.seek(-(_PREFIX + length) % ALIGNMENT, os.SEEK_CUR)
            rows = layout["rows"]
            dates = None
            if layout["date"] is not None and "labels" not in layout["date"]:
                dates = np.empty(rows, dtype=np.int64)
                _fill(f, dates)
            block = np.empty((len(_value_labels(layout)), rows), dtype=layout["dtype"])
            chunks = layout["chunks"]
            payload = f.read(sum(length for *_, length in chunks))
        _decompress(block, chunks, payload)
    except (OSError, ValueError, KeyError, TypeError, lz4.block.LZ4BlockError):
        return None
    return _rebuild(layout, dates, block)


def _compress(block: np.ndarray) -> list[list]:
    """``[first column, stop column, compressed length, bytes]`` per range of columns."""
    columns = len(block)
    ranges = min(columns, -(-block.nbytes // CHUNK_BYTES)) if block.nbytes else 0
    bounds = np.linspace(0, columns, ranges + 1).astype(int).tolist()
    chunks: list[list] = [[] for _ in range(ranges)]

    def run(first: int, stop: int) -> None:
        for i in range(first, stop):
            data = lz4.block.compress(
                _bytes(block[bounds[i] : bounds[i + 1]]), store_size=False
            )
            chunks[i] = [bounds[i], bounds[i + 1], len(data), data]

    for_each_range(ranges, block.size, run)
    return chunks


def _decompress(block: np.ndarray, chunks: list[list], payload: bytes) -> None:
    offsets = np.cumsum([0] + [length for *_, length in chunks]).tolist()
    if offsets[-1] != len(payload):
        raise ValueError("decoded copy is truncated")
    view = memoryview(payload)

    def run(first: int, stop: int) -> None:
        for i in range(first, stop):
            start, end, _ = chunks[i]
            target = _bytes(block[start:end])
            data = lz4.block.decompress(
                view[offsets[i] : offsets[i + 1]], uncompressed_size=len(target)
            )
            target[:] = data

    for_each_range(len(chunks), block.size, run)


def _bytes(array: np.ndarray) -> memoryview:
    """The raw bytes of a C-contiguous array, whatever its dtype (datetimes included)."""
    return array.reshape(-1).view(np.uint8).data


def _fill(f: io.BufferedReader, array: np.ndarray) -> None:
    view = _bytes(array)
    if f.readinto(view) != len(view):
        raise ValueError("decoded copy is truncated")


def redate(
    source: str, previous: tuple[int, int, int], identity: tuple[int, int, int]
) -> None:
    """Follow *source* being re-dated in place, so its decoded copy stays valid."""
    with contextlib.suppress(OSError), open(source + SUFFIX, "r+b") as f:
        prefix = f.read(_PREFIX)
        if (
            prefix.startswith(MAGIC)
            and _IDENTITY.unpack_from(prefix, _IDENTITY_OFFSET) == previous
        ):
            f.seek(_IDENTITY_OFFSET)
            f.write(_IDENTITY.pack(*identity))
