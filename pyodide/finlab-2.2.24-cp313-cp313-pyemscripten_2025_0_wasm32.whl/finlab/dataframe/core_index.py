"""Index conversion mixin for FinlabDataFrame.

Handles conversion between string-format financial indices (e.g. '2022-Q1',
'2022-M01') and datetime indices, including business-day alignment and
disclosure-date lookups.
"""

from __future__ import annotations

import datetime
import warnings
from typing import TYPE_CHECKING, Literal

import numpy as np
import pandas as pd

from finlab.compat import CANONICAL_NAME

if TYPE_CHECKING:
    from collections.abc import Iterable

    from finlab.dataframe.core import FinlabDataFrame


class IndexConversionMixin:
    """Methods for converting FinlabDataFrame indices between str and datetime."""

    def index_str_to_date(self: FinlabDataFrame) -> FinlabDataFrame:  # type: ignore[misc]
        """財務月季報索引格式轉換

        將以下資料的索引轉換成datetime格式:

        財務季報 (ex:2022-Q1) 從文字格式轉為財報電子檔資料上傳日。

        通常使用情境為對不同週期的dataframe做reindex，常用於以公告截止日作為訊號產生日。

        台股股票連續 20 個交易日沒有股價（與回測判定下市同一條規則），而且下一季的公告期限已過，
        就不再沿用舊季的值，復牌當天恢復。

        Returns:
          (pd.DataFrame): data

        Examples:
            ```py
            data.get('financial_statement:現金及約當現金').index_str_to_date()
            ```
        """
        if len(self.index) == 0 or not isinstance(self.index[0], str):
            return self

        if self.index[0].find("M") != -1:
            return self._index_str_to_date_month()
        if self.index[0].find("Q") != -1:
            return _route_season_market(self)

        return self

    @staticmethod
    def to_business_day(
        date: Iterable[datetime.date | pd.Timestamp],
        close: pd.DataFrame | None = None,
    ) -> np.ndarray:
        def skip_weekend(d: datetime.date) -> datetime.date:
            add_days = {5: 2, 6: 1}
            wd = d.weekday()
            if wd in add_days:
                d += datetime.timedelta(days=add_days[wd])
            return d

        if close is None:
            from finlab import data

            close = data.get("price:收盤價")

        trading = close.index
        if (
            isinstance(date, pd.DatetimeIndex)
            and date.dtype
            == np.dtype("datetime64[ns]")  # other units: Series infers its own
            and isinstance(trading, pd.DatetimeIndex)
            and date.dtype == trading.dtype
            and len(trading)
            and trading.is_monotonic_increasing
        ):
            # A date inside the trading calendar moves to the first trading day on
            # or after it; one outside it only skips a weekend.
            inside = (date >= trading[0]) & (date <= trading[-1])
            moved = date.to_numpy().copy()
            moved[inside] = trading.to_numpy()[trading.searchsorted(date[inside])]
            outside = np.flatnonzero(~inside)
            moved[outside] = [skip_weekend(d) for d in date[outside]]
            return moved

        return (
            pd.Series(date)
            .apply(
                lambda d: (
                    d
                    if d in close.index
                    else skip_weekend(d)
                    if d < close.index[0] or d > close.index[-1]
                    else close.loc[d:].index[0]
                )
            )
            .values
        )

    def _index_date_to_str_month(self: FinlabDataFrame) -> FinlabDataFrame:  # type: ignore[misc]
        from finlab.dataframe.core import FinlabDataFrame as FDF

        if len(self.index) == 0 or not isinstance(self.index[0], pd.Timestamp):
            return self

        index = (self.index - datetime.timedelta(days=30)).strftime("%Y-M%m")
        return FDF(self.values, index=index, columns=self.columns)

    def _index_str_to_date_month(self: FinlabDataFrame) -> FinlabDataFrame:  # type: ignore[misc]
        return self

    def _index_to_business_day(self: FinlabDataFrame) -> FinlabDataFrame:  # type: ignore[misc]
        from finlab.dataframe.core import FinlabDataFrame as FDF

        index = self.to_business_day(self.index)
        ret = FDF(self.values, index=index, columns=self.columns)
        ret.index.name = "date"
        return ret

    def _index_date_to_str_season(  # type: ignore[misc]
        self: FinlabDataFrame, postfix: str = ""
    ) -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame as FDF

        if len(self.index) == 0 or not isinstance(self.index[0], pd.Timestamp):
            return self

        if not isinstance(self.index, pd.DatetimeIndex):
            raise TypeError("Index must be a pd.DatetimeIndex")

        year = self.index.year.copy()
        if postfix:
            q = self.index.strftime("%m").astype(int).map({3: 1, 6: 2, 9: 3, 12: 4})
        else:
            q = (
                self.index.strftime("%m")
                .astype(int)
                .map({5: 1, 8: 2, 9: 2, 10: 3, 11: 3, 3: 4, 4: 4})
            )
            year -= q == 4
        index = year.astype(str) + f"{postfix}-Q" + q.astype(str)
        return FDF(self.values, index=index, columns=self.columns)

    def deadline(self: FinlabDataFrame) -> FinlabDataFrame:  # type: ignore[misc]
        """財務索引轉換成公告截止日

        將財務季報 (ex:2022Q1) 從文字格式轉為公告截止日的datetime格式，
        通常使用情境為對不同週期的dataframe做reindex，常用於以公告截止日作為訊號產生日。
        晚於截止日才公告的財報改用實際公告日，不會在公告前出現；下市股票同 `index_str_to_date()`。
        Returns:
          (pd.DataFrame): data
        Examples:
            ```py
            data.get('financial_statement:現金及約當現金').deadline()
            data.get('monthly_revenue:當月營收').deadline()
            ```
        """
        if len(self.index) == 0 or not isinstance(self.index[0], str):
            return self

        if self.index[0].find("M") != -1:
            return self._index_str_to_date_month()
        if self.index[0].find("Q") != -1:
            return _route_season_market(self, detail=False)

        raise ValueError(
            "Cannot apply deadline to dataframe. "
            "Index is not compatible. "
            "Index should be 2013-Q1 or 2013-M1."
        )

    def _index_str_to_date_season(  # type: ignore[misc]
        self: FinlabDataFrame,
        detail: bool = True,
        market: Literal[
            "hk_stock",
            "jp_stock",
            "kr_stock",
            "tw_stock",
            "uk_stock",
            "us_stock",
            "us_stock_all",
        ] = "tw_stock",
    ) -> FinlabDataFrame:
        from finlab import data
        from finlab.dataframe.core import FinlabDataFrame as FDF

        # Fiscal tables publish no deadlines; use their own disclosure dates.
        if fiscal_table := _fiscal_datekey_table(self.index[0]):
            datekey = data.get(f"{fiscal_table}:key_date")
            detail = True
        else:
            datekey = (
                _fetch_datekey(market, detail, self)
                if not detail
                else _fetch_datekey(market, detail)
            )

        intersect_cols = self.columns.intersection(datekey.columns)
        values = self[intersect_cols]
        # All-boolean masks pivot and ffill as one float block, unknown as NaN.
        dense = _dense_boolean(values)
        all_boolean = dense is not None
        # In mixed frames, pivoting staggered disclosure dates adds missing cells,
        # which turns bool columns into object; `~` on those yields -2/-1. Cast
        # them to nullable boolean so pre-disclosure cells stay unknown.
        boolean_dtypes = (
            {}
            if all_boolean
            else dict.fromkeys(
                values.select_dtypes(["bool", "boolean"]).columns, "boolean"
            )
        )
        # Default the axis name locally; writing it to self.columns would rename
        # the caller's frame.
        col_name = (
            self.columns.name if self.columns.name is not None else CANONICAL_NAME
        )
        # Only TW has listing prices and deadlines to tell a stock stopped trading.
        tw_listed = fiscal_table is None and market == "tw_stock"
        source = values if dense is None else dense
        disclosed = None
        if not boolean_dtypes:
            disclosed = _disclose(
                source, datekey, self.index, intersect_cols, col_name, tw_listed
            )
        if disclosed is None:
            disclosed = _disclose_by_pivot(
                source, datekey, self.index, intersect_cols, col_name, boolean_dtypes
            )
        filled, rows = disclosed
        ret = (
            filled.pipe(
                lambda df: _drop_stopped(df, rows, col_name) if tw_listed else df
            )
            # Public masks remain nullable: ~unknown must still be unknown.
            .pipe(lambda df: _dense_to_nullable(df) if all_boolean else df)
            .pipe(FDF)
            .rename_axis("date")
        )

        if not detail:
            ret.index = self.to_business_day(ret.index)
            # A weekend date lands on the next trading day; the later row carries both.
            ret = ret[~ret.index.duplicated(keep="last")]

        return _apply_truncation(ret)


def _disclose_by_pivot(
    values: pd.DataFrame,
    datekey: pd.DataFrame,
    index: pd.Index,
    columns: pd.Index,
    col_name: str,
    boolean_dtypes: dict[str, str],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Each period's values on the dates they were disclosed, forward filled.

    Also returns the disclosed rows (one per symbol and date) ``_drop_stopped`` reads.
    """
    disclosure_dates = datekey.reindex(index)[columns].unstack()
    unstacked = values.unstack()

    if unstacked.shape != disclosure_dates.shape:
        shared_idx = unstacked.index.intersection(disclosure_dates.index)
        unstacked = unstacked.reindex(shared_idx)
        disclosure_dates = disclosure_dates.reindex(shared_idx)

    ret = pd.DataFrame(
        {
            "value": unstacked.values,
            "disclosures": disclosure_dates.values,
        },
        unstacked.index,
    )
    ret.index.names = [col_name, "date"]

    rows = (
        ret.reset_index()
        .pipe(_latest_period_only, col_name)
        # A period without a disclosure date has no known availability; drop it
        # before ffill, otherwise its NaT row sorts first and leaks backward.
        .pipe(lambda df: df.loc[df["disclosures"].notna()])
    )
    filled = (
        rows.pivot(index="disclosures", columns=col_name, values="value")
        # Keep symbols whose periods all lack a disclosure date, as all-NaN columns.
        .reindex(columns=columns.sort_values().rename(col_name))
        # astype({}) still copies every column; skip it for numeric frames.
        .pipe(lambda df: df.astype(boolean_dtypes) if boolean_dtypes else df)
        .pipe(_safe_ffill)
    )
    return filled, rows


def _disclose(
    values: pd.DataFrame,
    datekey: pd.DataFrame,
    index: pd.Index,
    columns: pd.Index,
    col_name: str,
    with_rows: bool,
) -> tuple[pd.DataFrame, pd.DataFrame | None] | None:
    """``_disclose_by_pivot`` for one float block with unique labels, in numpy.

    Per symbol, cells are ordered by disclosure date, then period. A period is
    stale when a later period with a value was disclosed on an earlier date.
    On each date the latest period that has a value and is not stale is kept,
    and dates without one carry the previous value, as unstacking,
    ``_latest_period_only``, pivoting and forward filling do. Returns None for
    anything else, which then takes that route. *with_rows* also builds the
    disclosed rows that hold a value (all ``_drop_stopped`` reads).
    """
    from finlab.dataframe.parallel import inf_is_value

    symbols = columns.sort_values().rename(col_name)
    dates = datekey.reindex(index)[symbols]
    date_dtypes = dates.dtypes.unique()
    if not (
        inf_is_value()
        and index.is_unique
        and symbols.is_unique
        and datekey.index.is_unique
        and (values.dtypes == np.float64).all()
        and len(date_dtypes) == 1
        and isinstance(date_dtypes[0], np.dtype)
        and date_dtypes[0].kind == "M"
    ):
        return None
    date_dtype = date_dtypes[0]
    disclosed = dates.to_numpy()
    row, symbol = np.nonzero(~np.isnat(disclosed))
    if not len(row):
        return None
    periods = pd.factorize(index, sort=True)[0]
    day = disclosed[row, symbol].view(np.int64)
    days, day_rank = np.unique(day, return_inverse=True)
    # Symbol, then disclosure date, then period, as np.lexsort((periods[row], day,
    # symbol)) orders them; one key sorts faster, and no two cells share all three.
    # int64: the product passes 2**31 with thousands of symbols (wasm32 indices are 32-bit).
    key = (symbol.astype(np.int64) * len(days) + day_rank) * len(index) + periods[row]
    order = np.argsort(key, kind="stable")
    row, symbol, day, day_rank = row[order], symbol[order], day[order], day_rank[order]
    period = periods[row]
    value = values[symbols].to_numpy()[row, symbol]

    # The latest period with a value disclosed before each cell's date.
    published = np.where(np.isnan(value), -1, period)
    offset = symbol * (len(index) + 2)  # keeps each symbol's running max apart
    newest = np.maximum.accumulate(published + offset) - offset
    group = np.r_[True, (symbol[1:] != symbol[:-1]) | (day[1:] != day[:-1])]
    starts = np.flatnonzero(group)
    first_of_symbol = np.r_[True, symbol[1:] != symbol[:-1]][starts]
    before = np.where(first_of_symbol, -1, newest[starts - 1])
    fresh = (published >= 0) & (period >= before[np.cumsum(group) - 1])
    kept = np.maximum.reduceat(np.where(fresh, np.arange(len(fresh)), -1), starts)
    has = kept >= 0
    kept = kept[has]

    filled = np.full((len(days), len(symbols)), np.nan)
    filled[day_rank[kept], symbol[kept]] = value[kept]
    disclosures = pd.DatetimeIndex(days.view(date_dtype), name="disclosures")
    frame = pd.DataFrame(filled, index=disclosures, columns=symbols, copy=False)
    rows = None
    if with_rows:
        rows = pd.DataFrame(
            {
                col_name: symbols[symbol[kept]],
                "date": index[row[kept]],
                "value": value[kept],
                "disclosures": day[kept].view(date_dtype),
            }
        )
    return _safe_ffill(frame), rows


def _fiscal_datekey_table(idx0: str) -> str | None:
    """Return the fiscal table whose label postfix *idx0* carries, if any."""
    from finlab.data.transform import FISCAL_TABLE_POSTFIX

    return next(
        (t for t, postfix in FISCAL_TABLE_POSTFIX.items() if postfix in idx0),
        None,
    )


def _route_season_market(df: FinlabDataFrame, detail: bool = True) -> FinlabDataFrame:
    """Dispatch index_str_to_date to the correct market for Q-format indices."""
    idx0 = df.index[0]
    market_prefixes: dict[
        str,
        Literal[
            "hk_stock",
            "jp_stock",
            "kr_stock",
            "uk_stock",
            "us_stock",
            "us_stock_all",
        ],
    ] = {
        "US-ALL": "us_stock_all",
        "US": "us_stock",
        "JP": "jp_stock",
        "HK": "hk_stock",
        "KR": "kr_stock",
        "UK": "uk_stock",
    }
    for prefix, market in market_prefixes.items():
        if idx0.find(prefix) != -1:
            return df._index_str_to_date_season(detail=detail, market=market)
    return df._index_str_to_date_season(detail=detail)


def _fetch_datekey(
    market: str,
    detail: bool,
    values: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Fetch the disclosure-date or deadline DataFrame for the given market."""
    from finlab import data

    if not detail and market != "tw_stock":
        # Only TW statements have statutory deadlines (finlab#506).
        raise ValueError(
            f"Cannot apply deadline to {market} quarterly data: only TW labels "
            "such as 2013-Q1 have filing deadlines. Use index_str_to_date() to "
            "align to disclosure dates."
        )
    if market == "tw_stock":
        disclosures = data.get("etl:financial_statements_disclosure_dates")
        if detail:
            return disclosures.copy()
        deadlines = data.get("etl:financial_statements_deadline")
        if values is not None:
            _warn_deadline_date_coverage(values, deadlines, disclosures)
        disclosures = disclosures.reindex(
            index=deadlines.index, columns=deadlines.columns, fill_value=pd.NaT
        )
        # A statement filed after its deadline is public only from its filing date.
        return deadlines.mask(disclosures > deadlines, disclosures)

    if market == "us_stock_all":
        return data.get("us_fundamental_all:datekey").copy()

    if market in ("us_stock", "jp_stock", "hk_stock", "kr_stock", "uk_stock"):
        region = market.split("_", maxsplit=1)[0]
        return data.get(f"{region}_income_statement:key_date").copy()

    raise ValueError(
        f"Unsupported market: {market}. "
        "Supported markets are 'tw_stock', 'us_stock', 'us_stock_all', "
        "'jp_stock', 'hk_stock', 'kr_stock', 'uk_stock'."
    )


def _warn_deadline_date_coverage(
    values: pd.DataFrame, deadlines: pd.DataFrame, disclosures: pd.DataFrame
) -> None:
    # Boolean conditions can turn an undisclosed NaN into False (or True after
    # inversion); they do not prove that a financial value exists for that cell.
    numeric = pd.DataFrame(values).select_dtypes(include="number")
    if numeric.empty:
        return
    present = numeric.notna().to_numpy()
    # Both date tables legitimately have holes in pre-listing statements. Start
    # checking cells only once this stock has statutory deadline coverage.
    covered = (
        pd.DataFrame(deadlines)
        .sort_index()
        .notna()
        .cummax()
        .reindex(index=numeric.index, method="ffill", fill_value=False)
        .reindex(columns=numeric.columns, fill_value=False)
        .to_numpy()
    )
    gaps = []
    for key, source in (
        ("etl:financial_statements_deadline", deadlines),
        ("etl:financial_statements_disclosure_dates", disclosures),
    ):
        dates = pd.DataFrame(source)
        structural = (~numeric.index.isin(dates.index))[:, None] | (
            ~numeric.columns.isin(dates.columns)
        )[None, :]
        missing = (
            present
            & (structural | covered)
            & dates.reindex_like(numeric).isna().to_numpy()
        )
        rows, cols = np.where(missing)
        if not len(rows):
            continue
        examples = ", ".join(
            f"{numeric.columns[c]}/{numeric.index[r]}"
            for r, c in zip(rows[:5], cols[:5], strict=True)
        )
        gaps.append(f"{key} ({len(rows)} cells, e.g. {examples})")
    if gaps:
        detail = "; ".join(gaps)
        warnings.warn(
            f"deadline(): financial values lack date coverage in {detail}. "
            "Quarters with no usable date remain excluded; daily alignment may "
            "carry forward an older quarter. Check that financial values and "
            "both date tables form a complete matching snapshot.\n"
            f"財務數值存在但日期表覆蓋不足：{detail}。未知日期的季度仍不採用，"
            "日頻對齊可能沿用舊季；請確認財務值與兩張日期表為配套的完整快照。",
            UserWarning,
            stacklevel=6,
        )


def _drop_stopped(
    frame: pd.DataFrame, rows: pd.DataFrame, col_name: str
) -> pd.DataFrame:
    """Stop carrying a value while its stock is stopped and its next deadline passed.

    Stopped is ``_unpriced_mask``, the bar count at which ``sim()`` presumes a
    delisting. The mask is evaluated on every trading day, and the days it turns
    on or off become rows, so a halted stock gets its value back the day it trades
    again. Stocks without listing prices keep their values.
    """
    from finlab import data
    from finlab.backtest.delisting import DELISTING_MIN_TRAILING_BARS
    from finlab.data.indicator import _unpriced_mask
    from finlab.dataframe.parallel import _float_block

    close = data.get("price:收盤價")
    # Too few rows for any stock to go that long without a price.
    if len(close) <= DELISTING_MIN_TRAILING_BARS:
        return frame
    has_price = close.notna()
    # Only a stock missing that many prices after its first one can ever stop.
    missing = len(close) - has_price.to_numpy().argmax(axis=0) - has_price.sum()
    gappy = close.columns[has_price.any() & (missing >= DELISTING_MIN_TRAILING_BARS)]
    unpriced = _unpriced_mask(close[frame.columns.intersection(gappy)])
    unpriced = unpriced.loc[:, unpriced.any()]
    symbols = unpriced.columns
    if symbols.empty or frame.empty:
        return frame

    # Deadline of the period after each value; a stock without its own deadline
    # has the one most stocks have, and a period without any never comes due.
    rows = rows.loc[rows[col_name].isin(symbols) & rows["value"].notna()]
    periods = pd.Index(rows["date"].unique())
    following = data.get("etl:financial_statements_deadline").shift(-1).reindex(periods)
    common = following.median(axis=1).to_numpy(dtype="datetime64[ns]")[:, None]
    own = following.reindex(columns=symbols).to_numpy(dtype="datetime64[ns]")
    due = np.where(np.isnat(own), common, own)[
        periods.get_indexer(rows["date"]), symbols.get_indexer(rows[col_name])
    ]
    due = (
        rows.assign(due=np.where(np.isnat(due), np.datetime64(pd.Timestamp.max), due))
        .pivot(index="disclosures", columns=col_name, values="due")
        .reindex(index=frame.index, columns=symbols)
        .ffill()
        .to_numpy(dtype="datetime64[ns]")
    )

    # The state on each disclosure date and trading day; keep the days it flips.
    days = frame.index.union(close.index[close.index > frame.index[0]])
    stale = unpriced.reindex(days, method="ffill", fill_value=False).to_numpy() & (
        days.to_numpy()[:, None] >= due[frame.index.searchsorted(days, "right") - 1]
    )
    if not stale.any():
        return frame
    keep = days.isin(frame.index) | np.r_[False, (stale[1:] != stale[:-1]).any(axis=1)]
    frame = frame.reindex(days[keep], method="ffill")
    columns = frame.columns.get_indexer(symbols)
    if _float_block(frame):
        # frame.mask on the stopped columns alone: a copy in the block's memory
        # order, with NaN where stale, stays one block laid out as mask leaves it.
        values = frame.to_numpy().copy(order="K")
        values[:, columns] = np.where(stale[keep], np.nan, values[:, columns])
        return _labelled_like(frame, values)
    # One mask over the whole frame keeps it a single block; assigning the
    # affected columns would split it into hundreds.
    mask = np.zeros(frame.shape, dtype=bool)
    mask[:, columns] = stale[keep]
    return frame.mask(mask)


def _labelled_like(data: pd.DataFrame, values: np.ndarray) -> pd.DataFrame:
    """Wrap a freshly built 2-D array in ``data``'s labels without copying it."""
    return data._constructor(
        values, index=data.index, columns=data.columns, copy=False
    ).__finalize__(data)


def _dense_boolean(data: pd.DataFrame) -> pd.DataFrame | None:
    """Represent homogeneous masks as one float block, with NaN for unknown."""
    dtypes = data.dtypes
    if not len(data.columns) or not (
        all(dtype == np.dtype(bool) for dtype in dtypes)
        or all(isinstance(dtype, pd.BooleanDtype) for dtype in dtypes)
    ):
        return None
    return _labelled_like(data, data.to_numpy(dtype=float, na_value=np.nan))


def _nullable_boolean(
    data: pd.DataFrame, values: np.ndarray, unknown: np.ndarray
) -> pd.DataFrame:
    """Nullable boolean frame from 2-D arrays, ~7x faster than ``astype``."""
    values, unknown = np.asfortranarray(values), np.asfortranarray(unknown)
    result = data._constructor(
        {
            i: pd.arrays.BooleanArray(values[:, i], unknown[:, i])
            for i in range(values.shape[1])
        },
        index=data.index,
    ).__finalize__(data)
    result.columns = data.columns  # Positional keys keep duplicate labels intact.
    return result


def _dense_to_nullable(data: pd.DataFrame) -> pd.DataFrame:
    """Inverse of ``_dense_boolean``: 1.0/0.0/NaN become True/False/NA."""
    x = data.to_numpy()
    return _nullable_boolean(data, x == 1, np.isnan(x))


def fill_unknown_boolean(
    data: pd.DataFrame | pd.Series,
) -> pd.DataFrame | pd.Series:
    """Turn nullable boolean columns into plain bool, reading unknown as False.

    Quarterly masks are unknown (``pd.NA``) before a company's first disclosure.
    numpy consumers such as ``np.where`` or ``.values.astype(float)`` cannot
    convert ``pd.NA``. Other dtypes are returned untouched.
    """
    if isinstance(data, pd.Series):
        if isinstance(data.dtype, pd.BooleanDtype):
            return data.fillna(False).astype(bool)
        return data

    nullable = [
        col for col, dtype in data.dtypes.items() if isinstance(dtype, pd.BooleanDtype)
    ]
    if not nullable:
        return data
    if len(nullable) == data.shape[1]:
        # Construct one dense block rather than retaining one block per symbol.
        return _labelled_like(data, data.to_numpy(dtype=bool, na_value=False))
    return data.fillna(dict.fromkeys(nullable, False)).astype(
        dict.fromkeys(nullable, bool)
    )


def _safe_ffill(df: pd.DataFrame) -> pd.DataFrame:
    """Forward-fill without touching deprecated pandas 3+ future options."""
    from finlab.dataframe.parallel import ffill_columns

    pandas_major = int(pd.__version__.split(".", maxsplit=1)[0])
    future_options = getattr(pd.options, "future", None) if pandas_major < 3 else None
    if (
        future_options is not None
        and getattr(future_options, "no_silent_downcasting", None) is not None
    ):
        with pd.option_context("future.no_silent_downcasting", True):
            return ffill_columns(df)
    return ffill_columns(df)


def _apply_truncation(ret: pd.DataFrame) -> pd.DataFrame:
    """Apply truncation window if configured in finlab.data."""
    try:
        from finlab import data as finlab_data
    except ImportError:
        return ret

    t_start = getattr(finlab_data, "truncate_start", None)
    t_end = getattr(finlab_data, "truncate_end", None)
    if t_start is None and t_end is None:
        return ret

    start_ts = pd.to_datetime(t_start) if t_start is not None else None
    end_ts = pd.to_datetime(t_end) if t_end is not None else None

    if start_ts is not None and end_ts is not None:
        return ret.loc[(ret.index >= start_ts) & (ret.index <= end_ts)]
    if start_ts is not None:
        return ret.loc[ret.index >= start_ts]
    return ret.loc[ret.index <= end_ts]


def _latest_period_only(rows: pd.DataFrame, col_name: str) -> pd.DataFrame:
    """Per symbol and disclosure date keep one row, never older than a period already public.

    A late-filed older period (or several periods filed on one day) must not replace
    a newer period. Such stale rows keep their date (the output index is unchanged)
    but lose their value, so the newer period is carried forward instead.
    """
    period = pd.Series(pd.factorize(rows["date"], sort=True)[0], index=rows.index)
    order = rows.assign(_period=period).sort_values(
        [col_name, "disclosures", "_period"]
    )
    known = order["disclosures"].notna()
    # Only a period that actually carries a value counts as public.
    published = known & order["value"].notna()
    newest = (
        order["_period"].where(published).groupby(order[col_name], sort=False).cummax()
    )
    stale = known & (order["_period"] < newest)
    order["value"] = order["value"].mask(stale)
    # On a shared date keep the newest period that has a value, if any.
    order["_valued"] = order["value"].notna()
    order = order.sort_values([col_name, "disclosures", "_valued", "_period"])
    return order.drop_duplicates(["disclosures", col_name], keep="last").drop(
        columns=["_period", "_valued"]
    )
