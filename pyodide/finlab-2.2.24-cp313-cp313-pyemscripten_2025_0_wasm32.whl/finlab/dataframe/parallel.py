"""Run pandas' and numpy's own kernels on several ranges of a frame at once.

pandas' Cython rolling, rank and fill kernels and numpy's loops release the GIL,
but pandas calls them one column (or one frame) at a time. Handing ranges of
columns or dates to a thread pool runs those same kernels concurrently, so every
result is bit for bit what pandas returns, laid out in memory as pandas lays it.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
import pandas as pd
from pandas.core.window.rolling import Rolling

from finlab.threads import for_each_range

if TYPE_CHECKING:
    from collections.abc import Callable

# Aggregations whose pandas kernel starts its state over whenever a window begins
# at or after the previous window's end. Joining columns end to end, each column's
# first window does exactly that, so one call over the joined columns returns what
# separate calls per column do (sum, mean and var as of pandas 2.1 through 3.1).
_RESTARTING_KERNELS = frozenset({"sum", "mean", "var", "std"})


def _numeric(frame: pd.DataFrame) -> bool:
    return frame.ndim == 2 and all(
        isinstance(dtype, np.dtype) and dtype.kind in "biuf" for dtype in frame.dtypes
    )


class ParallelRolling(Rolling):
    """``Rolling`` that computes a numeric DataFrame's columns concurrently.

    Mirrors ``Rolling._apply_columnwise``: each column is cast to float64, its
    infinities become NaN, and the kernel pandas chose runs on it with the same
    window bounds. Anything else goes through pandas unchanged.
    """

    def _apply(
        self,
        func: Callable[..., np.ndarray],
        name: str,
        numeric_only: bool = False,
        numba_args: tuple[Any, ...] = (),
        **kwargs: Any,
    ) -> Any:
        obj = self._selected_obj
        if (
            name in ("apply", "count")  # apply holds the GIL; count casts first
            or self.method != "single"
            or self.step is not None
            or self.on is not None
            or getattr(self, "axis", 0) != 0  # pandas 2 only
            or not _numeric(obj)
            or obj.shape[1] < 2
        ):
            return super()._apply(func, name, numeric_only, numba_args, **kwargs)
        self._validate_numeric_only(name, numeric_only)
        obj = self._create_data(obj, numeric_only)

        values = np.asfortranarray(obj.to_numpy(dtype=np.float64))
        infinite = np.isinf(values)
        if infinite.any():
            values = np.asfortranarray(np.where(infinite, np.nan, values))
        indexer = self._get_window_indexer()
        min_periods = (
            self.min_periods if self.min_periods is not None else indexer.window_size
        )
        rows = len(values)
        start, end = indexer.get_window_bounds(
            num_values=rows,
            min_periods=min_periods,
            center=self.center,
            closed=self.closed,
            step=self.step,
        )
        self._check_window_bounds(start, end, rows)

        result = np.empty((values.shape[1], rows), dtype=np.float64)
        block = values.T  # one column per row, as pandas stores it
        joined = name in _RESTARTING_KERNELS

        def run(first: int, stop: int) -> None:
            with np.errstate(all="ignore"):
                if joined:
                    # The range's columns end to end: one kernel call, no GIL.
                    count = stop - first
                    offsets = np.arange(count, dtype=np.int64)[:, None] * rows
                    result[first:stop] = func(
                        block[first:stop].reshape(-1),
                        (start + offsets).ravel(),
                        (end + offsets).ravel(),
                        min_periods,
                        *numba_args,
                    ).reshape(count, rows)
                else:
                    for column in range(first, stop):
                        result[column] = func(
                            values[:, column], start, end, min_periods, *numba_args
                        )

        if rows:
            for_each_range(values.shape[1], values.size, run)
        out = type(obj)(result.T, index=obj.index, columns=obj.columns, copy=False)
        return self._resolve_output(out, obj)


def parallelize_rolling(window: Any) -> Any:
    """Let a plain ``Rolling`` run its columns concurrently; other windows stay as they are."""
    if type(window) is Rolling:
        window.__class__ = ParallelRolling
    return window


def rank_rows(values: np.ndarray, **options: Any) -> np.ndarray:
    """``DataFrame(values.T).rank(axis=0, **options)`` transposed back, dates in parallel.

    Each date is ranked on its own, so ranking ranges of dates concurrently
    returns exactly what one call over all of them would.
    """
    ranks = np.empty(values.shape, dtype=np.float64)

    def run(first: int, stop: int) -> None:
        part = pd.DataFrame(values[first:stop].T).rank(axis=0, **options)
        ranks[first:stop] = part.to_numpy().T

    for_each_range(len(values), values.size, run)
    return ranks


def ffill_columns(frame: pd.DataFrame) -> pd.DataFrame:
    """``frame.ffill()``, filling ranges of a float frame's columns concurrently.

    Each column is forward filled on its own, so filling ranges of columns with
    pandas' own kernel returns exactly what one call over all of them would.
    """
    if frame.shape[1] < 2 or not (frame.dtypes == np.float64).all():
        return frame.ffill()
    # Row-major, as DataFrame.ffill lays out its result whatever the input's order.
    filled = np.empty(frame.shape, dtype=np.float64)

    def run(first: int, stop: int) -> None:
        filled[:, first:stop] = frame.iloc[:, first:stop].ffill().to_numpy()

    for_each_range(frame.shape[1], frame.size, run)
    return frame._constructor(
        filled, index=frame.index, columns=frame.columns, copy=False
    ).__finalize__(frame)


def _float_block(frame: pd.DataFrame) -> bool:
    return (
        frame.shape[1] > 1
        and getattr(frame._mgr, "nblocks", 0) == 1  # pandas 2's ArrayManager has none
        and (frame.dtypes == np.float64).all()
    )


def pandas_option(name: str) -> object:
    """A pandas option, None where this pandas has none, read without deprecation warnings."""
    try:
        from pandas._config.config import _get_option

        return _get_option(name, silent=True)
    except (ImportError, KeyError):  # OptionError is a KeyError
        return None


def inf_is_value() -> bool:
    """False while pandas 2's ``mode.use_inf_as_na`` is on: pandas then reads inf as
    missing, which the numpy routes here do not."""
    return not pandas_option("mode.use_inf_as_na")


def count_valid_rows(frame: pd.DataFrame) -> pd.Series:
    """``frame.notna().sum(axis=1)``, counting ranges of a float frame's columns concurrently."""
    if not (_float_block(frame) and inf_is_value()):
        return frame.notna().sum(axis=1)
    values = frame.to_numpy()  # one column per contiguous run, as pandas holds it
    counts: dict[int, np.ndarray] = {}

    def run(first: int, stop: int) -> None:
        counts[first] = np.count_nonzero(~np.isnan(values[:, first:stop]), axis=1)

    for_each_range(frame.shape[1], frame.size, run)
    return pd.Series(sum(counts.values()), index=frame.index)


def take_rows(frame: pd.DataFrame, keep: np.ndarray) -> pd.DataFrame:
    """``frame.loc[keep]`` for a boolean row mask, copying column ranges concurrently."""
    if not _float_block(frame):
        return frame.loc[keep]
    rows = np.flatnonzero(keep)
    values = frame.to_numpy()
    # .loc keeps the block's memory order; values is that block transposed.
    taken = np.empty(
        (len(rows), frame.shape[1]),
        dtype=np.float64,
        order="C" if values.flags.c_contiguous else "F",
    )

    def run(first: int, stop: int) -> None:
        np.take(values[:, first:stop], rows, axis=0, out=taken[:, first:stop])

    for_each_range(frame.shape[1], taken.size, run)
    return frame._constructor(
        taken, index=frame.index.take(rows), columns=frame.columns, copy=False
    ).__finalize__(frame)
