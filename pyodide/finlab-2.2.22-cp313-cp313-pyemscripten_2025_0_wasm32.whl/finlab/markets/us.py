from __future__ import annotations

import datetime
from typing import ClassVar

import pandas as pd

from finlab import data

__all__ = ["USFundMarket", "USMarket"]
from finlab.market import Market


class USMarket(Market):
    _price_table: ClassVar[str] = "us_price"
    _adj_prefix: ClassVar[str] = "us_price:adj_"

    @staticmethod
    def get_freq() -> str:
        return "1D"

    @staticmethod
    def get_name() -> str:
        return "us_stock"

    @staticmethod
    def get_benchmark() -> pd.Series:
        return data.get("world_index:adj_close")["^GSPC"]

    @staticmethod
    def get_asset_id_to_name() -> dict[str, str]:
        profile = data.get("us_company_profile")
        mask = profile["company_name"].notna()
        return dict(
            zip(
                profile.loc[mask, "symbol"],
                profile.loc[mask, "company_name"],
                strict=True,
            )
        )

    @staticmethod
    def get_industry() -> dict[str, str]:
        profile = data.get("us_company_profile")
        mask = profile["industry"].notna()
        return dict(
            zip(profile.loc[mask, "symbol"], profile.loc[mask, "industry"], strict=True)
        )

    def market_close_at_timestamp(
        self, timestamp: pd.Timestamp | None = None
    ) -> pd.Timestamp:
        if timestamp is None:
            timestamp = self.get_price("close").index[-1]

        timestamp = self._normalize_market_timestamp(timestamp, "US/Eastern")

        # get market close time
        market_close = pd.Timestamp(timestamp.date()) + pd.Timedelta("16:00:00")
        return market_close.tz_localize("US/Eastern")

    @staticmethod
    def market_open_time() -> tuple[int, int]:
        return (9, 30)

    @staticmethod
    def default_fee_ratio() -> float:
        return 0.0

    @staticmethod
    def default_tax_ratio() -> float:
        return 0.0

    @staticmethod
    def tzinfo() -> datetime.timezone:
        return datetime.timezone(datetime.timedelta(hours=-5))


class USFundMarket(USMarket):
    """US fund/ETF market using us_fund_price data."""

    _price_table: ClassVar[str] = "us_fund_price"
    _adj_prefix: ClassVar[str] = "us_fund_price:adj_"

    @staticmethod
    def get_name() -> str:
        return "us_fund"

    def get_price(
        self, trade_at_price: str | pd.Series | pd.DataFrame, adj: bool = True
    ) -> pd.DataFrame:
        price = super().get_price(trade_at_price, adj=adj)
        if not isinstance(trade_at_price, str):
            return price
        # 2016–2023 的交易所休市平日仍有一百多檔共同基金帶值，回測不能在這些日子成交。
        # 有值的代號不到前後兩個交易日的一半就是休市；第一列和最後一列沒得比，保留。
        count = price.notna().sum(axis=1)
        closed = (count < count.shift() / 2) & (count < count.shift(-1) / 2)
        return price.loc[~closed]
