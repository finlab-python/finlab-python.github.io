import os
import logging
import pkgutil
import warnings
from getpass import getpass


# Get an instance of a logger
logger = logging.getLogger(__name__)

__version__ = '1.5.8'

_api_token_deprecation_warned = False
_login_deprecation_warned = False


def _detect_environment():
    """Detect runtime environment for migration guidance."""
    if os.environ.get('COLAB_RELEASE_TAG'):
        return 'colab'
    if os.environ.get('FUNCTION_TARGET') or os.environ.get('K_SERVICE'):
        return 'cloud_functions'
    return 'desktop'


def _build_deprecation_message(context='get_token'):
    """Build environment-aware deprecation message."""
    env = _detect_environment()
    if context == 'login':
        base = (
            "Passing api_token to finlab.login() is deprecated "
            "and will be removed in a future version."
        )
    else:
        base = (
            "FINLAB_API_TOKEN is deprecated "
            "and will be removed in a future version."
        )

    if env == 'colab':
        guidance = " Use finlab.login() (without arguments) to authenticate interactively."
    elif env == 'cloud_functions':
        guidance = (
            " Run 'python -m finlab token --env' locally, then set "
            "FINLAB_REFRESH_TOKEN, FINLAB_SESSION_ID, and FINLAB_API_KEY "
            "as environment variables."
        )
    else:
        guidance = " Run 'python -m finlab login' to authenticate with the new system."

    return base + guidance


def _warn_api_token_deprecated():
    """Emit FINLAB_API_TOKEN deprecation warning (once per session)."""
    global _api_token_deprecation_warned
    if not _api_token_deprecation_warned:
        _api_token_deprecation_warned = True
        warnings.warn(
            _build_deprecation_message('get_token'),
            DeprecationWarning,
            stacklevel=3,
        )


class LoginPanel():

    def __init__(self):
        pass

    def gui_supported(self):
        try:
            if "VSCODE_PID" in os.environ or pkgutil.find_loader('IPython') is None:
                return False # vscode not support getpass and display at the same time
            else:
                return True
        except Exception:
            return False

    def display_gui(self):

        from IPython.display import IFrame, display, clear_output
        iframe = IFrame(
            f'https://ai.finlab.tw/api_token/?version={__version__}', width=620, height=300)
        display(iframe)

        try:
            token = getpass('請從 https://ai.finlab.tw/api_token 複製驗證碼: \n')
        except Exception:
            print('請從 https://ai.finlab.tw/api_token 複製驗證碼: \n')
            token = input('驗證碼：')
        clear_output()
        self.login(token)

    def display_text_input(self):
        print('請從 https://ai.finlab.tw/api_token 複製驗證碼，貼於此處:\n')
        token = input('驗證碼：')
        self.login(token)
        print('之後可以使用以下方法自動登入')
        print('import finlab')
        print('finlab.login("YOUR API TOKEN")')

    @staticmethod
    def login(token):
        # set token
        token = token[:64]
        os.environ['finlab_id_token'] = token
        os.environ['FINLAB_API_TOKEN'] = token
        print('輸入成功!')


def login(api_token=None):
    """登錄量化平台。

    可以至 [api_token查詢頁面](https://ai.finlab.tw/api_token/) 獲取api_token，傳入函數後執行登錄動作。
    之後使用Finlab模組的會員功能時，系統就不會自動跳出請求輸入api_token的[GUI頁面](https://ai.finlab.tw/api_token/)。
    若傳入的api_toke格式有誤，系統會要求再次輸入。

    若不傳入 api_token，會啟動瀏覽器登入流程（新版）。

    Args:
        api_token (str): FinLab api_token
    """
    if api_token:
        # Old flow: static api_token
        global _login_deprecation_warned
        if not _login_deprecation_warned:
            _login_deprecation_warned = True
            warnings.warn(
                _build_deprecation_message('login'),
                DeprecationWarning,
                stacklevel=2,
            )
        lp = LoginPanel()
        lp.login(api_token)
        return

    # New flow: try browser-based login
    try:
        from finlab.auth import browser_login
        browser_login()
        return
    except ImportError as e:
        if 'cryptography' in str(e):
            print('Browser login requires: pip install cryptography')
        logger.debug(f'Browser login import failed: {e}')
    except Exception as e:
        logger.debug(f'Browser login failed: {e}')

    # Fallback to old interactive flow
    lp = LoginPanel()
    if lp.gui_supported():
        lp.display_gui()
    else:
        lp.display_text_input()


def get_token():
    """取得登錄會員的認證 token。

    認證優先順序：
    1. ~/.finlab/credentials.json (新版 Firebase auth) → 返回 id_token
    2. FINLAB_API_TOKEN 環境變數 (舊版) → 返回 api_token
    3. 互動式登入

    Returns:
        tuple: (token_string, token_type) where token_type is 'id_token' or 'api_token'
    """
    # Priority 1: New Firebase auth credentials
    try:
        from finlab.auth import get_id_token
        id_token = get_id_token()
        if id_token:
            if 'FINLAB_API_TOKEN' in os.environ:
                _warn_api_token_deprecated()
            return (id_token, 'id_token')
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f'Firebase token refresh failed: {e}')

    # Priority 2: Environment variable (old flow)
    if 'FINLAB_API_TOKEN' in os.environ:
        _warn_api_token_deprecated()
        return (os.environ['FINLAB_API_TOKEN'][:64], 'api_token')

    # Priority 3: Interactive login (only if no session exists at all)
    # If session exists but refresh failed, don't open browser — raise instead
    try:
        from finlab.auth import get_session
        has_session = get_session() is not None
    except ImportError:
        has_session = False

    if has_session:
        raise RuntimeError(
            'Token refresh failed (session exists but token expired). '
            'Run `python -m finlab login` to re-authenticate.'
        )

    login()

    # After login, check again
    try:
        from finlab.auth import get_id_token
        id_token = get_id_token()
        if id_token:
            return (id_token, 'id_token')
    except Exception:
        pass

    if 'FINLAB_API_TOKEN' in os.environ:
        _warn_api_token_deprecated()
        return (os.environ['FINLAB_API_TOKEN'][:64], 'api_token')

    raise RuntimeError('Login failed. Please run: python -m finlab login')
