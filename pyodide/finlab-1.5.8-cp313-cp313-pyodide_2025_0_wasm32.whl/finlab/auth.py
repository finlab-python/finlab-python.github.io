"""Firebase Auth module for finlab CLI.

Handles browser-based login, credential storage, and id_token refresh.
Credentials stored in ~/.finlab/credentials.json, encrypted with machine-bound key.
"""
from __future__ import annotations

import os
import sys
import json
import time
import base64
import hashlib
import logging
import socket
import subprocess
import webbrowser
import urllib.request
import urllib.error
import urllib.parse

logger = logging.getLogger(__name__)

CREDENTIALS_DIR = os.path.expanduser('~/.finlab')
CREDENTIALS_FILE = os.path.join(CREDENTIALS_DIR, 'credentials.json')

# Firebase REST API for token exchange
FIREBASE_TOKEN_URL = 'https://securetoken.googleapis.com/v1/token'

# User-Agent required to avoid Cloudflare bot blocking
_UA = 'finlab-cli/1.0'

# In-memory cache to avoid repeated disk reads and Firebase API calls
_cached_id_token: str | None = None
_cached_id_token_expiry: float = 0


def _get_machine_id() -> str:
    """Get a stable machine identifier.

    uuid.getnode() is unreliable — some Python builds return a random MAC
    each process (multicast bit set).  Use OS-level hardware IDs instead.
    """
    # macOS: IOPlatformUUID (stable across reboots)
    if sys.platform == 'darwin':
        try:
            out = subprocess.check_output(
                ['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'],
                text=True, timeout=5,
            )
            for line in out.splitlines():
                if 'IOPlatformUUID' in line:
                    return line.split('"')[-2]
        except Exception:
            pass

    # Linux: /etc/machine-id
    for path in ('/etc/machine-id', '/var/lib/dbus/machine-id'):
        try:
            with open(path) as f:
                mid = f.read().strip()
                if mid:
                    return mid
        except OSError:
            pass

    # Fallback: hostname (not ideal but stable per machine)
    return socket.gethostname()


def _get_machine_key() -> bytes:
    """Derive encryption key from a stable machine identifier."""
    machine_id = _get_machine_id()
    raw_key = f'finlab-{machine_id}-credential-key'.encode()
    return base64.urlsafe_b64encode(hashlib.sha256(raw_key).digest())


def _encrypt(data: bytes) -> bytes:
    """Encrypt data with machine-bound Fernet key."""
    from cryptography.fernet import Fernet
    f = Fernet(_get_machine_key())
    return f.encrypt(data)


def _decrypt(data: bytes) -> bytes:
    """Decrypt data with machine-bound Fernet key."""
    from cryptography.fernet import Fernet
    f = Fernet(_get_machine_key())
    return f.decrypt(data)


def _detect_session_name() -> str:
    """Auto-detect a session name for reuse-by-name.

    Returns 'colab' if running in Google Colab, otherwise the hostname.
    """
    if os.environ.get('COLAB_RELEASE_TAG'):
        return 'colab'
    return socket.gethostname()


def get_session() -> dict | None:
    """Read stored credentials. Checks env vars first, then encrypted file."""
    # Env var priority: for Cloud Functions / Lambda / headless environments
    env_refresh = os.environ.get('FINLAB_REFRESH_TOKEN')
    env_session = os.environ.get('FINLAB_SESSION_ID')
    env_api_key = os.environ.get('FINLAB_API_KEY')

    if env_refresh and env_session and env_api_key:
        return {
            'refresh_token': env_refresh,
            'session_id': env_session,
            'api_key': env_api_key,
            'source': 'env',
        }

    if not os.path.exists(CREDENTIALS_FILE):
        return None
    try:
        with open(CREDENTIALS_FILE, 'rb') as f:
            encrypted = f.read()
        decrypted = _decrypt(encrypted)
        return json.loads(decrypted)
    except Exception:
        logger.debug('Failed to read credentials, may be corrupted or from another machine')
        return None


def save_session(data: dict) -> None:
    """Encrypt and write credentials to disk."""
    os.makedirs(CREDENTIALS_DIR, exist_ok=True)
    encrypted = _encrypt(json.dumps(data).encode())
    with open(CREDENTIALS_FILE, 'wb') as f:
        f.write(encrypted)
    # Restrict file permissions (owner-only)
    os.chmod(CREDENTIALS_FILE, 0o600)


def clear_session() -> None:
    """Delete local credentials."""
    if os.path.exists(CREDENTIALS_FILE):
        os.remove(CREDENTIALS_FILE)


def get_id_token() -> str | None:
    """Exchange refresh_token for a fresh id_token via Firebase REST API.

    Uses in-memory cache to avoid repeated disk reads and Firebase API calls.
    Returns the id_token string, or None on failure.
    """
    global _cached_id_token, _cached_id_token_expiry

    now = time.time()

    # Fast path: return in-memory cached token if still valid
    if _cached_id_token and _cached_id_token_expiry > now + 60:
        return _cached_id_token

    session = get_session()
    if not session:
        return None

    refresh_token = session.get('refresh_token')
    api_key = session.get('api_key')
    if not refresh_token or not api_key:
        return None

    # Check disk-cached id_token (only if in-memory cache missed)
    cached_token = session.get('id_token')
    token_expiry = session.get('id_token_expiry', 0)

    if cached_token and token_expiry > now + 60:  # 60s buffer
        _cached_id_token = cached_token
        _cached_id_token_expiry = token_expiry
        return cached_token

    # Exchange refresh token for new id_token
    url = f'{FIREBASE_TOKEN_URL}?key={api_key}'
    data = urllib.parse.urlencode({
        'grant_type': 'refresh_token',
        'refresh_token': refresh_token,
    }).encode()

    try:
        req = urllib.request.Request(url, data=data, method='POST')
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')
        req.add_header('User-Agent', _UA)
        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.fp else ''
        logger.warning(f'Token refresh failed: {e.code} {body[:200]}')
        return None
    except Exception as e:
        logger.warning(f'Token refresh failed: {e}')
        return None

    id_token = result.get('id_token')
    expires_in = int(result.get('expires_in', 3600))
    new_refresh = result.get('refresh_token', refresh_token)

    if not id_token:
        return None

    # Update in-memory cache
    _cached_id_token = id_token
    _cached_id_token_expiry = now + expires_in

    # Update disk cache (skip for env-var sessions)
    session['id_token'] = id_token
    session['id_token_expiry'] = now + expires_in
    session['refresh_token'] = new_refresh
    if session.get('source') != 'env':
        save_session(session)

    return id_token


def invalidate_token_cache() -> None:
    """Clear in-memory token cache, forcing next call to re-read from disk."""
    global _cached_id_token, _cached_id_token_expiry
    _cached_id_token = None
    _cached_id_token_expiry = 0


def browser_login(base_url: str = 'https://www.finlab.finance') -> bool:
    """Perform browser-based login flow.

    1. POST /api/auth/cli/init to get sessionId + pollSecret
    2. Open browser with auth URL
    3. Poll /api/auth/poll for token
    4. Store credentials

    Returns True on success, False on failure.
    """
    # Step 1: Initialize session (v=2 signals new auth flow with session limits)
    session_name = _detect_session_name()
    init_url = f'{base_url}/api/auth/cli/init'
    try:
        body = json.dumps({'v': 2, 'session_name': session_name}).encode()
        req = urllib.request.Request(init_url, data=body, method='POST')
        req.add_header('Content-Type', 'application/json')
        req.add_header('User-Agent', _UA)
        with urllib.request.urlopen(req, timeout=30) as response:
            init_data = json.loads(response.read().decode())
    except Exception as e:
        print(f'Error: Failed to initialize login session: {e}')
        return False

    session_id = init_data.get('sessionId')
    poll_secret = init_data.get('pollSecret')
    auth_url = init_data.get('authUrl')
    expires_in = init_data.get('expiresIn', 300)

    if not session_id or not poll_secret or not auth_url:
        print('Error: Invalid response from server')
        return False

    # Step 2: Open browser
    print(f'Opening browser for login...')
    print(f'If browser does not open, visit: {auth_url}')
    webbrowser.open(auth_url)

    # Step 3: Poll for token
    poll_url = f'{base_url}/api/auth/poll?s={session_id}&secret={poll_secret}'
    start_time = time.time()
    poll_interval = 2

    print('Waiting for login...', end='', flush=True)
    while time.time() - start_time < expires_in:
        time.sleep(poll_interval)
        print('.', end='', flush=True)

        try:
            req = urllib.request.Request(poll_url)
            req.add_header('User-Agent', _UA)
            with urllib.request.urlopen(req, timeout=15) as response:
                result = json.loads(response.read().decode())
        except urllib.error.HTTPError as e:
            # Read error body for structured errors (e.g. session_limit_reached)
            try:
                result = json.loads(e.read().decode())
            except Exception:
                continue
        except Exception:
            continue

        if result.get('status') == 'success':
            print(' Done!')

            # New flow: has refresh_token and session data
            refresh_token = result.get('refresh_token')
            api_key = result.get('api_key')
            user_session_id = result.get('session_id')

            if refresh_token and api_key:
                creds = {
                    'refresh_token': refresh_token,
                    'api_key': api_key,
                    'session_id': user_session_id,
                    'api_token': result.get('token'),
                    'session_name': result.get('session_name', session_name),
                    'created_at': time.time(),
                }
                save_session(creds)
                print('Login successful! Credentials saved.')
                if result.get('session_name'):
                    print(f'Session name: {result["session_name"]}')
                return True
            else:
                # Old flow fallback: just got api_token
                token = result.get('token')
                if token:
                    os.environ['FINLAB_API_TOKEN'] = token[:64]
                    print('Login successful!')
                    return True

            return False

        if result.get('status') == 'pending':
            continue

        # Error
        error = result.get('error', 'Unknown error')
        message = result.get('message', '')

        if error == 'SESSION_LIMIT_REACHED':
            print(f'\n{message}')
            sessions = result.get('sessions', {})
            if sessions:
                print('\nActive sessions:')
                for sid, info in sessions.items():
                    device = info.get('device_name', 'Unknown') if isinstance(info, dict) else 'Unknown'
                    sname = info.get('session_name', '') if isinstance(info, dict) else ''
                    label = f'{device}'
                    if sname:
                        label += f' ({sname})'
                    print(f'  {sid[:8]}... - {label}')
            print('\nPlease run `python -m finlab logout` on another device, then retry.')
            return False

        print(f'\nError: {error}')
        if message:
            print(f'  {message}')
        return False

    print('\nTimeout: Login session expired. Please try again.')
    return False


def logout_session(base_url: str = 'https://www.finlab.finance') -> bool:
    """Logout: clear local credentials and remove session from server.

    Returns True if local cleanup succeeded.
    """
    session = get_session()

    # Try to remove server-side session
    if session and session.get('session_id'):
        id_token = get_id_token()
        if id_token:
            try:
                url = f'{base_url}/api/auth/cli/sessions'
                data = json.dumps({'session_id': session['session_id']}).encode()
                req = urllib.request.Request(url, data=data, method='DELETE')
                req.add_header('Content-Type', 'application/json')
                req.add_header('Authorization', f'Bearer {id_token}')
                req.add_header('User-Agent', _UA)
                urllib.request.urlopen(req, timeout=15)
            except Exception as e:
                logger.debug(f'Failed to remove server session: {e}')

    clear_session()
    return True


def get_status(base_url: str = 'https://www.finlab.finance') -> dict | None:
    """Get session info from server. Returns dict with sessions, plan info."""
    id_token = get_id_token()
    if not id_token:
        return None

    try:
        url = f'{base_url}/api/auth/cli/sessions'
        req = urllib.request.Request(url)
        req.add_header('Authorization', f'Bearer {id_token}')
        req.add_header('User-Agent', _UA)
        with urllib.request.urlopen(req, timeout=15) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        logger.debug(f'Failed to get session status: {e}')
        return None
