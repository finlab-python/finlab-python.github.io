"""Entry point for `python -m finlab` commands.

Usage:
    python -m finlab login     # Browser-based login
    python -m finlab logout    # Clear credentials + remove server session
    python -m finlab status    # Show active sessions and plan info
    python -m finlab token --env  # Export credentials as env vars
    python -m finlab migrate   # Migration guide from FINLAB_API_TOKEN
"""

import argparse
import sys


def cmd_login(args):
    from finlab.auth import browser_login
    success = browser_login()
    sys.exit(0 if success else 1)


def cmd_logout(args):
    from finlab.auth import logout_session, clear_session

    success = logout_session()
    if success:
        print('Logged out successfully.')
    else:
        # At least clear local
        clear_session()
        print('Local credentials cleared.')


def cmd_token(args):
    from finlab.auth import get_session

    session = get_session()
    if not session:
        print('Not logged in. Run: python -m finlab login', file=sys.stderr)
        sys.exit(1)

    if session.get('source') == 'env':
        print('Credentials are already from env vars.', file=sys.stderr)
        sys.exit(1)

    refresh_token = session.get('refresh_token')
    session_id = session.get('session_id')
    api_key = session.get('api_key')

    if not refresh_token or not session_id or not api_key:
        print('Incomplete credentials. Run: python -m finlab login', file=sys.stderr)
        sys.exit(1)

    if args.env:
        print(f'export FINLAB_REFRESH_TOKEN="{refresh_token}"')
        print(f'export FINLAB_SESSION_ID="{session_id}"')
        print(f'export FINLAB_API_KEY="{api_key}"')
    else:
        print(f'FINLAB_REFRESH_TOKEN={refresh_token}')
        print(f'FINLAB_SESSION_ID={session_id}')
        print(f'FINLAB_API_KEY={api_key}')


def cmd_migrate(args):
    import os
    from finlab import _detect_environment
    from finlab.auth import get_session

    env = _detect_environment()
    has_new_creds = get_session() is not None
    has_old_token = 'FINLAB_API_TOKEN' in os.environ

    if has_new_creds and has_old_token:
        print('Already migrated to new auth system!')
        print('Remove FINLAB_API_TOKEN from your environment to complete migration.')
        if env == 'desktop':
            print('Check your shell profile (~/.bashrc, ~/.zshrc) or .env files.')
        elif env == 'cloud_functions':
            print('Remove FINLAB_API_TOKEN from your Cloud Functions environment variables.')
    elif has_new_creds and not has_old_token:
        print('Already migrated! No action needed.')
    elif env == 'colab':
        print('Migration guide for Google Colab:')
        print('  1. Replace finlab.login("YOUR_API_TOKEN") with finlab.login()')
        print('  2. Follow the browser login flow')
        print('  3. Remove any FINLAB_API_TOKEN references from your notebook')
    elif env == 'cloud_functions':
        print('Migration guide for Cloud Functions:')
        print('  1. On your local machine, run: python -m finlab login')
        print('  2. Then run: python -m finlab token --env')
        print('  3. Set these 3 env vars in your Cloud Functions config:')
        print('       FINLAB_REFRESH_TOKEN')
        print('       FINLAB_SESSION_ID')
        print('       FINLAB_API_KEY')
        print('  4. Remove FINLAB_API_TOKEN from your config')
    else:
        print('Migration guide:')
        print('  1. Run: python -m finlab login')
        print('  2. Remove FINLAB_API_TOKEN from your shell profile')
        print('     (check ~/.bashrc, ~/.zshrc, or .env files)')


def cmd_status(args):
    from finlab.auth import get_session, get_status

    session = get_session()
    if not session:
        print('Not logged in.')
        print('Run: python -m finlab login')
        sys.exit(1)

    print(f'Local session: {session.get("session_id", "n/a")[:8]}...')
    print(f'API key: {"configured" if session.get("api_key") else "not configured"}')
    if session.get('session_name'):
        print(f'Session name: {session["session_name"]}')
    if session.get('source') == 'env':
        print('Source: environment variables')

    status = get_status()
    if status:
        plan = status.get('plan', {})
        role = plan.get('role', 'unknown')
        ai = plan.get('ai', 0)
        count = status.get('count', 0)
        max_sessions = status.get('max_sessions', 0)

        plan_name = 'Free'
        if role == 'vip_m':
            if ai == 2:
                plan_name = 'AI MAX'
            elif ai == 1:
                plan_name = 'AI'
            else:
                plan_name = 'VIP'

        print(f'Plan: {plan_name}')
        print(f'Sessions: {count}/{max_sessions}')

        sessions = status.get('sessions', {})
        if sessions:
            print('\nActive sessions:')
            for sid, info in sessions.items():
                device = info.get('device_name', 'Unknown')
                sname = info.get('session_name', '')
                current = ' (this device)' if sid == session.get('session_id') else ''
                label = f'{device}'
                if sname:
                    label += f' [{sname}]'
                print(f'  {sid[:8]}... - {label}{current}')
    else:
        print('Could not fetch server status (token may have expired).')
        print('Try: python -m finlab login')


def main():
    parser = argparse.ArgumentParser(
        prog='python -m finlab',
        description='FinLab CLI - Login and session management',
    )
    sub = parser.add_subparsers(dest='command')

    sub.add_parser('login', help='Login via browser')
    sub.add_parser('logout', help='Logout and clear credentials')
    sub.add_parser('status', help='Show session info')
    sub.add_parser('migrate', help='Migration guide from FINLAB_API_TOKEN')

    token_parser = sub.add_parser('token', help='Export credentials for headless environments')
    token_parser.add_argument('--env', action='store_true', help='Output as export commands for shell')

    args = parser.parse_args()

    commands = {
        'login': cmd_login,
        'logout': cmd_logout,
        'status': cmd_status,
        'token': cmd_token,
        'migrate': cmd_migrate,
    }

    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == '__main__':
    main()
