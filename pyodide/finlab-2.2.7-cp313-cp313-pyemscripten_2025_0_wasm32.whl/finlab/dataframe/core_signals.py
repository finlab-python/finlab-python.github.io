"""Signal generation mixin for FinlabDataFrame.

Implements trading signal methods: entry/exit detection, position holding
with rotation, stop-loss, take-profit, and trailing stops.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal, cast

import numpy as np
import pandas as pd

from finlab._stops import StopTable, stop_table, validate_stop_parameters

if TYPE_CHECKING:
    from collections.abc import Callable

    from finlab.dataframe.core import FinlabDataFrame

    _ExitAligner = Callable[[pd.DataFrame, pd.Index, pd.Index], pd.DataFrame]

ExitMode = Literal["state", "event"]


class SignalMixin:
    """Trading signal generation methods for FinlabDataFrame."""

    def is_entry(self) -> FinlabDataFrame:
        """進場點

        取進場訊號點，若符合條件的值則為True，反之為False。
        Returns:
          (pd.DataFrame): data
        Examples:
          策略為每日收盤價前10高，取進場點。
            ```py
            from finlab import data
            data.get('price:收盤價').is_largest(10).is_entry()
            ```
        """
        frame = cast("FinlabDataFrame", self)
        return frame & ~frame.shift(fill_value=False)

    def is_exit(self) -> FinlabDataFrame:
        """出場點

        取出場訊號點，若符合條件的值則為 True，反之為 False。
        Returns:
          (pd.DataFrame): data
        Examples:
          策略為每日收盤價前10高，取出場點。
            ```py
            from finlab import data
            data.get('price:收盤價').is_largest(10).is_exit()
            ```
        """
        frame = cast("FinlabDataFrame", self)
        return ~frame & frame.shift(fill_value=False)

    def entry_price(self, trade_at: str = "close") -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame as FDF

        frame = cast("FinlabDataFrame", self)
        signal = frame.is_entry()
        from finlab import data

        adj = (
            data.get("etl:adj_close")
            if trade_at == "close"
            else data.get("etl:adj_open")
        )
        adj, signal = adj.reshape(adj.loc[signal.index[0] : signal.index[-1]], signal)
        return FDF(adj.bfill()[signal.shift(fill_value=False)].astype("float").ffill())

    def sustain(self, nwindow: int, nsatisfy: int | None = None) -> FinlabDataFrame:
        """持續 N 天滿足條件

        取移動 nwindow 筆加總大於等於nsatisfy，若符合條件的值則為True，反之為False。

        Args:
          nwindow (positive-int): 設定移動窗格。
          nsatisfy (positive-int): 設定移動窗格計算後最低滿足數值。
        Returns:
          (pd.DataFrame): data
        Examples:
            收盤價是否連兩日上漲
            ```py
            from finlab import data
            data.get('price:收盤價').rise().sustain(2)
            ```
        """
        frame = cast("FinlabDataFrame", self)
        nsatisfy = nsatisfy or nwindow
        return frame.rolling(nwindow).sum() >= nsatisfy

    def exit_when(self, exit: pd.DataFrame) -> FinlabDataFrame:
        frame = cast("FinlabDataFrame", self)
        df, exit = frame.reshape(frame, exit)

        df = df.fillna(False)
        exit = exit.fillna(False)

        entry_signal = df.is_entry()
        exit_signal = df.is_exit()
        exit_signal |= exit

        position = pd.DataFrame(np.nan, index=df.index, columns=df.columns)
        position[entry_signal] = 1.0
        position[exit_signal] = 0.0

        position = position.ffill()
        position = position == 1.0
        return position.fillna(False)

    def hold_until(
        self,
        exit: pd.DataFrame,
        nstocks_limit: int | None = None,
        stop_loss: float | pd.DataFrame = -np.inf,
        take_profit: float | pd.DataFrame = np.inf,
        trail_stop: float = np.inf,
        trail_stop_activation: float = 0,
        trade_at: str = "close",
        rank: pd.DataFrame | None = None,
        *,
        exit_mode: ExitMode = "state",
    ) -> FinlabDataFrame:
        """訊號進出場

        這大概是所有策略撰寫中，最重要的語法糖，上述語法中 `entries` 為進場訊號，而 `exits` 是出場訊號。所以 `entries.hold_until(exits)` ，就是進場訊號為 `True` 時，買入並持有該檔股票，直到出場訊號為 `True ` 則賣出。

        <img src="https://i.ibb.co/PCt4hPd/Screen-Shot-2021-10-26-at-6-35-05-AM.png" alt="Screen-Shot-2021-10-26-at-6-35-05-AM">
        此函式有很多細部設定，可以讓你最多選擇 N 檔股票做輪動。另外，當超過 N 檔進場訊號發生，也可以按照客制化的排序，選擇優先選入的股票。最後，可以設定價格波動當輪動訊號，來增加出場的時機點。

        進場訊號一律是事件，只在自己有的日期生效。出場訊號的日期比較稀疏時（月營收、財報、週／月頻條件、只有事件日的資料），`exit` 沒有的日期怎麼處理由 `exit_mode` 決定：

        - `'state'`（預設，與 2.1.0 以前相同，至 2.0.23）：出場是持續的狀態。沒有的日期沿用 `exit` 前一個日期的值，所以月營收條件在下一次公布前一直有效，期間即使進場訊號為 True 也不會買進。`exit` 最後一筆是 True 時，之後都無法再進場；只有一個日期的單次事件也一樣會一直擋住進場。`exit` 的日期必須由舊到新排序，否則拋出 `ValueError`，請先 `exit.sort_index()`。
        - `'event'`（2.1.0～2.2.0 的預設）：出場是事件，只在 `exit` 自己有的日期生效，沒有的日期視為不出場。

        兩種模式下 NaN 都視為不出場：`'state'` 只補 `exit` 沒有的日期，不會把 NaN 換成更早的 True。

        `exit` 在每個進場日都有一列時，兩種模式結果相同；rank 或停損停利價格額外帶進的日期上沒有進場訊號，不影響結果。日頻的 `exit` 晚一天更新或缺一個交易日時，那一天 `'state'` 沿用前一筆，`'event'` 視為不出場，結果可能不同。

        `'event'` 只看得到傳進來的 `exit` 有哪些日期。下列情況 `exit` 已經被往後填到比較密的時間軸，填出來的每一列都當成一次事件，`'event'` 無法還原原本只在公布日出現的出場：

        - 和日頻資料運算過的條件（例如 `exits | (close < close.average(60))`），結果和 `'state'` 相同；要當成事件，請直接傳入原本的低頻條件。
        - 季頻字串索引：`index_str_to_date()` 以所有公司的公告日為索引，每家公司的值會延續到其他公司的公告日，值為 True 時 `'event'` 在這些日期也會出場。
        - lazy 的 `exit`（`data.get(..., lazy=True)` 或 `.lazy()` 算出的條件）：lazy 引擎在呼叫 `hold_until` 之前，先把它往後填到 lazy 的時間軸，即使指定 `'event'`，結果也和 `'state'` 相同。要事件語意，請傳入 eager 的 `exit`，例如 `entries.lazy().hold_until(exits, exit_mode='event').collect()`，或先只對低頻的出場條件呼叫 `.collect()`。

        Args:
          exit (pd.Dataframe): 出場訊號。季頻字串索引（如 `2024-Q1`）會先轉為財報公告日再對齊；日期比進場稀疏時的處理方式見 `exit_mode`。
          nstocks_limit (int)`: 輪動檔數上限，預設為None。
          stop_loss (float | pd.DataFrame): 價格波動輪動訊號，預設為None，不生成輪動訊號。範例：0.1，代表成本價下跌 10% 時產生出場訊號。也可傳入以日期為索引、股票為欄位的 DataFrame，讓每檔股票每天用不同門檻：每天採用該日或之前最近一筆的值，每一格的效果與同值的數字相同，NaN 代表該檔當天不停損。
          take_profit (float | pd.DataFrame): 價格波動輪動訊號，預設為None，不生成輪動訊號。範例：0.1，代表成本價上漲 10% 時產生出場訊號。也可傳入 DataFrame，規則同 `stop_loss`。
          trail_stop (float): 移動停利訊號，預設為 np.inf，不生成移動停利訊號。多單以進場成本為分母，當 (持倉最高價 - 目前價格) / 進場成本 > trail_stop 時產生出場訊號；成本 100、最高價 150、trail_stop=0.2 的門檻為 130。
          trail_stop_activation (float): 啟用移動停利前需先達到的獲利門檻。範例：0.2，代表獲利達 20% 後才啟用移動停利。
          trade_at (str): 價格波動輪動訊號參考價，預設為'close'。可選 `close` 或 `open`。
          rank (pd.Dataframe): 當天進場訊號數量超過 nstocks_limit 時，以 rank 數值越大的股票優先進場。
          exit_mode (str): 出場訊號的對齊方式，只能用關鍵字指定。`'state'`（預設）把出場訊號當成持續到下一筆資料的狀態，`'event'` 只在出場訊號自己的日期出場。要維持 2.1.0～2.2.0 的結果，請傳入 `exit_mode='event'`。其他值會拋出 `ValueError`。

        Returns:
          (pd.DataFrame): data

        Examples:
            價格 > 20 日均線入場, 價格 < 60 日均線出場，最多持有10檔，超過 10 個進場訊號，則以股價淨值比小的股票優先選入。
            ```py
            from finlab import data
            from finlab.backtest import sim

            close = data.get('price:收盤價')
            pb = data.get('price_earning_ratio:股價淨值比')

            sma20 = close.average(20)
            sma60 = close.average(60)

            entries = close > sma20
            exits = close < sma60

            #pb前10小的標的做輪動
            position = entries.hold_until(exits, nstocks_limit=10, rank=-pb)
            sim(position)
            ```

            月營收年增率為負就出場，之後公布的年增率不再是負數才會再進場（預設 `'state'`）；只想在月營收有資料的日期出場時改用 `'event'`。
            ```py
            yoy = data.get('monthly_revenue:去年同月增減(%)')

            position = entries.hold_until(yoy < 0, nstocks_limit=10)
            position_event = entries.hold_until(yoy < 0, nstocks_limit=10, exit_mode='event')
            ```
        """
        from finlab.dataframe.core import FinlabDataFrame as FDF

        align_exit = _exit_aligner(exit_mode)
        validate_stop_parameters(
            stop_loss=stop_loss,
            take_profit=take_profit,
            trail_stop=trail_stop,
            trail_stop_activation=trail_stop_activation,
        )
        frame = cast("FinlabDataFrame", self)
        if nstocks_limit is None:
            nstocks_limit = len(frame.columns)

        if not isinstance(exit, FDF):
            exit = FDF(exit)
        if rank is not None and not isinstance(rank, FDF):
            rank = FDF(rank)

        self_reindex = frame.index_str_to_date()
        exit_reindex = exit.index_str_to_date()
        rank_reindex = rank.index_str_to_date() if rank is not None else None

        union_index = self_reindex.index.union(exit_reindex.index)
        intersect_col = self_reindex.columns.intersection(exit_reindex.columns)

        dynamic_stops = isinstance(stop_loss, pd.DataFrame) or isinstance(
            take_profit, pd.DataFrame
        )
        if (
            dynamic_stops
            or stop_loss != -np.inf
            or take_profit != np.inf
            or trail_stop != np.inf
        ):
            from finlab import config

            market = config.get_market()
            price = market.get_price(trade_at, adj=True)

            union_index = union_index.union(
                price.loc[union_index[0] : union_index[-1]].index
            )
            intersect_col = intersect_col.intersection(price.columns)
        else:
            price = None

        if rank_reindex is not None:
            union_index = union_index.union(rank_reindex.index)
            intersect_col = intersect_col.intersection(rank_reindex.columns)

        entry = _align_events(self_reindex, union_index, intersect_col)
        exit = align_exit(exit_reindex, union_index, intersect_col)

        if price is not None:
            price = price.reindex(union_index, method="ffill")[intersect_col]
        stop_loss = stop_table(stop_loss, union_index, intersect_col, name="stop_loss")
        take_profit = stop_table(
            take_profit, union_index, intersect_col, name="take_profit"
        )

        if rank_reindex is not None:
            rank_reindex = rank_reindex.reindex(union_index, method="ffill")[
                intersect_col
            ]
        else:
            rank_reindex = pd.DataFrame(1, index=union_index, columns=intersect_col)

        rank_reindex = rank_reindex.replace([np.inf, -np.inf], np.nan)

        max_rank = rank_reindex.max().max()
        min_rank = rank_reindex.min().min()
        rank_reindex = (rank_reindex - min_rank) / (max_rank - min_rank)
        rank_reindex = rank_reindex.fillna(0)

        ret = np.zeros(entry.shape, dtype=int)
        ret = _rotate_stocks(
            ret,
            entry.astype(int).to_numpy(copy=True),
            exit.astype(int).to_numpy(copy=True),
            nstocks_limit,
            stop_loss,
            take_profit,
            trail_stop,
            trail_stop_activation,
            price=None if price is None else price.to_numpy(copy=True, dtype=float),
            ranking=rank_reindex.to_numpy(copy=True),
        )
        return FDF(ret, index=entry.index, columns=entry.columns).astype(bool)


def _align_events(
    signal: pd.DataFrame, index: pd.Index, columns: pd.Index
) -> pd.DataFrame:
    """Align an entry/exit signal onto the combined timeline as discrete events.

    Signals fire only on their own rows: index gaps and NaN cells mean "no
    signal" and are never forward-filled, so a sparse (weekly/monthly/single
    day) entry or exit acts once instead of persisting across denser rows.
    """
    return signal.reindex(index)[columns].astype(float).fillna(0.0)


def _align_state(
    signal: pd.DataFrame, index: pd.Index, columns: pd.Index
) -> pd.DataFrame:
    """Align an exit signal onto the combined timeline as a persisting state.

    Each index gap copies the signal's previous row, so a sparse
    (weekly/monthly/quarterly) exit keeps applying until its next row. NaN
    cells still mean "no signal": a gap copies a NaN row as NaN and never
    reaches back to an earlier True.

    The gap copies the previous row in index order, which on a descending
    index is a later date, so dates must run from old to new.
    """
    if not signal.index.is_monotonic_increasing:
        raise ValueError(
            "exit_mode='state' needs exit dates sorted from old to new; "
            "call exit.sort_index() first"
        )
    return signal.reindex(index, method="ffill")[columns].astype(float).fillna(0.0)


_EXIT_ALIGNERS: dict[str, _ExitAligner] = {
    "state": _align_state,
    "event": _align_events,
}


def _exit_aligner(exit_mode: object) -> _ExitAligner:
    """Return the exit alignment for *exit_mode*, rejecting anything else."""
    if not isinstance(exit_mode, str) or exit_mode not in _EXIT_ALIGNERS:
        valid = " or ".join(repr(mode) for mode in _EXIT_ALIGNERS)
        raise ValueError(f"exit_mode must be {valid}, got {exit_mode!r}")
    return _EXIT_ALIGNERS[exit_mode]


def _rotate_stocks(
    ret: np.ndarray,
    entry: np.ndarray,
    exit: np.ndarray,
    nstocks_limit: int,
    stop_loss: float | StopTable = -np.inf,
    take_profit: float | StopTable = np.inf,
    trail_stop: float = np.inf,
    trail_stop_activation: float = 0,
    price: np.ndarray | None = None,
    ranking: np.ndarray | None = None,
) -> np.ndarray:
    """Core stock rotation loop used by hold_until.

    Price stops apply only when ``price`` is given.
    """
    if ranking is None:
        ranking = np.ones(entry.shape)

    ret[0][np.argsort(entry[0], kind="stable")[-nstocks_limit:]] = 1
    ret[0][exit[0] == 1] = 0
    ret[0][entry[0] == 0] = 0

    entry_price = np.empty(entry.shape[1])
    entry_price[:] = np.nan
    max_return = np.ones(entry.shape[1])

    for i in range(1, entry.shape[0]):
        if price is not None:
            _apply_price_stops(
                ret,
                entry_price,
                max_return,
                exit,
                price,
                i,
                _threshold_row(stop_loss, i),
                _threshold_row(take_profit, i),
                trail_stop,
                trail_stop_activation,
            )

        # run signal
        rank = entry[i] * ranking[i] + ret[i - 1] * 3
        rank[exit[i] == 1] = -1
        rank[(entry[i] == 0) & (ret[i - 1] == 0)] = -1

        ret[i][np.argsort(rank)[-nstocks_limit:]] = 1
        ret[i][rank == -1] = 0

    return ret


def _threshold_row(threshold: float | StopTable, i: int) -> float | np.ndarray:
    """Return the thresholds on row *i*; a scalar applies to every row."""
    return threshold.at(i) if isinstance(threshold, StopTable) else threshold


def _apply_price_stops(
    ret: np.ndarray,
    entry_price: np.ndarray,
    max_return: np.ndarray,
    exit: np.ndarray,
    price: np.ndarray,
    i: int,
    stop_loss: float | np.ndarray,
    take_profit: float | np.ndarray,
    trail_stop: float,
    trail_stop_activation: float = 0,
) -> None:
    """Apply stop-loss, take-profit, and trailing-stop logic for row *i*.

    ``stop_loss`` and ``take_profit`` are scalars or per-stock thresholds.
    """

    is_entry = (ret[i - 2] == 0) if i > 1 else (ret[i - 1] == 1)
    is_waiting_for_entry = np.isnan(entry_price) & (ret[i - 1] == 1)
    is_entry |= is_waiting_for_entry

    entry_price[is_entry == 1] = price[i][is_entry == 1]
    max_return[is_entry == 1] = 1.0

    held = ret[i - 1] == 1
    returns = price[i] / entry_price
    stop = held & (
        (returns > 1 + np.abs(take_profit)) | (returns < 1 - np.abs(stop_loss))
    )

    if trail_stop != np.inf:
        max_return[:] = np.where(held, np.maximum(max_return, returns), max_return)
        trail_stop_active = max_return >= 1 + abs(trail_stop_activation)
        stop |= held & trail_stop_active & (returns < max_return - abs(trail_stop))

    exited = (ret[i - 1] == 0) & ~np.isnan(entry_price)
    entry_price[exited] = np.nan
    max_return[exited] = 1.0

    exit[i] |= stop.astype(int)
