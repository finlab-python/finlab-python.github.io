"""Backtest report construction and post-processing.

Handles building trades DataFrames, computing MAE/MFE metrics,
populating Report objects with weights/actions/trade metadata,
and final report assembly including upload and notification.
"""

from __future__ import annotations

import functools
import operator
import os
import sys
import threading
import warnings
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    import datetime

    from finlab.market import Market

    from .config import OperationAndWeight, SimConfig

import numpy as np
import pandas as pd

from finlab.core import mae_mfe as maemfe
from finlab.core import report
from finlab.core.upload import (
    UPLOAD_ERROR,
    UPLOAD_PENDING,
    UPLOAD_SKIPPED,
    UPLOAD_SUCCESS,
    StrategyUploadWarning,
    resolve_upload_name,
)

from .helpers import clip_mae_mfe_exit


class SimulationResultLike(Protocol):
    creturn: pd.Series
    position: pd.DataFrame
    trades: pd.DataFrame
    mae_mfe: pd.DataFrame
    operation_and_weight: OperationAndWeight
    org_position_index: pd.Index
    price: pd.DataFrame


def _is_pyodide_runtime() -> bool:
    return sys.platform == "emscripten"


def refine_mae_mfe(
    mae_mfe_window_step: int,
    touched_exit: bool,
    stop_loss: np.ndarray,
    take_profit: np.ndarray,
) -> pd.DataFrame:
    """Process raw mae_mfe data into a structured MultiIndex DataFrame.

    Touched exits clip each trade's exit metrics to its own thresholds.
    """
    if len(maemfe.mae_mfe) == 0:
        return pd.DataFrame()

    m = pd.DataFrame(maemfe.mae_mfe)
    nsets = int((m.shape[1] - 1) / 6)
    metrics = ["mae", "gmfe", "bmfe", "mdd", "pdays", "return"]

    tuples: list[tuple[int | str, str]] = functools.reduce(
        operator.iadd,
        [
            [
                (n, metric) if n == "exit" else (n * mae_mfe_window_step, metric)
                for metric in metrics
            ]
            for n in [*range(nsets), "exit"]
        ],
        [],
    )

    m.columns = pd.MultiIndex.from_tuples(tuples, names=["window", "metric"])
    m.index.name = "trade_index"
    m[m == -1] = np.nan

    if touched_exit and len(m) > 0 and "exit" in m.columns:
        m["exit"] = clip_mae_mfe_exit(m.exit.copy(), stop_loss, take_profit)

    return m


def build_trades_df(
    trades_raw: list[list[object]],
    tz: datetime.tzinfo | None,
    datetime_unit: str = "ns",
) -> pd.DataFrame:
    """Convert raw trade data from the Cython core into a DataFrame."""

    def convert_datetime_series(df: pd.DataFrame) -> pd.DataFrame:
        cols = ["entry_date", "exit_date", "entry_sig_date", "exit_sig_date"]
        if tz is None:
            df[cols] = df[cols].apply(lambda s: pd.to_datetime(s, unit=datetime_unit))
        else:
            df[cols] = df[cols].apply(
                lambda s: pd.to_datetime(s, unit=datetime_unit, utc=True).dt.tz_convert(
                    tz
                )
            )
        return df

    def assign_exit_nat(df: pd.DataFrame) -> pd.DataFrame:
        cols = ["exit_date", "exit_sig_date"]
        df[cols] = df[cols].loc[df.exit_index != -1]
        return df

    return (
        pd.DataFrame(
            trades_raw,
            columns=[
                "symbol",
                "entry_date",
                "exit_date",
                "entry_sig_date",
                "exit_sig_date",
                "position",
                "period",
                "entry_index",
                "exit_index",
            ],
        )
        .rename_axis("trade_index")
        .pipe(convert_datetime_series)
        .pipe(assign_exit_nat)
    )


def populate_report(
    r: report.Report,
    cfg: SimConfig,
    trades: pd.DataFrame,
    m: pd.DataFrame,
    operation_and_weight: OperationAndWeight,
    org_position_index: pd.DatetimeIndex,
    price: pd.DataFrame,
    market: Market,
) -> report.Report:
    """Attach weights, actions, trade metadata, and analyses to the report."""
    r.resample = cfg.resample
    # A per-date, per-stock stop has no single threshold to report or upload.
    r.stop_loss = None if isinstance(cfg.stop_loss, pd.DataFrame) else cfg.stop_loss
    r.take_profit = (
        None if isinstance(cfg.take_profit, pd.DataFrame) else cfg.take_profit
    )
    r.trail_stop = cfg.trail_stop
    r.trail_stop_activation = cfg.trail_stop_activation
    r.live_performance_start = cfg.live_performance_start
    r.mae_mfe = m
    r.trades = trades

    _attach_weights(r, operation_and_weight, org_position_index)
    _attach_actions(r, operation_and_weight)
    _map_stock_names(r, trades, market, cfg, price)
    _attach_trade_prices(r, cfg, market)
    _merge_mae_mfe_into_trades(r, trades)

    r.data_readiness = cfg.data_readiness
    r.planned_rebalance_date = cfg.planned_rebalance_date
    return r


def _attach_weights(
    r: report.Report,
    operation_and_weight: OperationAndWeight,
    org_position_index: pd.DatetimeIndex,
) -> None:
    """Set weights and next_weights on the report from operation data."""
    if len(operation_and_weight["weights"]) != 0:
        r.weights = pd.Series(operation_and_weight["weights"])
        r.weights.index = r.position.columns[r.weights.index]
    else:
        r.weights = pd.Series(dtype="float64")

    if len(operation_and_weight["next_weights"]) != 0:
        r.next_weights = pd.Series(operation_and_weight["next_weights"])
        r.next_weights.index = r.position.columns[r.next_weights.index]
    else:
        r.next_weights = pd.Series(dtype="float64")

    r.weights.name = org_position_index[operation_and_weight["weight_time"]]
    r.next_weights.name = org_position_index[operation_and_weight["next_weight_time"]]


def _attach_actions(
    r: report.Report,
    operation_and_weight: OperationAndWeight,
) -> None:
    """Set the actions series on the report."""
    if len(operation_and_weight["actions"]) != 0:
        r.actions = pd.Series(operation_and_weight["actions"])
        r.actions.index = r.position.columns[r.actions.index]
    else:
        r.actions = pd.Series(dtype=object)


def _map_stock_names(
    r: report.Report,
    trades: pd.DataFrame,
    market: Market,
    cfg: SimConfig,
    price: pd.DataFrame,
) -> None:
    """Map stock IDs to names/industries and handle action-based trade updates."""
    snames = market.get_asset_id_to_name()
    industry = market.get_industry()

    def f_id_to_name(sid: str) -> str:
        return f"{sid + ' ' + snames[sid] if sid in snames else sid}"

    def f_id_to_industry(sid: str) -> str:
        return industry.get(sid, "")

    if len(r.actions) != 0:
        _process_action_signals(r, trades, price)

    if len(trades) != 0:
        codes = r.trades.symbol
        r.trades["industry"] = codes.map(f_id_to_industry)
        r.trades["symbol"] = codes.map(f_id_to_name)
        r.trades["stock_id"] = codes
        r.trades["name"] = codes.map(snames).fillna("")

    if hasattr(r, "actions") and len(r.actions) != 0:
        r.actions.index = r.actions.index.map(f_id_to_name)

    r.weights.index = r.weights.index.map(f_id_to_name)
    r.next_weights.index = r.next_weights.index.map(f_id_to_name)


def _process_action_signals(
    r: report.Report,
    trades: pd.DataFrame,
    price: pd.DataFrame,
) -> None:
    """Update trades based on exit/enter action signals."""
    actions = r.actions
    sell_sids = actions[actions == "exit"].index
    instant_exit_mask = (
        (actions == "sl")
        | (actions == "tp")
        | (actions == "sl_enter")
        | (actions == "tp_enter")
    )
    sell_instant_sids = actions[instant_exit_mask].index
    buy_sids = actions[actions == "enter"].index

    if len(sell_instant_sids):
        r.next_trading_date = price.index[-1]

    if len(trades):
        if set(sell_sids) - set(trades.symbol[trades.exit_sig_date.isnull()]):
            raise ValueError("Sell signals contain symbols not found in open trades")

        if len(sell_sids):
            temp = trades.loc[trades.symbol.isin(sell_sids), "exit_sig_date"].fillna(
                r.position.index[-1]
            )
            trades.loc[trades.symbol.isin(sell_sids), "exit_sig_date"] = temp

        temp = trades.loc[
            trades.symbol.isin(sell_instant_sids), "exit_sig_date"
        ].fillna(price.index[-1])
        trades.loc[trades.symbol.isin(sell_instant_sids), "exit_sig_date"] = (
            temp.to_numpy()
        )

        if len(buy_sids) or len(r.position):
            r.trades = pd.concat(
                [
                    r.trades,
                    pd.DataFrame(
                        {
                            "symbol": buy_sids,
                            "entry_date": pd.NaT,
                            "entry_sig_date": r.position.index[-1],
                            "exit_date": pd.NaT,
                            "exit_sig_date": pd.NaT,
                        }
                    ),
                ],
                ignore_index=True,
            )

        r.trades["exit_sig_date"] = pd.to_datetime(r.trades.exit_sig_date)


def _prefilter_for_trade_dates(
    df: pd.DataFrame,
    trades: pd.DataFrame,
    date_cols: list[str] | str,
) -> pd.DataFrame:
    """Return a slice of ``df`` restricted to the unique trade dates.

    ``Report.add_trade_info`` would otherwise reindex ``df`` against
    ``df.index ∪ combined_dates`` inside the Cython core, materialising
    a transient copy sized like the full history. Passing a pre-sliced
    frame (forward-filled from ``df`` so values at non-trading-day trade
    dates are preserved) turns that internal reindex into a no-op.
    """

    combined = _trade_date_index(trades, date_cols)
    if len(combined) == 0:
        return df.iloc[0:0]

    valid_dates = combined[~combined.isna()].sort_values()
    if combined.hasnans and len(df) > 0:
        valid_dates = valid_dates.union(pd.Index([df.index[-1]]))

    if len(valid_dates) == 0:
        return df.iloc[0:0]

    return df.reindex(valid_dates, method="ffill")


def _trade_date_index(
    trades: pd.DataFrame,
    date_cols: list[str] | str,
) -> pd.Index:
    """Collect trade dates with pandas dtype semantics intact.

    ``Series.values`` loses timezone metadata for datetimetz columns, and
    dropping ``NaT`` changes ``Report.add_trade_info``'s open-trade fill
    behavior. Concatenating the Series lets pandas preserve both details
    before de-duplicating.
    """

    cols = [date_cols] if isinstance(date_cols, str) else list(date_cols)
    series = [trades[c] for c in cols if c in trades.columns]
    if not series:
        return pd.Index([])

    combined = pd.concat(series, ignore_index=True)
    if combined.empty:
        return pd.Index([], dtype=combined.dtype)

    return pd.Index(combined.unique())


def _attach_trade_prices(
    r: report.Report,
    cfg: SimConfig,
    market: Market,
) -> None:
    """Add trade price and adj_close info, run liquidity analysis if applicable."""
    trade_at_price = cfg.trade_at_price
    if isinstance(trade_at_price, str):
        trade_price_data = market.get_trading_price(trade_at_price, adj=False)
    else:
        trade_price_data = trade_at_price

    # Open trades are valued at the last bar, which must not pass end_date.
    if cfg.end_date is not None:
        trade_price_data = trade_price_data.loc[trade_price_data.index <= cfg.end_date]

    trade_price_slim = _prefilter_for_trade_dates(
        trade_price_data, r.trades, ["entry_date", "exit_date"]
    )
    r.add_trade_info("trade_price", trade_price_slim, ["entry_date", "exit_date"])

    adj_close_slim = _prefilter_for_trade_dates(
        market.get_price("close", adj=True), r.trades, ["entry_date"]
    )
    r.add_trade_info("adj_close", adj_close_slim, ["entry_date"])

    if len(r.trades) != 0 and market.get_name() == "tw_stock":
        r.run_analysis("Liquidity", display=False)


def _merge_mae_mfe_into_trades(
    r: report.Report,
    trades: pd.DataFrame,
) -> None:
    """Merge exit MAE/MFE data into the trades DataFrame."""
    if len(trades) != 0:
        current_trades = r.trades
        mae_mfe = r.mae_mfe
        exit_mae_mfe = mae_mfe["exit"].copy().drop(columns=["return"])
        r.trades = pd.concat([current_trades, exit_mae_mfe], axis=1)
        r.trades.index.name = "trade_index"
        r.calculate_current_trades()


def _upload_failure_message(result: object) -> str | None:
    """Return why ``Report.upload`` failed, or ``None`` when it succeeded."""
    if isinstance(result, dict) and result.get("status") == UPLOAD_ERROR:
        return str(result.get("message", result))
    if result is False:
        return "upload returned False"
    return None


def _upload_report(r: report.Report, name: str) -> None:
    """Upload a report, record the outcome in ``r.upload_status`` and warn on failure."""
    try:
        message = _upload_failure_message(r.upload(name))
    except Exception as e:  # noqa: BLE001 - every failure must reach the caller
        message = f"{type(e).__name__}: {e}"

    if message is None:
        r.upload_status = {"status": UPLOAD_SUCCESS, "name": name}
        return

    r.upload_status = {"status": UPLOAD_ERROR, "name": name, "message": message}
    warnings.warn(
        f"Failed to upload backtest report {name!r}: {message} "
        f"（上傳策略報告 {name!r} 失敗：{message}）",
        StrategyUploadWarning,
        stacklevel=2,
    )


def build_sim_report(
    cfg: SimConfig,
    result: SimulationResultLike,
    next_trading_date: pd.Timestamp,
    suppress_upload: bool = False,
) -> report.Report:
    """Construct the final Report object from raw simulation results.

    Creates the Report, attaches weights/actions/trades via populate_report,
    sends notifications and uploads if configured.

    Args:
        cfg: Simulation configuration.
        result: A _SimulationResult from the execution phase.
        next_trading_date: The next expected trading date.
        suppress_upload: If True, skip the upload step regardless of cfg.upload.
    """
    from .notify import line_notify

    if cfg.market is None:
        raise TypeError("market must be resolved before building report")

    r = report.Report(
        creturn=result.creturn,
        position=result.position,
        fee_ratio=cfg.fee_ratio,
        tax_ratio=cfg.tax_ratio,
        trade_at=cfg.trade_at_price,
        next_trading_date=next_trading_date,
        market=cfg.market,
    )

    r = populate_report(
        r,
        cfg,
        result.trades,
        result.mae_mfe,
        result.operation_and_weight,
        result.org_position_index,
        result.price,
        cfg.market,
    )

    if cfg.notification_enable:
        line_notify(r, cfg.line_access_token, name=cfg.name)

    if not cfg.upload or suppress_upload:
        r.upload_status = {"status": UPLOAD_SKIPPED}
        return r

    name = resolve_upload_name(cfg.name, os.environ)
    r.upload_status = {"status": UPLOAD_PENDING, "name": name}
    if _is_pyodide_runtime():
        _upload_report(r, name)
    else:
        threading.Thread(
            target=_upload_report,
            args=(r, name),
            daemon=False,
        ).start()

    return r
