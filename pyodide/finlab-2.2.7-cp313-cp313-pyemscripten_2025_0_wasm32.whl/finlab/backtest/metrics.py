"""Shared Metrics construction and JSON transport for formal backtests."""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any, cast

from finlab.core.metrics import Metrics  # type: ignore[import-not-found]

if TYPE_CHECKING:
    import pandas as pd


SCHEMA_VERSION = "finlab.agent-research.v2"


def metrics_from_creturn(creturn: pd.Series, backend: str) -> Metrics:
    """Build the same ``Metrics`` type exposed by ``Report.metrics``."""

    metrics = Metrics.from_creturn(creturn)
    metrics.warnings = []
    metrics.provenance = metrics_provenance(creturn, backend)
    return metrics


def metrics_from_nav(nav: pd.Series) -> Metrics:
    """Measure any engine's daily NAV with FinLab's curve-only Metrics.

    Supply costs-adjusted NAV neutralized for deposits/withdrawals. Dates must
    increase with one observation per day; invalid rows are never dropped or
    sorted. This computes caller-provided performance, not audited returns.
    Measurement uses local calendar dates without a timezone, so midnight DST
    transitions do not invalidate otherwise valid daily observations.
    No report, holdings, upload or orders are inferred from the curve.
    """
    import numpy as np
    import pandas as pd

    if not isinstance(nav, pd.Series) or not isinstance(nav.index, pd.DatetimeIndex):
        raise ValueError("NAV must be a Series with a DatetimeIndex")
    dates = nav.index.tz_localize(None).normalize()
    if len(nav) < 2 or not nav.index.is_monotonic_increasing or not dates.is_unique:
        raise ValueError("NAV requires at least two unique, increasing daily dates")
    if nav.dtype.kind not in "iuf":
        raise ValueError("NAV values must be finite positive numbers")
    values = nav.to_numpy(dtype=float, na_value=np.nan)
    if not np.isfinite(values).all() or (values <= 0).any():
        raise ValueError("NAV values must be finite positive numbers")
    with np.errstate(over="ignore", under="ignore"):
        values = values / values[0]
    if not np.isfinite(values).all() or (values <= 0).any():
        raise ValueError("NAV cannot be normalized to finite positive values")
    return metrics_from_creturn(pd.Series(values, index=dates.copy()), "external_nav")


def metrics_to_dict(metrics: Metrics) -> dict[str, float | None]:
    """Serialize the formal screening subset at the JS/JSON boundary."""

    def json_float(value: object) -> float | None:
        number = float(cast("Any", value))
        return number if math.isfinite(number) else None

    return {
        "cagr": json_float(metrics.annual_return()),
        "sharpe_ratio": json_float(metrics.sharpe_ratio()),
        "max_drawdown": json_float(metrics.max_drawdown()),
    }


def metrics_provenance(creturn: pd.Series, backend: str) -> dict[str, Any]:
    daily = creturn.resample("1D").last().dropna()
    return {
        "schema_version": SCHEMA_VERSION,
        "metrics_backend": backend,
        "metrics_only": True,
        "return_series_frequency": "daily",
        "return_observations": len(daily),
        "effective_sample_start": (daily.index[0].isoformat() if len(daily) else None),
        "effective_sample_end": daily.index[-1].isoformat() if len(daily) else None,
    }
