"""Independent daily NTD / integer-lot engine; no Cython simulation calls.

Signals execute strictly on the next available price trading day. Lots stay fixed
between rebalances; daily P&L is lots * multiplier * price change. Stage one
uses adjusted underlying prices and has no expiry, basis or roll mechanics.
"""

from __future__ import annotations

import dataclasses
import html
import json
import warnings
from collections import deque
from functools import cached_property
from typing import TYPE_CHECKING, Any, cast

import numpy as np
import pandas as pd

from finlab.core.metrics import Metrics  # type: ignore[import-not-found]
from finlab.core.report import Report

from .config import SimConfig, _normalize_position_input, _resolve_end_date
from .helpers import (
    filter_position_by_change,
    generate_string_rebalance_dates,
    normalize_position_weights,
)
from .metrics import metrics_provenance

if TYPE_CHECKING:
    from finlab.markets.tw_stock_futures import TWStockFuturesMarket


class FuturesSimulationWarning(UserWarning):
    """A requested integer-lot allocation cannot be funded."""


def _performance_status(curve: pd.Series) -> dict:
    nonpositive = curve.index[curve <= 0]
    return {
        "valid": nonpositive.empty,
        "first_nonpositive_equity": (
            None if nonpositive.empty else nonpositive[0].isoformat()
        ),
        "reason": (
            None
            if nonpositive.empty
            else "Percentage return statistics are unavailable after equity <= 0; "
            "the NTD ledger continues without simulated forced liquidation."
        ),
    }


def _require_positive_equity(curve: pd.Series) -> None:
    status = _performance_status(curve)
    if not status["valid"]:
        raise ValueError(
            f'{status["reason"]} First date: {status["first_nonpositive_equity"]}'
        )


def _json_safe(value: Any) -> Any:
    """Export non-finite statistics as null, including nested NumPy scalars."""
    if isinstance(value, dict):
        return {key: _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, np.generic):
        return _json_safe(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


class FuturesMetrics(Metrics):
    """Reuse return statistics only for paths with strictly positive equity."""

    def _ensure_stats_calculated(self, riskfree_rate: float = 0.02) -> dict:
        _require_positive_equity(self.creturn)
        return super()._ensure_stats_calculated(riskfree_rate)

    def _ensure_alpha_beta_calculated(self) -> tuple:
        _require_positive_equity(self.creturn)
        return super()._ensure_alpha_beta_calculated()

    def _ensure_monthly_return_calculated(self) -> pd.Series:
        _require_positive_equity(self.creturn)
        return super()._ensure_monthly_return_calculated()

    def _ensure_tail_ratio_calculated(self) -> float:
        _require_positive_equity(self.creturn)
        return super()._ensure_tail_ratio_calculated()

    def mae(self) -> float:
        raise NotImplementedError("Futures MAE is unavailable in stage one")

    def mfe(self) -> float:
        raise NotImplementedError("Futures MFE is unavailable in stage one")

    def _ensure_liquidity_calculated(self) -> None:
        raise NotImplementedError("Futures liquidity is unavailable in stage one")

    def _calc_capacity(self, percentage_of_volume: float = 0.05) -> float:
        raise NotImplementedError("Futures liquidity is unavailable in stage one")

    def expired(self) -> float:
        raise NotImplementedError(
            "Futures live data readiness is unavailable in stage one"
        )


class FuturesReport(Report):
    """Report with inherited return statistics and explicit futures ledgers.

    ``trades`` contains FIFO closed lots and marked open lots. ``transactions``
    lists executions and their actual costs; ``account`` reconciles daily NTD
    equity, P&L, commission, tax and margin. No MAE/MFE or stock liquidity
    columns are fabricated. The stock dashboard, cloud upload and stock
    execution adapter are unavailable; display/to_html render a local summary.
    """

    asset_type: str
    account: pd.DataFrame
    lot_positions: pd.DataFrame
    transactions: pd.DataFrame
    futures_config: dict

    @cached_property
    def metrics(self) -> FuturesMetrics:
        return FuturesMetrics(self)

    def is_tradable(self) -> bool:
        return False

    def position_info(self) -> dict:
        raise NotImplementedError(
            "Use lot_positions for futures holdings; stock holdings adapters are unavailable"
        )

    def position_info2(self) -> dict:
        return self.position_info()

    def run_analysis(self, analysis: Any, display: bool = True, **kwargs: Any) -> Any:
        name = analysis if isinstance(analysis, str) else type(analysis).__name__
        if name.lower().removesuffix("analysis") in ("maemfe", "liquidity"):
            raise NotImplementedError(
                f"Futures {name} analysis is unavailable in stage one"
            )
        _require_positive_equity(self.creturn)
        return super().run_analysis(analysis, display=display, **kwargs)

    @property
    def execution(self) -> Any:
        raise NotImplementedError(
            "Stage-one futures reports cannot be used for live stock execution"
        )

    @execution.setter
    def execution(self, value: Any) -> None:
        raise NotImplementedError(
            "Stage-one futures reports cannot be used for live stock execution"
        )

    def upload(self, name: str | None = None) -> None:
        raise NotImplementedError(
            "Futures report cloud upload is not supported in stage one"
        )

    def get_mae_mfe(self) -> pd.DataFrame:
        raise NotImplementedError("Futures MAE/MFE is not supported in stage one")

    def get_stats(self, resample: Any = None, riskfree_rate: float = 0.02) -> dict:
        """Reject ratio statistics for the whole path after nonpositive equity.

        Do not truncate to a profitable-looking prefix or invent a margin-call
        model. Account and FIFO ledgers retain the complete NTD losses.
        """
        _require_positive_equity(self.creturn)
        return super().get_stats(resample=resample, riskfree_rate=riskfree_rate)

    def get_metrics(
        self, stats_: dict | None = None, riskfree_rate: float = 0.02
    ) -> dict:
        """Return available statistics without manufacturing missing metrics."""
        performance = _performance_status(self.creturn)
        unavailable = ["mae", "mfe", "stock_liquidity", "live_execution", "rolls"]
        if not performance["valid"]:
            unavailable.append("percentage_return_statistics")
        return {
            "stats": self.get_stats(riskfree_rate=riskfree_rate)
            if performance["valid"]
            else {},
            "performance": performance,
            "futures": self.futures_config,
            "unavailable": unavailable,
        }

    def to_json(self) -> dict:
        return _json_safe(
            {
                "market": self.market.get_name(),
                "timestamps": self.creturn.index.astype(str).tolist(),
                "strategy": self.creturn.tolist(),
                "metrics": self.get_metrics(),
                "trades": json.loads(
                    self.trades.to_json(orient="records", date_format="iso")
                ),
            }
        )

    def _repr_html_(self) -> str:
        performance = _performance_status(self.creturn)
        warning = (
            ""
            if performance["valid"]
            else f'<p role="alert">{html.escape(performance["reason"])} '
            f'First date: {html.escape(performance["first_nonpositive_equity"])}</p>'
        )
        equity = self.account["equity"].to_numpy()
        low = equity.min()
        span = float(np.ptp(equity)) or 1
        points = " ".join(
            f"{i * 600 / max(len(equity) - 1, 1):.2f},{120 - (value - low) * 110 / span:.2f}"
            for i, value in enumerate(equity)
        )
        return (
            "<h2>Single-stock futures: stage one</h2>"
            + warning
            + '<p>Adjusted underlying prices; basis, expiry/roll gaps, margin calls, '
            'MAE/MFE and stock liquidity are unavailable. Costs are in NTD.</p>'
            f'<p>{html.escape(str(self.futures_config))}</p>'
            '<svg viewBox="0 0 600 130" role="img" aria-label="Equity in NTD">'
            f'<polyline points="{points}" fill="none" stroke="steelblue" stroke-width="2"/></svg>'
            '<h3>Daily account (NTD)</h3>'
            + self.account.to_html()
            + "<h3>Lots</h3>"
            + self.lot_positions.to_html()
            + "<h3>Executions and costs</h3>"
            + self.transactions.to_html(index=False)
            + "<h3>FIFO trades (return on entry notional)</h3>"
            + self.trades.to_html(index=False)
        )

    def to_html(self, path: str, title: str | None = None) -> None:
        title = html.escape(
            title if title is not None else "Single-stock futures: stage one"
        )
        with open(path, "w", encoding="utf-8") as stream:
            stream.write(
                f'<!doctype html><html><head><meta charset="utf-8"><title>{title}</title>'
                '</head><body>' + self._repr_html_() + "</body></html>"
            )

    def display(
        self, lagacy: bool = False, save_report_path: str | None = None
    ) -> None:
        from IPython.display import HTML, display

        if save_report_path is not None:
            self.to_html(save_report_path)
        display(HTML(self._repr_html_()))


_TRADE_COLUMNS = [
    "symbol",
    "entry_date",
    "exit_date",
    "entry_sig_date",
    "exit_sig_date",
    "lots",
    "entry_price",
    "exit_price",
    "fee",
    "tax",
    "pnl",
    "return",
]
_TRANSACTION_COLUMNS = [
    "date",
    "signal_date",
    "symbol",
    "lots",
    "price",
    "notional",
    "fee",
    "tax",
]
_ACCOUNT_COLUMNS = [
    "equity",
    "pnl",
    "fee",
    "tax",
    "margin",
    "free_equity",
    "gross_notional",
    "margin_excess",
]
# SimConfig options the lot engine cannot honour; each must stay at its default.
_UNSUPPORTED_OPTIONS = {
    field.name: field.default
    for field in dataclasses.fields(SimConfig)
    if field.name
    in {
        "stop_loss",
        "take_profit",
        "trail_stop",
        "trail_stop_activation",
        "touched_exit",
        "retain_cost_when_rebalance",
        "stop_trading_next_period",
        "mae_mfe_window",
        "mae_mfe_window_step",
        "fee_ratio",
        "tax_ratio",
        "notification_enable",
        "line_access_token",
    }
}


def _is_default(value: object, default: object) -> bool:
    # DataFrame stops are never the default; comparing them is elementwise.
    return not isinstance(value, pd.DataFrame) and value == default


def _validate_options(cfg: SimConfig) -> None:
    unsupported = [
        name
        for name, default in _UNSUPPORTED_OPTIONS.items()
        if not _is_default(getattr(cfg, name), default)
    ]
    if cfg.upload:
        unsupported.append("upload")
    if unsupported:
        raise ValueError(
            "TWStockFuturesMarket stage one does not support: "
            + ", ".join(unsupported)
            + ". Configure per-lot fees and tax on the market; use upload=False."
        )
    if not 0 < cfg.position_limit <= 1:
        raise ValueError("position_limit must be in (0, 1]")
    if not isinstance(cfg.resample, (str, type(None))):
        raise ValueError(
            "Futures stage one supports resample=None or a frequency string"
        )
    if cfg.resample is None and cfg.resample_offset is not None:
        raise ValueError("resample_offset requires a resample frequency")
    if isinstance(cfg.trade_at_price, str) and cfg.trade_at_price != "close":
        raise ValueError(
            'Futures stage one supports trade_at_price="close" or a daily adjusted price DataFrame'
        )


def _validated_frame(frame: pd.DataFrame, name: str) -> pd.DataFrame:
    if not isinstance(frame, pd.DataFrame) or frame.empty:
        raise ValueError(f"{name} must be a nonempty DataFrame")
    if not isinstance(frame.index, pd.DatetimeIndex):
        raise ValueError(f"{name} must have a DatetimeIndex")
    if not frame.index.is_monotonic_increasing or frame.index.hasnans:
        raise ValueError(f"{name} dates must be sorted, unique and nonmissing")
    result = frame.astype(float)
    # Stage one is daily: wall-clock labels must not change signal availability
    # or permit a same-day fill. Keep each market's local trading date/timezone.
    result.index = frame.index.normalize()
    if result.index.has_duplicates:
        raise ValueError(f"{name} must have one row per trading day")
    result.columns = result.columns.astype(str)
    if result.columns.has_duplicates:
        raise ValueError(f"{name} stock IDs must be unique")
    return result


def _schedule(
    position: pd.DataFrame, prices: pd.DataFrame, cfg: SimConfig
) -> dict[int, tuple[pd.Timestamp, np.ndarray]]:
    if cfg.resample is None:
        signals = filter_position_by_change(position)
    else:
        try:
            dates = generate_string_rebalance_dates(
                position.index[0],
                prices.index[-1],
                prices.index[-1],
                cast("str", cfg.resample),
                cfg.resample_offset,
                prices.index.tz,
            )
        except IndexError:
            # The shared helper indexes dates[-1] when this period has no dates.
            return {}
        signals = position.reindex(pd.DatetimeIndex(dates), method="ffill").dropna(
            how="all"
        )
    weights = normalize_position_weights(signals.to_numpy(), cfg.position_limit)
    executions = prices.index.searchsorted(signals.index, side="right")
    return {
        int(execution): (date, row)
        for date, execution, row in zip(signals.index, executions, weights, strict=True)
        if execution < len(prices)
    }


def _funded_lots(
    desired: np.ndarray,
    held: np.ndarray,
    notional: np.ndarray,
    tax_per_lot: np.ndarray,
    margins: np.ndarray,
    equity: float,
    market: TWStockFuturesMarket,
) -> np.ndarray:
    """Proportional reduction including execution costs, then integer rounding.

    A conservative turnover bound guarantees margin plus commissions/tax is
    fundable. Do not distribute leftover cash to a stock according to its
    column order; that would change the requested allocation.
    """
    cost_per_lot = market.fee_per_lot + tax_per_lot
    required = (
        np.abs(desired) @ (notional * margins) + np.abs(desired - held) @ cost_per_lot
    )
    if required <= equity:
        return desired
    closing_cost = float(np.abs(held) @ cost_per_lot)
    bound = float(np.abs(desired) @ (notional * margins + cost_per_lot))
    scale = min(1, max(equity - closing_cost, 0) / bound) if bound else 0
    funded = np.trunc(desired * scale).astype(np.int64)
    warnings.warn(
        "Insufficient margin/equity after fees and tax: proportionally reduced futures lots "
        "（保證金不足，已縮減口數）。",
        FuturesSimulationWarning,
        stacklevel=3,
    )
    return funded


def _trade_row(
    symbol: str,
    entry: dict,
    count: int,
    price: float,
    exit_date: pd.Timestamp,
    exit_signal: pd.Timestamp,
    exit_fee_per_lot: float,
    exit_tax_per_lot: float,
    market: TWStockFuturesMarket,
) -> list:
    """FIFO row for ``count`` lots; open lots pass NaT exits and zero exit costs."""
    multiplier = market.contract_multiplier
    fee = count * (market.fee_per_lot + exit_fee_per_lot)
    tax = count * (entry["tax"] + exit_tax_per_lot)
    signed = count * entry["side"]
    pnl = signed * multiplier * (price - entry["price"]) - fee - tax
    return [
        symbol,
        entry["date"],
        exit_date,
        entry["signal"],
        exit_signal,
        signed,
        entry["price"],
        price,
        fee,
        tax,
        pnl,
        pnl / (count * multiplier * entry["price"]),
    ]


def _record_execution(
    inventory: deque,
    trades: list[list],
    symbol: str,
    delta: int,
    price: float,
    tax_per_lot: float,
    date: pd.Timestamp,
    signal: pd.Timestamp,
    market: TWStockFuturesMarket,
) -> None:
    remaining = abs(delta)
    side = 1 if delta > 0 else -1
    while remaining and inventory and inventory[0]["side"] != side:
        entry = inventory[0]
        count = min(remaining, entry["count"])
        trades.append(
            _trade_row(
                symbol,
                entry,
                count,
                price,
                date,
                signal,
                market.fee_per_lot,
                tax_per_lot,
                market,
            )
        )
        entry["count"] -= count
        remaining -= count
        if not entry["count"]:
            inventory.popleft()
    if remaining:
        inventory.append(
            {
                "side": side,
                "count": remaining,
                "price": price,
                "date": date,
                "signal": signal,
                "tax": tax_per_lot,
            }
        )


def _default_cutoff(index: pd.DatetimeIndex, price_end: pd.Timestamp) -> pd.Timestamp:
    from .sim import _signals_reach_price_end

    available = index[index <= price_end]
    return (
        price_end if _signals_reach_price_end(available, price_end) else available[-1]
    )


def _prepare_frames(
    position: pd.DataFrame | pd.Series, cfg: SimConfig, market: TWStockFuturesMarket
) -> tuple[pd.DataFrame, pd.DataFrame]:
    position = _normalize_position_input(position)
    if isinstance(position, pd.Series):
        position = position.to_frame()
    position = _validated_frame(position, "position").fillna(0)
    if not np.isfinite(position.to_numpy()).all():
        raise ValueError("position weights must be finite")
    price_data = (
        cfg.trade_at_price
        if isinstance(cfg.trade_at_price, pd.DataFrame)
        else market.get_price("close", adj=True)
    )
    symbols = position.columns.tolist()
    if isinstance(price_data, pd.DataFrame):
        # Validate and copy only the traded columns, not the whole market table.
        missing = set(symbols) - set(price_data.columns.astype(str))
        if missing:
            raise ValueError(f"Prices missing stock IDs: {sorted(missing)}")
        price_data = price_data.loc[:, price_data.columns.astype(str).isin(symbols)]
    prices = _validated_frame(price_data, "price")
    if prices.index.tz != position.index.tz:
        raise ValueError("position and price must use the same timezone")
    if cfg.end_date is not None:
        cutoff = _resolve_end_date(cfg.end_date, prices.index.tz)
        position = position.loc[position.index <= cutoff]
        prices = prices.loc[prices.index <= cutoff]
    if position.empty or prices.empty:
        raise ValueError("end_date leaves no position or price data")
    if cfg.end_date is None:
        prices = prices.loc[: _default_cutoff(position.index, prices.index[-1])]
    prices = prices.loc[prices.index >= position.index[0]].reindex(columns=symbols)
    if (
        prices.empty
        or not np.isfinite(prices.to_numpy()).all()
        or (prices <= 0).any().any()
    ):
        raise ValueError(
            "All selected daily prices must be finite and positive; missing prices cannot value held lots"
        )
    return position, prices


def _target_lots(
    equity: float,
    weights: np.ndarray,
    notional: np.ndarray,
    market: TWStockFuturesMarket,
    date: pd.Timestamp,
    symbols: list[str],
) -> np.ndarray:
    raw = max(equity, 0) * market.leverage * weights / notional
    if not np.isfinite(raw).all() or (np.abs(raw) >= np.iinfo(np.int64).max).any():
        raise ValueError("Requested lots exceed integer capacity")
    desired = np.trunc(raw).astype(np.int64)
    too_small = (weights != 0) & (desired == 0)
    if too_small.any():
        warnings.warn(
            f"{date}: insufficient capital for one lot; 0 lots for "
            f"{np.asarray(symbols)[too_small].tolist()}（資金不足一口）。",
            FuturesSimulationWarning,
            stacklevel=3,
        )
    return desired


def simulate_futures(
    position: pd.DataFrame | pd.Series, cfg: SimConfig, metrics_only: bool = False
) -> Any:
    """Run the independent lot engine before stock defaults or licence checks."""
    _validate_options(cfg)
    # sim() selects the explicit or global futures market before stock defaults.
    market = cast("TWStockFuturesMarket", cfg.market)
    position, prices = _prepare_frames(position, cfg, market)
    symbols = position.columns.tolist()
    margins = np.asarray(market.margin_ratios(symbols))
    events = _schedule(position, prices, cfg)
    values = prices.to_numpy()
    held = np.zeros(len(symbols), dtype=np.int64)
    equity = market.initial_capital
    accounts: list[list] = []
    lots: list[np.ndarray] = []
    transactions: list[list] = []
    trades: list[list] = []
    inventories: list[deque[dict]] = [deque() for _ in symbols]
    for day, date in enumerate(prices.index):
        price = values[day]
        notional = price * market.contract_multiplier
        pnl = (
            float(held @ ((price - values[day - 1]) * market.contract_multiplier))
            if day
            else 0
        )
        equity += pnl
        fees = taxes = 0.0
        if day in events:
            signal, weights = events[day]
            tax_per_lot = notional * market.tax_ratio
            desired = _target_lots(equity, weights, notional, market, date, symbols)
            funded = _funded_lots(
                desired, held, notional, tax_per_lot, margins, equity, market
            )
            delta = funded - held
            for column in np.flatnonzero(delta):
                count = int(delta[column])
                fee = abs(count) * market.fee_per_lot
                tax = abs(count) * tax_per_lot[column]
                fees += fee
                taxes += tax
                transactions.append(
                    [
                        date,
                        signal,
                        symbols[column],
                        count,
                        price[column],
                        abs(count) * notional[column],
                        fee,
                        tax,
                    ]
                )
                _record_execution(
                    inventories[column],
                    trades,
                    symbols[column],
                    count,
                    price[column],
                    tax_per_lot[column],
                    date,
                    signal,
                    market,
                )
            equity -= fees + taxes
            held = funded
        margin = float(np.abs(held) @ (notional * margins))
        accounts.append(
            [
                equity,
                pnl,
                fees,
                taxes,
                margin,
                equity - margin,
                float(np.abs(held) @ notional),
                margin > equity,
            ]
        )
        lots.append(held)
    for column_index, inventory in enumerate(inventories):
        trades.extend(
            _trade_row(
                symbols[column_index],
                entry,
                entry["count"],
                values[-1, column_index],
                pd.NaT,
                pd.NaT,
                0,
                0,
                market,
            )
            for entry in inventory
        )
    account_index = prices.index
    if position.index[0] < prices.index[0]:
        # A weekend/holiday signal may execute on the first price bar. Include
        # its pre-trade cash observation so return statistics retain that fee.
        account_index = pd.DatetimeIndex([position.index[0]]).append(prices.index)
        accounts.insert(
            0, [market.initial_capital, 0, 0, 0, 0, market.initial_capital, 0, False]
        )
        lots.insert(0, np.zeros(len(symbols), dtype=np.int64))
    account = pd.DataFrame(accounts, index=account_index, columns=_ACCOUNT_COLUMNS)
    if account.margin_excess.any():
        warnings.warn(
            "Held margin exceeds equity on some dates; stage one does not simulate margin calls or forced liquidation. See account.margin_excess.",
            FuturesSimulationWarning,
            stacklevel=2,
        )
    lot_positions = pd.DataFrame(
        lots, index=account_index, columns=symbols, dtype=np.int64
    )
    curve = account.equity / market.initial_capital
    if metrics_only:
        metrics = FuturesMetrics.from_creturn(curve)
        metrics.warnings = []
        metrics.provenance = metrics_provenance(curve, "futures_lots_metrics_only")
        return metrics
    exposure = (
        lot_positions * prices.reindex(account_index) * market.contract_multiplier
    ).fillna(0)
    actual_weights = exposure.div(
        account.equity.where(account.equity > 0), axis=0
    ).where(lot_positions != 0, 0)
    result = FuturesReport(
        curve,
        actual_weights,
        None,
        market.tax_ratio,
        cfg.trade_at_price,
        prices.index[-1] + pd.offsets.BDay(),
        market,
    )
    # Do not rebase away initial transaction costs. The first bar is cash,
    # and creturn/daily_creturn both retain the original NTD capital base.
    result.daily_creturn = curve.resample("1D").last().dropna()
    result.asset_type = "tw_stock_futures"
    result.account = account
    result.lot_positions = lot_positions
    result.transactions = pd.DataFrame(transactions, columns=_TRANSACTION_COLUMNS)
    result.trades = pd.DataFrame(trades, columns=_TRADE_COLUMNS)
    result.weights = actual_weights.iloc[-1].copy()
    result.next_weights = pd.Series(dtype=float)
    result.actions = pd.Series(dtype=object)
    result.resample = cfg.resample
    result.live_performance_start = (
        pd.Timestamp(cfg.live_performance_start)
        if cfg.live_performance_start is not None
        else None
    )
    result.upload_status = {"status": "skipped"}
    result.data_readiness = {
        "final_ready": False,
        "reason": "stage_one_futures_backtest",
    }
    result.futures_config = {
        "contract": market.contract,
        "contract_multiplier": market.contract_multiplier,
        "initial_capital": market.initial_capital,
        "leverage": market.leverage,
        "fee_per_lot": market.fee_per_lot,
        "tax_ratio": market.tax_ratio,
        "margin_ratio": market.margin_ratio,
        "price_assumption": "adjusted_underlying",
    }
    return result
