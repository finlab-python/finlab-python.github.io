"""Canonical backtest package.

Public users should continue importing ``sim`` and ``line_notify`` from
``finlab.backtest``.  Internal implementation lives in focused package
modules such as ``config``, ``report``, and ``notify``.
"""

from .batch import sim_batch
from .config import OperationAndWeight, SimConfig
from .metrics import metrics_from_nav
from .notify import line_notify
from .sim import sim

__all__ = [
    "OperationAndWeight",
    "SimConfig",
    "line_notify",
    "metrics_from_nav",
    "sim",
    "sim_batch",
]
