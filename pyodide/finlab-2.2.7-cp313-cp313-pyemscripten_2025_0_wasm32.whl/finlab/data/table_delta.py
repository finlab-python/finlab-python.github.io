"""Merge a large full table's delta into its cache.

fdata publishes such a table as a base ``<dataset>.feather`` plus
``<dataset>.delta.feather`` (fdata/table_delta.py): the current rows of every
calendar day of the ``date`` column that changed after ``delta_since``, each
with its position in the current table, and in the Arrow schema metadata the
replaced days and the table's row count. A cache dated from ``delta_since`` on
(the delta's ``full_refresh_before`` in the revision index) drops its rows on
the replaced days, keeps the others in order and takes the delta rows at their
positions. Appends, in-place revisions and deletions on any day arrive this
way; the result is accepted only when it hashes to the published table hash.

The merge streams the cache one Arrow record batch at a time, so peak memory
is about one batch plus the delta. The merged table takes the delta's column
types, with dictionary columns decoded as in :mod:`.recent_merge`.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd
import pyarrow as pa
from pyarrow import ipc

from .feather_io import DATE_COLUMN
from .recent_merge import (
    MERGED_WRITE_OPTIONS,
    _conform_batch,
    _plain_output_schema,
    write_verified,
)

if TYPE_CHECKING:
    from collections.abc import Iterable, Iterator

DELTA_SUFFIX = ".delta"
POSITION_COLUMN = "__fdata_delta_position__"
CONTRACT_KEY = b"fdata.delta"
CONTRACT_VERSION = 1
_PANDAS_KEY = b"pandas"
_DAY = "datetime64[D]"


@dataclass(frozen=True)
class TableDelta:
    """A parsed delta: replacement rows, where they go, and which days they replace.

    ``rows`` already has the merged table's schema (dictionaries decoded).
    """

    rows: pa.Table
    positions: np.ndarray
    days: np.ndarray
    num_rows: int

    @classmethod
    def from_feather(cls, payload: bytes) -> TableDelta:
        """Parse a delta file; ``ValueError`` (or an Arrow error) when it is malformed."""
        table = ipc.open_file(pa.py_buffer(payload)).read_all()
        contract = json.loads((table.schema.metadata or {})[CONTRACT_KEY])
        if contract["version"] != CONTRACT_VERSION:
            msg = f"unsupported table delta version {contract['version']}"
            raise ValueError(msg)
        positions = table.column(POSITION_COLUMN).to_numpy()
        num_rows = int(contract["rows"])
        if len(positions) and (
            positions[0] < 0
            or positions[-1] >= num_rows
            or (np.diff(positions) <= 0).any()
        ):
            msg = "table delta positions are not ascending row numbers of the table"
            raise ValueError(msg)
        columns = [name for name in table.column_names if name != POSITION_COLUMN]
        schema = _plain_output_schema(table.schema, columns).with_metadata(
            _pandas_metadata(table.schema)
        )
        rows = pa.Table.from_batches(
            [_conform_batch(batch, schema) for batch in table.to_batches()], schema
        )
        return cls(
            rows=rows,
            positions=positions,
            days=np.asarray(contract["days"], dtype=_DAY),
            num_rows=num_rows,
        )


def _pandas_metadata(schema: pa.Schema) -> dict[bytes, bytes]:
    """The pandas metadata of *schema* without the position column.

    It restores extension dtypes such as ``Int64`` when the merged cache is read,
    as the producer hashed them.
    """
    raw = (schema.metadata or {}).get(_PANDAS_KEY)
    if raw is None:
        return {}
    pandas_metadata = json.loads(raw)
    pandas_metadata["columns"] = [
        column
        for column in pandas_metadata.get("columns", [])
        if column.get("name") != POSITION_COLUMN
    ]
    return {_PANDAS_KEY: json.dumps(pandas_metadata).encode()}


def _merged(source: Iterable[pa.RecordBatch], delta: TableDelta) -> Iterator[pa.Table]:
    """Merge *delta* into the cache batches *source*, in table order.

    Delta row ``i`` follows ``positions[i] - i`` kept cache rows. Raises
    ``ValueError`` when the cache keeps another number of rows than the delta
    leaves room for.
    """
    schema, replacement = delta.rows.schema, delta.rows
    kept_before = delta.positions - np.arange(len(delta.positions))
    kept_total = taken = 0
    for batch in source:
        days = batch.column(DATE_COLUMN).to_numpy(zero_copy_only=False).astype(_DAY)
        replaced = np.isin(days, delta.days)
        kept = pa.Table.from_batches(
            [
                _conform_batch(
                    batch.filter(pa.array(~replaced)) if replaced.any() else batch,
                    schema,
                )
            ]
        )
        end = kept_total + kept.num_rows
        until = int(np.searchsorted(kept_before, end, side="left"))
        if until == taken:
            yield kept
        else:
            # Where each delta row lands among this batch's output rows.
            landing = kept_before[taken:until] - kept_total + np.arange(until - taken)
            is_delta = np.zeros(kept.num_rows + until - taken, dtype=bool)
            is_delta[landing] = True
            order = np.empty(len(is_delta), dtype=np.int64)
            order[~is_delta] = np.arange(kept.num_rows)
            order[is_delta] = np.arange(kept.num_rows, len(is_delta))
            combined = pa.concat_tables([kept, replacement.slice(taken, until - taken)])
            yield combined.take(pa.array(order))
        kept_total, taken = end, until
    if kept_total + replacement.num_rows != delta.num_rows:
        msg = "the cache keeps another number of rows than the table delta expects"
        raise ValueError(msg)
    yield replacement.slice(taken)


def stream_merge_table_delta_feather(
    source_path: str, dest_path: str, delta: TableDelta, expected_hash: str
) -> bool:
    """Merge *delta* into the Feather cache at *source_path*, writing *dest_path*.

    Returns whether the merged table hashes to *expected_hash*; the caller
    promotes or discards ``dest_path``.
    """
    with pa.memory_map(source_path) as source:
        reader = ipc.open_file(source)
        batches = (reader.get_batch(i) for i in range(reader.num_record_batches))
        with ipc.new_file(
            dest_path, delta.rows.schema, options=MERGED_WRITE_OPTIONS
        ) as writer:
            return write_verified(
                _merged(batches, delta),
                expected_hash,
                lambda table, _frame: writer.write(table),
            )


def merge_table_delta_frame(
    df: pd.DataFrame, delta: TableDelta, expected_hash: str
) -> pd.DataFrame | None:
    """Merge *delta* into an in-memory cache; None when the result does not verify."""
    source = pa.Table.from_pandas(df, preserve_index=False).to_batches()
    frames: list[pd.DataFrame] = []
    if not write_verified(
        _merged(source, delta),
        expected_hash,
        lambda _table, frame: frames.append(frame),
    ):
        return None
    return pd.concat(frames)
