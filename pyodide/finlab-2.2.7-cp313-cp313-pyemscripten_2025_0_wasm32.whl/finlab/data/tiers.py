"""Which cache holds an account's data, and when a free account's cache is current.

The signing service serves a free account other bytes than a paid one under the
same dataset name (Taiwan data comes from a bucket truncated at the free cutoff),
so the two never share a cache. A :class:`FileStorage` keeps free data in its
``free`` namespace, a subfolder no paid read looks into, and every process on the
machine shares it. A :class:`CacheStorage` holds one process's data and is emptied
when its free account turns out to be paid.

The service answers a free account's request for a cached dataset without signing
a download and without comparing dates. Such a request costs no quota, so a free
cache is offered with its stamp, the creation time of the blob it was downloaded
from, and counts as current only while no newer blob exists.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from .context import FREE_ROLE
from .storage import _READ_ONLY_CACHE_ERRNOS, CacheStorage, FileStorage

if TYPE_CHECKING:
    import datetime

    from .auth import FetchMetadata
    from .storage import StorageBackend

logger = logging.getLogger(__name__)

FREE_NAMESPACE = "free"


def offered_storage(storage: StorageBackend, role: str | None) -> StorageBackend | None:
    """The storage whose caches a request offers the signing service, if any.

    Only free caches are offered, and only by an account that may be free: one
    identified as free, or one not yet identified in this process, which offers
    the free caches other processes left behind; the reply says whether it may use
    them. A paid account offers none, and paid caches are never offered.
    """
    if role == FREE_ROLE and isinstance(storage, CacheStorage):
        return storage
    if (
        role in (None, FREE_ROLE)
        and isinstance(storage, FileStorage)
        and storage._has_namespace(FREE_NAMESPACE)
    ):
        return storage._namespace(FREE_NAMESPACE)
    return None


def storage_for_role(storage: StorageBackend, role: str) -> StorageBackend:
    """The storage that holds data downloaded for *role*.

    A CacheStorage serves every role; the caller empties it when a free account
    turns out to be paid. Without a writable folder free data stays in memory.
    """
    if not isinstance(storage, FileStorage):
        return storage
    if role != FREE_ROLE:
        return storage._base()
    try:
        return storage._namespace(FREE_NAMESPACE)
    except OSError as exc:
        if exc.errno not in _READ_ONLY_CACHE_ERRNOS:
            raise
        logger.debug("No writable folder for free data; keeping it in memory: %s", exc)
        return CacheStorage()


def holds_signed_blob(stamp: datetime.datetime, result: FetchMetadata) -> bool:
    """Whether a free cache stamped *stamp* holds the blob an unsigned reply describes.

    A reply without the blob's creation time cannot vouch for any cache.
    """
    return (
        result.role == FREE_ROLE
        and result.time_created is not None
        and stamp >= result.time_created
    )
