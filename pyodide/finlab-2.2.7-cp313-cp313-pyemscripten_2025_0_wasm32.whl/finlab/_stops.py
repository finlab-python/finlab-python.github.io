"""Stop parameters shared by backtests and signal generation."""

from __future__ import annotations

import warnings
from decimal import Decimal
from numbers import Real
from typing import NamedTuple

import numpy as np
import pandas as pd

# Stops that may vary by date and asset; the others take a single number.
_DYNAMIC_STOPS = frozenset({"stop_loss", "take_profit"})
_ALL_ASSETS = slice(None)
_SHOWN_COLUMNS = 5


class StopTable(NamedTuple):
    """Stop thresholds by date and asset, stored once per distinct row.

    ``values[rows[i], j]`` is the threshold of asset ``j`` on date ``i``.
    """

    values: np.ndarray
    rows: np.ndarray

    def at(
        self, dates: int | slice | np.ndarray, assets: slice | np.ndarray = _ALL_ASSETS
    ) -> np.ndarray:
        """Return the thresholds of ``assets`` on the given date positions."""
        return self.values[self.rows[dates], assets]

    def maximum_between(
        self, starts: np.ndarray, ends: np.ndarray, assets: np.ndarray
    ) -> np.ndarray:
        """Largest absolute threshold during each trade, for historical metrics.

        Rows are chronological. An open trade (end=-1) includes the last bar.
        A tighter exit threshold must not erase earlier excursions.
        """
        if len(self.values) == 1:
            return np.abs(self.values[0, assets])
        return np.array(
            [
                np.abs(self.values[self.rows[start] : self.rows[end] + 1, asset]).max()
                for start, end, asset in zip(starts, ends, assets, strict=True)
            ]
        )


def validate_stop_parameters(**parameters: object) -> None:
    """Reject stop inputs that cannot represent their thresholds."""
    for name, value in parameters.items():
        if value is None or isinstance(value, (Real, Decimal, np.bool_)):
            continue
        if name not in _DYNAMIC_STOPS:
            raise TypeError(
                f"{name} only accepts a scalar number; got {type(value).__name__}. "
                "For per-stock or time-varying stops, put exit conditions in "
                "position (False after triggering), or pass them as exit to hold_until()."
            )
        if not isinstance(value, pd.DataFrame):
            raise TypeError(
                f"{name} accepts a scalar number or a DataFrame of per-date, "
                f"per-stock thresholds; got {type(value).__name__}."
            )
        if not isinstance(value.index, pd.DatetimeIndex):
            raise TypeError(
                f"{name} DataFrame needs a DatetimeIndex of the dates each "
                f"threshold becomes available; got {type(value.index).__name__}."
            )
        if value.index.hasnans or not value.index.is_unique:
            raise ValueError(
                f"{name} DataFrame dates must be unique and contain no NaT"
            )
        if not value.columns.is_unique:
            raise ValueError(f"{name} DataFrame stock columns must be unique")


def stop_table(
    stop: float | pd.DataFrame,
    dates: pd.Index | np.ndarray,
    columns: pd.Index | np.ndarray,
    *,
    strictly_before: bool = False,
    unset: float | None = None,
    missing: float | None = None,
    name: str = "stop",
) -> StopTable:
    """Return ``stop`` as thresholds for every date and asset.

    A number applies everywhere without copying. A DataFrame row applies from
    its date, or after it with ``strictly_before``, until the next row. Dates
    before the first row and assets missing from ``stop`` are NaN. ``unset``
    replaces NaN and 0 cells, for callers where 0 means no stop. ``missing``
    can separately disable missing cells without changing scalar-zero behavior.
    """
    if not isinstance(stop, pd.DataFrame):
        return StopTable(
            np.broadcast_to(np.float64(stop), (1, len(columns))),
            np.broadcast_to(np.intp(0), (len(dates),)),
        )
    if not stop.index.is_monotonic_increasing:
        stop = stop.sort_index()
    positions = stop.columns.get_indexer(columns)
    unmatched = positions < 0
    if unmatched.any():
        missing_columns = pd.Index(columns)[unmatched]
        warnings.warn(
            f"{name} DataFrame has no column for {len(missing_columns)} stocks "
            f"(e.g. {missing_columns[:_SHOWN_COLUMNS].tolist()!r}); these stocks "
            "have no stop. Check stock column labels and their types.",
            UserWarning,
            stacklevel=3,
        )
    # Row 0 holds the cells before the first date, so searchsorted needs no offset.
    values = np.empty((len(stop) + 1, len(columns)))
    values[0] = np.nan
    if len(stop.columns):
        source = stop.to_numpy(dtype=float)
        np.take(source, positions, axis=1, out=values[1:], mode="clip")
    values[1:, unmatched] = np.nan
    if unset is not None:
        values[np.isnan(values)] = unset if missing is None else missing
        values[values == 0] = unset
    side = "left" if strictly_before else "right"
    rows = (
        stop.index.searchsorted(dates, side=side)
        if len(stop)
        else np.zeros(len(dates), dtype=np.intp)
    )
    return StopTable(values, rows)
