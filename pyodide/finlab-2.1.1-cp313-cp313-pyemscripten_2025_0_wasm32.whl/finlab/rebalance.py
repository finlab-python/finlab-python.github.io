"""Pure rebalance schedule helpers shared by backtest and lazy execution."""

from __future__ import annotations

import datetime as _dt
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from finlab.core.report import ReportExecution
    from finlab.session_calendar import SessionCalendar

import pandas as pd
from pandas.tseries.frequencies import to_offset
from pandas.tseries.offsets import DateOffset


def generate_string_rebalance_dates(
    position_start: pd.Timestamp | _dt.datetime,
    present_data_date: pd.Timestamp | _dt.datetime,
    price_end: pd.Timestamp | _dt.datetime,
    resample: str,
    resample_offset: str | None,
    tz: object | None,
) -> list[pd.Timestamp]:
    """Build a list of rebalance timestamps from a frequency string."""
    if pd.__version__ >= "2.2.0":
        old_names = ["M", "BM", "SM", "CBM", "Q", "BQ", "A", "Y", "BY"]
        if resample in old_names:
            resample += "E"

    # Pandas now expects weekly weekday suffixes in uppercase, e.g. W-SUN.
    if resample.startswith("W-"):
        head, tail = resample.split("-", 1)
        resample = f"{head}-{tail.upper()}"

    offset_days = 0
    if "+" in resample:
        resample, offset_str = resample.rsplit("+", 1)
        offset_days = int(offset_str)
    elif "-" in resample:
        parts = resample.rsplit("-", 1)
        if parts[-1].isdigit():
            resample = parts[0]
            offset_days = -int(parts[-1])

    alldates = pd.date_range(
        position_start,
        present_data_date + _dt.timedelta(days=360),
        freq=resample,
        tz=tz,
    )
    alldates += DateOffset(days=offset_days)

    if resample_offset is not None:
        alldates += to_offset(resample_offset)

    dates = [d for d in alldates if position_start <= d <= present_data_date]

    return _append_next_boundary(dates, alldates, price_end)


def _append_next_boundary(
    dates: list[pd.Timestamp],
    alldates: pd.DatetimeIndex,
    price_end: pd.Timestamp | _dt.datetime,
) -> list[pd.Timestamp]:
    if not dates or price_end > dates[-1]:
        remain = set(alldates) - set(dates)
        if remain:
            dates.append(min(remain))

    if not dates:
        raise ValueError("resample has no usable dates")
    return dates


def signal_label(value: object) -> pd.Timestamp | None:
    """A signal date label as a Timestamp; None for names like "weight" or NaT."""
    if not isinstance(value, (str, _dt.date)):
        return None
    try:
        label = pd.Timestamp(value)
    except (TypeError, ValueError):
        return None
    return None if pd.isna(label) else label


def _date_label(value: object, timezone: _dt.tzinfo) -> _dt.date | None:
    """Naive signal labels are market dates, never machine-local timestamps."""
    if not isinstance(value, (_dt.date, _dt.datetime, pd.Timestamp)):
        return None
    stamp = pd.Timestamp(value)
    if pd.isna(stamp):
        return None
    if stamp.tzinfo is not None:
        stamp = stamp.tz_convert(timezone)
    return stamp.date()


def execution_session_for(
    label: object, *, now: _dt.datetime | None = None
) -> _dt.date | None:
    """The TW trading session that executes a signal label, if the calendar knows.

    Returns None for non-date labels or when no fresh calendar covers the label.
    """
    from finlab.data.calendar import get_calendar
    from finlab.session_calendar import TW, UTC

    day = _date_label(label, TW)
    if day is None:
        return None
    now = now or _dt.datetime.now(UTC)
    try:
        calendar = get_calendar(now=now)
        calendar.require_usable(now)
        return calendar.window(day).execution_session
    except (ValueError, TypeError, KeyError, OSError):
        return None


def execution_timing(
    execution: ReportExecution,
    *,
    now: _dt.datetime | None = None,
    calendar: SessionCalendar | None = None,
) -> dict[str, Any]:
    """Additive daily TW schedule information; historical sampling stays intact."""
    from finlab.data.calendar import get_calendar
    from finlab.session_calendar import TW, UTC

    now = now or _dt.datetime.now(UTC)
    market = execution.market
    result = {"schema_version": 1, "as_of": now.isoformat(), "status": "unknown"}
    if market.get_name() != "tw_stock" or market.get_freq() not in {"D", "1D"}:
        return {**result, "reason": "unsupported_market"}
    a = _date_label(execution.weights.name, TW)
    c = _date_label(execution.next_weights.name, TW)
    result.update(
        current_rebalance_date=a.isoformat() if a else None,
        next_rebalance_date=c.isoformat() if c else None,
    )
    if c is None:
        return {**result, "reason": "missing_signal_date"}
    pending = isinstance(execution.resample, str) or a != c
    planned = _date_label(getattr(execution, "planned_rebalance_date", None), TW)
    progress_end = c if pending else planned
    result.update(
        planned_rebalance_date=planned.isoformat() if planned else None,
        progress_end_date=progress_end.isoformat() if progress_end else None,
        can_update=False,
        rebalance_due=False,
    )
    try:
        calendar = calendar or get_calendar(now=now)
        calendar.require_usable(now)
        result.update(status="known", calendar_version=calendar.version)
        if pending:
            window = calendar.window(c)
            # Data updates close at the open, but a pending rebalance stays due
            # until the next signal date replaces it, so a run after the
            # execution session's close still trades instead of waiting a period.
            rebalance_end = calendar.close_at(window.execution_session)
            result.update(
                window.as_dict(),
                can_update=window.contains(now),
                rebalance_end_at=rebalance_end.isoformat(),
                rebalance_due=window.update_start_at <= now,
            )
        else:
            result["reason"] = (
                "planned_rebalance" if planned else "no_pending_rebalance"
            )
        _add_holding_progress(
            result, calendar, a, c if pending else planned, planned, now
        )
        return result
    except (ValueError, TypeError, KeyError, OSError) as exc:
        return {
            **result,
            "status": "unknown",
            "can_update": False,
            "rebalance_due": False,
            "reason": "calendar_unavailable",
            "error_type": type(exc).__name__,
        }


def _add_holding_progress(
    result: dict,
    calendar: SessionCalendar,
    start: _dt.date | None,
    end: _dt.date | None,
    planned: _dt.date | None,
    now: _dt.datetime,
) -> None:
    """Optional display metadata cannot disable an otherwise valid update window."""
    from finlab.session_calendar import TW, CalendarUnavailable

    today = now.astimezone(TW).date()
    if planned:
        try:
            result["planned_window"] = calendar.window(planned).as_dict()
        except CalendarUnavailable:
            result["planned_reason"] = "outside_calendar_coverage"
    if start is None or start > today:
        return
    try:
        result["held_sessions"] = calendar.count_sessions(start, today)
        if end is not None and start <= end:
            result["holding_progress"] = calendar.position_progress(start, today, end)
    except CalendarUnavailable:
        result["progress_reason"] = "outside_calendar_coverage"
