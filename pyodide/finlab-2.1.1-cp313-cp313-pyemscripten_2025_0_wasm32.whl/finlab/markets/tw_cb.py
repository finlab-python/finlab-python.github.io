from __future__ import annotations

import datetime

import pandas as pd

from finlab import data
from finlab.market import Market

__all__ = ["TWCBMarket"]


class TWCBMarket(Market):
    """台灣可轉債市場類別

    可轉債的特性：
    - 沒有還原價（無除權息調整）
    - 交易單位為「張」（面額十萬元），非一般股票的「股」
    - 交易稅率為 0.1%（低於普通股的 0.3%）
    - 資料來源為 cb_price 系列

    使用方式：
        from finlab import data
        from finlab.backtest import sim
        from finlab.markets.tw_cb import TWCBMarket

        close = data.get('cb_price:收盤價')
        position = ...  # 計算持倉

        report = sim(position=position, market=TWCBMarket(), ...)
    """

    @staticmethod
    def get_freq() -> str:
        return "1D"

    @staticmethod
    def get_name() -> str:
        return "tw_cb"

    @staticmethod
    def get_benchmark() -> pd.Series:
        return data.get("benchmark_return:發行量加權股價報酬指數").squeeze()

    @staticmethod
    def get_asset_id_to_name() -> dict[str, str]:
        """取得可轉債代碼對應名稱"""
        try:
            cb_info = data.get("cb_published_info")
            if cb_info is not None and not cb_info.empty:
                from finlab.compat import resolve_id_column

                _reset = cb_info.reset_index()
                id_col = resolve_id_column(_reset)
                name_col = next(
                    (col for col in ("債券簡稱", "name") if col in _reset.columns),
                    None,
                )
                if name_col is not None:
                    names = _reset.dropna(subset=[id_col, name_col]).copy()
                    names[name_col] = names[name_col].astype(str).str.strip()
                    names = names[names[name_col].ne("")]
                    if "date" in names.columns:
                        names = names.sort_values(
                            "date", kind="stable", na_position="first"
                        )
                    return dict(
                        zip(names[id_col].astype(str), names[name_col], strict=False)
                    )
        except (ImportError, KeyError, ValueError, RuntimeError):
            pass
        return {}

    @staticmethod
    def get_industry() -> dict[str, str]:
        return {}

    def get_price(
        self, trade_at_price: str | pd.Series | pd.DataFrame, adj: bool = True
    ) -> pd.DataFrame:
        """取得可轉債價格

        Args:
            trade_at_price: 價格類型 ('open', 'close', 'high', 'low', 'volume')
                           或 pd.DataFrame/pd.Series
            adj: 是否使用還原價（可轉債無還原價，此參數會被忽略）

        Returns:
            pd.DataFrame: 可轉債價格資料
        """
        if isinstance(trade_at_price, pd.Series):
            return trade_at_price.to_frame()

        if isinstance(trade_at_price, pd.DataFrame):
            return trade_at_price

        if isinstance(trade_at_price, str):
            if trade_at_price == "volume":
                return data.get("cb_price:成交張數")

            price_name = {
                "open": "開盤價",
                "close": "收盤價",
                "high": "最高價",
                "low": "最低價",
            }[trade_at_price]

            return data.get(f"cb_price:{price_name}")

        raise ValueError(
            "trade_at_price is not allowed (accepted types: pd.DataFrame, pd.Series, str)."
        )

    @staticmethod
    def get_market_value() -> pd.DataFrame:
        return pd.DataFrame()

    def market_close_at_timestamp(
        self, timestamp: pd.Timestamp | None = None
    ) -> pd.Timestamp:
        timestamp = self._normalize_market_timestamp(timestamp, "Asia/Taipei")
        market_close = pd.Timestamp(timestamp.date()) + pd.Timedelta("15:00:00")
        return market_close.tz_localize("Asia/Taipei")

    @staticmethod
    def tzinfo() -> datetime.timezone:
        return datetime.timezone(datetime.timedelta(hours=8))

    def get_reference_price(self) -> dict[str, float]:
        """取得可轉債參考價"""
        try:
            close = data.get("cb_price:收盤價")
            if close is not None and not close.empty:
                return close.iloc[-1].dropna().to_dict()
        except (KeyError, ValueError, RuntimeError):
            pass
        return {}

    @staticmethod
    def default_fee_ratio() -> float:
        return 1.425 / 1000

    @staticmethod
    def default_tax_ratio() -> float:
        # 可轉債交易稅率為 0.1%（普通股為 0.3%）
        return 1 / 1000

    @staticmethod
    def get_odd_lot() -> int:
        return 1

    @staticmethod
    def get_board_lot_size() -> int:
        return 1
