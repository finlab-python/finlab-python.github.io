from __future__ import annotations

import logging
import os
import pkgutil
import warnings
from getpass import getpass
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import TYPE_CHECKING, Any

from finlab.exceptions import LoginError

# Get an instance of a logger
logger = logging.getLogger(__name__)


def _get_version() -> str:
    try:
        return version("finlab")
    except PackageNotFoundError:
        pyproject = Path(__file__).resolve().parents[1] / "pyproject.toml"
        in_project_section = False
        try:
            for line in pyproject.read_text(encoding="utf-8").splitlines():
                stripped = line.strip()
                if stripped == "[project]":
                    in_project_section = True
                    continue
                if in_project_section and stripped.startswith("["):
                    break
                if in_project_section and stripped.startswith("version"):
                    return stripped.split("=", 1)[1].strip().strip('"')
        except OSError:
            return "0+unknown"
        return "0+unknown"


__version__ = _get_version()

if TYPE_CHECKING:
    from finlab.dataframe import FinlabDataFrame

__all__ = ["FinlabDataFrame", "LoginPanel", "__version__", "get_token", "login"]


def __getattr__(name: str) -> Any:
    # Importing finlab.dataframe pulls in pandas/numpy (~1s), which every CLI
    # startup would pay; defer it until FinlabDataFrame is actually accessed.
    if name == "FinlabDataFrame":
        from finlab.dataframe import FinlabDataFrame

        return FinlabDataFrame
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


_DEPRECATION_DEADLINE = "2026/08/01"

_api_token_deprecation_warned: bool = False
_login_deprecation_warned: bool = False
_firebase_fallback_warned: bool = False


def _detect_environment() -> str:
    """Detect runtime environment for migration guidance."""
    if os.environ.get("COLAB_RELEASE_TAG"):
        return "colab"
    if os.environ.get("FUNCTION_TARGET") or os.environ.get("K_SERVICE"):
        return "cloud_functions"
    return "desktop"


def _build_deprecation_message(context: str = "get_token") -> str:
    """Build environment-aware deprecation message."""
    env = _detect_environment()
    if context == "login":
        base = (
            "Passing api_token to finlab.login() is deprecated "
            f"and will be removed after {_DEPRECATION_DEADLINE}."
        )
    else:
        base = f"FINLAB_API_TOKEN is deprecated and will be removed after {_DEPRECATION_DEADLINE}."

    if env == "colab":
        guidance = (
            " Use finlab.login() (without arguments) to authenticate interactively."
        )
    elif env == "cloud_functions":
        guidance = (
            " Run 'python -m finlab token --env' locally, then set "
            "FINLAB_REFRESH_TOKEN, FINLAB_SESSION_ID, and FINLAB_API_KEY "
            "as environment variables."
        )
    else:
        guidance = " Run 'python -m finlab login' to authenticate with the new system."

    return base + guidance


def _warn_api_token_deprecated() -> None:
    """Emit FINLAB_API_TOKEN deprecation warning (once per session)."""
    global _api_token_deprecation_warned
    if not _api_token_deprecation_warned:
        _api_token_deprecation_warned = True
        warnings.warn(
            _build_deprecation_message("get_token"),
            DeprecationWarning,
            stacklevel=3,
        )


class LoginPanel:
    def __init__(self) -> None:
        pass

    def gui_supported(self) -> bool:
        try:
            return (
                "VSCODE_PID" not in os.environ
                and pkgutil.find_loader("IPython") is not None
            )
        except (ImportError, AttributeError):
            return False

    def display_gui(self) -> None:
        from IPython.display import IFrame, clear_output, display

        iframe = IFrame(
            f"https://ai.finlab.tw/api_token/?version={__version__}",
            width=620,
            height=300,
        )
        display(iframe)

        try:
            token = getpass("請從 https://ai.finlab.tw/api_token 複製驗證碼: \n")
        except (EOFError, OSError):
            print("請從 https://ai.finlab.tw/api_token 複製驗證碼: \n")
            token = input("驗證碼：")
        clear_output()
        self.login(token)

    def display_text_input(self) -> None:
        print("請從 https://ai.finlab.tw/api_token 複製驗證碼:\n")
        token = input("驗證碼：")
        self.login(token)
        print("之後可以使用以下方法自動登入")
        print("import finlab")
        print('finlab.login("YOUR API TOKEN")')

    @staticmethod
    def login(token: str) -> None:
        # set token
        token = token[:64]
        os.environ["FINLAB_API_TOKEN"] = token
        print("輸入成功!")


def _login_legacy(api_token: str) -> None:
    """Handle legacy api_token login with deprecation warning."""
    global _login_deprecation_warned
    if not _login_deprecation_warned:
        _login_deprecation_warned = True
        warnings.warn(
            _build_deprecation_message("login"),
            DeprecationWarning,
            stacklevel=3,
        )
    LoginPanel().login(api_token)


def _login_via_auth() -> bool:
    """Attempt new-style auth login.

    Returns True when logged in and False only when the auth module is
    unavailable. Raises ``LoginError`` when the browser login fails or times out.
    """
    try:
        from finlab import auth as _auth
    except ImportError:
        return False

    try:
        if _auth.get_id_token():
            print("已登入（使用快取憑證）。")
            return True
    except ImportError as e:
        if "cryptography" in str(e):
            print("Browser login requires: pip install cryptography")
        logger.debug(f"Auth dependency missing: {e}")
    except (OSError, ValueError, RuntimeError) as e:
        logger.debug(f"Token check failed: {e}")

    try:
        logged_in = _auth.browser_login()
    except (OSError, ValueError, RuntimeError) as e:
        raise _browser_login_error() from e
    if not logged_in:
        raise _browser_login_error()
    return True


def _browser_login_error() -> LoginError:
    return LoginError(
        "FinLab 瀏覽器登入失敗或逾時，目前尚未登入。"
        "請重新執行 finlab.login()，或在終端機執行 `python -m finlab login`。"
        "無法開啟瀏覽器的環境（伺服器、排程）請先在本機登入後執行 "
        "`python -m finlab token --env`，再設定 FINLAB_REFRESH_TOKEN、"
        "FINLAB_SESSION_ID、FINLAB_API_KEY 環境變數。\n"
        "Browser login failed or timed out; you are not logged in. "
        "Run finlab.login() again or `python -m finlab login`. "
        "For headless environments, run `python -m finlab token --env` on a "
        "logged-in machine and set FINLAB_REFRESH_TOKEN, FINLAB_SESSION_ID "
        "and FINLAB_API_KEY."
    )


def login(api_token: str | None = None) -> None:
    """登錄量化平台。

    不傳入參數時啟動瀏覽器登入，成功後憑證存於 ``~/.finlab/credentials.json``，
    之後同一台機器會自動使用。Colab 同樣直接呼叫 ``finlab.login()``。
    無瀏覽器的環境（伺服器、排程）請在本機執行 ``python -m finlab token --env``，
    並設定 ``FINLAB_REFRESH_TOKEN``、``FINLAB_SESSION_ID``、``FINLAB_API_KEY``。

    Args:
        api_token (str): 已棄用的舊版 api_token，請改用瀏覽器登入。

    Raises:
        LoginError: 瀏覽器登入失敗、被拒絕或逾時。
    """
    if api_token:
        _login_legacy(api_token)
        return

    if _login_via_auth():
        return

    # Fallback to old interactive flow
    lp = LoginPanel()
    if lp.gui_supported():
        lp.display_gui()
    else:
        lp.display_text_input()


def _try_firebase_token() -> tuple[str | None, bool]:
    """Try Firebase auth. Return (id_token_or_None, refresh_failed)."""
    try:
        from finlab.auth import get_id_token, get_session
    except ImportError:
        return None, False

    try:
        id_token = get_id_token()
        if id_token:
            return id_token, False
        # get_id_token() returned None -- if a session exists, refresh failed
        return None, get_session() is not None
    except (ImportError, OSError, ValueError, RuntimeError) as e:
        logger.debug(f"Firebase token refresh failed: {e}")
        return None, True


def _get_env_id_token() -> tuple[str, str] | None:
    """Return (token, 'id_token') from env var, or None."""
    if "FINLAB_ID_TOKEN" not in os.environ:
        return None
    return (os.environ["FINLAB_ID_TOKEN"], "id_token")


def _get_env_api_token(firebase_refresh_failed: bool) -> tuple[str, str] | None:
    """Return (token, 'api_token') from env var, or None."""
    if "FINLAB_API_TOKEN" not in os.environ:
        return None
    if firebase_refresh_failed:
        global _firebase_fallback_warned
        if not _firebase_fallback_warned:
            _firebase_fallback_warned = True
            logger.warning(
                "Firebase token refresh failed. "
                "Falling back to FINLAB_API_TOKEN (legacy auth). "
                + _build_deprecation_message("get_token")
            )
    _warn_api_token_deprecated()
    return (os.environ["FINLAB_API_TOKEN"][:64], "api_token")


def get_token() -> tuple[str, str]:
    """取得登錄會員的認證 token。

    認證優先順序：
    1. ~/.finlab/credentials.json (新版 Firebase auth) → 返回 id_token
    2. FINLAB_ID_TOKEN 環境變數 (新版 Firebase auth) → 返回 id_token
    3. FINLAB_API_TOKEN 環境變數 (舊版) → 返回 api_token
    4. 互動式登入

    Returns:
        tuple: (token_string, token_type) where token_type is 'id_token' or 'api_token'
    """
    # Priority 1: New Firebase auth credentials
    id_token, firebase_refresh_failed = _try_firebase_token()
    if id_token:
        if "FINLAB_API_TOKEN" in os.environ:
            _warn_api_token_deprecated()
        return (id_token, "id_token")

    # Priority 2: Environment variable for browser/Pyodide runtimes.
    env_id_result = _get_env_id_token()
    if env_id_result:
        if "FINLAB_API_TOKEN" in os.environ:
            _warn_api_token_deprecated()
        return env_id_result

    # Priority 3: Environment variable (old flow)
    env_result = _get_env_api_token(firebase_refresh_failed)
    if env_result:
        return env_result

    # Priority 4: Interactive login (only if no session exists at all)
    _require_no_stale_session()
    login()
    return _get_token_after_login()


def _require_no_stale_session() -> None:
    """Raise if a session file exists but refresh failed."""
    try:
        from finlab.auth import get_session
    except ImportError:
        return
    if get_session() is not None:
        raise RuntimeError(
            "Token refresh failed (session exists but token expired). "
            "Run `python -m finlab login` to re-authenticate."
        )


def _get_token_after_login() -> tuple[str, str]:
    """Retrieve token after interactive login."""
    try:
        from finlab.auth import get_id_token

        id_token = get_id_token()
        if id_token:
            return (id_token, "id_token")
    except (ImportError, OSError, ValueError, RuntimeError):
        logger.debug("Post-login token retrieval failed")

    if "FINLAB_API_TOKEN" in os.environ:
        _warn_api_token_deprecated()
        return (os.environ["FINLAB_API_TOKEN"][:64], "api_token")

    raise RuntimeError("Login failed. Please run: python -m finlab login")
