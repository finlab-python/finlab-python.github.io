"""Execution engine for lazy wide DataFrame expression trees."""

from __future__ import annotations

import operator
from collections import Counter
from typing import TYPE_CHECKING, Any, cast

import numpy as np
import pandas as pd

from finlab.dataframe.core import FinlabDataFrame
from finlab.dataframe.core import _top_n as _core_top_n
from finlab.dataframe.lazy_nodes import (
    BinaryNode,
    GetitemNode,
    Node,
    ReindexNode,
    RollingNode,
    ScalarNode,
    SourceLike,
    SourceNode,
    StorageSourceNode,
    UnaryNode,
    _children,
    _collect_full_index,
    _collect_sources,
    _source_data,
    _source_index,
    _str_freq,
    _unique_source,
)
from finlab.rebalance import generate_string_rebalance_dates

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator

_BINARY_DISPATCH: dict[str, Any] = {
    "__add__": operator.add,
    "__sub__": operator.sub,
    "__mul__": operator.mul,
    "__truediv__": operator.truediv,
    "__floordiv__": operator.floordiv,
    "__mod__": operator.mod,
    "__pow__": operator.pow,
    "__gt__": operator.gt,
    "__ge__": operator.ge,
    "__lt__": operator.lt,
    "__le__": operator.le,
    "__eq__": operator.eq,
    "__ne__": operator.ne,
    "__and__": operator.and_,
    "__or__": operator.or_,
    "__xor__": operator.xor,
}

_INDEX_CONVERSION_METHODS = {"deadline", "index_str_to_date"}
_INDEX_UNKNOWN_METHODS = {"hold_until"}
_REQUESTED_TARGET_DATES = "__requested_target_dates__"
_MISSING = object()


def collect(
    node: Node,
    dates: pd.DatetimeIndex | list | None = None,
) -> pd.DataFrame:
    """Execute at explicit dates, or all dates if *dates* is None."""
    _cache = _build_execution_cache(node)
    full_index = _collect_full_index(node, _cache)

    if _is_string_index(full_index):
        result = _native_result_as_dates(node, _cache)
        if dates is not None:
            return result.reindex(pd.DatetimeIndex(dates), method="ffill")
        return result

    if dates is None:
        target_pos = np.arange(len(full_index))
    else:
        requested_dates = pd.DatetimeIndex(dates)
        target_pos = _positions_for_dates(full_index, requested_dates)
        _remember_requested_dates(_cache, full_index, target_pos, requested_dates)
    return _execute(node, target_pos, full_index, _cache)


def rebalance(
    node: Node,
    freq: str | pd.Index | list | Node = "M",
    offset: str | None = None,
    start: str | pd.Timestamp | None = None,
    end: str | pd.Timestamp | None = None,
) -> pd.DataFrame:
    """Execute, computing only at rebalance dates."""
    if isinstance(freq, Node):
        _cache = _build_execution_cache(node, freq)
        full_index = _collect_full_index(node, _cache)
        targets = _filter_dates(_targets_from_rebalance_node(freq, _cache), start, end)
        return _rebalance_at_targets(node, targets, full_index, _cache)

    _cache = _build_execution_cache(node)
    full_index = _collect_full_index(node, _cache)

    if not isinstance(freq, str):
        targets = _filter_dates(pd.DatetimeIndex(freq), start, end)
        return _rebalance_at_targets(node, targets, full_index, _cache)

    if _is_string_index(full_index):
        result = _native_result_as_dates(node, _cache)
        targets = _filter_dates(
            _rebalance_dates(result.index, freq, offset), start, end
        )
        return result.reindex(targets, method="ffill")

    targets = _filter_dates(_rebalance_dates(full_index, freq, offset), start, end)
    target_pos = _positions_for_dates(full_index, targets)
    _remember_requested_dates(_cache, full_index, target_pos, targets)
    return _execute(node, target_pos, full_index, _cache)


def _rebalance_at_targets(
    node: Node,
    targets: pd.DatetimeIndex,
    full_index: pd.Index,
    _cache: dict,
) -> pd.DataFrame:
    if _is_string_index(full_index):
        result = _native_result_as_dates(node, _cache)
        return result.reindex(targets)
    target_pos = _positions_for_dates(full_index, targets)
    _remember_requested_dates(_cache, full_index, target_pos, targets)
    result = _execute(node, target_pos, full_index, _cache)
    return result.reindex(targets)


def _targets_from_rebalance_node(node: Node, _cache: dict) -> pd.DatetimeIndex:
    full_index = _collect_full_index(node, _cache)
    if _is_string_index(full_index):
        result = _native_result_as_dates(node, _cache)
    else:
        result = _execute(node, np.arange(len(full_index)), full_index, _cache)
        if not isinstance(result, FinlabDataFrame):
            result = FinlabDataFrame(result)
        result = result.index_str_to_date()
    return pd.DatetimeIndex(result.index)


def _positions_for_dates(full_index: pd.Index, dates: pd.DatetimeIndex) -> np.ndarray:
    """Snap *dates* to nearest previous positions in *full_index*."""
    pos = full_index.searchsorted(dates, side="right") - 1
    pos = np.clip(pos, 0, len(full_index) - 1)
    return np.unique(pos)


def _requested_dates_key(full_index: pd.Index, target_pos: np.ndarray) -> tuple:
    return (id(full_index), target_pos.tobytes())


def _remember_requested_dates(
    _cache: dict,
    full_index: pd.Index,
    target_pos: np.ndarray,
    dates: pd.DatetimeIndex,
) -> None:
    if len(target_pos) == 0:
        return
    requested = _cache.setdefault(_REQUESTED_TARGET_DATES, {})
    requested[_requested_dates_key(full_index, target_pos)] = pd.DatetimeIndex(dates)


def _requested_target_dates(
    _cache: dict,
    full_index: pd.Index,
    target_pos: np.ndarray,
) -> pd.DatetimeIndex | None:
    requested = _cache.get(_REQUESTED_TARGET_DATES)
    if not isinstance(requested, dict):
        return None
    return requested.get(_requested_dates_key(full_index, target_pos))


def _target_dates_for_reindex(
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> pd.Index:
    requested = _requested_target_dates(_cache, full_index, target_pos)
    if requested is not None:
        return requested
    return full_index[target_pos]


def _is_string_index(index: pd.Index) -> bool:
    return len(index) > 0 and isinstance(index[0], str)


def _filter_dates(
    dates: pd.DatetimeIndex,
    start: str | pd.Timestamp | None,
    end: str | pd.Timestamp | None,
) -> pd.DatetimeIndex:
    if start is not None:
        dates = dates[dates >= pd.Timestamp(start)]
    if end is not None:
        dates = dates[dates <= pd.Timestamp(end)]
    return dates


def _native_result_as_dates(node: Node, _cache: dict | None = None) -> pd.DataFrame:
    result = _execute_on_native(node, {} if _cache is None else _cache)
    return _frame_index_str_to_date(result)


def _frame_index_str_to_date(result: Any) -> pd.DataFrame:
    if not isinstance(result, FinlabDataFrame):
        result = FinlabDataFrame(result)
    return result.index_str_to_date()


def _reindex_dates_to_target(
    result: pd.DataFrame,
    target_pos: np.ndarray,
    full_index: pd.Index,
    *,
    include_result_index: bool = False,
) -> pd.DataFrame:
    target_dates = full_index[target_pos]
    if include_result_index:
        target_dates = target_dates.union(result.index)
    valid = target_dates[target_dates >= result.index[0]]
    return result.reindex(valid, method="ffill")


def _is_full_history_target(
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> bool:
    return _requested_target_dates(
        _cache, full_index, target_pos
    ) is None and np.array_equal(target_pos, np.arange(len(full_index)))


def _execute_on_native(node: Node, _cache: dict) -> pd.DataFrame:
    """Execute a string-indexed subtree on its native index."""
    sources = _collect_sources(node)
    if not sources:
        raise ValueError("No source found in subtree")
    native_index = _source_index(sources[0], _cache)
    native_pos = np.arange(len(native_index))
    return _execute(node, native_pos, native_index, _cache)


def _rebalance_dates(
    index: pd.Index, freq: str, offset: str | None = None
) -> pd.DatetimeIndex:
    """Build rebalance dates using the same logic as sim()."""
    dates = generate_string_rebalance_dates(
        position_start=index[0],
        present_data_date=index[-1],
        price_end=index[-1],
        resample=freq,
        resample_offset=offset,
        tz=None,
    )
    return pd.DatetimeIndex(dates)


def _expand_pos(
    target_pos: np.ndarray,
    lookback: int,
    n: int,
) -> tuple[np.ndarray, int]:
    if lookback <= 0 or len(target_pos) == 0:
        return target_pos, int(target_pos[0]) if len(target_pos) else 0
    return np.arange(n), 0


def _top_n(df: pd.DataFrame, n: int, *, largest: bool) -> pd.DataFrame:
    """Select top/bottom *n* per row, returning a plain DataFrame.

    Quarterly rows are converted to disclosure dates first and the result stays
    a ``FinlabDataFrame``, matching the eager ``FinlabDataFrame.is_largest``:
    each date only compares public values, and later operators align with the
    remaining quarterly operands the same way.
    """
    if _is_string_index(df.index):
        return _core_top_n(_frame_index_str_to_date(df), n, largest=largest)
    result = _core_top_n(df, n, largest=largest)
    if isinstance(result, FinlabDataFrame):
        result = pd.DataFrame(result)
    return result


def _is_contiguous(pos: np.ndarray) -> bool:
    return len(pos) > 0 and len(pos) == int(pos[-1]) - int(pos[0]) + 1


def _iloc(df: pd.DataFrame, pos: np.ndarray) -> pd.DataFrame:
    if _is_contiguous(pos):
        return df.iloc[int(pos[0]) : int(pos[-1]) + 1]
    return df.iloc[pos]


def _trim_pos(
    result: Any,
    target_pos: np.ndarray,
    slice_start: int,
) -> Any:
    if not isinstance(result, (pd.DataFrame, pd.Series)):
        return result
    return _iloc(result, target_pos - slice_start)


def _trim_index_unknown_result(
    result: Any,
    target_pos: np.ndarray,
    full_index: pd.Index,
    slice_start: int,
    _cache: dict,
) -> Any:
    if not isinstance(result, (pd.DataFrame, pd.Series)):
        return result
    if result.index.equals(full_index):
        return _trim_pos(result, target_pos, slice_start)
    if len(target_pos) == 0:
        return result.iloc[0:0]
    if len(result.index) == 0:
        return result
    if _requested_target_dates(
        _cache, full_index, target_pos
    ) is None and np.array_equal(target_pos, np.arange(len(full_index))):
        return result

    target_dates = _target_dates_for_reindex(target_pos, full_index, _cache)
    if _is_string_index(full_index) and not _is_string_index(result.index):
        return result

    try:
        valid = target_dates[target_dates >= result.index[0]]
    except TypeError:
        valid = target_dates.intersection(result.index)
        return result.reindex(valid)
    return result.reindex(valid, method="ffill")


def _has_positional_index(
    result: Any,
    full_index: pd.Index,
    slice_start: int,
) -> bool:
    if not isinstance(result, (pd.DataFrame, pd.Series)):
        return True
    expected = full_index[slice_start : slice_start + len(result.index)]
    return result.index.equals(expected)


def _build_execution_cache(*nodes: Node) -> dict:
    node_remaining: Counter[int] = Counter()

    def count(current: Node) -> None:
        node_remaining[id(current)] += 1
        for child in _children(current):
            count(child)

    for node in nodes:
        count(node)
    return {
        "__node_remaining__": node_remaining,
        "__node_cache_keys__": {},
        "__alignment_plan_cache__": {},
    }


def _first_datetime_index_value(index: pd.Index) -> pd.Timestamp | None:
    if len(index) == 0 or not isinstance(index, pd.DatetimeIndex):
        return None
    return index[0]


def _native_output_start(node: Node) -> pd.Timestamp | None:
    native = _native_result_as_dates(node)
    if len(native.index) == 0 or _is_string_index(native.index):
        return None
    return native.index[0]


def _child_starts(node: Node, start_fn: Any) -> list[pd.Timestamp]:
    return [
        child_start
        for child in _children(node)
        if (child_start := start_fn(child)) is not None
    ]


def _estimate_unary_output_start(
    node: UnaryNode,
    start_fn: Any,
) -> pd.Timestamp | None:
    starts = _child_starts(node, start_fn)
    if node.method == "hold_until":
        return min(starts) if starts else None
    return starts[0] if starts else None


def _estimate_binary_output_start(
    node: BinaryNode,
    start_fn: Any,
) -> pd.Timestamp | None:
    starts = [s for s in (start_fn(node.left), start_fn(node.right)) if s is not None]
    return max(starts) if starts else None


def _estimate_getitem_output_start(
    node: GetitemNode,
    start_fn: Any,
) -> pd.Timestamp | None:
    starts = [start_fn(node.child)]
    if isinstance(node.key, Node):
        starts.append(start_fn(node.key))
    valid_starts = [s for s in starts if s is not None]
    return max(valid_starts) if valid_starts else None


def _estimate_output_start_once(
    node: Node,
    start_fn: Any,
) -> pd.Timestamp | None:
    if _str_freq(node) is not None:
        return _native_output_start(node)
    if isinstance(node, (SourceNode, StorageSourceNode)):
        return _first_datetime_index_value(_source_index(node))
    if isinstance(node, ScalarNode):
        return None
    if isinstance(node, UnaryNode):
        return _estimate_unary_output_start(node, start_fn)
    if isinstance(node, ReindexNode):
        return start_fn(node.child)
    if isinstance(node, RollingNode):
        return start_fn(node.child)
    if isinstance(node, BinaryNode):
        return _estimate_binary_output_start(node, start_fn)
    if isinstance(node, GetitemNode):
        return _estimate_getitem_output_start(node, start_fn)
    return None


def estimate_output_start(node: Node) -> pd.Timestamp | None:
    """Best-effort first output date for scheduling a lazy expression."""
    memo: dict[int, pd.Timestamp | None] = {}

    def start(current: Node) -> pd.Timestamp | None:
        node_id = id(current)
        if node_id not in memo:
            memo[node_id] = _estimate_output_start_once(current, start)
        return memo[node_id]

    return start(node)


def _node_cache_key(
    node: Node,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> tuple[int, int, bytes] | None:
    if not len(target_pos):
        return None
    key = target_pos.tobytes()
    requested = _requested_target_dates(_cache, full_index, target_pos)
    if requested is not None:
        key += b"\0requested_dates\0" + requested.asi8.tobytes()
    return (id(node), id(full_index), key)


def _should_cache_node_result(node: Node, _cache: dict) -> bool:
    node_remaining = _cache.get("__node_remaining__")
    if node_remaining is None:
        return True
    return node_remaining[id(node)] > 1


def _track_node_cache_key(
    node: Node, cache_key: tuple[int, int, bytes], _cache: dict
) -> None:
    node_cache_keys = _cache.get("__node_cache_keys__")
    if isinstance(node_cache_keys, dict):
        node_cache_keys.setdefault(id(node), set()).add(cache_key)


def _release_node(node: Node, _cache: dict) -> None:
    node_remaining = _cache.get("__node_remaining__")
    node_id = id(node)
    if node_remaining is None or node_id not in node_remaining:
        return
    if node_remaining[node_id] <= 0:
        return

    node_remaining[node_id] -= 1
    if node_remaining[node_id] > 0:
        return

    node_cache_keys = _cache.get("__node_cache_keys__")
    if isinstance(node_cache_keys, dict):
        for cache_key in node_cache_keys.pop(node_id, ()):
            _cache.pop(cache_key, None)

    if isinstance(node, StorageSourceNode):
        _cache.pop(("__source_data__", id(node)), None)
        _cache.pop(("__source_index__", id(node)), None)


def _release_skipped_descendants(node: Node, _cache: dict) -> None:
    for child in _children(node):
        _release_skipped_descendants(child, _cache)
        _release_node(child, _cache)


def _execute(
    node: Node,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict | None = None,
) -> Any:
    """Recursively execute the tree, computing only at *target_pos*."""
    if _cache is None:
        _cache = {}

    cache_key = _node_cache_key(node, target_pos, full_index, _cache)
    if cache_key is not None and cache_key in _cache:
        result = _cache[cache_key]
        _release_skipped_descendants(node, _cache)
        _release_node(node, _cache)
        return result

    result = _execute_inner(node, target_pos, full_index, _cache)
    if cache_key is not None and _should_cache_node_result(node, _cache):
        _cache[cache_key] = result
        _track_node_cache_key(node, cache_key, _cache)
    _release_node(node, _cache)
    return result


def _execute_inner(
    node: Node,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    n = len(full_index)

    if isinstance(node, (SourceNode, StorageSourceNode)):
        src = _source_data(node, _cache)
        if len(src) == n:
            return _iloc(src, target_pos)
        target_dates = full_index[target_pos]
        return src.reindex(target_dates, method="ffill")
    if isinstance(node, ScalarNode):
        return _resolve_scalar_value(node.value, target_pos, full_index)
    if isinstance(node, UnaryNode):
        return _exec_unary(node, target_pos, full_index, _cache)
    if isinstance(node, ReindexNode):
        return _exec_reindex(node, target_pos, full_index, _cache)
    if isinstance(node, RollingNode):
        return _exec_rolling(node, target_pos, full_index, _cache)
    if isinstance(node, BinaryNode):
        return _exec_binary(node, target_pos, full_index, _cache)
    if isinstance(node, GetitemNode):
        return _exec_getitem(node, target_pos, full_index, _cache)
    raise TypeError(f"Unknown node: {type(node).__name__}")


def _resolve_scalar_value(
    value: Any,
    target_pos: np.ndarray,
    full_index: pd.Index,
) -> Any:
    if not isinstance(value, (pd.DataFrame, pd.Series)):
        return value
    if not isinstance(value.index, pd.DatetimeIndex):
        return value
    if not isinstance(full_index, pd.DatetimeIndex):
        return value
    if len(target_pos) == 0:
        return value.iloc[0:0]
    target_dates = full_index[target_pos]
    if value.index.equals(full_index):
        return _iloc(value, target_pos)
    if len(value.index) == 0:
        return value
    valid = target_dates[target_dates >= value.index[0]]
    return value.reindex(valid, method="ffill")


def _exec_unary(
    node: UnaryNode,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    child_pos, start = _expand_pos(target_pos, node.lookback, len(full_index))
    child_result = _execute(node.child, child_pos, full_index, _cache)

    method = node.method
    needs_trim = node.lookback > 0 and method not in _INDEX_CONVERSION_METHODS
    if method == "__invert__":
        result = ~child_result
    elif method == "__neg__":
        result = -child_result
    elif method == "is_largest":
        result = _top_n(child_result, cast("int", node.args[0]), largest=True)
    elif method == "is_smallest":
        result = _top_n(child_result, cast("int", node.args[0]), largest=False)
    elif method == "__array_ufunc__":
        ufunc = cast("Callable[..., Any]", node.args[0])
        result = ufunc(child_result, **node.kwargs)
    else:
        arg_pos = child_pos if method in _INDEX_UNKNOWN_METHODS else target_pos
        args = _resolve_lazy_args(node.args, arg_pos, full_index, _cache)
        kwargs = _resolve_lazy_kwargs(node.kwargs, arg_pos, full_index, _cache)
        result = getattr(child_result, method)(*args, **kwargs)

    if needs_trim and (
        method in _INDEX_UNKNOWN_METHODS
        or not _has_positional_index(result, full_index, start)
    ):
        return _trim_index_unknown_result(result, target_pos, full_index, start, _cache)
    return _trim_pos(result, target_pos, start) if needs_trim else result


def _exec_reindex(
    node: ReindexNode,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    target_index = _fast_reindex_target(node)
    if target_index is not None and isinstance(full_index, pd.DatetimeIndex):
        return _exec_fast_ffill_reindex(
            node.child, target_index, target_pos, full_index, _cache
        )
    return _exec_reindex_fallback(node, target_pos, full_index, _cache)


def _exec_reindex_fallback(
    node: ReindexNode,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    full_pos = np.arange(len(full_index))
    child_result = _execute(node.child, full_pos, full_index, _cache)
    args = _resolve_lazy_args(node.args, target_pos, full_index, _cache)
    kwargs = _resolve_lazy_kwargs(node.kwargs, target_pos, full_index, _cache)
    result = child_result.reindex(*args, **kwargs)
    if _is_full_history_target(target_pos, full_index, _cache):
        return result
    return _trim_index_unknown_result(result, target_pos, full_index, 0, _cache)


def _fast_reindex_target(node: ReindexNode) -> pd.DatetimeIndex | None:
    """Return static row target for the conservative ffill/pad fast path."""
    if not _supports_fast_ffill_reindex(node.args, node.kwargs):
        return None

    target = _static_reindex_target(node.args, node.kwargs)
    if target is _MISSING or target is None or _lazy_node(target) is not None:
        return None
    return _as_increasing_datetime_index(target)


def _supports_fast_ffill_reindex(args: tuple[object, ...], kwargs: dict) -> bool:
    if len(args) > 1:
        return False
    if args and ("index" in kwargs or "labels" in kwargs):
        return False
    if "index" in kwargs and "labels" in kwargs:
        return False
    if kwargs.get("method") not in ("ffill", "pad"):
        return False
    if kwargs.get("axis") not in (None, 0, "index"):
        return False
    if kwargs.get("columns") is not None:
        return False
    return _fast_reindex_extra_kwargs_ok(kwargs)


def _fast_reindex_extra_kwargs_ok(kwargs: dict) -> bool:
    for key in ("level", "limit", "tolerance"):
        if kwargs.get(key) is not None:
            return False
    return "fill_value" not in kwargs or kwargs["fill_value"] is None


def _static_reindex_target(args: tuple[object, ...], kwargs: dict) -> object:
    target = kwargs.get("index", _MISSING)
    if target is _MISSING:
        target = kwargs.get("labels", _MISSING)
    if target is _MISSING and args:
        target = args[0]
    return target


def _as_increasing_datetime_index(target: object) -> pd.DatetimeIndex | None:
    try:
        target_index = pd.DatetimeIndex(target)
    except (TypeError, ValueError):
        return None

    if target_index.hasnans or not target_index.is_monotonic_increasing:
        return None
    return target_index


def _exec_fast_ffill_reindex(
    child: Node,
    target_index: pd.DatetimeIndex,
    target_pos: np.ndarray,
    full_index: pd.DatetimeIndex,
    _cache: dict,
) -> Any:
    full_history = _is_full_history_target(target_pos, full_index, _cache)
    if full_history:
        output_index = target_index
        anchor_index = target_index
    else:
        requested_dates = pd.DatetimeIndex(
            _target_dates_for_reindex(target_pos, full_index, _cache)
        )
        if len(target_index) == 0:
            output_index = target_index
            anchor_index = target_index
        else:
            pos = target_index.searchsorted(requested_dates, side="right") - 1
            valid = pos >= 0
            output_index = requested_dates[valid]
            anchor_index = target_index[pos[valid]]

    return _execute_child_for_ffill_reindex(
        child, anchor_index, output_index, full_index, _cache
    )


def _execute_child_for_ffill_reindex(
    child: Node,
    anchor_index: pd.DatetimeIndex,
    output_index: pd.DatetimeIndex,
    full_index: pd.DatetimeIndex,
    _cache: dict,
) -> Any:
    child_index = pd.DatetimeIndex(anchor_index.unique())
    child_pos = _positions_for_dates(full_index, child_index)
    _remember_requested_dates(_cache, full_index, child_pos, child_index)
    child_result = _execute(child, child_pos, full_index, _cache)
    if not isinstance(child_result, (pd.DataFrame, pd.Series)):
        return child_result
    result = child_result.reindex(anchor_index, method="ffill")
    result.index = output_index
    return result


def _lazy_node(value: Any) -> Node | None:
    node = getattr(value, "_node", None)
    return node if isinstance(node, Node) else None


def _resolve_lazy_args(
    args: tuple, target_pos: np.ndarray, full_index: pd.Index, _cache: dict
) -> tuple:
    return tuple(
        _resolve_subtree(node, target_pos, full_index, _cache)
        if (node := _lazy_node(arg)) is not None
        else arg
        for arg in args
    )


def _resolve_lazy_kwargs(
    kwargs: dict, target_pos: np.ndarray, full_index: pd.Index, _cache: dict
) -> dict:
    return {
        key: _resolve_subtree(node, target_pos, full_index, _cache)
        if (node := _lazy_node(value)) is not None
        else value
        for key, value in kwargs.items()
    }


def _alignment_plan(
    left: pd.DataFrame,
    right: pd.DataFrame,
    _cache: dict,
) -> tuple[pd.Index, pd.Index]:
    plan_cache = _cache.get("__alignment_plan_cache__")
    key = (
        id(left.index),
        id(right.index),
        id(left.columns),
        id(right.columns),
    )
    if isinstance(plan_cache, dict) and key in plan_cache:
        return plan_cache[key]

    target_idx = left.index.union(right.index)
    idx_start = max(left.index[0], right.index[0])
    target_idx = target_idx[target_idx >= idx_start]
    target_cols = left.columns.intersection(right.columns)
    plan = (target_idx, target_cols)
    if isinstance(plan_cache, dict):
        plan_cache[key] = plan
    return plan


def _align_pair(
    left: pd.DataFrame,
    right: pd.DataFrame,
    _cache: dict,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if left.index.equals(right.index) and left.columns.equals(right.columns):
        return left, right
    target_idx, target_cols = _alignment_plan(left, right, _cache)
    return (
        left.reindex(index=target_idx, method="ffill")[target_cols],
        right.reindex(index=target_idx, method="ffill")[target_cols],
    )


def _flatten_binary_chain(node: BinaryNode) -> tuple[list[Node], list[BinaryNode]]:
    operands: list[Node] = []
    skipped: list[BinaryNode] = []

    def visit(current: Node) -> None:
        if isinstance(current, BinaryNode) and current.op == node.op:
            skipped.append(current)
            visit(current.left)
            visit(current.right)
            return
        operands.append(current)

    visit(node.left)
    visit(node.right)
    return operands, skipped


def _release_skipped_binary_nodes(nodes: list[BinaryNode], _cache: dict) -> None:
    for node in nodes:
        _release_node(node, _cache)


def _combine_binary_pair(
    op: str,
    left: Any,
    right: Any,
    _cache: dict,
) -> Any:
    if (
        isinstance(left, pd.DataFrame)
        and isinstance(right, pd.DataFrame)
        and not _same_shape(left, right)
    ):
        left, right = _align_pair(left, right, _cache)
    return _BINARY_DISPATCH[op](left, right)


def _exec_binary_chain(
    node: BinaryNode,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    operands, skipped = _flatten_binary_chain(node)
    try:
        return _fold_binary_chain_operands(
            node.op, operands, target_pos, full_index, _cache
        )
    finally:
        _release_skipped_binary_nodes(skipped, _cache)


def _fold_binary_chain_operands(
    op: str,
    operands: list[Node],
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    values = _iter_binary_chain_values(operands, target_pos, full_index, _cache)
    try:
        result = next(values)
    except StopIteration as exc:
        raise ValueError("Binary chain has no operands") from exc

    for value in values:
        result = _combine_binary_pair(op, result, value, _cache)
    return result


def _iter_binary_chain_values(
    operands: list[Node],
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Iterator[Any]:
    i = 0
    while i < len(operands):
        if not _can_resolve_native_string_run(operands[i], full_index, _cache):
            yield _resolve_subtree(operands[i], target_pos, full_index, _cache)
            i += 1
            continue

        run: list[Node] = []
        while i < len(operands) and _can_resolve_native_string_run(
            operands[i], full_index, _cache
        ):
            run.append(operands[i])
            i += 1
        yield from _iter_native_string_run_values(run, target_pos, full_index, _cache)


def _can_resolve_native_string_run(
    node: Node,
    full_index: pd.Index,
    _cache: dict,
) -> bool:
    return (
        not _is_string_index(full_index) and _cached_str_freq(node, _cache) is not None
    )


def _iter_native_string_run_values(
    operands: list[Node],
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Iterator[pd.DataFrame]:
    current: pd.DataFrame | None = None
    for operand in operands:
        value = _execute_on_native(operand, _cache)
        if current is None:
            current = value
            continue
        if _same_shape(current, value):
            current = _BINARY_DISPATCH["__and__"](current, value)
        else:
            yield _string_group_to_target_dates(current, target_pos, full_index, _cache)
            current = value

    if current is not None:
        yield _string_group_to_target_dates(current, target_pos, full_index, _cache)


def _string_group_to_target_dates(
    result: pd.DataFrame,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> pd.DataFrame:
    return _reindex_dates_to_target(
        _frame_index_str_to_date(result),
        target_pos,
        full_index,
        include_result_index=_is_full_history_target(target_pos, full_index, _cache),
    )


def _same_shape(left: pd.DataFrame, right: pd.DataFrame) -> bool:
    return left.index.equals(right.index) and left.columns.equals(right.columns)


def _cached_str_freq(node: Node, _cache: dict) -> str | None:
    key = ("__str_freq__", id(node))
    if key not in _cache:
        _cache[key] = _str_freq(node, _cache)
    return _cache[key]


def _cached_unique_source(node: Node, _cache: dict) -> SourceLike | None:
    key = ("__unique_src__", id(node))
    if key not in _cache:
        _cache[key] = _unique_source(node, _cache)
    return _cache[key]


def _resolve_subtree(
    node: Node,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    if _cached_str_freq(node, _cache) is not None:
        if _is_string_index(full_index):
            return _execute(node, target_pos, full_index, _cache)
        result = _native_result_as_dates(node, _cache)
        return _reindex_dates_to_target(
            result,
            target_pos,
            full_index,
            include_result_index=_is_full_history_target(
                target_pos, full_index, _cache
            ),
        )

    unique_src = _cached_unique_source(node, _cache)
    if unique_src is not None:
        src_index = _source_index(unique_src, _cache)
        if not src_index.equals(full_index):
            target_dates = _target_dates_for_reindex(target_pos, full_index, _cache)
            valid = target_dates[target_dates >= src_index[0]]
            src_pos = _positions_for_dates(src_index, valid)
            _remember_requested_dates(
                _cache, src_index, src_pos, pd.DatetimeIndex(valid)
            )
            result = _execute(node, src_pos, src_index, _cache)
            return result.reindex(valid, method="ffill")

    return _execute(node, target_pos, full_index, _cache)


def _exec_binary(
    node: BinaryNode,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    if _is_string_index(full_index):
        # Same-frequency string indexes: let pandas align by label (NaN for
        # missing periods) instead of ffill, which would carry stale data.
        left = _execute(node.left, target_pos, full_index, _cache)
        right = _execute(node.right, target_pos, full_index, _cache)
        return _BINARY_DISPATCH[node.op](left, right)

    if node.op == "__and__" and (
        isinstance(node.left, BinaryNode) or isinstance(node.right, BinaryNode)
    ):
        return _exec_binary_chain(node, target_pos, full_index, _cache)

    left = _resolve_subtree(node.left, target_pos, full_index, _cache)
    right = _resolve_subtree(node.right, target_pos, full_index, _cache)
    if (
        isinstance(left, pd.DataFrame)
        and isinstance(right, pd.DataFrame)
        and not (left.index.equals(right.index) and left.columns.equals(right.columns))
    ):
        left, right = _align_pair(left, right, _cache)

    return _BINARY_DISPATCH[node.op](left, right)


def _exec_rolling(
    node: RollingNode,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    child_pos, start = _expand_pos(target_pos, node.window, len(full_index))
    child_result = _execute(node.child, child_pos, full_index, _cache)
    rolling_obj = child_result.rolling(node.window, **node.rolling_kwargs)
    result = getattr(rolling_obj, node.method)(*node.method_args, **node.method_kwargs)
    if not _has_positional_index(result, full_index, start):
        return _trim_index_unknown_result(result, target_pos, full_index, start, _cache)
    return _trim_pos(result, target_pos, start)


def _exec_getitem(
    node: GetitemNode,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    child = _resolve_subtree(node.child, target_pos, full_index, _cache)
    key = (
        _resolve_subtree(node.key, target_pos, full_index, _cache)
        if isinstance(node.key, Node)
        else node.key
    )

    if (
        isinstance(child, pd.DataFrame)
        and isinstance(key, pd.DataFrame)
        and not (child.index.equals(key.index) and child.columns.equals(key.columns))
    ):
        child, key = _align_pair(child, key, _cache)

    return child[key]
