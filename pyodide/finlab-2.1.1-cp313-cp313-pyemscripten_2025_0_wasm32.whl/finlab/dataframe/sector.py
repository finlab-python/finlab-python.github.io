"""SectorAccessor — sector-relative operations, accessed via ``df.sector.xxx``."""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeAlias

import numpy as np
import pandas as pd
from scipy.stats import rankdata

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from finlab.dataframe.core import FinlabDataFrame

    # Explicit TypeAlias: without it mypy treats these as plain variables and rejects
    # every annotation that uses them ("Variable ... is not valid as a type").
    SectorBy: TypeAlias = Mapping[str, str] | pd.Series | pd.DataFrame | None
    RowGroups: TypeAlias = Callable[[int], list[tuple[object, np.ndarray]]]


def resolve_labels(obj: FinlabDataFrame, by: SectorBy) -> tuple[np.ndarray, bool]:
    """Resolve ``by`` into sector labels for ``obj``'s columns.

    Returns ``(labels, static)``: ``labels`` is a 1-D per-column array when
    ``static`` is True, else a 2-D (n_rows, n_cols) array for time-varying
    classifications. Unlisted columns get NaN labels.
    """
    if isinstance(by, pd.DataFrame):
        aligned = by.reindex(columns=obj.columns).reindex(obj.index, method="ffill")
        return aligned.values, False
    if by is None:
        return obj._get_column_categories().values, True
    mapping = by if isinstance(by, pd.Series) else pd.Series(dict(by))
    return mapping.reindex(obj.columns).values, True


def row_groups(labels: np.ndarray, static: bool) -> RowGroups:
    """Return a function mapping row position -> [(sector, column mask)] pairs.

    Masks for static labels are computed once and shared across rows.
    """

    def groups_of(labs: np.ndarray) -> list[tuple[object, np.ndarray]]:
        return [(s, labs == s) for s in pd.unique(labs) if not pd.isna(s)]

    if static:
        groups = groups_of(labels)
        return lambda _: groups
    return lambda i: groups_of(labels[i])


class SectorAccessor:
    """Sector-relative (within-sector per-row) transforms on a FinlabDataFrame."""

    def __init__(self, obj: FinlabDataFrame, by: SectorBy = None) -> None:
        # Quarterly data is compared per disclosure date, never across a
        # whole quarter whose peers have not all reported yet.
        self._obj = obj.index_str_to_date()
        self._by = by

    def __call__(self, by: SectorBy) -> SectorAccessor:
        """使用自訂產業分類

        Args:
            by: 自訂分類。可以是股票代號 → 產業名的 dict 或 pd.Series，
                或 index=日期、columns=股票代號的時變分類 pd.DataFrame。
                未列入的股票不參與計算（結果為 NaN）。
                若為 None，使用預設 ``security_categories`` 產業分類。

        Returns:
            (SectorAccessor): 使用自訂分類的 accessor。

        Examples:
            ```py
            my_map = {"2330": "AI供應鏈", "2317": "AI供應鏈", "2882": "金融"}
            roe.sector(my_map).rank()
            ```
        """
        return SectorAccessor(self._obj, by)

    def _wrap(self, result: np.ndarray) -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame

        return FinlabDataFrame(result, index=self._obj.index, columns=self._obj.columns)

    def _apply_groups(self, func: Callable[[np.ndarray], object]) -> FinlabDataFrame:
        """Apply ``func(valid_values)`` to each (row, sector) group.

        ``func`` may return a scalar (broadcast to the group) or an array of
        the same length. Cells with NaN value or NaN sector label stay NaN.
        """
        groups = row_groups(*resolve_labels(self._obj, self._by))
        arr = np.asarray(self._obj.values, dtype=float)
        result = np.full(arr.shape, np.nan)

        for i in range(arr.shape[0]):
            row = arr[i]
            notna = ~np.isnan(row)
            for _, mask in groups(i):
                valid = mask & notna
                if valid.any():
                    result[i, valid] = func(row[valid])

        return self._wrap(result)

    def rank(self) -> FinlabDataFrame:
        """產業內百分位排名

        每列（日期）內，在同產業股票中計算百分位排名。

        Returns:
            (FinlabDataFrame): 產業內百分位排名。
        """
        return self._apply_groups(lambda v: rankdata(v) / len(v))

    def winsorize(self, lower: float = 0.05, upper: float = 0.95) -> FinlabDataFrame:
        """產業內百分位縮尾

        每列（日期）內，在同產業股票中進行百分位縮尾處理。

        Args:
            lower (float): 下界百分位數。預設 0.05。
            upper (float): 上界百分位數。預設 0.95。

        Returns:
            (FinlabDataFrame): 縮尾後的資料。
        """
        return self._apply_groups(
            lambda v: np.clip(
                v, np.percentile(v, lower * 100), np.percentile(v, upper * 100)
            )
        )

    def bucket(self, n: int) -> FinlabDataFrame:
        """產業內分組

        每列（日期）內，在同產業股票中分為 n 個等分位組。

        Args:
            n (int): 分組數量。

        Returns:
            (FinlabDataFrame): 組別編號（1 = 最低，n = 最高）。
        """
        return self._apply_groups(
            lambda v: np.ceil(rankdata(v, method="ordinal") / len(v) * n)
        )

    def zscore(self) -> FinlabDataFrame:
        """產業內標準化

        每列（日期）內，在同產業股票中計算 z-score。
        若產業內標準差為零，回傳 0。

        Returns:
            (FinlabDataFrame): 產業內標準化後的資料。
        """

        def z(v: np.ndarray) -> object:
            if len(v) < 2:
                return 0.0
            s = np.std(v, ddof=1)
            return 0.0 if s < 1e-10 else (v - v.mean()) / s

        return self._apply_groups(z)

    def map(self, mapping: Mapping[str, float]) -> FinlabDataFrame:
        """產業值廣播

        將產業層級的數值廣播成與原資料同形狀的 DataFrame，
        方便與因子分數運算，例如 ``roe.sector.rank() * roe.sector.map(w)``。

        Args:
            mapping (dict): 產業名 → 數值。未列入的產業為 NaN。

        Returns:
            (FinlabDataFrame): 廣播後的資料（原 NaN 位置維持 NaN）。
        """
        labels, _ = resolve_labels(self._obj, self._by)
        values = pd.Series(dict(mapping), dtype=float)
        broadcast = values.reindex(labels.ravel()).values.reshape(labels.shape)
        arr = np.asarray(self._obj.values, dtype=float)
        return self._wrap(np.where(np.isnan(arr), np.nan, broadcast))

    def mean(self) -> FinlabDataFrame:
        """產業內平均值

        每列（日期）內，將每個股票的值替換為同產業的平均值。

        Returns:
            (FinlabDataFrame): 產業內平均值。
        """
        return self._apply_groups(np.mean)

    def std(self, ddof: int = 1) -> FinlabDataFrame:
        """產業內標準差

        每列（日期）內，將每個股票的值替換為同產業的標準差。

        Args:
            ddof (int): 自由度修正。預設 1（樣本標準差）。

        Returns:
            (FinlabDataFrame): 產業內標準差。
        """
        return self._apply_groups(lambda v: np.std(v, ddof=ddof) if len(v) > 1 else 0.0)

    def median(self) -> FinlabDataFrame:
        """產業內中位數

        每列（日期）內，將每個股票的值替換為同產業的中位數。

        Returns:
            (FinlabDataFrame): 產業內中位數。
        """
        return self._apply_groups(np.median)

    def sum(self) -> FinlabDataFrame:
        """產業內總和

        每列（日期）內，將每個股票的值替換為同產業的總和。

        Returns:
            (FinlabDataFrame): 產業內總和。
        """
        return self._apply_groups(np.sum)

    def min(self) -> FinlabDataFrame:
        """產業內最小值

        每列（日期）內，將每個股票的值替換為同產業的最小值。

        Returns:
            (FinlabDataFrame): 產業內最小值。
        """
        return self._apply_groups(np.min)

    def max(self) -> FinlabDataFrame:
        """產業內最大值

        每列（日期）內，將每個股票的值替換為同產業的最大值。

        Returns:
            (FinlabDataFrame): 產業內最大值。
        """
        return self._apply_groups(np.max)

    def count(self) -> FinlabDataFrame:
        """產業內有效值數量

        每列（日期）內，將每個股票的值替換為同產業的非 NaN 數量。

        Returns:
            (FinlabDataFrame): 產業內有效值數量。
        """
        return self._apply_groups(lambda v: float(len(v)))

    def demean(self) -> FinlabDataFrame:
        """產業內去均值

        每列（日期）內，減去同產業股票的平均值。

        Returns:
            (FinlabDataFrame): 產業內去均值後的資料。
        """
        return self._apply_groups(lambda v: v - v.mean())
