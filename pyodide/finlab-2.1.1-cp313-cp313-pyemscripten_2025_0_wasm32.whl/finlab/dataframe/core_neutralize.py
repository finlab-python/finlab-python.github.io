"""Neutralization mixin for FinlabDataFrame.

Provides cross-sectional factor neutralization (single/multi-factor) and
industry neutralization via dummy-variable regression.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, cast, overload

import numpy as np
import pandas as pd

_NEUTRALIZE_WORKING_SET_BYTES = 64 * 1024 * 1024

if TYPE_CHECKING:
    from finlab.dataframe.core import FinlabDataFrame


class NeutralizeMixin:
    """Factor and industry neutralization methods for FinlabDataFrame."""

    def neutralize(
        self,
        neutralizers: pd.DataFrame | list[pd.DataFrame] | dict[str, pd.DataFrame],
        add_const: bool = True,
    ) -> FinlabDataFrame:
        """Multi-factor cross-sectional neutralization

        Performs cross-sectional regression to neutralize factors from the data.
        The residuals from regressing self on the neutralizers are returned.

        Args:
            neutralizers: Factor(s) to neutralize against. Can be:
                - A single DataFrame
                - A list of DataFrames
                - A dict of DataFrames (keys are factor names)
            add_const (bool): Whether to add a constant term to the regression. Default True.

        Returns:
            (FinlabDataFrame): Neutralized data (regression residuals)

        Examples:
            Neutralize a factor against size:
            ```py
            from finlab import data

            factor = data.get('price_earning_ratio:本益比')
            size = data.get('fundamental_features:市值')

            neutralized = factor.neutralize(size)
            ```

            Neutralize against multiple factors using a list:
            ```py
            neutralized = factor.neutralize([size, beta])
            ```

            Neutralize against multiple factors using a dict:
            ```py
            neutralized = factor.neutralize({
                'size': size,
                'size2': size ** 2,
                'beta': beta,
            })
            ```
        """
        from finlab.dataframe.core import FinlabDataFrame as FDF

        frame = cast("FinlabDataFrame", self)
        neutralizers_dict = _normalize_neutralizers(neutralizers)

        # Regress per disclosure date, never across a whole quarter whose
        # peers have not all reported yet (same as neutralize_industry).
        df1 = frame.index_str_to_date()
        for name, df in list(neutralizers_dict.items()):
            df1, reshaped = frame.reshape(df1, FDF(df).index_str_to_date())
            neutralizers_dict[name] = reshaped

        out = [
            _neutralize_row(df1, neutralizers_dict, date, add_const)
            for date in df1.index
        ]

        ret = FDF(out)
        ret.index.name = "date"
        ret.columns.name = "symbol"
        return ret

    def neutralize_industry(
        self,
        categories: pd.DataFrame | None = None,
        add_const: bool = True,
    ) -> FinlabDataFrame:
        """Industry neutralization using dummy variables

        Performs cross-sectional regression to neutralize industry effects from the data.
        Each stock is assigned to an industry, and the factor is regressed on industry
        dummy variables. The residuals (industry-neutral factor) are returned.

        Args:
            categories (pd.DataFrame): Optional DataFrame with 'stock_id' and 'category' columns.
                If not provided, uses `data.get('security_categories')`.
            add_const (bool): Whether to add a constant term to the regression. Default True.
                Note: When using industry dummies, adding a constant creates multicollinearity,
                so one industry dummy is automatically dropped when add_const=True.

        Returns:
            (FinlabDataFrame): Industry-neutralized data (regression residuals)

        Examples:
            Neutralize a factor against industry:
            ```py
            from finlab import data

            factor = data.get('price_earning_ratio:本益比')
            neutralized = factor.neutralize_industry()
            ```

            Using custom categories:
            ```py
            custom_cats = pd.DataFrame({
                'stock_id': ['2330', '2317', '1101'],
                'category': ['半導體', '電子', '水泥']
            })
            neutralized = factor.neutralize_industry(categories=custom_cats)
            ```
        """
        from finlab.dataframe.core import FinlabDataFrame as FDF

        frame = cast("FinlabDataFrame", self)
        col_categories = _resolve_column_categories(categories, frame.columns)
        df1 = frame.index_str_to_date()
        ret = FDF(_neutralize_industry_frame(df1, col_categories, add_const))
        ret.index.name = "date"
        ret.columns.name = "symbol"
        return ret


@overload
def neutralize_industry_batch(
    factors: Mapping[str, pd.DataFrame],
    categories: pd.DataFrame | None = None,
    add_const: bool = True,
) -> dict[str, FinlabDataFrame]: ...


@overload
def neutralize_industry_batch(
    factors: Sequence[pd.DataFrame],
    categories: pd.DataFrame | None = None,
    add_const: bool = True,
) -> list[FinlabDataFrame]: ...


def neutralize_industry_batch(
    factors: Mapping[str, pd.DataFrame] | Sequence[pd.DataFrame],
    categories: pd.DataFrame | None = None,
    add_const: bool = True,
) -> dict[str, FinlabDataFrame] | list[FinlabDataFrame]:
    """Neutralize factors while sharing category and index preparation."""
    from finlab.dataframe.core import FinlabDataFrame as FDF

    is_mapping = isinstance(factors, Mapping)
    items: list[tuple[object, pd.DataFrame]] = (
        [
            (name, frame)
            for name, frame in cast("Mapping[str, pd.DataFrame]", factors).items()
        ]
        if is_mapping
        else [
            (index, frame)
            for index, frame in enumerate(cast("Sequence[pd.DataFrame]", factors))
        ]
    )
    if not items:
        return {} if is_mapping else []
    if not all(isinstance(frame, pd.DataFrame) for _, frame in items):
        raise TypeError("factors must contain only pandas DataFrame objects")

    converted_items = [
        (name, FDF(factor).index_str_to_date()) for name, factor in items
    ]
    output: dict[object, FinlabDataFrame] = {}
    groups: dict[tuple[object, ...], list[tuple[object, pd.DataFrame]]] = {}
    from finlab.data.category_cache import columns_fingerprint

    for name, factor in converted_items:
        axes_key = (
            len(factor.index),
            str(factor.index[0]) if len(factor) else None,
            str(factor.index[-1]) if len(factor) else None,
            columns_fingerprint(factor.columns),
        )
        groups.setdefault(axes_key, []).append((name, factor))

    for group_items in groups.values():
        representative = group_items[0][1]
        if not all(
            factor.index.equals(representative.index)
            and factor.columns.equals(representative.columns)
            for _, factor in group_items
        ):
            # Extremely unlikely fingerprint collision: fall back to singleton
            # groups without compromising numerical correctness.
            for name, factor in group_items:
                output[name] = FDF(factor).neutralize_industry(categories, add_const)
            continue

        mapping = _resolve_column_categories(categories, representative.columns)
        bytes_per_factor = max(representative.size * np.dtype(float).itemsize, 1)
        chunk_size = max(1, _NEUTRALIZE_WORKING_SET_BYTES // (bytes_per_factor * 3))
        for start in range(0, len(group_items), chunk_size):
            chunk = group_items[start : start + chunk_size]
            values = np.stack(
                [factor.to_numpy(dtype=float, copy=False) for _, factor in chunk]
            )
            neutralized = _neutralize_industry_array_batch(values, mapping, add_const)
            for (name, factor), result_values in zip(chunk, neutralized, strict=True):
                result = FDF(
                    result_values,
                    index=factor.index,
                    columns=factor.columns,
                )
                result.index.name = "date"
                result.columns.name = "symbol"
                output[name] = result

    if is_mapping:
        return cast(
            "dict[str, FinlabDataFrame]",
            {name: output[name] for name, _ in items},
        )
    return [output[i] for i in range(len(items))]


def _resolve_column_categories(
    categories: pd.DataFrame | None,
    columns: pd.Index,
) -> pd.Series:
    if categories is not None:
        return _build_column_categories(categories, columns)

    from finlab import data
    from finlab.data.category_cache import get_categories, get_column_mapping

    raw, version = get_categories(lambda: data.get("security_categories"))
    return get_column_mapping(raw, columns, _build_column_categories, version=version)


def _neutralize_industry_frame(
    frame: pd.DataFrame,
    col_categories: pd.Series,
    add_const: bool,
) -> pd.DataFrame:
    """Vectorized industry dummy-regression residuals for every date."""
    values = frame.astype(float)
    result = pd.DataFrame(np.nan, index=values.index, columns=values.columns)
    categories = pd.unique(col_categories)
    present_groups = pd.DataFrame(False, index=values.index, columns=categories)

    group_data: list[tuple[object, pd.Index, pd.DataFrame, pd.Series, pd.Series]] = []
    first_mean = pd.Series(np.nan, index=values.index)
    first_category = pd.Series(None, index=values.index, dtype=object)
    for category in categories:
        columns = col_categories.index[col_categories.eq(category)]
        group = values.loc[:, columns]
        present = group.notna().any(axis=1)
        present_groups[category] = present
        group_mean = group.mean(axis=1)
        choose = first_mean.isna() & present
        first_mean.loc[choose] = group_mean.loc[choose]
        first_category.loc[choose] = category
        group_data.append((category, columns, group, group_mean, present))

    for category, columns, group, group_mean, _present in group_data:
        # Match the two historical OLS encodings.  They fit identical category
        # means mathematically, but the constant-plus-omitted-dummy path has
        # its own floating-point operation order, which existing callers test.
        fitted = first_mean + (group_mean - first_mean) if add_const else group_mean
        if add_const:
            fitted = fitted.where(first_category.ne(category), first_mean)
        result.loc[:, columns] = group.sub(fitted, axis=0)

    insufficient = present_groups.sum(axis=1) < 2
    result.loc[insufficient, :] = np.nan
    return result


def _neutralize_industry_array_batch(
    values: np.ndarray,
    col_categories: pd.Series,
    add_const: bool,
) -> np.ndarray:
    """Neutralize ``(factor, date, symbol)`` arrays in shared category passes."""
    result = np.full(values.shape, np.nan, dtype=float)
    categories = pd.unique(col_categories)
    present_count = np.zeros(values.shape[:2], dtype=np.int16)
    first_mean = np.full(values.shape[:2], np.nan)
    first_category = np.full(values.shape[:2], -1, dtype=np.int16)
    for category_index, category in enumerate(categories):
        column_positions = np.flatnonzero(col_categories.eq(category).to_numpy())
        group = values[:, :, column_positions]
        present = np.any(~np.isnan(group), axis=2)
        present_count += present
        totals = np.nansum(group, axis=2)
        counts = np.sum(~np.isnan(group), axis=2)
        group_mean = np.divide(
            totals,
            counts,
            out=np.full(totals.shape, np.nan),
            where=counts != 0,
        )
        choose = np.isnan(first_mean) & present
        first_mean[choose] = group_mean[choose]
        first_category[choose] = category_index
    for category_index, category in enumerate(categories):
        column_positions = np.flatnonzero(col_categories.eq(category).to_numpy())
        group = values[:, :, column_positions]
        totals = np.nansum(group, axis=2)
        counts = np.sum(~np.isnan(group), axis=2)
        group_mean = np.divide(
            totals,
            counts,
            out=np.full(totals.shape, np.nan),
            where=counts != 0,
        )
        fitted = first_mean + (group_mean - first_mean) if add_const else group_mean
        if add_const:
            fitted = np.where(first_category == category_index, first_mean, fitted)
        result[:, :, column_positions] = group - fitted[:, :, None]
    result[present_count < 2, :] = np.nan
    return result


def _normalize_neutralizers(
    neutralizers: pd.DataFrame | list[pd.DataFrame] | dict[str, pd.DataFrame],
) -> dict[str, pd.DataFrame]:
    """Convert neutralizers to a uniform dict format."""
    if isinstance(neutralizers, pd.DataFrame):
        return {"factor_0": neutralizers}
    if isinstance(neutralizers, list):
        return {f"factor_{i}": df for i, df in enumerate(neutralizers)}
    return neutralizers


def _neutralize_row(
    df1: pd.DataFrame,
    neutralizers_dict: dict[str, pd.DataFrame],
    date: object,
    add_const: bool,
) -> pd.Series:
    """Compute OLS residuals for a single cross-section date."""
    y = df1.loc[date]
    X_list: list[pd.Series] = []
    mask = y.notna()
    for df in neutralizers_dict.values():
        xi = df.loc[date]
        mask &= xi.notna()
        X_list.append(xi)

    if mask.sum() < len(neutralizers_dict) + 1:
        return pd.Series(index=df1.columns, name=date)

    Y = y[mask].values.reshape(-1, 1)
    X = np.column_stack([x.loc[mask].values for x in X_list])
    if add_const:
        X = np.hstack([np.ones((X.shape[0], 1)), X])

    beta = np.linalg.lstsq(X, Y, rcond=None)[0]
    resid = (Y - X @ beta).ravel()

    s = pd.Series(index=df1.columns, name=date, dtype=float)
    s.loc[mask] = resid
    return s


def _build_column_categories(
    categories: pd.DataFrame,
    columns: pd.Index,
) -> pd.Series:
    """Build a refined symbol-to-category mapping for the given columns.

    Reuses the shared normalization logic from core._fetch_refined_categories
    but accepts an explicit categories DataFrame instead of fetching from data.
    """
    from finlab.compat import resolve_id_column

    cat_map = categories.set_index(resolve_id_column(categories))["category"].to_dict()

    # Same normalization as _fetch_refined_categories in core.py
    org_set = set(cat_map.values())
    valid_names = {o for o in org_set if isinstance(o, str) and o != "nan"}

    refine_cat: dict[str, str] = {}
    for s, c in cat_map.items():
        if c is None or c == "nan" or (isinstance(c, float) and np.isnan(c)):
            refine_cat[s] = "其他"
        elif c == "電腦及週邊":
            refine_cat[s] = "電腦及週邊設備業"
        elif c[-1] == "業" and c[:-1] in valid_names:
            refine_cat[s] = c[:-1]
        else:
            refine_cat[s] = c

    return pd.Series({col: refine_cat.get(col, "其他") for col in columns})


def _neutralize_industry_row(
    df1: pd.DataFrame,
    col_categories: pd.Series,
    date: object,
    add_const: bool,
) -> pd.Series:
    """Compute industry-neutralized residuals for a single cross-section date."""
    y = df1.loc[date]
    mask = y.notna()

    if mask.sum() < 2:
        return pd.Series(index=df1.columns, name=date, dtype=float)

    valid_cols = y[mask].index
    valid_cats = col_categories.loc[valid_cols]
    cats_in_row = valid_cats.unique()

    if len(cats_in_row) < 2:
        return pd.Series(index=df1.columns, name=date, dtype=float)

    dummy_dict: dict[str, np.ndarray] = {}
    for cat in cats_in_row:
        dummy_dict[cat] = (valid_cats == cat).astype(float).values

    X = np.column_stack(list(dummy_dict.values()))

    if add_const:
        X = X[:, 1:]  # Drop first dummy to avoid multicollinearity
        X = np.hstack([np.ones((X.shape[0], 1)), X])

    Y = y[mask].values.reshape(-1, 1)

    beta = np.linalg.lstsq(X, Y, rcond=None)[0]
    resid = (Y - X @ beta).ravel()

    s = pd.Series(index=df1.columns, name=date, dtype=float)
    s.loc[mask] = resid
    return s
