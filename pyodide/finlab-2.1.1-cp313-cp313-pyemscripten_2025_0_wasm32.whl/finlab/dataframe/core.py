"""Pandas-backed ``FinlabDataFrame`` frontend.

``FinlabDataFrame`` owns the pandas semantics and convenience APIs used by the
documented dataframe SDK.
"""

from __future__ import annotations

import inspect
import logging
import sys
import uuid
import warnings
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

__all__ = ["FinlabDataFrame", "PandasLeftOperandWarning", "TopNPaddingWarning"]

if TYPE_CHECKING:
    from collections.abc import Callable

    from finlab.dataframe.cs import CsAccessor
    from finlab.dataframe.lazy import LazyWide
    from finlab.dataframe.sector import SectorAccessor
    from finlab.dataframe.weight import WeightAccessor

import numpy as np
import pandas as pd

from finlab.dataframe.core_index import IndexConversionMixin, fill_unknown_boolean
from finlab.dataframe.core_industry import IndustryMixin
from finlab.dataframe.core_neutralize import NeutralizeMixin
from finlab.dataframe.core_signals import SignalMixin
from finlab.dataframe.profiling import profile_alignment_call

logger = logging.getLogger(__name__)


class LookaheadWarning(UserWarning):
    """警告：偵測到可能的 look-ahead bias。"""


class PandasLeftOperandWarning(UserWarning):
    """``pd_df <op> finlab_df`` aligned with pandas, not FinlabDataFrame, rules.

    Filter it by class, e.g.
    ``warnings.simplefilter("ignore", PandasLeftOperandWarning)``.
    """


class TopNPaddingWarning(UserWarning):
    """``is_largest``/``is_smallest`` filled N with stocks tied at the row floor.

    Filter it by class, e.g.
    ``warnings.simplefilter("ignore", TopNPaddingWarning)``.
    """


_TOP_N_PADDING_EXAMPLE_DATES = 3


_LOGICAL_OPS = frozenset(
    {"__and__", "__or__", "__xor__", "__iand__", "__ior__", "__ixor__"}
)


def _is_plain_bool(data: object) -> bool:
    return isinstance(data, pd.DataFrame) and bool(
        (data.dtypes == np.dtype(bool)).all()
    )


def reshape_operations(cls: type) -> type:
    # Define a mapping of operations to override to their corresponding pandas method
    methods_to_check = [
        "__getitem__",
        "__add__",
        "__sub__",
        "__mul__",
        "__truediv__",
        "__floordiv__",
        "__mod__",
        "__pow__",
        "__lshift__",
        "__rshift__",
        "__and__",
        "__or__",
        "__xor__",
        "__iadd__",
        "__isub__",
        "__imul__",
        "__itruediv__",
        "__ifloordiv__",
        "__imod__",
        "__ipow__",
        "__ilshift__",
        "__irshift__",
        "__iand__",
        "__ior__",
        "__ixor__",
        "__lt__",
        "__le__",
        "__eq__",
        "__ne__",
        "__gt__",
        "__ge__",
    ]

    # find operation mapping that map str -> function for the function need reshape.

    base_class = pd.DataFrame
    operations_mapping: dict[str, Callable[..., pd.DataFrame]] = {}

    for method_name in methods_to_check:
        if hasattr(base_class, method_name):
            method = getattr(base_class, method_name)
            params = inspect.signature(method).parameters
            can_accept_df = any(
                param.annotation in (pd.DataFrame, inspect._empty)
                for param in params.values()
            )
            if can_accept_df:
                operations_mapping[method_name] = getattr(pd.DataFrame, method_name)

    # replace original function to reshaped function

    for op, pandas_method in operations_mapping.items():
        if hasattr(cls, op):

            def make_wrapped_method(
                op: str, pandas_method: Callable[..., pd.DataFrame]
            ) -> Callable[[pd.DataFrame, pd.DataFrame | pd.Series], pd.DataFrame]:
                def wrapped_method(
                    self: pd.DataFrame, other: pd.DataFrame | pd.Series
                ) -> pd.DataFrame:
                    if isinstance(other, pd.Series) and op == "__getitem__":
                        return _select_by_series(self, other, pandas_method)

                    df1, df2 = self.reshape(self, other)
                    result = pandas_method(df1, df2)
                    # A plain bool mask combined with a quarterly mask stays
                    # plain bool, as it did when quarterly masks were object.
                    if op in _LOGICAL_OPS and (
                        _is_plain_bool(df1) or _is_plain_bool(df2)
                    ):
                        return fill_unknown_boolean(result)
                    return result

                return wrapped_method

            setattr(cls, op, make_wrapped_method(op, pandas_method))

    return cls


# Reflected op -> forward op. Python calls a subclass's reflected method before
# the base class's forward one, so these run first for ``pd_df <op> finlab_df``.
_REFLECTED_TO_FORWARD = {
    "__radd__": "__add__",
    "__rsub__": "__sub__",
    "__rmul__": "__mul__",
    "__rtruediv__": "__truediv__",
    "__rfloordiv__": "__floordiv__",
    "__rmod__": "__mod__",
    "__rpow__": "__pow__",
    "__rand__": "__and__",
    "__ror__": "__or__",
    "__rxor__": "__xor__",
}

_PANDAS_LEFT_OPERAND_MESSAGE = (
    "A plain pandas DataFrame is on the left of a FinlabDataFrame and their "
    "dates or stocks differ, so pandas alignment was used: no forward fill of "
    "dates, union of stocks, plain DataFrame result. Put the FinlabDataFrame on "
    "the left, or wrap the other side with FinlabDataFrame(df), to align like "
    "FinlabDataFrame.\n"
    "pandas DataFrame 在 FinlabDataFrame 左邊且日期或股票不同，因此用 pandas "
    "規則對齊：日期不向前填補、股票取聯集、結果是一般 DataFrame。"
    "請把 FinlabDataFrame 放在左邊，或用 FinlabDataFrame(df) 包起來。"
)


def warn_on_pandas_left_operand(cls: type) -> type:
    """Warn when ``pd_df <op> finlab_df`` aligns differently than finlab would.

    The result is unchanged: the plain DataFrame's forward op runs exactly as
    it would without these methods (2.0.21 semantics, which templates rely
    on). Only frames whose axes already match skip the warning, since both
    alignments then agree.
    """
    for reflected, forward in _REFLECTED_TO_FORWARD.items():
        setattr(
            cls,
            reflected,
            _make_reflected_method(
                getattr(pd.DataFrame, reflected), getattr(pd.DataFrame, forward)
            ),
        )
    return cls


def _make_reflected_method(
    pandas_reflected: Callable[[pd.DataFrame, object], pd.DataFrame],
    pandas_forward: Callable[[pd.DataFrame, object], pd.DataFrame],
) -> Callable[[pd.DataFrame, object], pd.DataFrame]:
    def reflected_method(self: pd.DataFrame, other: object) -> pd.DataFrame:
        # Only an exact pd.DataFrame reaches here ahead of its own forward op;
        # scalars, Series and unrelated subclasses keep the pandas path.
        if type(other) is not pd.DataFrame:
            return pandas_reflected(self, other)
        if not (other.index.equals(self.index) and other.columns.equals(self.columns)):
            warnings.warn(
                _PANDAS_LEFT_OPERAND_MESSAGE, PandasLeftOperandWarning, stacklevel=2
            )
        return pandas_forward(other, self)

    return reflected_method


def get_index_str_frequency(df: pd.DataFrame | pd.Series) -> str | None:
    if not hasattr(df, "index"):
        return None

    if len(df.index) == 0:
        return None

    if not isinstance(df.index[0], str):
        return None

    if (df.index.str.find("M") != -1).all():
        return "month"

    if (df.index.str.find("Q") != -1).all():
        return "season"

    return None


def _has_quarter_str_index(df: pd.DataFrame | pd.Series) -> bool:
    """True for a '2013-Q1'-style index; checks the first label before scanning."""
    return (
        len(df.index) > 0
        and isinstance(df.index[0], str)
        and get_index_str_frequency(df) == "season"
    )


def _is_date_index(labels: object) -> bool:
    if isinstance(labels, pd.DatetimeIndex):
        return True
    if labels is None or isinstance(labels, (str, bytes)):
        return False
    try:
        return pd.api.types.is_datetime64_any_dtype(pd.Index(labels))
    except (TypeError, ValueError):
        return False


def _to_date_index_for_alignment(
    df: pd.DataFrame, other: pd.DataFrame | pd.Series
) -> pd.DataFrame:
    """Convert a quarterly FinlabDataFrame to disclosure dates before aligning.

    A plain DataFrame has no disclosure dates to convert with, so it is
    returned unchanged and aligns with pandas semantics, as in 2.0.21.
    """
    if (
        isinstance(df, FinlabDataFrame)
        and _has_quarter_str_index(df)
        and _is_date_index(other.index)
    ):
        return df.index_str_to_date()
    return df


_DATE_AXIS = "index"
_STOCK_AXIS = "columns"


def _has_date_axis(df: pd.DataFrame) -> bool:
    """True for a wide frame whose rows are dates or quarter/month strings."""
    return isinstance(df.index, pd.DatetimeIndex) or bool(get_index_str_frequency(df))


def _series_axis(df: pd.DataFrame, s: pd.Series) -> str:
    """Which axis of ``df`` the Series labels: dates (rows) or stocks (columns).

    A date or quarterly/monthly string index labels dates. Otherwise the
    labels must overlap exactly one axis of ``df``; overlapping both or
    neither is ambiguous and raises instead of silently misaligning.
    """
    if isinstance(s.index, pd.DatetimeIndex) or get_index_str_frequency(s):
        return _DATE_AXIS
    col_hit = bool(s.index.isin(df.columns).any())
    row_hit = bool(s.index.isin(df.index).any())
    if col_hit != row_hit:
        return _STOCK_AXIS if col_hit else _DATE_AXIS
    overlap = (
        "both the dates and the stocks"
        if col_hit
        else "neither the dates nor the stocks"
    )
    raise ValueError(
        f"Cannot tell how to align this Series: its index matches {overlap} of "
        "the DataFrame. Pick the axis explicitly, e.g. df.mul(s, axis=0) to "
        "align on dates or df.mul(s, axis=1) to align on stocks (likewise "
        "add/sub/div/gt/lt/eq...).\n"
        "無法判斷 Series 要對齊日期還是股票：請明確指定，例如 "
        "df.mul(s, axis=0) 對齊日期、df.mul(s, axis=1) 對齊股票。"
    )


def _broadcast_over_dates(df: pd.DataFrame, s: pd.Series) -> FinlabDataFrame:
    """Repeat a per-stock Series on every date of ``df``.

    Stocks missing from the Series are False for a boolean Series (so logical
    ops treat them as not selected) and NaN otherwise.
    """
    fill_value = False if pd.api.types.is_bool_dtype(s.dtype) else np.nan
    row = s.reindex(df.columns, fill_value=fill_value).to_numpy()
    return FinlabDataFrame(
        np.broadcast_to(row, df.shape), index=df.index, columns=df.columns
    )


def _as_bool_mask(s: pd.Series) -> pd.Series | None:
    """``s`` as a bool Series when every value is a bool, else ``None``.

    Object-dtype Series holding only bools count too: pandas selects rows
    with them just like with a bool dtype.
    """
    if pd.api.types.is_bool_dtype(s.dtype):
        return s
    if s.dtype == object and pd.api.types.infer_dtype(s, skipna=False) == "boolean":
        return s.astype(bool)
    return None


def _select_by_series(
    df: pd.DataFrame,
    s: pd.Series,
    pandas_getitem: Callable[..., pd.DataFrame],
) -> pd.DataFrame:
    """``df[s]`` on a dated frame: a per-stock mask selects columns.

    A per-date mask keeps every date and empties the rows where it is False,
    so ``position[timing]`` goes to cash like ``position & timing``. Label
    Series and frames without a date index (long tables such as
    ``broker_transactions``) keep pandas semantics, so
    ``df[df["stock_id"] == "2330"]`` filters rows.
    """
    mask = _as_bool_mask(s)
    if mask is None or not _has_date_axis(df):
        return pandas_getitem(df, s)
    if _series_axis(df, mask) == _STOCK_AXIS:
        return df.loc[:, mask.reindex(df.columns, fill_value=False).to_numpy()]
    return _empty_masked_dates(df, mask)


def _empty_masked_dates(df: pd.DataFrame, mask: pd.Series) -> pd.DataFrame:
    """Keep the dates of ``df & mask``; rows where ``mask`` is False hold nothing.

    Dates align as in ``df & mask``: a date missing from ``mask`` takes the
    previous mask value. Nothing is False for a boolean frame and 0 for a
    weight frame, which ``sim()`` treats as cash.
    """
    aligned, date_mask = FinlabDataFrame.reshape(df, mask)
    held = date_mask.fillna(False).astype(bool)
    empty = False if all(map(pd.api.types.is_bool_dtype, aligned.dtypes)) else 0
    return aligned.where(held, empty)


def _reindex_row_labels(args: tuple[object, ...], kwargs: dict[str, object]) -> object:
    """Row labels requested by a ``DataFrame.reindex`` call, if any."""
    if "index" in kwargs:
        return kwargs["index"]
    labels = args[0] if args else kwargs.get("labels")
    if kwargs.get("axis") in (None, 0, "index", "rows"):
        return labels
    return None


def _fetch_refined_categories() -> dict[str, str]:
    """Fetch security categories and normalize sector names.

    Returns a dict mapping stock_id -> refined sector name.
    Shared by the FinlabDataFrame accessors that need sector lookups.
    """
    from finlab import data
    from finlab.compat import resolve_id_column

    categories = data.get("security_categories")
    cat = categories.set_index(resolve_id_column(categories)).category.to_dict()
    org_set = set(cat.values())
    valid_names = {o for o in org_set if isinstance(o, str) and o != "nan"}

    refine_cat: dict[str, str] = {}
    for s, c in cat.items():
        if c is None or c == "nan":
            refine_cat[s] = "其他"
        elif c == "電腦及週邊":
            refine_cat[s] = "電腦及週邊設備業"
        elif c[-1] == "業" and c[:-1] in valid_names:
            refine_cat[s] = c[:-1]
        else:
            refine_cat[s] = c
    return refine_cat


@warn_on_pandas_left_operand
@reshape_operations
class FinlabDataFrame(
    IndexConversionMixin,
    SignalMixin,
    NeutralizeMixin,
    IndustryMixin,
    pd.DataFrame,
):
    """回測語法糖
    除了使用熟悉的 Pandas 語法外，我們也提供很多語法糖，讓大家開發程式時，可以用簡易的語法完成複雜的功能，讓開發策略更簡潔！
    我們將所有的語法糖包裹在 `FinlabDataFrame` 中，用起來跟 `pd.DataFrame` 一樣，但是多了很多功能！
    只要使用 `finlab.data.get()` 所獲得的資料，皆為 `FinlabDataFrame` 格式，
    接下來我們就來看看， `FinlabDataFrame` 有哪些好用的語法糖吧！

    當資料日期沒有對齊（例如: 財報 vs 收盤價 vs 月報）時，在使用以下運算符號：
    `+`, `-`, `*`, `/`, `>`, `>=`, `==`, `<`, `<=`, `&`, `|`, `~`，
    不需要先將資料對齊，因為 `FinlabDataFrame` 會自動幫你處理，以下是示意圖。

    <img src="https://i.ibb.co/pQr5yx5/Screen-Shot-2021-10-26-at-5-32-44-AM.png" alt="steps">

    以下是範例：`cond1` 與 `cond2` 分別為「每天」，和「每季」的資料，假如要取交集的時間，可以用以下語法：

    ```py
    from finlab import data
    # 取得 FinlabDataFrame
    close = data.get('price:收盤價')
    roa = data.get('fundamental_features:ROA稅後息前')

    # 運算兩個選股條件交集
    cond1 = close > 37
    cond2 = roa > 0
    cond_1_2 = cond1 & cond2
    ```
    擷取 1101 台泥 的訊號如下圖，可以看到 `cond1` 跟 `cond2` 訊號的頻率雖然不相同，
    但是由於 `cond1` 跟 `cond2` 是 `FinlabDataFrame`，所以可以直接取交集，而不用處理資料頻率對齊的問題。
    <br />
    <img src="https://i.ibb.co/m9chXSQ/imageconds.png" alt="imageconds">

    總結來說，FinlabDataFrame 與一般 dataframe 唯二不同之處：
    1. 多了一些 method，如`df.is_largest()`, `df.sustain()`...等。
    2. 在做四則運算、不等式運算前，會將 df1、df2 的 index 取聯集，column 取交集。

    與 `pd.Series` 運算時，依 Series 的 index 判斷對齊方向：日期（或季/月字串）
    index 對齊日期；股票代號 index 對齊股票、套用到每一天（`&` / `|` 缺少的股票視為
    `False`，四則運算為 `NaN`）；兩者皆符合或皆不符合時會報錯，請改用
    `df.mul(s, axis=0)`（日期）或 `df.mul(s, axis=1)`（股票）明確指定。
    日期布林 Series 擇時：`position[cond]` 與 `position & cond` 都保留每個日期，
    False 的日期空手。
    """

    def __init__(self, *args: object, **kwargs: object) -> None:
        init = cast("Callable[..., None]", super().__init__)
        init(*args, **kwargs)
        self.id: int = uuid.uuid4().int

    @property
    def _constructor(self) -> type[FinlabDataFrame]:
        return FinlabDataFrame

    @property
    def weight(self) -> WeightAccessor:
        from finlab.dataframe.weight import WeightAccessor

        return WeightAccessor(self)

    @property
    def cs(self) -> CsAccessor:
        from finlab.dataframe.cs import CsAccessor

        return CsAccessor(self)

    @property
    def sector(self) -> SectorAccessor:
        from finlab.dataframe.sector import SectorAccessor

        return SectorAccessor(self)

    def __setattr__(self, name: str, value: object) -> None:
        if name == "index":
            caller_file = sys._getframe(1).f_code.co_filename
            caller_path = Path(caller_file).resolve()
            pandas_root = Path(pd.__file__).resolve().parent
            finlab_root = Path(__file__).resolve().parents[1]
            is_internal_assignment = caller_path.is_relative_to(
                pandas_root
            ) or caller_path.is_relative_to(finlab_root)
            if not is_internal_assignment:
                raise AttributeError(
                    "\n不要直接覆寫 FinlabDataFrame 的 index！"
                    "\n"
                    "\n原因："
                    "\n  FinlabDataFrame 會保留季報/月報索引的資料時間語意。"
                    "\n  直接覆寫 index 可能把尚未公開的資料提前用在回測中，"
                    "\n  導致未來資料汙染 (lookahead bias)。"
                    "\n"
                    "\n如果你要對齊季報/月報資料，請改用："
                    "\n  df = df.deadline()          # 依財報截止日統一換股（所有股票同日換）"
                    "\n  df = df.index_str_to_date() # 依各股實際財報公布日換股（避免前視偏差）"
                    "\n"
                    "\n如果你確定只是要用 pandas 語意自行處理 index，"
                    "\n請先轉成一般 DataFrame，再自行承擔時間對齊責任："
                    "\n  df = pd.DataFrame(df)"
                    "\n  df.index = pd.to_datetime(df.index)"
                    "\n"
                    "\n範例："
                    "\n  ❌ df.index = pd.to_datetime(df.index)"
                    "\n  ✅ df = df.deadline()"
                    "\n  ✅ df = df.index_str_to_date()"
                    "\n  ✅ df = pd.DataFrame(df); df.index = pd.to_datetime(df.index)"
                )
        super().__setattr__(name, value)

    @staticmethod
    @profile_alignment_call
    def reshape(
        df1: pd.DataFrame,
        df2: pd.DataFrame | pd.Series,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        isdf1 = isinstance(df1, pd.DataFrame)
        isdf2 = isinstance(df2, (pd.DataFrame, pd.Series))

        d1_index_freq = get_index_str_frequency(df1) if isdf1 else None
        d2_index_freq = get_index_str_frequency(df2) if isdf2 else None

        if isinstance(df2, pd.Series):
            if isdf1 and _series_axis(df1, df2) == _STOCK_AXIS:
                return df1, _broadcast_over_dates(df1, df2)
            df2 = FinlabDataFrame(dict.fromkeys(df1.columns, df2))
            if d2_index_freq:
                # tell user has high chance to use future data
                logger.warning(
                    "Detect pd.Series has season/month index, the chance of using future data is high!\n"
                    "Please convert index from str to date first then perform calculations.\n"
                    "Example: df.quantile(0.3, axis=1) -> df.index_str_to_date().quantile(0.3, axis=1)"
                )

        if (
            ((d1_index_freq or d2_index_freq) and (d1_index_freq != d2_index_freq))
            and isdf1
            and isdf2
        ):
            df1 = df1.index_str_to_date() if isinstance(df1, FinlabDataFrame) else df1
            df2 = df2.index_str_to_date() if isinstance(df2, FinlabDataFrame) else df2

        if (
            isdf1
            and isdf2
            and len(df1)
            and len(df2)
            and isinstance(df1.index[0], pd.Timestamp)
            and isinstance(df2.index[0], pd.Timestamp)
        ):
            # Fast path: skip reindex when index and columns already match
            if (
                len(df1.index) == len(df2.index)
                and len(df1.columns) == len(df2.columns)
                and df1.index.equals(df2.index)
                and df1.columns.equals(df2.columns)
            ):
                return df1, df2

            index = df1.index.union(df2.index)
            columns = df1.columns.intersection(df2.columns)

            if len(df1.index) * len(df2.index) != 0:
                index_start = max(df1.index[0], df2.index[0])
                index = index[index >= index_start]

            return (
                df1.reindex(index=index, method="ffill")[columns],
                df2.reindex(index=index, method="ffill")[columns],
            )

        return df1, df2

    def reindex(self, *args: Any, **kwargs: Any) -> FinlabDataFrame:
        """``pd.DataFrame.reindex`` that understands quarterly string indexes.

        Reindexing a quarterly ('2013-Q1') FinlabDataFrame onto dates first
        converts the quarters to disclosure dates with ``index_str_to_date()``,
        so ``df.reindex(close.index, method='ffill')`` gives each stock's
        latest disclosed value instead of all NaN or a TypeError.
        """
        if _has_quarter_str_index(self) and _is_date_index(
            _reindex_row_labels(args, kwargs)
        ):
            return self.index_str_to_date().reindex(*args, **kwargs)
        return cast("FinlabDataFrame", super().reindex(*args, **kwargs))

    def align(
        self, other: pd.DataFrame | pd.Series, *args: Any, **kwargs: Any
    ) -> tuple[FinlabDataFrame, pd.DataFrame | pd.Series]:
        """``pd.DataFrame.align`` that converts a quarterly side to dates first."""
        left = _to_date_index_for_alignment(self, other)
        if isinstance(other, pd.DataFrame):
            other = _to_date_index_for_alignment(other, left)
        if left is not self:
            return cast(
                "tuple[FinlabDataFrame, pd.DataFrame | pd.Series]",
                left.align(other, *args, **kwargs),
            )
        return cast(
            "tuple[FinlabDataFrame, pd.DataFrame | pd.Series]",
            super().align(other, *args, **kwargs),
        )

    def average(self, n: int) -> FinlabDataFrame:
        """取 n 筆移動平均

        若股票在時間窗格內，有 N/2 筆 NaN，則會產生 NaN。
        Args:
          n (positive-int): 設定移動窗格數。
        Returns:
          (pd.DataFrame): data
        Examples:
            股價在均線之上
            ```py
            from finlab import data
            close = data.get('price:收盤價')
            sma = close.average(10)
            cond = close > sma
            ```
            只需要簡單的語法，就可以將其中一部分的訊號繪製出來檢查：
            ```py
            import matplotlib.pyplot as plt

            close.loc['2021', '2330'].plot()
            sma.loc['2021', '2330'].plot()
            cond.loc['2021', '2330'].mul(20).add(500).plot()

            plt.legend(['close', 'sma', 'cond'])
            ```
            <img src="https://i.ibb.co/Mg1P85y/sma.png" alt="sma">
        """
        return self.rolling(n, min_periods=int(n / 2)).mean()

    def is_largest(self, n: int) -> FinlabDataFrame:
        """取每列前 n 筆大的數值

        若符合 `True` ，反之為 `False` 。用來篩選每天數值最大的股票。

        <img src="https://i.ibb.co/8rh3tbt/is-largest.png" alt="is-largest">
        Args:
          n (positive-int): 設定每列前 n 筆大的數值。
        Returns:
          (pd.DataFrame): data
        Examples:
            每季 ROA 前 10 名的股票
            ```py
            from finlab import data

            roa = data.get('fundamental_features:ROA稅後息前')
            good_stocks = roa.is_largest(10)
            ```

            只在符合條件的股票中排名：用 `score[cond]` 排除不符合的股票，
            不要用 `cond * score`。後者讓不符合的股票分數為 0，符合的股票
            少於 n 檔時會被補進來，並發出 `TopNPaddingWarning`。
            ```py
            top = score[cond].is_largest(10)
            ```
        """
        # Quarterly rows become disclosure dates first, so each date only
        # compares values already public on that date.
        return _top_n(self.index_str_to_date(), n, largest=True)

    def is_smallest(self, n: int) -> FinlabDataFrame:
        """取每列前 n 筆小的數值

        若符合 `True` ，反之為 `False` 。用來篩選每天數值最小的股票。
        Args:
          n (positive-int): 設定每列前 n 筆小的數值。
        Returns:
          (pd.DataFrame): data
        Examples:
            股價淨值比最小的 10 檔股票
            ```py
            from finlab import data

            pb = data.get('price_earning_ratio:股價淨值比')
            cheap_stocks = pb.is_smallest(10)
            ```

            只在符合條件的股票中排名時用 `pb[cond].is_smallest(10)`。
            每列同為最高值的股票多於剩餘名額、只能依欄位順序挑選時，
            會發出 `TopNPaddingWarning`。
        """
        return _top_n(self.index_str_to_date(), n, largest=False)

    def rank(
        self,
        *args: object,
        valid: pd.DataFrame | pd.Series | None = None,
        **kwargs: object,
    ) -> FinlabDataFrame:
        """Cross-sectional or time-series ranking.

        Args:
            valid (DataFrame or Series of bool, optional):
                只有 valid 為 True 的 cell 才參與排名。
                valid 為 False/NaN 的 cell 在排名前設為 NaN，
                因此不影響 pct=True 的分母。
                常見用法：fillna 後傳入原始 notna() mask，
                避免新上市或歷史不足的股票污染百分位排名。
        """
        # 1) 解析 axis，預設為 0（沿時間軸）
        axis = args[0] if args else kwargs.get("axis", 0)

        # 2) look-ahead 檢查
        if axis in (0, "index"):
            warnings.warn(
                "Unsafe rank: 排名沿時間軸 (axis=0) 可能洩漏未來資料；"
                "請改用 rolling().rank()、expanding().rank()，或 axis=1。",
                LookaheadWarning,
                stacklevel=2,
            )

        # 3) Fast path for axis=1 (cross-sectional) ranking.
        #    Convert quarterly rows to disclosure dates BEFORE ranking so each
        #    date only ranks the values already public on that date.  Ranking
        #    the raw quarter row first would let an early reporter be ranked
        #    against peers' same-quarter values that were not yet disclosed.
        #    The converted frame holds one row per distinct disclosure date,
        #    so only event rows are ranked, not every trading day.
        pct = kwargs.get("pct", False)
        ascending = kwargs.get("ascending", True)
        na_option = kwargs.get("na_option", "keep")

        if axis in (1, "columns") and na_option == "keep":
            masked = self.where(valid) if valid is not None else self
            source = masked.index_str_to_date()

            # Delegate tie handling to pandas.  The previous numpy-argsort fast
            # path assigned ordinal ranks (method="first"), which silently
            # disagreed with pandas' default method="average": tied cells
            # received distinct percentiles (e.g. low-cardinality/discrete
            # factors), so the same tied group had non-zero cross-sectional
            # std instead of 0.
            method = kwargs.get("method", "average")
            # Nullable-boolean cells not yet disclosed become NaN, not False.
            values = source.to_numpy(dtype="float64", na_value=np.nan)
            # Rank the transposed view along axis=0: pandas ranks contiguous
            # columns ~1.6x faster than rows, with identical results.
            ranks = pd.DataFrame(values.T).rank(
                axis=0,
                method=method,
                ascending=ascending,
                pct=pct,
                na_option="keep",
            )

            return FinlabDataFrame(
                ranks.to_numpy().T, index=source.index, columns=source.columns
            )

        # 4) Fallback: full index conversion + pandas rank
        converted = self.index_str_to_date()
        if valid is not None:
            converted = converted.where(valid)
        rank = cast("Callable[..., pd.DataFrame]", pd.DataFrame.rank)
        ranked = rank(converted, *args, **kwargs)
        return FinlabDataFrame(ranked)

    def rise(self, n: int = 1) -> FinlabDataFrame:
        """數值上升中

        取是否比前第n筆高，若符合條件的值則為True，反之為False。
        <img src="https://i.ibb.co/Y72bN5v/Screen-Shot-2021-10-26-at-6-43-41-AM.png" alt="Screen-Shot-2021-10-26-at-6-43-41-AM">
        Args:
          n (positive-int): 設定比較前第n筆高。
        Returns:
          (pd.DataFrame): data
        Examples:
            收盤價是否高於10日前股價
            ```py
            from finlab import data
            data.get('price:收盤價').rise(10)
            ```
        """
        return self > self.shift(n)

    def fall(self, n: int = 1) -> FinlabDataFrame:
        """數值下降中

        取是否比前第n筆低，若符合條件的值則為True，反之為False。
        <img src="https://i.ibb.co/Y72bN5v/Screen-Shot-2021-10-26-at-6-43-41-AM.png" alt="Screen-Shot-2021-10-26-at-6-43-41-AM">
        Args:
          n (positive-int): 設定比較前第n筆低。
        Returns:
          (pd.DataFrame): data
        Examples:
            收盤價是否低於10日前股價
            ```py
            from finlab import data
            data.get('price:收盤價').fall(10)
            ```
        """
        return self < self.shift(n)

    def rebalance(self, freq: str | pd.Index | list) -> FinlabDataFrame:
        """Downsample to keep only the last observation per period.

        Equivalent to ``self.resample(freq).last()``.

        Args:
            freq: Pandas frequency string, e.g. ``'ME'`` (month-end),
                ``'W'`` (weekly), ``'QE'`` (quarter-end), or explicit dates
                to select with ``reindex``.
        """
        if not isinstance(freq, str):
            return FinlabDataFrame(self.reindex(pd.DatetimeIndex(freq)))
        return FinlabDataFrame(self.resample(freq).last())

    def lazy(self) -> LazyWide:
        """Wrap this DataFrame into a lazy computation handle.

        Returns a ``LazyWide`` proxy that records operations without
        executing them.  Call ``.rebalance(freq)`` or ``.collect()``
        on the result to trigger execution at specific dates only.

        Example::

            close = data.get('price:收盤價')
            position = (
                close.lazy()
                .rolling(60).mean()
                .rank(axis=1, pct=True)
                .is_largest(10)
                .rebalance('M')
            )
        """
        from finlab.dataframe.lazy import lazy

        return lazy(self)

    def quantile_row(self, c: float) -> pd.Series:
        """股票當天數值分位數

        取得每列c定分位數的值。
        Args:
          c (positive-int): 設定每列 n 定分位數的值。
        Returns:
          (pd.DataFrame): data
        Examples:
            取每日股價前90％分位數
            ```py
            from finlab import data
            data.get('price:收盤價').quantile_row(0.9)
            ```
        """
        return self.index_str_to_date().quantile(c, axis=1)


def _top_n(df: FinlabDataFrame, n: int, *, largest: bool) -> FinlabDataFrame:
    """Vectorised top-/bottom-n row selector for is_largest/is_smallest.

    Uses ``np.argpartition`` (``O(ncols)`` per row) instead of a full
    ``argsort`` to find the top/bottom threshold without a full sort.
    Values tied at the threshold are selected in their original column
    order, matching stable sort semantics.
    """

    vals = df.to_numpy(dtype="float64", na_value=np.nan, copy=True)
    nrows, ncols = vals.shape

    if nrows == 0 or ncols == 0 or n <= 0:
        return FinlabDataFrame(
            np.zeros((nrows, ncols), dtype=bool),
            index=df.index,
            columns=df.columns,
        )

    valid = ~np.isnan(vals)
    if n >= ncols:
        return FinlabDataFrame(valid, index=df.index, columns=df.columns)

    if largest:
        np.negative(vals, out=vals)
    # Worst valid value per row (fmax skips NaN, before NaN becomes inf).
    floor = np.fmax.reduce(vals, axis=1)
    vals[~valid] = np.inf

    result = np.zeros((nrows, ncols), dtype=bool)
    valid_count = valid.sum(axis=1)
    select_all = valid_count <= n
    result[select_all] = valid[select_all]

    rows = np.flatnonzero(~select_all)
    if rows.size:
        partition_idx = np.argpartition(vals, n - 1, axis=1)
        thresholds = vals[rows, partition_idx[rows, n - 1]].copy()
        del partition_idx

        better = vals[rows] < thresholds[:, None]
        result[rows] = better

        # Rows here hold more than n valid values, so a threshold equal to the
        # row's worst valid value means the floor tie group exceeds the free
        # slots and column order picked the rest.
        padded_rows = np.flatnonzero(thresholds == floor[rows])
        if padded_rows.size:
            shown = padded_rows[:_TOP_N_PADDING_EXAMPLE_DATES]
            _warn_top_n_padding(
                n,
                padded_rows.size,
                df.index[rows[shown]],
                n - better[shown].sum(axis=1),
                largest=largest,
            )

        for row, threshold in zip(rows, thresholds, strict=True):
            need = n - int(result[row].sum())
            if need <= 0:
                continue
            ties = valid[row] & (vals[row] == threshold)
            tie_idx = np.flatnonzero(ties)
            result[row, tie_idx[:need]] = True

    return FinlabDataFrame(result, index=df.index, columns=df.columns)


def _warn_top_n_padding(
    n: int,
    n_dates: int,
    example_dates: pd.Index,
    padded: np.ndarray,
    *,
    largest: bool,
) -> None:
    call = f"{'is_largest' if largest else 'is_smallest'}({n})"
    floor, floor_zh = ("lowest", "最低") if largest else ("highest", "最高")
    labels = (
        example_dates.strftime("%Y-%m-%d")
        if isinstance(example_dates, pd.DatetimeIndex)
        else example_dates
    )
    examples = ", ".join(
        f"{label} ({count})" for label, count in zip(labels, padded, strict=True)
    )
    warnings.warn(
        f"{call} filled its slots with stocks tied at the row's {floor} value, "
        f"picked by column order, on {n_dates} date(s), e.g. {examples} "
        f"(date (stocks filled)). This usually comes from (cond * score).{call}: "
        f"stocks failing cond get score 0 and fill the slots when fewer than {n} "
        f"qualify. Use score[cond].{call} or score.where(cond).{call} to exclude "
        "them. The selection result is unchanged.\n"
        f"{call} 在 {n_dates} 個日期用每列{floor_zh}值的同分股票補滿名額，"
        f"依欄位順序挑選，例如 {examples}（日期（補入檔數））。常見原因是 "
        f"(cond * score).{call}：不符合 cond 的股票分數為 0，符合的股票少於 "
        f"{n} 檔時會被補進來。請改用 score[cond].{call} 或 "
        f"score.where(cond).{call} 排除它們。選股結果不變。",
        TopNPaddingWarning,
        stacklevel=4,
    )
