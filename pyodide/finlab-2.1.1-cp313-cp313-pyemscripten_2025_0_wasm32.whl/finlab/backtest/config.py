"""Backtest configuration and input validation.

Houses SimConfig, parameter validation, and deprecation helpers
extracted from the monolithic backtest module.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    import datetime

import pandas as pd

from finlab import config
from finlab.core.upload import FORCED_STRATEGY_NAME_ENV
from finlab.dataframe import FinlabDataFrame
from finlab.dataframe.core_index import fill_unknown_boolean
from finlab.market import Market
from finlab.markets import get_market_by_name
from finlab.utils import check_version

from .helpers import coerce_object_position, resolve_stop_defaults


class OperationAndWeight(TypedDict):
    """Typed dict describing weights and actions from the backtest core."""

    weights: list[float]
    next_weights: list[float]
    weight_time: int
    next_weight_time: int
    actions: list[str]


@dataclass(slots=True)
class SimConfig:
    """Configuration for backtest simulation parameters.

    Groups the many sim() parameters into a single config object
    for cleaner internal passing between phases.
    """

    resample: (
        str
        | pd.DataFrame
        | pd.Series
        | pd.DatetimeIndex
        | list[datetime.datetime]
        | None
    ) = None
    data_readiness: dict | None = None
    planned_rebalance_date: pd.Timestamp | None = None
    resample_offset: str | None = None
    trade_at_price: str | pd.DataFrame = "close"
    position_limit: float = 1
    fee_ratio: float | None = None
    tax_ratio: float | None = None
    name: str = "未命名"
    stop_loss: float | None = None
    take_profit: float | None = None
    trail_stop: float | None = None
    trail_stop_activation: float | None = None
    touched_exit: bool = False
    retain_cost_when_rebalance: bool = False
    stop_trading_next_period: bool = True
    live_performance_start: str | datetime.datetime | None = None
    end_date: str | datetime.date | pd.Timestamp | None = None
    mae_mfe_window: int = 0
    mae_mfe_window_step: int = 1
    market: Market | None = None
    upload: bool | None = None
    notification_enable: bool = False
    line_access_token: str = ""

    def __post_init__(self) -> None:
        if self.upload is None:
            # Cloud-scheduled runs must refresh the deployed report; Studio and
            # local runs upload only when the caller passes upload=True.
            self.upload = FORCED_STRATEGY_NAME_ENV in os.environ


def _validate_notification_config(cfg: SimConfig) -> None:
    if cfg.notification_enable and cfg.line_access_token == "":
        raise ValueError(
            "line_access_token is required when enabling notifications. Please provide a valid token."
        )


def _normalize_position_input(
    position: pd.DataFrame | pd.Series,
) -> pd.DataFrame | pd.Series:
    if isinstance(position, FinlabDataFrame):
        position = position.index_str_to_date()

    # Give nullable-boolean and object (merged-sleeve) columns a real dtype.
    return coerce_object_position(fill_unknown_boolean(position))


def _fill_missing_position(
    position: pd.DataFrame | pd.Series,
) -> pd.DataFrame | pd.Series:
    """Read missing position values as not held, once for every sim path.

    This is the only place position NaN is handled: everything downstream
    (rebalance detection, the engine, report weights) sees NaN-free input.
    Boolean columns cannot hold NaN after ``_normalize_position_input``, so
    ``0`` only lands in numeric columns. A NaN-free frame is not copied.
    """
    return position.fillna(0)


def _resolve_end_date(
    end_date: str | datetime.date | pd.Timestamp,
    tz: datetime.tzinfo | None,
) -> pd.Timestamp:
    """Parse ``end_date`` as an inclusive bound in the position's timezone.

    A bare date (midnight) covers that whole day, so intraday bars on the
    end date are kept.
    """
    cutoff = pd.Timestamp(end_date)
    if cutoff.tzinfo is None and tz is not None:
        cutoff = cutoff.tz_localize(tz)
    elif cutoff.tzinfo is not None:
        cutoff = cutoff.tz_convert(tz) if tz is not None else cutoff.tz_localize(None)
    if cutoff == cutoff.normalize():
        # Whole seconds stay exact for indexes stored in s/ms/us/ns units.
        cutoff += pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
    return cutoff


def _apply_end_date(
    position: pd.DataFrame | pd.Series,
    cfg: SimConfig,
) -> pd.DataFrame | pd.Series:
    if cfg.end_date is None:
        return position
    if not isinstance(position.index, pd.DatetimeIndex):
        raise TypeError("Expected the dataframe to have a DatetimeIndex")

    cfg.end_date = _resolve_end_date(cfg.end_date, position.index.tz)
    cut = position.loc[position.index <= cfg.end_date]
    if cut.empty:
        raise ValueError(
            f"end_date={cfg.end_date} is earlier than the first position date "
            f"{position.index[0]}."
        )
    return cut


def _validate_position_shape(position: pd.DataFrame | pd.Series) -> None:
    if not position.notna().to_numpy().any():
        raise ValueError(
            "position must contain at least one non-NaN value and one asset. "
            "Combining disjoint positions with + can produce all NaN; "
            "use left.add(right, fill_value=0) to combine holdings, "
            "or explicit zeros for an all-cash strategy."
        )
    if not isinstance(position.index, pd.DatetimeIndex):
        raise TypeError("Expected the dataframe to have a DatetimeIndex")

    if isinstance(position, pd.Series) and position.name is None:
        raise ValueError(
            'Asset name not found. Please asign asset name by "position.name = \'2330\'".'
        )


def _normalize_trade_at_price(cfg: SimConfig) -> None:
    _ = cfg.trade_at_price


def _normalize_resample_config(cfg: SimConfig) -> None:
    _ = cfg.resample_offset
    _ = cfg.resample


def _resolve_market_config(cfg: SimConfig) -> None:
    if cfg.market is None:
        cfg.market = config.get_market()
    elif isinstance(cfg.market, str):
        cfg.market = get_market_by_name(cfg.market)

    if not isinstance(cfg.market, Market):
        raise TypeError(
            "It seems like the market has "
            "not been specified well when using the hold_until"
            " function. Please provide the market='TW', "
            "market='US' or market=Market"
        )

    if cfg.fee_ratio is None:
        cfg.fee_ratio = cfg.market.default_fee_ratio()
    if cfg.tax_ratio is None:
        cfg.tax_ratio = cfg.market.default_tax_ratio()


def _validate_market_position_compatibility(
    position: pd.DataFrame | pd.Series,
    cfg: SimConfig,
) -> None:
    if cfg.market is None:
        raise TypeError("market must be resolved before validating position columns")
    symbol = (
        position.columns[0] if isinstance(position, pd.DataFrame) else position.name
    )
    if not str(symbol)[0].isdigit() and cfg.market.get_name() == "tw_stock":
        raise ValueError(
            "Stock ID should be a number. Please check the stock ID in the position dataframe.\n"
            "If you are backtesting US stocks, please set market='US_STOCK'"
        )


def _build_engine_inputs(cfg: SimConfig) -> None:
    (
        cfg.stop_loss,
        cfg.take_profit,
        cfg.trail_stop,
        cfg.trail_stop_activation,
    ) = resolve_stop_defaults(
        cfg.stop_loss,
        cfg.take_profit,
        cfg.trail_stop,
        cfg.trail_stop_activation,
    )


def validate_sim_inputs(
    position: pd.DataFrame | pd.Series,
    cfg: SimConfig,
    *,
    check_package_version: bool = True,
) -> tuple[pd.DataFrame | pd.Series, SimConfig]:
    """Validate sim parameters, resolve market/fee defaults, and check types.

    Performs version checks, validates notification config, resolves the market
    instance, fills in default fee/tax ratios, and validates position structure.
    Returns the (possibly converted) position and the updated config.
    """
    if check_package_version:
        check_version()
    _validate_notification_config(cfg)
    position = _normalize_position_input(position)
    position = _apply_end_date(position, cfg)
    _normalize_resample_config(cfg)
    _normalize_trade_at_price(cfg)
    # The all-NaN check must see NaN, so the fill runs right after it.
    _validate_position_shape(position)
    position = _fill_missing_position(position)
    _resolve_market_config(cfg)
    _validate_market_position_compatibility(position, cfg)
    _build_engine_inputs(cfg)

    return position, cfg
