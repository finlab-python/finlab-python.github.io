"""Formal multi-strategy backtest screening."""

from __future__ import annotations

import hashlib
import json
import logging
import time
import uuid
from collections.abc import Callable, Mapping
from dataclasses import replace
from typing import Any

import pandas as pd

from finlab.utils import check_version

from .config import SimConfig
from .metrics import SCHEMA_VERSION, metrics_from_creturn, metrics_to_dict
from .sim import (
    _align_position_with_market,
    _authorize_backtest,
    _backtest_context,
    _collect_lazy_position_for_sim,
    _derive_simulation_schedule,
    _execute_backtest_engine,
    _finalize_creturn,
    _prefetch_market_datasets,
    _prepare_simulation_inputs,
    _validate_sim_inputs,
)

logger = logging.getLogger(__name__)
ProgressCallback = Callable[[dict[str, Any]], None]


def _schedule_with_shared_calendar(
    position: pd.DataFrame | pd.Series,
    cfg: SimConfig,
    price: pd.DataFrame,
    cached: tuple[pd.DatetimeIndex, Any] | None,
) -> tuple[Any, tuple[pd.DatetimeIndex, Any] | None]:
    """Reuse a formal resample calendar when position indexes are identical."""
    if (
        cached is not None
        and cfg.resample is not None
        and position.index.equals(cached[0])
    ):
        template = cached[1]
        frame = position.to_frame() if isinstance(position, pd.Series) else position
        if template.dates is not None:
            frame = frame.reindex(template.dates, method="ffill")
        return (
            replace(template, position=_align_position_with_market(frame, price)),
            cached,
        )

    schedule = _derive_simulation_schedule(position, cfg, price)
    if cfg.resample is not None:
        cached = (position.index.copy(), schedule)
    return schedule, cached


def _emit(callback: ProgressCallback | None, phase: str, **values: Any) -> None:
    if callback is None:
        return
    try:
        callback({"phase": phase, **values})
    except Exception:
        logger.exception("sim_batch progress_callback failed during %s", phase)


def _config_group(cfg: SimConfig) -> str:
    market = cfg.market
    market_name = market.get_name() if market is not None else None
    trade_at = cfg.trade_at_price
    if isinstance(trade_at, pd.DataFrame):
        trade_at = {
            "kind": "dataframe",
            "shape": list(trade_at.shape),
            "columns": [str(value) for value in trade_at.columns],
        }
    payload = {
        "market": market_name,
        "resample": str(cfg.resample),
        "resample_offset": cfg.resample_offset,
        "trade_at_price": trade_at,
        "position_limit": cfg.position_limit,
        "fee_ratio": cfg.fee_ratio,
        "tax_ratio": cfg.tax_ratio,
        "stop_loss": cfg.stop_loss,
        "take_profit": cfg.take_profit,
        "trail_stop": cfg.trail_stop,
        "trail_stop_activation": cfg.trail_stop_activation,
        "touched_exit": cfg.touched_exit,
        "retain_cost_when_rebalance": cfg.retain_cost_when_rebalance,
        "stop_trading_next_period": cfg.stop_trading_next_period,
        "mae_mfe_window": cfg.mae_mfe_window,
        "mae_mfe_window_step": cfg.mae_mfe_window_step,
        "end_date": cfg.end_date,
    }
    encoded = json.dumps(payload, sort_keys=True, default=str).encode()
    return "sha256:" + hashlib.sha256(encoded).hexdigest()


def _failed_item(
    strategy: str,
    error: Exception,
    *,
    batch_id: str,
    batch_group: str,
    batch_size: int,
    elapsed_ms: int,
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "strategy": strategy,
        "status": "failed",
        "metrics": {},
        "warnings": [],
        "provenance": {
            "schema_version": SCHEMA_VERSION,
            "metrics_backend": "native_sim_batch",
            "metrics_only": True,
            "batch_id": batch_id,
            "batch_group": batch_group,
            "batch_size": batch_size,
        },
        "fallback_reason": None,
        "elapsed_ms": elapsed_ms,
        "error": {"type": type(error).__name__, "message": str(error)},
    }


def sim_batch(  # noqa: C901
    positions: Mapping[str, pd.DataFrame | pd.Series],
    *,
    metrics_only: bool = True,
    progress_callback: ProgressCallback | None = None,
    **sim_options: Any,
) -> list[dict[str, Any]]:
    """Screen multiple compatible positions with the formal backtest engine.

    A call is one compatibility group: all formal engine options are shared.
    Callers must make separate calls for different markets, schedules, prices,
    fees, taxes, or stop settings. Failures are returned per strategy and never
    cause already-independent siblings to be discarded.
    """
    if not isinstance(positions, Mapping) or not positions:
        raise ValueError("positions must be a non-empty mapping")
    strategy_ids = [str(strategy) for strategy in positions]
    if len(set(strategy_ids)) != len(strategy_ids):
        raise ValueError("position keys must remain unique when converted to strings")
    if not metrics_only:
        raise ValueError("sim_batch currently supports metrics_only=True only")
    if "fast_mode" in sim_options:
        raise TypeError(
            "fast_mode was removed; use formal sim_batch(..., metrics_only=True)"
        )
    if sim_options.get("upload"):
        raise ValueError("sim_batch screening cannot upload reports")
    if sim_options.get("notification_enable"):
        raise ValueError("sim_batch screening cannot send notifications")

    sim_options["upload"] = False
    sim_options["notification_enable"] = False
    cfg = SimConfig(**sim_options)
    batch_id = "batch-" + uuid.uuid4().hex
    total = len(positions)
    _emit(
        progress_callback,
        "batch_engine_start",
        completed=0,
        total=total,
        batch_size=total,
        batch_id=batch_id,
        metrics_backend="native_sim_batch",
    )

    # Version/data status is intentionally checked once per batch, not once per
    # position. Market resolution and engine defaults remain the formal ones.
    check_version()
    validated: dict[str, pd.DataFrame | pd.Series] = {}
    validation_errors: dict[str, Exception] = {}
    for strategy, position in positions.items():
        try:
            if hasattr(position, "collect") and not isinstance(
                position, (pd.DataFrame, pd.Series)
            ):
                position = _collect_lazy_position_for_sim(position, cfg)
            position, cfg = _validate_sim_inputs(
                position, cfg, check_package_version=False
            )
            validated[str(strategy)] = position
        except Exception as error:  # noqa: BLE001 - isolate invalid batch items
            validation_errors[str(strategy)] = error

    # If no item validates, there is no market context to prepare.
    batch_group = _config_group(cfg)
    if not validated:
        invalid_results = [
            _failed_item(
                str(strategy),
                validation_errors[str(strategy)],
                batch_id=batch_id,
                batch_group=batch_group,
                batch_size=total,
                elapsed_ms=0,
            )
            for strategy in positions
        ]
        for index, invalid_item in enumerate(invalid_results, start=1):
            _emit(
                progress_callback,
                "item_result",
                strategy=invalid_item["strategy"],
                completed=index,
                total=total,
                batch_size=total,
                batch_id=batch_id,
                item=invalid_item,
            )
        _emit(
            progress_callback,
            "batch_engine_complete",
            completed=total,
            total=total,
            batch_size=total,
            batch_id=batch_id,
        )
        return invalid_results

    _prefetch_market_datasets(cfg)
    first_position = next(iter(validated.values()))
    shared_prepared = _prepare_simulation_inputs(first_position, cfg)
    comparison_start = max(position.index[0] for position in validated.values())
    comparison_end = min(position.index[-1] for position in validated.values())
    comparison_index = shared_prepared.price.loc[comparison_start:comparison_end].index
    if comparison_index.empty:
        raise ValueError("sim_batch positions do not share a common evaluation period")
    encryption = _authorize_backtest()
    results: list[dict[str, Any]] = []
    shared_calendar: tuple[pd.DatetimeIndex, Any] | None = None

    with _backtest_context():
        for index, strategy_value in enumerate(positions, start=1):
            strategy = str(strategy_value)
            started = time.perf_counter()
            _emit(
                progress_callback,
                "running",
                strategy=strategy,
                completed=index - 1,
                total=total,
                batch_size=total,
                batch_id=batch_id,
                batch_group=batch_group,
            )
            validation_error = validation_errors.get(strategy)
            item: dict[str, Any]
            if validation_error is not None:
                item = _failed_item(
                    strategy,
                    validation_error,
                    batch_id=batch_id,
                    batch_group=batch_group,
                    batch_size=total,
                    elapsed_ms=int((time.perf_counter() - started) * 1000),
                )
            else:
                try:
                    position = validated[strategy]
                    prepared = replace(shared_prepared, position=position)
                    schedule, shared_calendar = _schedule_with_shared_calendar(
                        position, cfg, prepared.price, shared_calendar
                    )
                    engine_run = _execute_backtest_engine(
                        cfg, prepared, schedule, encryption
                    )
                    creturn = _finalize_creturn(cfg, prepared, schedule, engine_run)
                    creturn = creturn.reindex(comparison_index).ffill().fillna(1.0)
                    metrics = metrics_from_creturn(creturn, "native_sim_batch")
                    provenance = dict(metrics.provenance)
                    provenance.update(
                        {
                            "batch_id": batch_id,
                            "batch_group": batch_group,
                            "batch_size": total,
                            "comparison_period_start": comparison_index[0].isoformat(),
                            "comparison_period_end": comparison_index[-1].isoformat(),
                        }
                    )
                    item = {
                        "schema_version": SCHEMA_VERSION,
                        "strategy": strategy,
                        "status": "completed",
                        "metrics": metrics_to_dict(metrics),
                        "warnings": [],
                        "provenance": provenance,
                        "fallback_reason": None,
                        "elapsed_ms": int((time.perf_counter() - started) * 1000),
                        "error": None,
                    }
                except Exception as caught:  # noqa: BLE001 - isolate engine failures
                    item = _failed_item(
                        strategy,
                        caught,
                        batch_id=batch_id,
                        batch_group=batch_group,
                        batch_size=total,
                        elapsed_ms=int((time.perf_counter() - started) * 1000),
                    )
            results.append(item)
            _emit(
                progress_callback,
                "item_result",
                strategy=strategy,
                completed=index,
                total=total,
                batch_size=total,
                batch_id=batch_id,
                item=item,
            )

    _emit(
        progress_callback,
        "batch_engine_complete",
        completed=total,
        total=total,
        batch_size=total,
        batch_id=batch_id,
    )
    return results
