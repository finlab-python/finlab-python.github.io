"""Pure helper functions extracted from ``finlab.backtest``.

Every function in this module is a *pure* transformation: it takes explicit
inputs, returns explicit outputs, and has no side-effects (no network, no
module-level state, no mutation of inputs).  This makes them independently
testable offline.
"""

from __future__ import annotations

import functools
import numbers
import operator
import warnings
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    import datetime


# ---------------------------------------------------------------------------
# Stop / take-profit / trail-stop sentinel defaults
# ---------------------------------------------------------------------------


def resolve_stop_defaults(
    stop_loss: float | None,
    take_profit: float | None,
    trail_stop: float | None,
    trail_stop_activation: float | None = None,
) -> tuple[float, float, float, float]:
    """Map user-facing ``None`` / ``0`` sentinels to engine-safe defaults.

    The backtest engine uses ``1`` for "no stop-loss" (i.e. never triggers),
    ``inf`` for "no take-profit" and ``inf`` for "no trail-stop".

    Returns:
        ``(stop_loss, take_profit, trail_stop, trail_stop_activation)`` with
        sentinels resolved.
    """
    resolved_sl = stop_loss if (stop_loss is not None and stop_loss != 0) else 1
    resolved_tp = (
        take_profit if (take_profit is not None and take_profit != 0) else np.inf
    )
    resolved_ts = trail_stop if (trail_stop is not None and trail_stop != 0) else np.inf
    resolved_tsa = (
        trail_stop_activation
        if (trail_stop_activation is not None and trail_stop_activation != 0)
        else 0
    )
    return resolved_sl, resolved_tp, resolved_ts, resolved_tsa


# ---------------------------------------------------------------------------
# Position weight normalisation
# ---------------------------------------------------------------------------


def normalize_position_weights(
    position_values: np.ndarray,
    position_limit: float,
) -> np.ndarray:
    """Normalise position weights so that total absolute weight <= 1.

    Each row is independently scaled so that ``sum(|w|) <= 1``.  If
    ``position_limit < 1``, individual weights are further clipped.
    ``NaN`` weights mean "not held" and become ``0``. ``sim()`` never passes
    NaN (it fills once at input), but ``Position.from_weight`` forwards raw
    user weights and ``df.weight`` methods pass unknown weights as NaN.

    Args:
        position_values: 2-D float array of raw position weights
            (rows = dates, cols = assets).  **A copy is made internally;
            the caller's array is never mutated.**
        position_limit: Per-asset cap (0 < limit <= 1).

    Returns:
        New 2-D float array with normalised weights.
    """
    pos = position_values.astype(float, copy=True)
    pos[np.isnan(pos)] = 0
    total_weight = np.abs(pos).sum(axis=1)
    np.clip(total_weight, 1, None, out=total_weight)
    mask = total_weight != 0
    pos[mask] = pos[mask] / total_weight[mask, np.newaxis]
    pos[~mask] = 0
    if position_limit < 1:
        np.clip(pos, -abs(position_limit), abs(position_limit), out=pos)
    return pos


# ``infer_dtype`` kinds that become float. An all-missing ("empty") column
# carries no type, so it stays float NaN for the all-NaN position check.
_FLOAT_KINDS = frozenset(
    {"empty", "integer", "floating", "mixed-integer-float", "decimal"}
)
# Kinds that may mix numbers with non-numbers and need a per-value check.
_MIXED_KINDS = frozenset({"mixed", "mixed-integer"})
_MAX_REPORTED_COLUMNS = 5


def _is_real_number(value: object) -> bool:
    return isinstance(value, (numbers.Real, np.bool_))


def _holds_python_objects(dtype: object) -> bool:
    return pd.api.types.is_object_dtype(dtype) or isinstance(dtype, pd.StringDtype)


def _coerce_object_column(column: pd.Series) -> pd.Series | None:
    """Coerce one ``object`` column, or return ``None`` if it cannot be."""
    kind = pd.api.types.infer_dtype(column, skipna=True)
    if kind == "boolean":
        return column.fillna(False).astype(bool)
    if kind in _FLOAT_KINDS or (
        kind in _MIXED_KINDS and column.dropna().map(_is_real_number).all()
    ):
        return pd.to_numeric(column).astype(float)
    return None


def coerce_object_position(
    position: pd.DataFrame | pd.Series,
) -> pd.DataFrame | pd.Series:
    """Give ``object`` position columns the dtype their values imply.

    Merging boolean sleeves whose dates or assets differ leaves ``NaN`` in the
    unmatched cells, so pandas stores those columns as ``object``. Boolean
    columns become plain ``bool`` with ``NaN`` read as not held, exactly like
    ``fillna(False).astype(bool)``; numeric columns become ``float``. Frames
    without ``object`` or string columns are returned untouched.

    Raises:
        ValueError: If an ``object`` or string column holds values that are
            neither booleans nor numbers.
    """
    if isinstance(position, pd.Series):
        if not _holds_python_objects(position.dtype):
            return position
        coerced = {position.name: _coerce_object_column(position)}
    else:
        object_columns = position.columns[position.dtypes.map(_holds_python_objects)]
        if object_columns.empty:
            return position
        coerced = {col: _coerce_object_column(position[col]) for col in object_columns}

    invalid = [str(col) for col, values in coerced.items() if values is None]
    if invalid:
        shown = ", ".join(invalid[:_MAX_REPORTED_COLUMNS])
        more = len(invalid) - _MAX_REPORTED_COLUMNS
        suffix = f" and {more} more" if more > 0 else ""
        raise ValueError(
            f"position columns {shown}{suffix} hold values that are neither "
            "booleans nor numbers. Positions must be True/False signals or "
            "numeric weights."
        )

    if isinstance(position, pd.Series):
        return coerced[position.name]
    result = position.copy()
    for col, values in coerced.items():
        result[col] = values
    return result


# ---------------------------------------------------------------------------
# Rebalance-schedule helpers
# ---------------------------------------------------------------------------


def filter_position_by_change(position: pd.DataFrame) -> pd.DataFrame:
    """Return rows of *position* where the allocation actually changed.

    Used when ``resample is None`` – only the first row and dates where the
    signal differs from the previous row are kept. Expects NaN-free input,
    which ``sim()`` guarantees by filling missing values at input.

    Args:
        position: A DataFrame with ``DatetimeIndex`` rows and asset columns.

    Returns:
        Filtered copy (subset of rows).
    """
    change = position.diff().abs().sum(axis=1).to_numpy() != 0
    change[:1] = True
    return position.loc[change]


def generate_string_rebalance_dates(
    position_start: pd.Timestamp | datetime.datetime,
    present_data_date: pd.Timestamp | datetime.datetime,
    price_end: pd.Timestamp | datetime.datetime,
    resample: str,
    resample_offset: str | None,
    tz: object | None,
) -> list[pd.Timestamp]:
    """Build a list of rebalance timestamps from a frequency string.

    Handles pandas 2.2+ offset name changes (``"M"`` -> ``"ME"``),
    in-string ``+N`` / ``-N`` day offsets, and the optional
    ``resample_offset``.

    Args:
        position_start: Earliest date in the position DataFrame.
        present_data_date: Latest relevant date for filtering.
        price_end: Last date in the price DataFrame.
        resample: Frequency string (e.g. ``"M"``, ``"W-Fri"``).
        resample_offset: Additional pandas offset string (e.g. ``"1D"``).
        tz: Timezone for ``pd.date_range``.

    Returns:
        Ordered list of ``pd.Timestamp`` rebalance dates.
    """
    import datetime as _dt

    from pandas.tseries.frequencies import to_offset
    from pandas.tseries.offsets import DateOffset

    if pd.__version__ >= "2.2.0":
        old_names = ["M", "BM", "SM", "CBM", "Q", "BQ", "A", "Y", "BY"]
        if resample in old_names:
            resample += "E"

    # Pandas now expects weekly weekday suffixes in uppercase, e.g. W-SUN.
    if resample.startswith("W-"):
        head, tail = resample.split("-", 1)
        resample = f"{head}-{tail.upper()}"

    offset_days = 0
    if "+" in resample:
        resample, offset_str = resample.rsplit("+", 1)
        offset_days = int(offset_str)
    elif "-" in resample:
        parts = resample.rsplit("-", 1)
        if parts[-1].isdigit():
            resample = parts[0]
            offset_days = -int(parts[-1])

    alldates = pd.date_range(
        position_start,
        present_data_date + _dt.timedelta(days=360),
        freq=resample,
        tz=tz,
    )
    alldates += DateOffset(days=offset_days)

    if resample_offset is not None:
        alldates += to_offset(resample_offset)

    dates = [d for d in alldates if position_start <= d <= present_data_date]

    if price_end > dates[-1]:
        remain = set(alldates) - set(dates)
        if remain:
            dates.append(min(remain))

    return dates


# ---------------------------------------------------------------------------
# Trade return bounds (touched-exit clipping)
# ---------------------------------------------------------------------------


def compute_trade_return_bounds(
    fee_ratio: float,
    tax_ratio: float,
    stop_loss: float,
    take_profit: float,
) -> tuple[float, float]:
    """Compute theoretical min/max single-trade return under touched-exit.

    When ``touched_exit=True``, trade returns are clipped to the bounds
    implied by fee/tax ratios and stop/take-profit levels.

    Returns:
        ``(min_return, max_return)``
    """
    min_return = (1 - fee_ratio) * (1 - abs(stop_loss)) * (
        1 - tax_ratio - fee_ratio
    ) - 1
    max_return = (1 - fee_ratio) * (1 + abs(take_profit)) * (
        1 - tax_ratio - fee_ratio
    ) - 1
    return min_return, max_return


# ---------------------------------------------------------------------------
# MAE / MFE column construction
# ---------------------------------------------------------------------------

_MAE_MFE_METRICS = ("mae", "gmfe", "bmfe", "mdd", "pdays", "return")


def build_mae_mfe_columns(
    n_columns: int,
    window_step: int,
) -> pd.MultiIndex:
    """Build the ``(window, metric)`` MultiIndex for an MAE/MFE DataFrame.

    The raw Cython core returns a flat array of columns.  This function
    computes the structured column index from the number of flat columns
    and the window step size.

    Args:
        n_columns: Total number of flat columns in the raw data.
        window_step: Step between consecutive windows.

    Returns:
        ``pd.MultiIndex`` with levels ``["window", "metric"]``.
    """
    nsets = int((n_columns - 1) / 6)

    tuples: list[tuple[int | str, str]] = functools.reduce(
        operator.iadd,
        [
            [
                (n, metric) if n == "exit" else (n * window_step, metric)
                for metric in _MAE_MFE_METRICS
            ]
            for n in [*range(nsets), "exit"]
        ],
        [],
    )

    return pd.MultiIndex.from_tuples(tuples, names=["window", "metric"])


def clip_mae_mfe_exit(
    exit_data: pd.DataFrame,
    stop_loss: float,
    take_profit: float,
) -> pd.DataFrame:
    """Clip MAE/MFE exit-window metrics to stop/take-profit bounds.

    Only the ``gmfe``, ``bmfe``, ``mae``, and ``mdd`` columns are clipped;
    other columns are left unchanged.

    Args:
        exit_data: DataFrame with columns ``gmfe``, ``bmfe``, ``mae``,
            ``mdd`` (and possibly others like ``pdays``, ``return``).
        stop_loss: Absolute stop-loss threshold.
        take_profit: Absolute take-profit threshold.

    Returns:
        New DataFrame with clipped values.
    """
    lo = -abs(stop_loss)
    hi = abs(take_profit)
    return (
        exit_data.assign(gmfe=exit_data.gmfe.clip(lo, hi))
        .assign(bmfe=exit_data.bmfe.clip(lo, hi))
        .assign(mae=exit_data.mae.clip(lo, hi))
        .assign(mdd=exit_data.mdd.clip(lo, hi))
    )


# ---------------------------------------------------------------------------
# Position-column overlap validation
# ---------------------------------------------------------------------------


def validate_position_columns(
    position_columns: pd.Index,
    price_columns: pd.Index,
    *,
    min_overlap_ratio: float = 0.1,
) -> pd.Index:
    """Intersect position columns with price columns and warn on low overlap.

    Args:
        position_columns: Column index from the position DataFrame.
        price_columns: Column index from the price DataFrame.
        min_overlap_ratio: If the matched fraction drops below this value,
            emit a ``UserWarning``.

    Returns:
        The intersection ``pd.Index``.

    Raises:
        ValueError: If none of the position columns match.
    """
    matched = position_columns.intersection(price_columns)
    orig = len(position_columns)

    if orig > 0 and len(matched) == 0:
        raise ValueError(
            f"No position columns match the market price columns "
            f"(0 out of {orig} matched). "
            f"Check that the position data source matches the market's price data."
        )
    if orig > 0 and len(matched) / orig < min_overlap_ratio:
        warnings.warn(
            f"Only {len(matched)} out of {orig} position columns "
            f"matched the market price columns "
            f"({len(matched) / orig:.1%} overlap). "
            f"The backtest result may be unreliable. "
            f"Check that the position data source matches the market.",
            stacklevel=2,
        )

    return matched
