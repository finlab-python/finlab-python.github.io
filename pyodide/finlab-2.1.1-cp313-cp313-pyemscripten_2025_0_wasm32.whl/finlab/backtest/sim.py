"""Backtest simulation orchestrator.

This is the main entry point for running backtests via ``sim()``.
Configuration, validation, report building, and notifications are
delegated to focused package modules:

- ``finlab.backtest.config`` -- SimConfig, input validation
- ``finlab.backtest.report`` -- trades, MAE/MFE, report assembly
- ``finlab.backtest.notify`` -- Line notification delivery
"""

from __future__ import annotations

import contextlib
import datetime
import functools
import inspect
import json
import sys
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal, cast, overload
from urllib.parse import urlencode

__all__ = ["SimConfig", "sim"]

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Iterator

    from finlab.core import report
    from finlab.core.metrics import Metrics  # type: ignore[import-not-found]
    from finlab.market import Market

import logging

import numpy as np
import pandas as pd

import finlab

logger = logging.getLogger(__name__)
from finlab import data as _data_module
from finlab.core.backtest_core import backtest_, get_trade_stocks
from finlab.dataframe import FinlabDataFrame
from finlab.utils import requests

from .config import (
    OperationAndWeight,
    SimConfig,
    _resolve_end_date,
    _resolve_market_config,
)
from .config import validate_sim_inputs as _validate_sim_inputs
from .delisting import exclude_delisted_holdings
from .helpers import (
    compute_trade_return_bounds,
    filter_position_by_change,
    generate_string_rebalance_dates,
    normalize_position_weights,
    validate_position_columns,
)
from .metrics import metrics_from_creturn
from .report import build_sim_report as _build_sim_report
from .report import build_trades_df as _build_trades_df
from .report import refine_mae_mfe as _refine_mae_mfe

# Type alias for the positional arguments passed to backtest_()
BacktestArgs = list[np.ndarray]

_suppress_upload: bool = False
_BACKTEST_AUTH_URL = "https://asia-east2-fdata-299302.cloudfunctions.net/auth_backtest"


def columns_to_numpy(df: pd.DataFrame) -> np.ndarray:
    """Convert DataFrame columns to numpy array for pandas 3.0+ compatibility."""
    return np.asarray(df.columns.astype(str), dtype=object)


def _download_backtest_auth(params: dict[str, str]) -> dict[str, object] | None:
    """Sync GET to auth_backtest. Pyodide-aware: bypasses urllib3-emscripten,
    which throws "Unknown typed array type 'Uint8Array'" while reading the
    response body in pyodide 0.29.x.
    """
    if "pyodide" in sys.modules:
        from finlab.data.auth import _pyodide_get_text

        try:
            text = _pyodide_get_text(f"{_BACKTEST_AUTH_URL}?{urlencode(params)}")
        except (OSError, RuntimeError, requests.HTTPError):
            return None
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            return None
        return payload if isinstance(payload, dict) else None

    res = requests.get(_BACKTEST_AUTH_URL, params)
    if not res.ok:
        try:
            return res.json()
        except (ValueError, json.JSONDecodeError):
            return None
    return res.json()


def download_backtest_encryption_function_factory() -> Callable[[], str]:
    encryption_time = datetime.datetime.now(tz=datetime.timezone.utc)
    encryption = ""

    def ret() -> str:
        nonlocal encryption_time
        nonlocal encryption

        if (
            datetime.datetime.now(tz=datetime.timezone.utc)
            < encryption_time + datetime.timedelta(days=1)
            and encryption
        ):
            return encryption

        token_result = finlab.get_token()
        if isinstance(token_result, tuple):
            token, token_type = token_result
        else:
            token, token_type = token_result, "api_token"

        params = {
            token_type: token,
            "time": str(datetime.datetime.now(tz=datetime.timezone.utc)),
        }
        d = _download_backtest_auth(params)
        if d is None:
            print(None)
            return ""
        if "encryption" not in d:
            print(d)
            return ""

        if "v" in d and "v_msg" in d and finlab.__version__ < str(d["v"]):
            print(d["v_msg"])

        if "msg" in d:
            print(d["msg"])

        encryption_time = datetime.datetime.now(tz=datetime.timezone.utc)
        encryption = str(d["encryption"])

        return encryption

    return ret


download_backtest_encryption: Callable[[], str] = (
    download_backtest_encryption_function_factory()
)


def calc_essential_price(
    price: pd.DataFrame, dates: Iterable[pd.Timestamp]
) -> pd.DataFrame:
    dt = min(price.index.values[1:] - price.index.values[:-1])
    date_index = pd.DatetimeIndex(dates)

    indexer = price.index.get_indexer(date_index + dt)

    valid_idx = np.where(
        indexer == -1, np.searchsorted(price.index, date_index, side="right"), indexer
    )
    valid_idx = np.where(valid_idx >= len(price), len(price) - 1, valid_idx)

    return price.iloc[valid_idx]


def arguments(
    price: pd.DataFrame,
    close: pd.DataFrame,
    high: pd.DataFrame,
    low: pd.DataFrame,
    open_: pd.DataFrame,
    position: pd.DataFrame,
    resample_dates: Iterable[pd.Timestamp] | None = None,
) -> BacktestArgs:
    resample_index = pd.DatetimeIndex(
        price.index if resample_dates is None else resample_dates
    )
    if resample_index.dtype != price.index.dtype:
        resample_index = resample_index.astype(price.index.dtype)

    position = position.astype(float)

    if pd.__version__ >= "2.2.0":
        resample_dates_array = pd.Series(resample_index).astype(np.int64).values
    else:
        resample_dates_array = pd.Series(resample_index).view(np.int64).values

    position_index = position.index
    if position_index.dtype != price.index.dtype:
        position_index = position_index.astype(price.index.dtype)

    return [
        price.values,
        close.values,
        high.values,
        low.values,
        open_.values,
        price.index.view(np.int64),
        columns_to_numpy(price),
        position.values,
        position_index.view(np.int64),
        columns_to_numpy(position),
        resample_dates_array,
    ]


def _reindex_if_needed(df: pd.DataFrame, ref_df: pd.DataFrame) -> pd.DataFrame:
    if df.shape != ref_df.shape:
        df = df.reindex_like(ref_df)
    return df


def _require_market(cfg: SimConfig) -> Market:
    if cfg.market is None:
        raise RuntimeError("market must be resolved before simulation")
    return cfg.market


def _last_resample_date(dates: list[pd.Timestamp]) -> pd.Timestamp:
    if not dates:
        raise ValueError("resample has no dates within the simulation range")
    return dates[-1]


def _compute_resample_dates(
    position: pd.DataFrame,
    resample: str
    | pd.DataFrame
    | pd.Series
    | pd.DatetimeIndex
    | list[datetime.datetime]
    | None,
    resample_offset: str | None,
    present_data_date: pd.Timestamp | datetime.datetime,
    price: pd.DataFrame,
    tz: datetime.tzinfo | None,
) -> tuple[list[pd.Timestamp] | None, pd.Timestamp, pd.DataFrame]:
    """Compute rebalance dates from the resample parameter.

    Returns (dates, next_trading_date, position) where dates may be None.
    """
    dates = None
    next_trading_date = position.index[-1]

    if isinstance(resample, (pd.DataFrame, pd.Series)):
        if isinstance(resample.index, pd.DatetimeIndex):
            dates = resample.index.tolist()
        elif isinstance(resample, FinlabDataFrame):
            dates = resample.index_str_to_date().index.tolist()
        if dates is None:
            raise TypeError("resample dataframe must have a DatetimeIndex")
        dates = [d for d in dates if position.index[0] <= d <= present_data_date]
        next_trading_date = _last_resample_date(dates)

    elif isinstance(resample, pd.DatetimeIndex):
        dates = resample.tolist()
        dates = [d for d in dates if position.index[0] <= d <= present_data_date]
        next_trading_date = _last_resample_date(dates)

    elif isinstance(resample, list):
        first_date = _last_resample_date(resample[:1])
        if not isinstance(first_date, datetime.datetime):
            raise TypeError(
                "resample list elements must be datetime.datetime instances"
            )
        dates = [d for d in resample if position.index[0] <= d <= present_data_date]
        next_trading_date = _last_resample_date(dates)

    elif isinstance(resample, str):
        dates = generate_string_rebalance_dates(
            position.index[0],
            present_data_date,
            price.index[-1],
            resample,
            resample_offset,
            tz,
        )
        next_trading_date = _last_resample_date(dates)

    elif resample is None:
        position = filter_position_by_change(position)
        next_trading_date = position.index[-1]

    return dates, next_trading_date, position


def _prepare_price_data(
    cfg: SimConfig,
    price: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Fetch and align price data (close, high, low, open) for the backtest.

    Emits warnings when using a DataFrame as trade_at_price with touched_exit.
    Parses live_performance_start if provided as a string.
    Returns (close, high, low, open_).
    """
    if isinstance(cfg.trade_at_price, pd.DataFrame) and cfg.touched_exit:
        print(
            "**WARNING: Using trade_at_price as dataframe without high, and low price. Candle information is not completed."
        )
        print("           The backtest result can be incorrect when touched_exit=True.")
        print(
            "           If the complete backtest result is required, please implement Market Class with get_price function."
        )
        print("           Market details: https://doc.finlab.tw/reference/market_info/")
        print(
            "           And use backtest.sim(..., market=Market) during backtest, so that the correct information is accessable from backtest.sim()."
        )

    try:
        if isinstance(cfg.live_performance_start, str):
            cfg.live_performance_start = datetime.datetime.fromisoformat(
                cfg.live_performance_start
            )
    except ValueError as e:
        raise ValueError(
            "**ERROR: live_performance_start string format not valid. It should be ISO format, i.e. YYYY-MM-DD."
        ) from e

    close = price
    high = price
    low = price
    open_ = price
    market = _require_market(cfg)
    if cfg.touched_exit:
        high = _reindex_if_needed(market.get_price("high", adj=True), price)
        low = _reindex_if_needed(market.get_price("low", adj=True), price)
        open_ = _reindex_if_needed(market.get_price("open", adj=True), price)

    if not isinstance(cfg.trade_at_price, str) or cfg.trade_at_price != "close":
        close = _reindex_if_needed(
            market.get_price("close", adj=True).reindex_like(price), price
        )

    return close, high, low, open_


@dataclass(slots=True)
class _PreparedSimulationInputs:
    """Configuration and price inputs prepared before scheduling/execution."""

    cfg: SimConfig
    position: pd.DataFrame | pd.Series
    price: pd.DataFrame
    close: pd.DataFrame
    high: pd.DataFrame
    low: pd.DataFrame
    open_: pd.DataFrame


@dataclass(slots=True)
class _SimulationSchedule:
    """Derived execution schedule and normalized position state."""

    position: pd.DataFrame
    dates: list[pd.Timestamp] | None
    next_trading_date: pd.Timestamp
    tz: datetime.tzinfo | None
    backtest_end_date: pd.Timestamp


@dataclass(slots=True)
class _EngineRun:
    """Raw output from the backtest engine plus execution metadata."""

    creturn_value: np.ndarray
    args: BacktestArgs
    position: pd.DataFrame


def _prefetch_market_datasets(cfg: SimConfig) -> None:
    market = _require_market(cfg)
    if not hasattr(market, "sim_datasets"):
        return

    trade_at_price = cfg.trade_at_price if isinstance(cfg.trade_at_price, str) else None
    fn = market.sim_datasets
    kwargs: dict[str, object] = {}
    params = _sim_datasets_params(fn)
    if params is None or "trade_at_price" in params:
        kwargs["trade_at_price"] = trade_at_price
    if params is None or "touched_exit" in params:
        kwargs["touched_exit"] = cfg.touched_exit
    if params is not None and not params:
        # Pre-kwarg zero-arg shape from third-party Market subclasses.
        kwargs = {}

    datasets = fn(**kwargs)
    if not datasets:
        return

    with contextlib.suppress(ImportError):
        _data_module.gets(*datasets)


@functools.lru_cache(maxsize=16)
def _sim_datasets_params(fn: Callable[..., object]) -> frozenset[str] | None:
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        return None
    accepts_var_kw = any(
        p.kind is inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()
    )
    if accepts_var_kw:
        return None
    return frozenset(
        name
        for name, p in sig.parameters.items()
        if p.kind
        in (inspect.Parameter.KEYWORD_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
    )


def _resolve_trade_price_frame(cfg: SimConfig) -> pd.DataFrame:
    price = cfg.trade_at_price
    if isinstance(cfg.trade_at_price, str):
        price = _require_market(cfg).get_trading_price(cfg.trade_at_price, adj=True)

    if not isinstance(price, pd.DataFrame):
        raise TypeError("trade_at_price must resolve to a pd.DataFrame")

    return price


def _cut_at_end_date(frame: pd.DataFrame, cfg: SimConfig) -> pd.DataFrame:
    if cfg.end_date is None:
        return frame
    return frame.loc[frame.index <= cfg.end_date]


def _prepare_simulation_inputs(
    position: pd.DataFrame | pd.Series,
    cfg: SimConfig,
) -> _PreparedSimulationInputs:
    price = _cut_at_end_date(_resolve_trade_price_frame(cfg), cfg)
    close, high, low, open_ = _prepare_price_data(cfg, price)
    return _PreparedSimulationInputs(
        cfg=cfg,
        position=position,
        price=price,
        close=close,
        high=high,
        low=low,
        open_=open_,
    )


def _authorize_backtest() -> str:
    encryption = download_backtest_encryption()
    if encryption == "":
        raise PermissionError("Cannot perform backtest, permission denied.")
    return encryption


def _align_position_with_market(
    position: pd.DataFrame,
    price: pd.DataFrame,
) -> pd.DataFrame:
    matched_columns = validate_position_columns(position.columns, price.columns)
    return position[matched_columns]


def _signals_reach_price_end(
    position_index: pd.DatetimeIndex,
    price_end: pd.Timestamp,
) -> bool:
    """Infer whether the latest signal is still live at the end of the prices.

    The last signal is live when one more rebalance step, estimated from the
    spacing of the last three signals, would pass the last price bar. With
    fewer than three signals there is no spacing to estimate, so the position
    is held to the end of the prices.
    """
    min_signals_for_spacing = 3
    if len(position_index) < min_signals_for_spacing:
        return True
    delta_time_rebalance = position_index[-1] - position_index[-3]
    return bool(position_index[-1] + delta_time_rebalance > price_end)


def _latest_session_time(
    position_index: pd.DatetimeIndex,
    cfg: SimConfig,
) -> datetime.datetime:
    """Return now, or yesterday's close when today's daily bar is not final."""
    market = _require_market(cfg)
    now = datetime.datetime.now(tz=position_index.tz or market.tzinfo())
    if position_index.tz is None:
        now = now.replace(tzinfo=None)
    available = position_index[position_index <= now]
    is_daily = (
        (available.hour == 0).all()
        and (available.minute == 0).all()
        and (available.second == 0).all()
    )
    if is_daily and market.get_name() == "tw_stock":
        from finlab.data.calendar import get_calendar
        from finlab.session_calendar import TW, CalendarUnavailable

        market_now = datetime.datetime.now(tz=TW)
        try:
            if not get_calendar(now=market_now).is_session(market_now.date()):
                return now
        except CalendarUnavailable:
            pass  # Keep the existing conservative cutoff if coverage is unknown.
    if (
        is_daily
        and datetime.datetime.now(tz=market.tzinfo())
        < market.market_close_at_timestamp()
    ):
        now = now.replace(
            hour=23, minute=59, second=0, microsecond=0
        ) - datetime.timedelta(days=1)
    return now


def _present_data_date(
    position_index: pd.DatetimeIndex,
    price: pd.DataFrame,
    cfg: SimConfig,
) -> tuple[pd.Timestamp, bool]:
    """Return the last date the backtest may use and whether it runs to the end.

    Without ``end_date`` the end is inferred from the signal spacing. With
    ``end_date`` the prices are already cut there, so the backtest always
    runs to the last price bar and never looks past ``end_date``.
    """
    present = max(price.index[-1], _latest_session_time(position_index, cfg))
    if cfg.end_date is not None:
        present = min(present, cfg.end_date)
    # Future plans must not extend historical performance by changing the
    # spacing heuristic. Only currently available signals establish its range.
    available = position_index[position_index <= present]
    backtest_to_end = cfg.end_date is not None or _signals_reach_price_end(
        available, price.index[-1]
    )
    if not backtest_to_end:
        return available[-1], False
    return pd.Timestamp(present), True


def _planned_rebalance_date(
    position: pd.DataFrame, cfg: SimConfig, cutoff: pd.Timestamp
) -> pd.Timestamp | None:
    """Next supplied change/schedule beyond cutoff; display-only metadata."""
    if cfg.end_date is not None or isinstance(cfg.resample, str):
        return None
    if cfg.resample is None:
        dates = filter_position_by_change(position).index
    elif isinstance(cfg.resample, (pd.DataFrame, pd.Series)):
        dates = cfg.resample.index
        if not isinstance(dates, pd.DatetimeIndex):
            return None
    else:
        dates = pd.DatetimeIndex(cfg.resample)
    future = dates[dates > cutoff]
    return pd.Timestamp(future.min()) if len(future) else None


def _derive_simulation_schedule(
    position: pd.DataFrame | pd.Series,
    cfg: SimConfig,
    price: pd.DataFrame,
) -> _SimulationSchedule:
    """Derive runtime schedule, rebalance dates, and aligned position state.

    Converts Series to DataFrame, computes rebalance dates, aligns the
    position columns to the market price frame, and returns the schedule
    state needed by subsequent phases.

    Precondition: ``_validate_sim_inputs`` has already run, so the position
    has a DatetimeIndex and Series inputs have a valid name.
    """
    if isinstance(position, pd.Series):
        position = position.to_frame()

    if len(position.shape) < 2:
        raise ValueError("position must be a 2D DataFrame")

    tz = position.index.tz
    present_data_date, backtest_to_end = _present_data_date(position.index, price, cfg)
    # Retain only a date for display. Future allocations must never reach the
    # engine, next_weights, actions, or order generation.
    cfg.planned_rebalance_date = _planned_rebalance_date(
        position, cfg, present_data_date
    )
    position = position.loc[(position.index <= present_data_date)]
    if position.empty:
        raise ValueError(
            "position has no usable signals at the current cutoff; all signals are in the future"
        )
    backtest_end_date = price.index[-1] if backtest_to_end else position.index[-1]

    dates, next_trading_date, position = _compute_resample_dates(
        position, cfg.resample, cfg.resample_offset, present_data_date, price, tz
    )

    if dates is not None:
        position = position.reindex(dates, method="ffill")

    return _SimulationSchedule(
        position=_align_position_with_market(position, price),
        dates=dates,
        next_trading_date=next_trading_date,
        tz=tz,
        backtest_end_date=backtest_end_date,
    )


@dataclass(slots=True)
class _SimulationResult:
    """Container for raw results from the backtest core execution."""

    creturn: pd.Series
    position: pd.DataFrame
    org_position_index: pd.DatetimeIndex
    trades: pd.DataFrame
    mae_mfe: pd.DataFrame
    operation_and_weight: OperationAndWeight
    price: pd.DataFrame


def _execute_backtest_engine(
    cfg: SimConfig,
    prepared: _PreparedSimulationInputs,
    schedule: _SimulationSchedule,
    encryption: str,
) -> _EngineRun:
    """Run the Cython backtest core only and return raw execution artifacts.

    Post-processing and report assembly are intentionally handled in later
    phases so the engine boundary stays explicit.
    """
    position, delisting_bars = exclude_delisted_holdings(
        schedule.position,
        prepared.price,
        _require_market(cfg).get_delisting_notices(),
        rebalance_on_delisting=cfg.resample is None,
    )
    dates = schedule.dates
    stop_loss = cast("float", cfg.stop_loss)
    take_profit = cast("float", cfg.take_profit)
    trail_stop = cast("float", cfg.trail_stop)
    trail_stop_activation = cast("float", cfg.trail_stop_activation)

    args = arguments(
        prepared.price,
        prepared.close,
        prepared.high,
        prepared.low,
        prepared.open_,
        position,
        dates,
    )

    return _EngineRun(
        creturn_value=backtest_(
            *args,
            encryption=encryption,
            fee_ratio=cfg.fee_ratio,
            tax_ratio=cfg.tax_ratio,
            stop_loss=stop_loss,
            take_profit=take_profit,
            trail_stop=trail_stop,
            trail_stop_activation=trail_stop_activation,
            touched_exit=cfg.touched_exit,
            position_limit=cfg.position_limit,
            retain_cost_when_rebalance=cfg.retain_cost_when_rebalance,
            stop_trading_next_period=cfg.stop_trading_next_period,
            mae_mfe_window=cfg.mae_mfe_window,
            mae_mfe_window_step=cfg.mae_mfe_window_step,
            periodically_rebalance=cfg.resample is not None,
            delisting_bars=delisting_bars,
        ),
        args=args,
        position=position,
    )


def _finalize_simulation_result(
    cfg: SimConfig,
    prepared: _PreparedSimulationInputs,
    schedule: _SimulationSchedule,
    engine_run: _EngineRun,
) -> _SimulationResult:
    """Transform raw engine output into the data required for report building."""
    position = engine_run.position
    position = pd.DataFrame(
        normalize_position_weights(position.values, cfg.position_limit),
        index=position.index,
        columns=position.columns,
    )

    creturn = _finalize_creturn(cfg, prepared, schedule, engine_run)

    position = position.loc[creturn.index[0] :]

    price_index = engine_run.args[5]
    position_columns = engine_run.args[9]
    trades_raw, operation_and_weight = get_trade_stocks(
        position_columns, price_index, touched_exit=cfg.touched_exit
    )

    stop_loss = cast("float", cfg.stop_loss)
    take_profit = cast("float", cfg.take_profit)
    m = _refine_mae_mfe(
        cfg.mae_mfe_window_step, cfg.touched_exit, stop_loss, take_profit
    )
    price_index_dtype = prepared.price.index.dtype
    if getattr(prepared.price.index, "tz", None) is not None:
        price_index_dtype = prepared.price.index.tz_localize(None).dtype

    datetime_unit = np.datetime_data(price_index_dtype)[0]
    trades = _build_trades_df(trades_raw, schedule.tz, datetime_unit)

    if len(trades) != 0:
        trades = trades.assign(**{"return": (m.iloc[:, -1])})

        if cfg.touched_exit:
            if cfg.fee_ratio is None or cfg.tax_ratio is None:
                raise RuntimeError("fee_ratio and tax_ratio must be resolved")
            min_return, max_return = compute_trade_return_bounds(
                cfg.fee_ratio,
                cfg.tax_ratio,
                stop_loss,
                take_profit,
            )
            trades["return"] = trades["return"].clip(min_return, max_return)

    return _SimulationResult(
        creturn=creturn,
        position=position,
        org_position_index=engine_run.position.index,
        trades=trades,
        mae_mfe=m,
        operation_and_weight=operation_and_weight,
        price=prepared.price,
    )


def _finalize_creturn(
    cfg: SimConfig,
    prepared: _PreparedSimulationInputs,
    schedule: _SimulationSchedule,
    engine_run: _EngineRun,
) -> pd.Series:
    """Finalize only cumulative returns, without constructing a Report."""
    creturn_dates = prepared.price.index
    return (
        pd.Series(engine_run.creturn_value, creturn_dates)
        .pipe(lambda df: df[(df != 1).cumsum().shift(-1, fill_value=1) != 0])
        .loc[: schedule.backtest_end_date]
        .pipe(lambda df: df if len(df) != 0 else pd.Series(1, schedule.position.index))
    )


def _build_simulation_report(
    cfg: SimConfig,
    prepared: _PreparedSimulationInputs,
    schedule: _SimulationSchedule,
    engine_run: _EngineRun,
) -> report.Report:
    result = _finalize_simulation_result(cfg, prepared, schedule, engine_run)
    return _build_sim_report(
        cfg,
        result,
        schedule.next_trading_date,
        _suppress_upload,
    )


def _restore_backtest_context() -> None:
    from finlab.data.category_cache import clear_category_cache
    from finlab.markets.tw import TWMarket as _TW

    _TW._categories_cache = None
    clear_category_cache(market="tw_stock")


@contextlib.contextmanager
def _backtest_context() -> Iterator[None]:
    with _data_module._default_context.override(prefer_local_if_exists=True):
        try:
            yield
        finally:
            _restore_backtest_context()


def _collect_lazy_position_for_sim(
    position: object,
    cfg: SimConfig,
) -> pd.DataFrame:
    """Collect LazyWide positions on the same calendar dates sim will use."""
    from finlab.dataframe.lazy_execution import (
        _build_execution_cache,
    )
    from finlab.dataframe.lazy_nodes import _collect_full_index

    if not isinstance(cfg.resample, str):
        return position.collect()  # type: ignore[attr-defined]

    _resolve_market_config(cfg)
    cache = _build_execution_cache(position._node)  # type: ignore[attr-defined]
    full_index = _collect_full_index(position._node, cache)  # type: ignore[attr-defined]
    if not isinstance(full_index, pd.DatetimeIndex) or len(full_index) < 3:
        return position.collect()  # type: ignore[attr-defined]

    if cfg.end_date is not None:
        cfg.end_date = _resolve_end_date(cfg.end_date, full_index.tz)
        full_index = full_index[full_index <= cfg.end_date]
        if len(full_index) < 3:
            return position.collect()  # type: ignore[attr-defined]

    price = _cut_at_end_date(_resolve_trade_price_frame(cfg), cfg)
    tz = full_index.tz
    present_data_date, _ = _present_data_date(full_index, price, cfg)
    position_start = max(price.index[0], full_index[0])
    dates = generate_string_rebalance_dates(
        position_start,
        present_data_date,
        price.index[-1],
        cfg.resample,
        cfg.resample_offset,
        tz,
    )

    collect_dates = pd.DatetimeIndex(dates)
    last_signal_pos = full_index.searchsorted(present_data_date, side="right") - 1
    if last_signal_pos >= 0:
        collect_dates = collect_dates.union(
            pd.DatetimeIndex([full_index[last_signal_pos]])
        )

    collected = position.collect(collect_dates)  # type: ignore[attr-defined]
    collected = collected.reindex(collect_dates, method="ffill")
    valid_rows = collected.notna().any(axis=1)
    if valid_rows.any():
        collected = collected.loc[valid_rows.idxmax() :]
    if len(collected) < 3:
        return position.collect()  # type: ignore[attr-defined]

    return collected


@overload
def sim(
    position: pd.DataFrame | pd.Series,
    resample: str | None = None,
    resample_offset: str | None = None,
    trade_at_price: str | pd.DataFrame = "close",
    position_limit: float = 1,
    fee_ratio: float | None = None,
    tax_ratio: float | None = None,
    name: str = "未命名",
    stop_loss: float | None = None,
    take_profit: float | None = None,
    trail_stop: float | None = None,
    trail_stop_activation: float | None = None,
    touched_exit: bool = False,
    retain_cost_when_rebalance: bool = False,
    stop_trading_next_period: bool = True,
    live_performance_start: str | None = None,
    mae_mfe_window: int = 0,
    mae_mfe_window_step: int = 1,
    market: Market | None = None,
    upload: bool | None = None,
    *,
    end_date: str | datetime.date | pd.Timestamp | None = None,
    metrics_only: Literal[True],
    notification_enable: bool = False,
    line_access_token: str = "",
) -> Metrics: ...


@overload
def sim(
    position: pd.DataFrame | pd.Series,
    resample: str | None = None,
    resample_offset: str | None = None,
    trade_at_price: str | pd.DataFrame = "close",
    position_limit: float = 1,
    fee_ratio: float | None = None,
    tax_ratio: float | None = None,
    name: str = "未命名",
    stop_loss: float | None = None,
    take_profit: float | None = None,
    trail_stop: float | None = None,
    trail_stop_activation: float | None = None,
    touched_exit: bool = False,
    retain_cost_when_rebalance: bool = False,
    stop_trading_next_period: bool = True,
    live_performance_start: str | None = None,
    mae_mfe_window: int = 0,
    mae_mfe_window_step: int = 1,
    market: Market | None = None,
    upload: bool | None = None,
    *,
    end_date: str | datetime.date | pd.Timestamp | None = None,
    metrics_only: Literal[False] = False,
    notification_enable: bool = False,
    line_access_token: str = "",
) -> report.Report: ...


def sim(
    position: pd.DataFrame | pd.Series,
    resample: str | None = None,
    resample_offset: str | None = None,
    trade_at_price: str | pd.DataFrame = "close",
    position_limit: float = 1,
    fee_ratio: float | None = None,
    tax_ratio: float | None = None,
    name: str = "未命名",
    stop_loss: float | None = None,
    take_profit: float | None = None,
    trail_stop: float | None = None,
    trail_stop_activation: float | None = None,
    touched_exit: bool = False,
    retain_cost_when_rebalance: bool = False,
    stop_trading_next_period: bool = True,
    live_performance_start: str | None = None,
    mae_mfe_window: int = 0,
    mae_mfe_window_step: int = 1,
    market: Market | None = None,
    upload: bool | None = None,
    *,
    end_date: str | datetime.date | pd.Timestamp | None = None,
    metrics_only: bool = False,
    notification_enable: bool = False,
    line_access_token: str = "",
) -> report.Report | Metrics:
    """Simulate the equity given the stock position history.

    See the module-level docstring and the parameter docs below for full details.

    Args:
        position: Buy/sell signal history. True = hold, False = flat.
            Can also be a ``LazyWide`` — it will be auto-collected at
            the rebalance dates determined by *resample*.
        resample: Trading period frequency (e.g. 'W', 'M', 'Q').
        resample_offset: Time offset for the resample period.
        trade_at_price: Price type for trade execution ('close', 'open', etc.).
        position_limit: Maximum single-stock weight (0-1).
        fee_ratio: Trading fee ratio.
        tax_ratio: Trading tax ratio.
        name: Strategy name.
        stop_loss: Stop-loss threshold.
        take_profit: Take-profit threshold.
        trail_stop: Drop from peak return, measured relative to entry cost.
            For a long position with close-price execution and touched_exit=False,
            signal an exit when (peak_price - close) / entry_cost > trail_stop.
            Entry 100, peak 150 and trail_stop=0.2 give a 130 threshold.
            The signal is executed on the next bar, not at a guaranteed threshold price.
        trail_stop_activation: Profit threshold before trailing stop activates.
        touched_exit: Use intraday touched stop-loss/take-profit.
        retain_cost_when_rebalance: Keep original cost basis on rebalance.
        stop_trading_next_period: Skip next period after stop-loss/take-profit.
        live_performance_start: ISO date string marking live trading start.
        mae_mfe_window: Window size for MAE/MFE calculation.
        mae_mfe_window_step: Step size for MAE/MFE window.
        market: Market instance or name string ('TW_STOCK', 'US_STOCK').
        upload: Whether to upload the strategy report to FinLab cloud. Defaults
            to ``None``: upload only in cloud-scheduled runs (the
            ``FINLAB_FORCED_STRATEGY_NAME`` environment variable is set). FinLab
            Studio, local, Jupyter and Colab runs upload only when
            ``upload=True`` is passed.
        end_date: Last date of the backtest (inclusive; a bare date covers the
            whole day). Position, prices and the report (creturn, trades,
            stats) stop there, as if the backtest ran on that day. Positions
            still open on ``end_date`` stay open in ``report.trades``.
            ``None`` (default) keeps the current behavior: the end is inferred
            from the position's signal spacing.
        metrics_only: Return the same ``Metrics`` type as ``Report.metrics``
            without constructing a Report. Return-series metrics such as CAGR,
            Sharpe ratio and maximum drawdown remain available.
        notification_enable: Send Line notifications on completion.
        line_access_token: Line Notify access token.

    Returns:
        A Report, or a Metrics object when ``metrics_only=True``.
    """
    cfg = SimConfig(
        resample=resample,
        resample_offset=resample_offset,
        trade_at_price=trade_at_price,
        position_limit=position_limit,
        fee_ratio=fee_ratio,
        tax_ratio=tax_ratio,
        name=name,
        stop_loss=stop_loss,
        take_profit=take_profit,
        trail_stop=trail_stop,
        trail_stop_activation=trail_stop_activation,
        touched_exit=touched_exit,
        retain_cost_when_rebalance=retain_cost_when_rebalance,
        stop_trading_next_period=stop_trading_next_period,
        live_performance_start=live_performance_start,
        end_date=end_date,
        mae_mfe_window=mae_mfe_window,
        mae_mfe_window_step=mae_mfe_window_step,
        market=market,
        upload=upload,
        notification_enable=notification_enable,
        line_access_token=line_access_token,
    )

    from finlab.data import readiness
    from finlab.data.context import _default_context

    _resolve_market_config(cfg)
    # A historical backtest is never tradable, so skip the calendar and
    # metadata round-trips that readiness() would make.
    cfg.data_readiness = (
        readiness(cfg.market)
        if end_date is None
        else {
            "schema_version": 1,
            "final_ready": False,
            "datasets": {},
            "reason": "historical_backtest",
        }
    )
    verify_execution_prices = end_date is None and (
        any(value is not None for value in (stop_loss, take_profit, trail_stop))
        or touched_exit
    )
    # Quote/benchmark/name data fetched for a report must not become inputs of
    # this or the next strategy. Freeze source evidence before any lazy pricing.
    with _default_context.override(
        _loaded_datasets=set(_default_context._loaded_datasets)
    ):
        return _sim_from_config(position, cfg, metrics_only, verify_execution_prices)


def _sim_from_config(
    position: pd.DataFrame | pd.Series,
    cfg: SimConfig,
    metrics_only: bool,
    verify_execution_prices: bool,
) -> report.Report | Metrics:
    if cfg.data_readiness is None:
        raise RuntimeError("Source readiness must be captured before simulation")
    signal_ready = cfg.data_readiness
    # Auto-collect LazyWide at rebalance dates for optimal performance.
    from finlab.dataframe.lazy import LazyWide

    if isinstance(position, LazyWide):
        position = _collect_lazy_position_for_sim(position, cfg)

    # Suggest lazy() when position is large and resampled.
    if (
        isinstance(position, pd.DataFrame)
        and cfg.resample is not None
        and len(position) > 500
    ):
        logger.info(
            "Tip: wrap your computation with .lazy() for faster rebalanced "
            "strategies. Example: close.lazy().rolling(60).mean().is_largest(10)"
        )

    position, cfg = _validate_sim_inputs(position, cfg)
    _prefetch_market_datasets(cfg)
    if verify_execution_prices:
        from finlab.data import readiness
        from finlab.data.context import _default_context

        policy = getattr(cfg.market, "_TRADE_AT_PRICE_ADJ_TABLES", {})
        keys = (
            set(policy.get(cfg.trade_at_price, ()))
            if isinstance(cfg.trade_at_price, str)
            else set()
        )
        # The engine evaluates ordinary stops against close_values even when
        # fills use open (or another trade_at_price).
        keys.update(policy.get("close", ()))
        if cfg.touched_exit:
            for price_type in ("high", "low", "open"):
                keys.update(policy.get(price_type, ()))
        if not isinstance(cfg.trade_at_price, str) or not keys:
            cfg.data_readiness = {
                **signal_ready,
                "final_ready": False,
                "reason": "unverified_execution_prices",
            }
        else:
            with _default_context.override(_loaded_datasets=keys):
                prices_ready = readiness(cfg.market)
            cfg.data_readiness = {
                **signal_ready,
                "datasets": {**prices_ready["datasets"], **signal_ready["datasets"]},
                "final_ready": signal_ready["final_ready"]
                and prices_ready["final_ready"]
                and signal_ready.get("execution_session")
                == prices_ready.get("execution_session"),
            }

    with _backtest_context():
        prepared = _prepare_simulation_inputs(position, cfg)
        schedule = _derive_simulation_schedule(
            prepared.position,
            prepared.cfg,
            prepared.price,
        )
        engine_run = _execute_backtest_engine(
            prepared.cfg,
            prepared,
            schedule,
            _authorize_backtest(),
        )
        if metrics_only:
            creturn = _finalize_creturn(prepared.cfg, prepared, schedule, engine_run)
            return metrics_from_creturn(creturn, "native_metrics_only")
        return _build_simulation_report(prepared.cfg, prepared, schedule, engine_run)
