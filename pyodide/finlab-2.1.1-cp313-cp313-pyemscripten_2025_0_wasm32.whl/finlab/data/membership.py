"""Effective-date Taiwan listing eligibility, independent of snapshot universes."""

from __future__ import annotations

import warnings

import pandas as pd

from finlab.dataframe import FinlabDataFrame

_MARKETS = {"TSE": ("上市日期", "下市日期"), "OTC": ("上櫃日期", "下櫃日期")}


def _records(frame: pd.DataFrame) -> pd.DataFrame:
    frame = pd.DataFrame(frame).copy()
    if not any(c in frame.columns for c in ("symbol", "stock_id")):
        frame = frame.reset_index()
    key = "symbol" if "symbol" in frame.columns else "stock_id"
    if key not in frame:
        raise ValueError("Membership source is missing symbol/stock_id")
    frame["symbol"] = frame[key].astype(str).str.strip()
    return frame


def _date(value: object) -> pd.Timestamp | None:
    if pd.isna(value) or str(value).strip().lower() in {
        "",
        "nan",
        "nat",
        "none",
        "-",
        "--",
    }:
        return None
    # Data sources provide Gregorian dates; do not guess ROC years or integers.
    if isinstance(value, (int, float)):
        raise ValueError(f"Invalid membership date: {value!r}")
    result = pd.Timestamp(value)
    if result.tz is not None or result.year < 1900:
        raise ValueError(f"Invalid membership date: {value!r}")
    return result.normalize()


_Events = dict[tuple[str, str], set[pd.Timestamp]]
_Event = tuple[str, str, pd.Timestamp]

# Verified symbol succession, not a present-day market/category fallback.
# On 2002-11-04 the surviving entity (23357403) adopted predecessor 2301.
# Its company listing date belongs to its earlier symbol, not to 2301.
# https://www.liteon.com/zh-tw/milestone/milestones
_SYMBOL_SUCCESSIONS = {("2301", "TSE", "23357403"): pd.Timestamp("2002-11-04")}


def _apply_symbol_successions(
    companies: pd.DataFrame,
) -> tuple[pd.DataFrame, set[_Event]]:
    companies = _records(companies).reset_index(drop=True)
    successions: set[_Event] = set()
    for i, row in companies.iterrows():
        for exchange, (field, _) in _MARKETS.items():
            key = (row["symbol"], exchange, str(row.get("營利事業統一編號", "")))
            effective = _SYMBOL_SUCCESSIONS.get(key)
            start = _date(row.get(field))
            if effective is not None and start is not None and start <= effective:
                companies.loc[i, field] = effective.strftime("%Y-%m-%d")
                successions.add((row["symbol"], exchange, effective))
    return companies, successions


def _add_event(events: _Events, key: tuple[str, str], value: object) -> None:
    date = _date(value)
    if date is not None:
        events.setdefault(key, set()).add(date)


def _listing_events(
    companies: pd.DataFrame,
    delisted: pd.DataFrame,
    tse_ends: pd.DataFrame,
    otc_ends: pd.DataFrame,
) -> tuple[_Events, _Events, set[str], set[_Event]]:
    companies, successions = _apply_symbol_successions(companies)
    rows = pd.concat([companies, _records(delisted)], ignore_index=True)
    for field in ("上市日期", "上櫃日期"):
        if field not in rows:
            raise ValueError(f"Membership source is missing {field}")
    starts: dict[tuple[str, str], set[pd.Timestamp]] = {}
    ends: dict[tuple[str, str], set[pd.Timestamp]] = {}
    known = set(rows.symbol)
    for row in rows.to_dict("records"):
        for exchange, (start_field, end_field) in _MARKETS.items():
            key = (row["symbol"], exchange)
            _add_event(starts, key, row.get(start_field))
            _add_event(ends, key, row.get(end_field))
    for exchange, frame, field in (
        ("TSE", tse_ends, "終止上市日期"),
        ("OTC", otc_ends, "終止上櫃日期"),
    ):
        frame = _records(frame)
        if field not in frame:
            raise ValueError(f"Membership source is missing {field}")
        for row in frame.to_dict("records"):
            known.add(row["symbol"])
            end = _date(row[field])
            if end is not None:
                ends.setdefault((row["symbol"], exchange), set()).add(end)

    return starts, ends, known, successions


def _build_membership(
    price: pd.DataFrame,
    companies: pd.DataFrame,
    delisted: pd.DataFrame,
    tse_ends: pd.DataFrame,
    otc_ends: pd.DataFrame,
    market: str,
) -> FinlabDataFrame:
    """Build half-open [listing, delisting) intervals; never infer from prices."""
    index = price.index
    if not isinstance(index, pd.DatetimeIndex) or index.tz is not None:
        raise ValueError("Membership requires a timezone-naive DatetimeIndex")
    if (
        not index.is_unique
        or not index.is_monotonic_increasing
        or not price.columns.is_unique
    ):
        raise ValueError("Membership price axes must be unique and dates sorted")
    starts, ends, known, successions = _listing_events(
        companies, delisted, tse_ends, otc_ends
    )

    result = pd.DataFrame(False, index=index, columns=price.columns)
    selected = set(_MARKETS) if market == "TSE_OTC" else {market}
    matched_ends: set[_Event] = set()
    for (symbol, exchange), dates in starts.items():
        # A later entry on either exchange ends the preceding listing period.
        all_starts = set().union(*(starts.get((symbol, m), set()) for m in _MARKETS))
        for start in sorted(dates):
            boundaries = [
                d
                for d in ends.get((symbol, exchange), set())
                if d >= start
                and not (d == start and (symbol, exchange, start) in successions)
            ]
            boundaries += [d for d in all_starts if d > start]
            end = min(boundaries) if boundaries else None
            if end is not None and end in ends.get((symbol, exchange), set()):
                matched_ends.add((symbol, exchange, end))
            if exchange not in selected or symbol not in result.columns:
                continue
            active = index >= start
            if end is not None:
                active &= index < end
            result.loc[active, symbol] = True
    missing = sorted(
        s
        for s in known.intersection(price.columns)
        if not any(starts.get((s, m)) for m in _MARKETS)
    )
    # Each end must close a reconstructed interval. An earlier, already closed
    # listing cannot account for a later termination with a missing relisting.
    # A predecessor's end also cannot close its same-day successor's interval.
    incomplete = sorted(
        {
            s
            for (s, m), ds in ends.items()
            if s in price.columns and any((s, m, end) not in matched_ends for end in ds)
        }
    )
    mask = FinlabDataFrame(result)
    mask.attrs["membership_missing_history"] = sorted(set(missing) | set(incomplete))
    mask.attrs["membership_market"] = market
    if mask.attrs["membership_missing_history"]:
        ids = mask.attrs["membership_missing_history"]
        warnings.warn(
            f"Membership has incomplete listing history for {len(ids)} securities "
            f"({', '.join(ids[:10])}). Unverified periods remain False; "
            "inspect result.attrs['membership_missing_history'].",
            UserWarning,
            stacklevel=3,
        )
    return mask


def membership(
    market: str = "TSE_OTC", *, force_download: bool = False
) -> FinlabDataFrame:
    """Return daily TW listing eligibility for explicit pre-ranking masking.

    Supports TSE, OTC, and TSE_OTC. Dates/columns follow the unfiltered Taiwan
    close-price table (subject to the active data date window). Listing dates
    are inclusive and termination dates exclusive. Suspensions and zero-volume
    days do not terminate membership. Unknown periods are False and reported
    by warning/attrs. This is effective-date eligibility reconstructed from
    current records, not a historical data vintage or an as-known-at-the-time
    guarantee. Source corrections may change historical eligibility.

    Existing universe context/filter state is neither applied nor changed.
    Obtain scores without a snapshot universe that already removed securities.
    Apply the mask before *each* cross-sectional ranking. No version argument
    or automatic changes to ranking methods are introduced.

    Examples
    --------
    >>> from finlab import data
    >>> from finlab.data import universe
    >>> close = data.get('price:收盤價')
    >>> eligible = universe.membership('TSE_OTC')
    >>> position = close.pct_change(20)[eligible].is_largest(20)
    """
    from . import data as data_module
    from .context import _default_context
    from .universe import _membership_read

    if not isinstance(market, str) or market.upper() not in {*_MARKETS, "TSE_OTC"}:
        raise ValueError("membership supports only TSE, OTC, and TSE_OTC")
    if _default_context._current_market not in (None, "tw"):
        raise ValueError("membership requires the Taiwan data market")
    token = _membership_read.set(True)
    try:
        frames = [
            data_module.get(name, force_download=force_download)
            for name in (
                "price:收盤價",
                "company_basic_info",
                "delisted_companies",
                "delisted_companies_tse",
                "delisted_companies_otc",
            )
        ]
    finally:
        _membership_read.reset(token)
    price, companies, delisted, tse_ends, otc_ends = frames
    return _build_membership(
        price, companies, delisted, tse_ends, otc_ends, market.upper()
    )
