"""Feather V2 (Arrow IPC) read/write helpers.

pyarrow deprecated the ``pyarrow.feather`` module in 24.0.0; Feather V2 is
the Arrow IPC file format, so these helpers are drop-in equivalents built on
``pyarrow.ipc`` that read and write the same files without FutureWarnings.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Final

import pyarrow as pa

if TYPE_CHECKING:
    import pandas as pd

DATE_COLUMN: Final = "date"
"""Physical column (or named index) a date-range pushdown filters on."""


class DateColumnMissingError(ValueError):
    """Raised when a start/end filter targets a dataset without a ``date`` column.

    Subclasses ``ValueError`` (an API/usage error), so callers can distinguish it
    from a corrupt-cache read error and surface it to the user unchanged.
    """


def _date_column_error() -> DateColumnMissingError:
    return DateColumnMissingError(
        f"This dataset has no '{DATE_COLUMN}' column, so the start/end date-range "
        "filter is not supported for it. Call data.get(...) without start/end, or "
        "filter the returned DataFrame yourself."
    )


def read_frame(source: Any) -> pd.DataFrame:
    """Read a Feather V2 payload (buffer or open file) into a DataFrame."""
    return pa.ipc.open_file(source).read_all().to_pandas()


def read_frame_from_path(path: str, columns: list[str] | None = None) -> pd.DataFrame:
    """Read a Feather V2 file, optionally projecting to ``columns``.

    Selecting ``columns`` preserves the stored pandas schema metadata, so an
    index column selected here is restored as the DataFrame index, matching
    ``pd.read_feather(..., columns=...)``. Projection goes through
    ``pyarrow.dataset`` so only the selected columns are decompressed —
    ``read_all().select()`` would decompress the whole lz4 table first.
    """
    if columns is not None:
        try:
            import pyarrow.dataset as ds
        except ImportError:  # minimal pyarrow builds (e.g. wasm) lack dataset
            pass
        else:
            dataset = ds.dataset(path, format="feather")
            return dataset.to_table(columns=columns).to_pandas()
    with pa.memory_map(path, "r") as source:
        table = pa.ipc.open_file(source).read_all()
        if columns is not None:
            table = table.select(columns)
        return table.to_pandas()


def _build_date_predicate(pa_ds: Any, start: Any, end: Any) -> Any:
    """Build a ``pyarrow.dataset`` predicate for an inclusive ``[start, end]`` range."""
    field = pa_ds.field(DATE_COLUMN)
    predicate = None
    if start is not None:
        lower = field >= start
        predicate = lower if predicate is None else predicate & lower
    if end is not None:
        upper = field <= end
        predicate = upper if predicate is None else predicate & upper
    return predicate


def read_frame_date_range(path: str, start: Any, end: Any) -> pd.DataFrame:
    """Read a Feather V2 file, keeping only rows with ``date`` in ``[start, end]``.

    The bounds are pushed down to ``pyarrow.dataset`` so only in-range rows are
    decoded into pandas -- the full table is never materialised. Both bounds are
    optional and inclusive; at least one is expected to be set. Raises
    ``ValueError`` when the file has no ``date`` column so a caller cannot
    silently fall back to reading the whole (potentially huge) table.
    """
    try:
        import pyarrow.dataset as pa_ds
    except ImportError:  # minimal pyarrow builds (e.g. wasm) lack dataset
        return filter_frame_date_range(read_frame_from_path(path), start, end)

    dataset = pa_ds.dataset(path, format="feather")
    if DATE_COLUMN not in dataset.schema.names:
        raise _date_column_error()
    predicate = _build_date_predicate(pa_ds, start, end)
    if predicate is None:
        return dataset.to_table().to_pandas()
    return dataset.to_table(filter=predicate).to_pandas()


def filter_frame_date_range(df: pd.DataFrame, start: Any, end: Any) -> pd.DataFrame:
    """Filter an in-memory frame to rows with ``date`` in ``[start, end]``.

    Mirrors :func:`read_frame_date_range` for frames already in memory (in-cache
    storage, legacy pickle caches, or wasm builds without ``pyarrow.dataset``).
    ``date`` may be a column, a named index, or a ``MultiIndex`` level. Raises
    ``ValueError`` when no ``date`` is present.
    """
    import pandas as pd

    index = df.index
    if DATE_COLUMN in df.columns:
        values = df[DATE_COLUMN].to_numpy()
    elif index.name == DATE_COLUMN:
        values = index.to_numpy()
    elif isinstance(index, pd.MultiIndex) and DATE_COLUMN in index.names:
        values = index.get_level_values(DATE_COLUMN).to_numpy()
    else:
        raise _date_column_error()

    mask = None
    if start is not None:
        lower = values >= start.to_datetime64()
        mask = lower if mask is None else mask & lower
    if end is not None:
        upper = values <= end.to_datetime64()
        mask = upper if mask is None else mask & upper
    if mask is None:
        return df
    return df.loc[mask]


def write_frame(df: pd.DataFrame, path: str) -> None:
    """Write a DataFrame as a Feather V2 file (lz4, like ``df.to_feather``)."""
    table = pa.Table.from_pandas(df)
    options = pa.ipc.IpcWriteOptions(compression="lz4")
    with (
        pa.OSFile(path, "wb") as sink,
        pa.ipc.new_file(sink, table.schema, options=options) as writer,
    ):
        writer.write_table(table)
