"""Explain ``data.get()`` misses: equivalent-key redirects and did-you-mean hints."""

from __future__ import annotations

from typing import Final

from finlab.exceptions import DatasetNotFoundError

from .catalog import KeyAlias, find_key_alias, suggest_similar_keys

# Prefix of the per-dataset metadata error for keys that have no stored file.
_NOT_FOUND_ERROR_PREFIX: Final = "Cannot find data"
_SEARCH_HINT: Final = "可用 data.search('關鍵字') 查詢可用的資料集。"


def is_not_found_error(error: str) -> bool:
    """Whether a metadata error means the dataset key does not exist."""
    return error.startswith(_NOT_FOUND_ERROR_PREFIX)


def equivalent_key_alias(dataset: str) -> KeyAlias | None:
    """Return the alias entry when ``dataset`` is a published equivalent key."""
    key_alias = find_key_alias(dataset)
    return key_alias if key_alias is not None and key_alias.is_equivalent else None


def redirect_warning_message(key_alias: KeyAlias) -> str:
    """Warning shown when ``data.get`` fetches the equivalent target instead."""
    message = (
        f"找不到 {key_alias.alias}，已自動改用相同資料 {key_alias.target}。"
        f"請改寫為 data.get('{key_alias.target}')。"
    )
    return f"{message}{key_alias.note}" if key_alias.note else message


def dataset_not_found_error(dataset: str) -> DatasetNotFoundError:
    """Build the user-facing error for a missing dataset key."""
    key_alias = find_key_alias(dataset)
    related_notes: dict[str, str] = {}
    if key_alias is not None:
        related_notes[key_alias.target] = key_alias.note
    suggestions = tuple(dict.fromkeys([*related_notes, *suggest_similar_keys(dataset)]))

    lines = [f"找不到 {dataset}（Cannot find data: {dataset}）。"]
    if suggestions:
        lines.append("您是不是要找：")
        for key in suggestions:
            note = related_notes.get(key)
            lines.append(f"  - {key}（{note}）" if note else f"  - {key}")
    lines.append(_SEARCH_HINT)
    return DatasetNotFoundError(dataset, "\n".join(lines), suggestions)
