"""Data freshness: ``is_tradable()``, ``next_future_expiry()``, ``suggested_tradable_time()``."""

from __future__ import annotations

import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from finlab.market import Market

from .context import _default_context
from .storage import CacheStorage, FileStorage

__all__ = [
    "is_tradable",
    "next_future_expiry",
    "suggested_tradable_time",
]


# ---------------------------------------------------------------------------
# Expiry dict
# ---------------------------------------------------------------------------


def _get_expiry_dict() -> dict[str, datetime.datetime]:
    """Get the expiry dict from current storage.

    When datasets have been loaded via get(), only return expiry entries
    for those datasets so that unrelated cached data doesn't affect
    suggested_tradable_time() / is_tradable().
    """
    ctx = _default_context
    storage = ctx._storage
    if isinstance(storage, FileStorage):
        expiry = storage._expiry
    elif isinstance(storage, CacheStorage):
        expiry = storage._cache_expiry
    else:
        return {}

    if not ctx._loaded_datasets:
        return {}

    return {k: v for k, v in expiry.items() if k in ctx._loaded_datasets}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def next_future_expiry() -> datetime.datetime | None:
    """Next future expiry time among cached datasets (UTC).

    Returns only expiry times in the future, skipping already expired data.

    Returns:
        datetime in UTC representing the next future expiry, or None if
        no future expiries exist or no data is available.
    """
    expiry_dict = _get_expiry_dict()
    if not expiry_dict:
        return None

    now = datetime.datetime.now(tz=datetime.timezone.utc)

    future_expiries = [
        expiry for expiry in expiry_dict.values() if expiry is not None and expiry > now
    ]

    if not future_expiries:
        return None

    return min(future_expiries)


def suggested_tradable_time(market: Market | None = None) -> datetime.datetime | None:
    """Latest required scheduled source check, not a guaranteed arrival time.

    Returns None if readiness is unknown or every required slot has passed.
    Rerun the strategy after the scheduled check and confirm readiness again.
    """
    from .readiness import readiness

    result = readiness(market)
    now = datetime.datetime.now(datetime.timezone.utc)
    slots = [
        datetime.datetime.fromisoformat(source["required_refresh_at"])
        for item in result["datasets"].values()
        for source in item.get("sources", [])
        if source.get("pending")
    ]
    future = [slot for slot in slots if slot > now]
    return max(future) if future else None


def _without_publication_schedule(result: dict) -> bool:
    """Whether readiness() had no schedule to judge against: an unsupported
    market or no trading calendar. Missing evidence for a dataset is not this.
    """
    reason = result.get("reason")
    return reason == "unsupported_market" or (
        reason == "readiness_unavailable"
        and result.get("error_type") == "CalendarUnavailable"
    )


def is_tradable(market: Market | None = None) -> bool:
    """Whether loaded data completed its final scheduled refresh before next open.

    Daily TW data is judged by publication evidence, not cache expiry; use
    data.readiness() for the reason. Markets without publication evidence and
    runs without a trading calendar fall back to the cache-expiry rule.
    """
    from .readiness import readiness

    result = readiness(market)
    if _without_publication_schedule(result):
        return _expiry_is_tradable(market)
    return result["final_ready"]


def _expiry_is_tradable(market: Market | None) -> bool:
    """True when no loaded dataset has expired or refreshes again before the open."""
    from finlab.markets.tw import TWMarket

    if market is None:
        market = TWMarket()

    expiry_dict = _get_expiry_dict()
    if not expiry_dict:
        return False

    now = datetime.datetime.now(tz=datetime.timezone.utc)
    tz = market.tzinfo() or datetime.timezone(datetime.timedelta(hours=8))
    open_hour, open_minute = market.market_open_time()
    now_local = now.astimezone(tz)
    today_open_local = now_local.replace(
        hour=open_hour, minute=open_minute, second=0, microsecond=0
    )
    today_open_utc = today_open_local.astimezone(datetime.timezone.utc)
    market_opened_today = now_local >= today_open_local

    for expiry in expiry_dict.values():
        if expiry is None:
            continue
        if now >= expiry:
            return False
        if (not market_opened_today) and expiry <= today_open_utc:
            return False
    return True
