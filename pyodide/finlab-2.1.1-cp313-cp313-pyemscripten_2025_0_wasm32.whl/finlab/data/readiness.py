"""Readiness of the exact datasets loaded in the current data context."""

from __future__ import annotations

import datetime as dt
import json
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import pandas as pd

    from finlab.market import Market
    from finlab.session_calendar import SessionCalendar

    from .auth import FetchMetadata
    from .context import DataContext
    from .storage import CacheStorage, FileStorage
from collections import OrderedDict

from finlab.session_calendar import UTC

from .calendar import get_calendar
from .context import _default_context
from .publication import METADATA_KEY, DatasetSnapshot, evaluate_readiness


def record_publication(
    storage: CacheStorage | FileStorage,
    dataset: str,
    result: FetchMetadata,
    frame: pd.DataFrame | None = None,
    *,
    verified: bool = False,
) -> None:
    """Bind evidence to a cache revision; legacy/mismatched replies stay unknown.

    A generation-pinned full download and a hash-verified merge already prove
    their version. Metadata-only replies must additionally match local contents.
    """
    records = getattr(storage, "_publications", None)
    if not isinstance(records, dict):
        records = storage._publications = {}
    publication = result.publication
    valid = (
        isinstance(publication, dict)
        and type(publication.get("schema_version")) is int
        and publication["schema_version"] == 1
    )
    if valid and isinstance(publication, dict):
        valid = bool(result.hash) and publication.get("content_hash") == result.hash
    if valid and not verified:
        from .get import hash as frame_hash

        try:
            valid = frame is not None and frame_hash(frame) == result.hash
        except (ValueError, TypeError):
            valid = False
    records[dataset] = (
        storage.get_time_created(dataset),
        publication if valid else None,
    )


def _selection_reason(ctx: DataContext, market: Market | None) -> str | None:
    if market is not None and (
        market.get_name() != "tw_stock" or market.get_freq() not in {"D", "1D"}
    ):
        return "unsupported_market"
    if not ctx._loaded_datasets:
        return "no_loaded_data"
    if (
        ctx.truncate_start is not None
        or ctx.truncate_end is not None
        or ctx._loaded_datasets.intersection(ctx._projected_datasets)
    ):
        # Hashes describe raw cached objects, not data.get's projected frames.
        return "historical_data_selection"
    return None


def readiness(
    market: Market | None = None,
    *,
    execution_session: str | dt.date | None = None,
    now: dt.datetime | None = None,
    calendar: SessionCalendar | None = None,
) -> dict[str, Any]:
    """Describe whether all loaded data is current by its pre-open schedule.

    Scheduled checks are not guaranteed delivery deadlines. Unknown evidence,
    unsupported markets, stale calendars and unavailable sources return false.
    Calling this never silently replaces data already used by a strategy.
    """
    live_clock = now is None
    now = now or dt.datetime.now(UTC)
    ctx = _default_context
    base: dict[str, Any] = {
        "schema_version": 1,
        "validation_version": 2,
        "scope": "execution_session" if execution_session else "next_market_open",
        "checked_at": now.isoformat(),
        "final_ready": False,
        "datasets": {},
        "reason": None,
    }
    selection_reason = _selection_reason(ctx, market)
    if selection_reason:
        return {**base, "reason": selection_reason}
    try:
        calendar = calendar or get_calendar(now=now)
        calendar.require_usable(now)
        session = (
            dt.date.fromisoformat(str(execution_session))
            if execution_session
            else calendar.next_open(now).date()
        )
        storage = ctx._storage
        records = getattr(storage, "_publications", {})
        if not isinstance(records, dict):
            records = {}
        missing = [
            name
            for name in ctx._loaded_datasets
            if name not in records or records[name][0] != storage.get_time_created(name)
        ]
        # Older disk caches have no evidence. Fetch only metadata and compare its
        # hash once; never certify a newer version against previously used bytes.
        if missing and not ctx.use_local_data_only:
            from .auth import fetch_metadata_batch

            metadata = fetch_metadata_batch(
                OrderedDict((name, storage.get_time_created(name)) for name in missing)
            )
            for name in missing:
                result = metadata.get(name)
                if result is not None:
                    record_publication(
                        storage, name, result, storage.get_dataframe(name)
                    )
            records = getattr(storage, "_publications", {})
        datasets = {}
        for name in sorted(ctx._loaded_datasets):
            created, pub = records.get(name, (None, None))
            if created != storage.get_time_created(name):
                pub = None
            meta = (
                {
                    "hash": pub.get("content_hash"),
                    METADATA_KEY: json.dumps(pub.get("evidence")),
                    "refresh_policy": pub.get("refresh_policy"),
                    "data_period": pub.get("data_period"),
                    **(
                        {"observed_at": pub["observed_at"]}
                        if "observed_at" in pub
                        else {}
                    ),
                }
                if pub
                else {}
            )
            datasets[name] = DatasetSnapshot(meta.get("hash") or "", meta)
        # A metadata-only request may finish after the initial timestamp.
        # Evaluate at completion, keeping the original execution session so
        # a request crossing opening cannot certify the closed window.
        now = dt.datetime.now(UTC) if live_clock else now
        base["checked_at"] = now.isoformat()
        evaluation = evaluate_readiness(calendar, session, datasets, now=now)
        return {**base, **evaluation}
    except Exception as exc:  # noqa: BLE001 -- optional readiness must fail closed, never break data access
        return {
            **base,
            "reason": "readiness_unavailable",
            "error_type": type(exc).__name__,
        }


def snapshot_is_ready(snapshot: dict | None, *, now: dt.datetime | None = None) -> bool:
    """A saved True is applicable only before its original execution cutoff."""
    now = now or dt.datetime.now(UTC)
    try:
        return bool(
            snapshot
            and type(snapshot.get("validation_version")) is int
            and snapshot.get("validation_version") == 2
            and snapshot.get("final_ready") is True
            and dt.datetime.fromisoformat(snapshot["checked_at"])
            <= now
            < dt.datetime.fromisoformat(snapshot["update_end_at"])
        )
    except (KeyError, TypeError, ValueError):
        return False
