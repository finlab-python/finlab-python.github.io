from __future__ import annotations

import sys
import types

from .calendar import get_calendar
from .data import (
    _CONTEXT_ATTRS,
    DataContext,
    _default_context,
    category_cache_stats,
    clear,
    clear_category_cache,
    get,
    get_role,
    get_strategies,
    gets,
    indicator,
    is_tradable,
    is_vip,
    market,
    next_future_expiry,
    search,
    set_market,
    set_storage,
    suggested_tradable_time,
)
from .entries import entry_names
from .readiness import readiness
from .storage import CacheStorage, FileStorage
from .universe import reset_universe, set_universe, universe, us_universe

__all__: list[str] = [
    "CacheStorage",
    "DataContext",
    "FileStorage",
    "_default_context",
    "_storage",
    "category_cache_stats",
    "clear",
    "clear_category_cache",
    "entry_names",
    "force_cloud_download",
    "get",
    "get_calendar",
    "get_role",
    "get_strategies",
    "gets",
    "indicator",
    "is_tradable",
    "is_vip",
    "market",
    "next_future_expiry",
    "prefer_local_if_exists",
    "readiness",
    "reset_universe",
    "search",
    "set_market",
    "set_storage",
    "set_universe",
    "suggested_tradable_time",
    "truncate_end",
    "truncate_start",
    "universe",
    "us_universe",
    "use_local_data_only",
]

# ---------------------------------------------------------------------------
# Module wrapper — intercepts attribute get/set so that
# ``finlab.data.truncate_start = X`` flows into the DataContext singleton
# rather than being silently stored on the module __dict__.
# ---------------------------------------------------------------------------


class _DataPackageModule(types.ModuleType):
    """Thin wrapper that proxies context-attr reads/writes to the singleton."""

    def __getattr__(self, name: str):  # noqa: ANN204
        if name in _CONTEXT_ATTRS:
            return getattr(_default_context, name)
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    def __setattr__(self, name: str, value: object) -> None:
        if name in _CONTEXT_ATTRS:
            setattr(_default_context, name, value)
        else:
            super().__setattr__(name, value)


# Replace this module in sys.modules with the proxy.
_this = sys.modules[__name__]
_proxy = _DataPackageModule(__name__, _this.__doc__)
_proxy.__dict__.update(
    {k: v for k, v in _this.__dict__.items() if k not in _CONTEXT_ATTRS}
)
_proxy.__path__ = _this.__path__
_proxy.__package__ = _this.__package__
_proxy.__spec__ = _this.__spec__
_proxy.__file__ = _this.__file__
sys.modules[__name__] = _proxy
