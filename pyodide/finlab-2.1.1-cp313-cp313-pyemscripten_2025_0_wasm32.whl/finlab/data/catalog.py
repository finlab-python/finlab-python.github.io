"""Firestore data catalog and dataset search for finlab."""

from __future__ import annotations

import base64
import difflib
import gzip
import json
import logging
import re
import sys
import unicodedata
import zlib
from dataclasses import dataclass, field
from functools import lru_cache
from typing import TYPE_CHECKING, Any, Final

import pandas as pd
import requests

import finlab.utils

from . import context as _context

if TYPE_CHECKING:
    from collections.abc import Mapping

logger = logging.getLogger(__name__)

DEFAULT_MARKET: Final = "tw"
KEY_ALIAS_EQUIVALENT: Final = "equivalent"
KEY_ALIAS_RELATED: Final = "related"

_FIRESTORE_CATALOG_URL: Final = (
    "https://firestore.googleapis.com/v1/projects/fdata-299302/"
    "databases/(default)/documents/data_categories"
)
_ROTC_KEY_PREFIX: Final = "rotc_"
# Representative symbols for dynamic stock-day dataset families.
_INTRADAY_REPRESENTATIVES: Final = ("tw_tick:2330", "tw_minute:2330")
# fdata category names carry a market prefix such as "TW_Stock-"; it is not
# descriptive and would make every dataset match keywords like "stock".
_CATEGORY_MARKET_PREFIX: Final = re.compile(r"^[A-Za-z]+_[A-Za-z]+-")
# Joins a key's texts so a keyword never matches across two of them.
_SEARCH_TERM_SEPARATOR: Final = "\n"
_SEARCH_TEXT_REPLACEMENTS: Final = (
    ("占", "佔"),
    ("(%)", ""),
    ("今日", ""),
    ("當日", ""),
)
_SUGGESTION_LIMIT: Final = 3
_SUGGESTION_CUTOFF: Final = 0.6

_MARKET_TO_FIRESTORE_DOC: Final[dict[str, str]] = {
    "tw": "finlab_tw_stock",
    "rotc": "finlab_tw_stock",
    "us": "finlab_us_stock",
    "us_fund": "finlab_us_stock",
    "hk": "fdata-hk-stock",
    "jp": "fdata-jp-stock",
    "kr": "fdata-kr-stock",
    "uk": "fdata-uk-stock",
}


def _parse_firestore_value(
    value: dict[str, Any],
) -> str | int | float | bool | list[Any] | dict[str, Any] | None:
    """Parse a Firestore REST API value into a native Python type."""
    if "stringValue" in value:
        return value["stringValue"]
    if "integerValue" in value:
        return int(value["integerValue"])
    if "doubleValue" in value:
        return float(value["doubleValue"])
    if "booleanValue" in value:
        return value["booleanValue"]
    if "nullValue" in value:
        return None
    if "arrayValue" in value:
        values = value["arrayValue"].get("values", [])
        return [_parse_firestore_value(v) for v in values]
    if "mapValue" in value:
        fields = value["mapValue"].get("fields", {})
        return {k: _parse_firestore_value(v) for k, v in fields.items()}
    if "timestampValue" in value:
        return value["timestampValue"]
    return None


def _fetch_firestore_json(url: str) -> dict[str, Any]:
    """Sync GET-and-parse helper. Uses pyodide.http.pyfetch in pyodide to
    bypass urllib3-emscripten's broken bytes-to-JS bridge."""
    if "pyodide" in sys.modules:
        from finlab.data.auth import _pyodide_get_text

        return json.loads(_pyodide_get_text(url))
    return finlab.utils.requests.get(url, timeout=30).json()


@dataclass(frozen=True)
class KeyAlias:
    """A known wrong or legacy dataset key and the key users should use."""

    alias: str
    target: str
    kind: str
    note: str = ""

    @property
    def is_equivalent(self) -> bool:
        """Whether ``target`` holds exactly the same values as ``alias``."""
        return self.kind == KEY_ALIAS_EQUIVALENT


@dataclass(frozen=True)
class DataCatalog:
    """Dataset keys of one Firestore catalog document plus their search text."""

    keys: tuple[str, ...] = ()
    search_texts: tuple[str, ...] = ()
    key_aliases: Mapping[str, KeyAlias] = field(default_factory=dict)


def normalize_search_text(text: str) -> str:
    """Normalize dataset keys and search keywords so equivalent spellings match.

    Applies NFKC (full-width letters and brackets become half-width), case
    folding, 占 → 佔, and drops the noise tokens ``(%)``, ``今日`` and ``當日``.
    """
    normalized = unicodedata.normalize("NFKC", text).casefold()
    for old, new in _SEARCH_TEXT_REPLACEMENTS:
        normalized = normalized.replace(old, new)
    return normalized


def _string_list(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, str) and item]


def _dict_list(value: object) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


def _decode_categories_gz(encoded: object) -> list[dict[str, Any]] | None:
    """Decode the base64 gzip JSON ``categories_gz`` field; None when unusable."""
    if not isinstance(encoded, str) or not encoded:
        return None
    try:
        decoded = json.loads(gzip.decompress(base64.b64decode(encoded)))
    except (ValueError, OSError, EOFError, zlib.error) as e:
        logger.debug("Failed to decode categories_gz: %s", e)
        return None
    return _dict_list(decoded) if isinstance(decoded, list) else None


def _category_search_terms(category: dict[str, Any]) -> list[str]:
    name = category.get("name")
    terms = _string_list(category.get("aliases"))
    if isinstance(name, str) and name:
        terms.append(_CATEGORY_MARKET_PREFIX.sub("", name))
    return terms


def _item_search_terms(info: dict[str, Any]) -> list[str]:
    terms = [info.get("name"), info.get("description")]
    return [
        *(term for term in terms if isinstance(term, str) and term),
        *_string_list(info.get("aliases")),
        *_string_list(info.get("columns")),
    ]


def _item_key(table_alias: str, info: dict[str, Any]) -> str:
    key = info.get("alias")
    if isinstance(key, str) and key:
        return key
    name = info.get("name")
    if table_alias and isinstance(name, str) and name:
        return f"{table_alias}:{name}"
    return ""


def _collect_search_terms(categories: list[dict[str, Any]]) -> dict[str, list[str]]:
    """Map each dataset key (catalog order) to the raw texts that describe it.

    Table-format datasets list one ``data_info`` entry per column under the same
    key, so their column names accumulate on that key.
    """
    terms_by_key: dict[str, list[str]] = {}
    for category in categories:
        table_alias = category.get("alias")
        table_alias = table_alias if isinstance(table_alias, str) else ""
        category_terms = _category_search_terms(category)
        for info in _dict_list(category.get("data_info")):
            key = _item_key(table_alias, info)
            if not key:
                continue
            terms = terms_by_key.setdefault(key, [key, *category_terms])
            terms.extend(_item_search_terms(info))
        if table_alias in terms_by_key:
            terms_by_key[table_alias].extend(_string_list(category.get("columns")))
    return terms_by_key


def _parse_key_aliases(value: object) -> dict[str, KeyAlias]:
    key_aliases: dict[str, KeyAlias] = {}
    for entry in _dict_list(value):
        alias, target = entry.get("alias"), entry.get("target")
        if not (
            isinstance(alias, str) and alias and isinstance(target, str) and target
        ):
            continue
        kind = entry.get("kind")
        note = entry.get("note")
        key_aliases[alias] = KeyAlias(
            alias=alias,
            target=target,
            kind=kind if isinstance(kind, str) else KEY_ALIAS_RELATED,
            note=note if isinstance(note, str) else "",
        )
    return key_aliases


def _build_catalog(fields: dict[str, Any]) -> DataCatalog:
    """Build a catalog from Firestore fields, preferring the full ``categories_gz``."""
    categories = _decode_categories_gz(
        _parse_firestore_value(fields.get("categories_gz", {}))
    )
    if categories is None:
        categories = _dict_list(_parse_firestore_value(fields.get("categories", {})))
    terms_by_key = _collect_search_terms(categories)
    return DataCatalog(
        keys=tuple(terms_by_key),
        search_texts=tuple(
            normalize_search_text(_SEARCH_TERM_SEPARATOR.join(terms))
            for terms in terms_by_key.values()
        ),
        key_aliases=_parse_key_aliases(
            _parse_firestore_value(fields.get("key_aliases", {}))
        ),
    )


@lru_cache(maxsize=8)
def _load_catalog(document_id: str) -> DataCatalog:
    """Fetch and index one Firestore catalog document; empty on failure."""
    url = f"{_FIRESTORE_CATALOG_URL}/{document_id}"
    try:
        raw = _fetch_firestore_json(url)
        return _build_catalog(raw.get("fields", {}))
    except (requests.RequestException, json.JSONDecodeError, KeyError, ValueError) as e:
        logger.warning("Failed to fetch data catalog from %s: %s", document_id, e)
        return DataCatalog()


def _fetch_data_catalog_from_firestore(document_id: str) -> tuple[str, ...]:
    """Return the dataset keys listed in a Firestore catalog document."""
    return _load_catalog(document_id).keys


def _catalog_document_for_current_market() -> str:
    market = _context._default_context._current_market or DEFAULT_MARKET
    return _MARKET_TO_FIRESTORE_DOC.get(
        market, _MARKET_TO_FIRESTORE_DOC[DEFAULT_MARKET]
    )


def find_key_alias(dataset: str) -> KeyAlias | None:
    """Return the published alias entry for a missing dataset key, if any."""
    return _load_catalog(_catalog_document_for_current_market()).key_aliases.get(
        dataset
    )


def suggest_similar_keys(dataset: str) -> list[str]:
    """Return catalog keys whose normalized spelling is close to ``dataset``."""
    catalog = _load_catalog(_catalog_document_for_current_market())
    keys_by_normalized = {
        normalize_search_text(key): key for key in catalog.keys if key != dataset
    }
    matches = difflib.get_close_matches(
        normalize_search_text(dataset),
        keys_by_normalized,
        n=_SUGGESTION_LIMIT,
        cutoff=_SUGGESTION_CUTOFF,
    )
    return [keys_by_normalized[match] for match in matches]


def _catalog_for_market(market: str) -> DataCatalog:
    if market == "all":
        catalogs = [
            _load_catalog(doc_id)
            for doc_id in dict.fromkeys(_MARKET_TO_FIRESTORE_DOC.values())
        ]
        return DataCatalog(
            keys=tuple(key for catalog in catalogs for key in catalog.keys),
            search_texts=tuple(
                text for catalog in catalogs for text in catalog.search_texts
            ),
        )
    catalog = _load_catalog(_MARKET_TO_FIRESTORE_DOC[market])
    if market != "rotc":
        return catalog
    rotc = [
        (key, text)
        for key, text in zip(catalog.keys, catalog.search_texts, strict=True)
        if key.startswith(_ROTC_KEY_PREFIX)
    ]
    return DataCatalog(
        keys=tuple(key for key, _ in rotc),
        search_texts=tuple(text for _, text in rotc),
    )


def search(keyword: str | None = None, market: str | None = None) -> pd.Series:
    """Search available data fields in the finlab database.

    The keyword matches dataset keys and, when the catalog provides them, each
    dataset's name, description, aliases and table columns. Matching ignores
    case, full/half-width differences, 占/佔, ``(%)`` and ``今日``/``當日``.

    Returns a pandas Series of dataset names (object dtype, name "dataset")."""
    valid_market_names = set(_MARKET_TO_FIRESTORE_DOC) | {"all"}
    if keyword is not None and market is None and keyword.lower() in valid_market_names:
        market = keyword.lower()
        keyword = None

    if market is None:
        market = _context._default_context._current_market or DEFAULT_MARKET
    market = market.lower()
    if market not in valid_market_names:
        valid = ", ".join(sorted(_MARKET_TO_FIRESTORE_DOC)) + ", all"
        raise ValueError(f"Invalid market: '{market}'. Must be one of: {valid}")

    catalog = _catalog_for_market(market)
    keys = list(catalog.keys)
    search_texts = list(catalog.search_texts)
    if market in {DEFAULT_MARKET, "all"}:
        intraday = [name for name in _INTRADAY_REPRESENTATIVES if name not in keys]
        keys.extend(intraday)
        search_texts.extend(normalize_search_text(name) for name in intraday)

    if keyword is not None:
        needle = normalize_search_text(keyword) or keyword.casefold()
        keys = [
            key for key, text in zip(keys, search_texts, strict=True) if needle in text
        ]

    return pd.Series(keys, dtype="object", name="dataset")
