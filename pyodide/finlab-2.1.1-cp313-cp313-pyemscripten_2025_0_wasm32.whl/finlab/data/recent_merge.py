"""Merge a ``.recent`` delta into a cached table.

Two equivalent strategies are provided:

* :func:`merge_recent_df` — the in-memory merge used for :class:`CacheStorage`
  and legacy pickle caches. It concatenates the full table with the delta and
  drops superseded rows.
* :func:`stream_merge_recent_feather` — a record-batch streaming merge for
  on-disk Feather V2 caches. It walks the stored table one Arrow record batch
  at a time, drops rows whose key appears in the delta, appends the delta, and
  hashes the result on the fly. Peak memory is ~= one record batch + the delta
  instead of three full copies of the table, which is what lets a ~100M-row
  cache refresh on a 16 GB machine without OOM.

Both produce byte-identical output (``DataFrame.equals`` including row order)
and the same ``hash_pandas_object`` digest, so the server-side hash check that
guards the merge needs no change.
"""

from __future__ import annotations

import hashlib
from typing import TYPE_CHECKING

import pandas as pd
import pyarrow as pa
from pyarrow import ipc

if TYPE_CHECKING:
    from collections.abc import Sequence

# Columns that identify a logical row across a full table and its recent delta.
# Only those present in a given dataset participate in de-duplication.
MERGE_DEDUP_COLS = ["symbol", "stock_id", "date", "持股分級", "broker"]

# ``data.get`` compares the first 7 hex chars of the md5 digest, matching the
# server-provided ``result.hash``. Kept here so the in-memory and streaming
# paths truncate identically.
HASH_HEXDIGEST_PREFIX = 7


def merge_recent_df(df: pd.DataFrame, short_df: pd.DataFrame) -> pd.DataFrame:
    """Merge a recent delta into an existing DataFrame, deduplicating rows."""
    compare_cols = df.columns.intersection(MERGE_DEDUP_COLS)
    return (
        pd.concat([df, short_df])
        .pipe(lambda d: d[~d.duplicated(subset=compare_cols, keep="last")])[
            short_df.columns
        ]
        .reset_index(drop=True)
    )


def _dedup_columns(columns: Sequence[str]) -> list[str]:
    return [col for col in MERGE_DEDUP_COLS if col in columns]


def _plain_output_schema(schema: pa.Schema, columns: Sequence[str]) -> pa.Schema:
    """Schema matching :func:`merge_recent_df`'s output for ``columns``.

    Dictionary-encoded columns are decoded to their value type because
    concatenating two categoricals with differing categories yields a plain
    (string) column, which is exactly what the in-memory path stores. Dropping
    the source pandas metadata makes the reread frame a fresh ``RangeIndex``,
    matching ``merge_recent_df``'s trailing ``reset_index(drop=True)``.
    """
    fields = []
    for name in columns:
        field = schema.field(name)
        field_type = field.type
        if pa.types.is_dictionary(field_type):
            field_type = field_type.value_type
        fields.append(pa.field(name, field_type))
    return pa.schema(fields)


def _decode_dictionary_columns(batch: pa.RecordBatch) -> pa.RecordBatch:
    """Decode any dictionary-encoded columns so batches share one plain schema.

    Arrow IPC files only allow a single non-delta dictionary per field, so
    appending the delta (with its own dictionary) to the retained batches would
    otherwise raise a dictionary-replacement error.
    """
    arrays = [
        column.dictionary_decode() if pa.types.is_dictionary(column.type) else column
        for column in batch.columns
    ]
    return pa.record_batch(arrays, names=batch.schema.names)


def _update_streaming_hash(
    digest: hashlib._Hash, frame: pd.DataFrame, offset: int
) -> int:
    """Fold ``frame``'s per-row hashes into ``digest`` under a global RangeIndex.

    ``hash_pandas_object`` hashes each row independently, so hashing chunk by
    chunk with contiguous ``RangeIndex`` labels reproduces the whole-table
    digest exactly. Returns the next offset.
    """
    frame.index = pd.RangeIndex(offset, offset + len(frame))
    digest.update(pd.util.hash_pandas_object(frame, index=True).values.tobytes())
    return offset + len(frame)


def stream_merge_recent_feather(
    source_path: str,
    dest_path: str,
    short_df: pd.DataFrame,
    expected_hash: str,
) -> bool:
    """Stream-merge a recent delta from ``source_path`` into ``dest_path``.

    Walks the stored table one record batch at a time, drops rows whose dedup
    key is present in ``short_df``, appends the (de-duplicated) delta, and
    computes the merged hash incrementally. ``dest_path`` is always written; the
    return value reports whether the streamed hash matches ``expected_hash``.
    The caller is responsible for promoting ``dest_path`` on success and
    discarding it on mismatch.

    Peak memory is ~= one record batch + the delta.
    """
    columns = list(short_df.columns)
    compare_cols = _dedup_columns(columns)
    if not compare_cols:
        return False

    delta = short_df[~short_df.duplicated(subset=compare_cols, keep="last")]
    delta_keys = pd.MultiIndex.from_frame(delta[compare_cols])

    digest = hashlib.md5()
    offset = 0
    options = ipc.IpcWriteOptions(compression="lz4")

    with pa.memory_map(source_path) as source:
        reader = ipc.open_file(source)
        write_schema = _plain_output_schema(reader.schema, columns)
        with ipc.new_file(dest_path, write_schema, options=options) as writer:
            for batch_index in range(reader.num_record_batches):
                batch = reader.get_batch(batch_index)
                keys = pd.MultiIndex.from_frame(batch.select(compare_cols).to_pandas())
                kept = batch.filter(pa.array(~keys.isin(delta_keys)))
                if kept.num_rows == 0:
                    continue
                kept = _decode_dictionary_columns(kept.select(columns)).cast(
                    write_schema
                )
                writer.write_batch(kept)
                offset = _update_streaming_hash(digest, kept.to_pandas(), offset)

            delta_frame = delta[columns].copy()
            offset = _update_streaming_hash(digest, delta_frame, offset)
            writer.write_table(
                pa.Table.from_pandas(delta_frame, preserve_index=False).cast(
                    write_schema
                )
            )

    return digest.hexdigest()[:HASH_HEXDIGEST_PREFIX] == expected_hash
