"""Publication evidence for the final scheduled refresh before a TW opening.

Cache expiry is deliberately not an input. The evaluator is network-free and
considers exactly the dataset versions supplied by its caller, not all datasets
in the account. Source evidence must prove a successful read after the final scheduled slot.
Server observation and cache expiry cannot certify that a source ran. Unknown
evidence fails closed without changing legacy expiry.
"""

from __future__ import annotations

import datetime as dt
import json
from dataclasses import dataclass
from functools import lru_cache
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping
from zoneinfo import ZoneInfo

from finlab.session_calendar import TW, SessionCalendar, aware

from .period import data_period

METADATA_KEY = "readiness_v1"


def _sources(metadata: dict) -> list[dict]:
    raw = json.loads(metadata.get(METADATA_KEY, "{}"))
    if (
        type(raw.get("version")) is not int
        or raw["version"] != 1
        or not raw.get("sources")
        or raw.get("reason")
    ):
        raise ValueError("Missing publication evidence")
    if not isinstance(raw["sources"], list):
        raise TypeError("Invalid source evidence")
    return raw["sources"]


@lru_cache(maxsize=2048)
def _last_slot(
    schedule: str,
    timezone: str,
    opening: dt.datetime,
    trading_days_only: bool,
    calendar: SessionCalendar,
) -> dt.datetime:
    """Cached cron calculation; cost paid once per policy/execution session."""
    from croniter import croniter  # type: ignore[import-untyped]

    zone = ZoneInfo(timezone)
    local_open = opening.astimezone(zone)
    candidates = []
    for expression in schedule.split("|"):
        it = croniter(expression.strip(), local_open)
        # A schedule exactly at opening is too late for this execution session.
        slot = it.get_prev(dt.datetime)
        while trading_days_only and not calendar.is_session(slot.astimezone(TW).date()):
            # Jump across a holiday block rather than walk every minute of a
            # high-frequency cron. Session lookup is a binary search.
            previous = calendar.previous_session(slot.astimezone(TW).date())
            after_previous = dt.datetime.combine(
                previous + dt.timedelta(days=1), dt.time(), TW
            )
            it = croniter(expression.strip(), after_previous.astimezone(zone))
            slot = it.get_prev(dt.datetime)
        if slot.astimezone(TW).date() < calendar.valid_from:
            raise ValueError("Required scheduled run is outside calendar coverage")
        candidates.append(slot)
    return max(candidates)


@dataclass(frozen=True)
class DatasetSnapshot:
    """Metadata and version returned WITH the data object loaded by the strategy."""

    content_hash: str
    metadata: dict


def _policy_slot(
    policy: dict, opening: dt.datetime, calendar: SessionCalendar
) -> dt.datetime:
    if (
        not isinstance(policy, dict)
        or type(policy.get("trading_days_only")) is not bool
    ):
        raise ValueError("Invalid refresh policy")
    if not isinstance(policy.get("schedule"), str) or not policy["schedule"].strip():
        raise ValueError("Missing source schedule")
    return _last_slot(
        policy["schedule"],
        policy["schedule_timezone"],
        opening,
        policy["trading_days_only"],
        calendar,
    )


def _source_readiness(
    source: dict,
    *,
    opening: dt.datetime,
    previous: dt.date,
    calendar: SessionCalendar,
    now: dt.datetime,
    observed: dt.datetime | None,
    policy_slot: dt.datetime | None,
) -> tuple[str | None, dict]:
    if not isinstance(source.get("name"), str) or not source["name"]:
        raise ValueError("Missing source name")
    if type(source.get("daily")) is not bool:
        raise ValueError("Invalid daily coverage policy")
    checked = aware(dt.datetime.fromisoformat(source["checked_at"]))
    # v1 entries are emitted only after a successful source read. Their start
    # already proves completion cannot predate the slot. New publishers also
    # carry the explicit completion time; never use object observation as one.
    completed = (
        aware(dt.datetime.fromisoformat(source["completed_at"]))
        if "completed_at" in source
        else None
    )
    slot = _policy_slot(source, opening, calendar)
    if policy_slot is not None:
        slot = max(slot, policy_slot)
    details = {
        "name": source["name"],
        "checked_at": checked.isoformat(),
        "required_refresh_at": slot.isoformat(),
        "data_date": source.get("data_date"),
        "pending": checked < slot,
    }
    if completed is not None:
        details["completed_at"] = completed.isoformat()
    last_event = completed if completed is not None else checked
    if (
        last_event < checked
        or last_event > now
        or last_event >= opening
        or (observed is not None and last_event > observed)
    ):
        return "invalid_check_time", details
    if checked < slot:
        return "final_refresh_pending", details
    if source["daily"]:
        day = (
            dt.date.fromisoformat(source["data_date"])
            if source.get("data_date")
            else None
        )
        if day is None or day < previous:
            return "price_date_behind", details
        if day != previous or not calendar.is_session(day):
            return "invalid_data_date", details
    return None, details


def evaluate_readiness(
    calendar: SessionCalendar,
    execution_session: dt.date,
    datasets: Mapping[str, DatasetSnapshot],
    *,
    now: dt.datetime,
) -> dict[str, Any]:
    """Return final_ready and per-dataset reasons, without downloading any prices.

    datasets maps requested dataset names to DatasetSnapshot. Hash equality
    prevents checking new metadata against an older in-memory data version.
    All loaded dependencies, including fundamentals, must be supplied.
    """
    now = aware(now)
    calendar.require_usable(now)
    opening = calendar.open_at(execution_session)
    previous = calendar.previous_session(execution_session, inclusive=False)
    results: dict[str, dict[str, Any]] = {}
    for name, snapshot in datasets.items():
        reason = None
        details = []
        version_matches = (
            isinstance(snapshot.content_hash, str)
            and bool(snapshot.content_hash)
            and snapshot.metadata.get("hash") == snapshot.content_hash
        )
        if not version_matches:
            reason = "version_mismatch"
        try:
            # A policy can tighten the required slot, never replace lineage.
            sources = _sources(snapshot.metadata)
            policy = snapshot.metadata.get("refresh_policy")
            policy_slot = (
                _policy_slot(policy, opening, calendar) if policy is not None else None
            )
            observed = (
                aware(dt.datetime.fromisoformat(snapshot.metadata["observed_at"]))
                if "observed_at" in snapshot.metadata
                else None
            )
            if observed is not None and (observed > now or observed >= opening):
                reason = reason or "invalid_check_time"
            for source in sources:
                source_reason, detail = _source_readiness(
                    source,
                    opening=opening,
                    previous=previous,
                    calendar=calendar,
                    now=now,
                    observed=observed,
                    policy_slot=policy_slot,
                )
                reason = reason or source_reason
                details.append(detail)
        except (ValueError, TypeError, KeyError, OverflowError, AttributeError):
            reason = reason or "unknown_evidence"
        if now >= opening:
            reason = "execution_cutoff_passed"
        results[name] = {"ready": reason is None, "reason": reason, "sources": details}
        # Optional display facts are still useful without source evidence. They
        # must match the loaded bytes and never influence final_ready.
        period = data_period(snapshot.metadata.get("data_period"))
        if period is not None and version_matches:
            results[name]["data_period"] = period
    return {
        "schema_version": 1,
        "validation_version": 2,
        "execution_session": execution_session.isoformat(),
        "update_end_at": opening.isoformat(),
        "calendar_version": calendar.version,
        "final_ready": bool(results) and all(r["ready"] for r in results.values()),
        "datasets": results,
    }
