"""Bounded, manifest-backed TW tick and minute partition downloads."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
import sys
import time
import uuid
from io import BytesIO
from typing import Any

import pandas as pd

import finlab.utils
from finlab.exceptions import DataError

from . import auth, context

FAMILIES = frozenset({"tw_tick", "tw_minute"})
TICK_COLUMNS = (
    "stock_id",
    "trade_date",
    "timestamp",
    "sequence",
    "ts",
    "close",
    "volume",
    "tick_type",
    "bid_price",
    "bid_volume",
    "ask_price",
    "ask_volume",
    "session",
)
BAR_COLUMNS = (
    "stock_id",
    "trade_date",
    "timestamp",
    "session",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "tick_count",
    "vwap",
)


def is_intraday(dataset: str) -> bool:
    return isinstance(dataset, str) and dataset.split(":", 1)[0] in FAMILIES


def _date(value: Any) -> str:
    if value is None:
        raise ValueError("Intraday data requires both start and end dates")
    stamp = pd.Timestamp(value)
    if pd.isna(stamp) or stamp.tzinfo is not None or stamp != stamp.normalize():
        raise ValueError("Use date-only start/end in Asia/Taipei (YYYY-MM-DD)")
    return stamp.strftime("%Y-%m-%d")


def _post(query: dict[str, Any]) -> dict[str, Any]:
    for attempt in range(2):
        body = {**auth._resolve_auth_params(), "intraday": query}
        try:
            if "pyodide" in sys.modules:
                raw = auth._pyfetch_bytes_sync(
                    auth._AUTH_URL,
                    method="POST",
                    headers={"Content-Type": "application/json"},
                    body=json.dumps(body),
                    raise_for_status=False,
                )
                result = json.loads(raw.decode("utf-8"))
            else:
                response = finlab.utils.requests.post(
                    auth._AUTH_URL, json=body, timeout=60
                )
                result = response.json()
        except Exception:  # noqa: BLE001 - Pyodide transport errors use different types.
            if attempt == 0:
                time.sleep(1)
                continue
            raise DataError("Intraday authorization service is unavailable") from None
        if result.get("error") == "token_expired" and attempt == 0:
            auth._refresh_id_token()
            continue
        if "error" in result:
            detail = (
                result.get("missing_dates") or result.get("available_through") or ""
            )
            raise DataError(
                f"{result.get('code', 'intraday_error')}: {result['error']} {detail}".strip()
            )
        if (
            result.get("schema_version") != 1
            or result.get("dataset") != query["dataset"]
        ):
            raise DataError("Unsupported intraday response schema or dataset")
        context._default_context._role = result.get("role")
        return result
    raise DataError("Intraday authentication failed")


def _download(part: dict[str, Any]) -> bytes:
    for attempt in range(2):
        try:
            if "pyodide" in sys.modules:
                raw = auth._pyodide_get_bytes(part["url"])
            else:
                response = finlab.utils.requests.get(part["url"], timeout=120)
                if response.status_code != 200:
                    raise DataError(
                        f"Intraday partition download failed (HTTP {response.status_code})"
                    )
                raw = response.content
            if (
                len(raw) != part["size"]
                or hashlib.sha256(raw).hexdigest() != part["sha256"]
            ):
                raise DataError("Intraday partition size or checksum mismatch")
            return raw
        except Exception:  # noqa: BLE001 - Never expose signed URLs in transport errors.
            if attempt:
                raise DataError(
                    "Intraday partition download failed; retry data.get()"
                ) from None
            time.sleep(1)
    raise DataError("Intraday partition download failed")


def _empty(family: str) -> pd.DataFrame:
    columns = TICK_COLUMNS if family == "tw_tick" else BAR_COLUMNS
    frame = pd.DataFrame({c: pd.Series(dtype="object") for c in columns})
    frame["timestamp"] = pd.Series(dtype="datetime64[ns, Asia/Taipei]")
    for c in ("volume", "sequence", "ts", "tick_count"):
        if c in frame:
            frame[c] = frame[c].astype("int64")
    for c in ("open", "high", "low", "close", "vwap", "bid_price", "ask_price"):
        if c in frame:
            frame[c] = frame[c].astype("float64")
    if family == "tw_tick":
        frame["tick_type"] = frame.tick_type.astype("int8")
        for c in ("bid_volume", "ask_volume"):
            frame[c] = frame[c].astype("Int64")
    return frame


def _validate(
    frame: pd.DataFrame, part: dict[str, Any], symbol: str, family: str
) -> None:
    expected = TICK_COLUMNS if family == "tw_tick" else BAR_COLUMNS
    if tuple(frame.columns) != expected or len(frame) != part["rows"]:
        raise DataError("Intraday partition schema or row count mismatch")
    if str(frame.timestamp.dt.tz) != "Asia/Taipei":
        raise DataError("Intraday partition timezone mismatch")
    if not (
        frame.stock_id.eq(symbol).all() and frame.trade_date.eq(part["date"]).all()
    ):
        raise DataError("Intraday partition identity mismatch")
    if not frame.timestamp.dt.strftime("%Y-%m-%d").eq(part["date"]).all():
        raise DataError("Intraday partition date mismatch")


def _parse_range(dataset: str, start: Any, end: Any) -> tuple[str, str, str, str]:
    match = re.fullmatch(r"(tw_tick|tw_minute):([0-9A-Z]{4,10})", dataset)
    if not match:
        raise ValueError("Expected tw_tick:SYMBOL or tw_minute:SYMBOL")
    family, symbol = match.groups()
    first, last = _date(start), _date(end)
    if not 0 <= (dt.date.fromisoformat(last) - dt.date.fromisoformat(first)).days < 31:
        raise ValueError("Request between 1 and 31 calendar days")
    return family, symbol, first, last


def _verify_signed_partition(
    actual: dict[str, Any] | None, part: dict[str, Any]
) -> dict[str, Any]:
    if actual is None or any(
        actual.get(k) != part[k]
        for k in ("key", "generation", "sha256", "size", "rows")
    ):
        raise DataError("Publication changed during download; retry data.get()")
    return actual


def get_intraday(
    dataset: str,
    *,
    start: Any,
    end: Any,
    force_download: bool,
    save_to_storage: bool,
    lazy: bool,
    progress: str,
    progress_callback: Any,
) -> pd.DataFrame:
    family, symbol, first, last = _parse_range(dataset, start, end)
    if lazy or progress != "silent" or progress_callback is not None:
        raise ValueError(
            "Intraday data currently supports eager, silent data.get() only"
        )
    ctx = context._default_context
    if ctx.use_local_data_only:
        raise ValueError(
            "Intraday data requires a live publication manifest; local-only mode is unsupported"
        )
    force_download = force_download or ctx.force_cloud_download
    query = {"dataset": dataset, "start": first, "end": last}
    manifest = _post({**query, "mode": "manifest"})
    frames, needed = {}, []
    partitions = manifest["partitions"]
    cache = ctx._storage
    for part in partitions:
        if part["status"] == "no_trades":
            continue
        if part.get("status") != "ready":
            raise DataError("Intraday partition is not ready")
        identity = hashlib.sha256(
            f"{part['key']}:{part['generation']}:{part['sha256']}".encode()
        ).hexdigest()[:24]
        key = f"_intraday_v1_{family}_{symbol}_{part['date']}_{identity}"
        cached = (
            cache.get_dataframe(key) if save_to_storage and not force_download else None
        )
        if cached is not None:
            _validate(cached, part, symbol, family)
            frames[part["date"]] = cached
        else:
            needed.append((part, key))
    for offset in range(0, len(needed), 5):
        batch = needed[offset : offset + 5]
        signed = _post(
            {
                **query,
                "mode": "download",
                "request_id": uuid.uuid4().hex,
                "partitions": [
                    {"date": p["date"], "generation": p["generation"]} for p, _ in batch
                ],
            }
        )
        by_date = {p["date"]: p for p in signed["partitions"]}
        for part, key in batch:
            actual = by_date.get(part["date"])
            actual = _verify_signed_partition(actual, part)
            frame = pd.read_parquet(BytesIO(_download(actual)))
            _validate(frame, part, symbol, family)
            if save_to_storage:
                cache.set_dataframe(key, frame)
            frames[part["date"]] = frame
    result = (
        pd.concat([frames[d] for d in sorted(frames)], ignore_index=True)
        if frames
        else _empty(family)
    )
    result = result.sort_values(
        ["timestamp", "sequence"] if family == "tw_tick" else ["timestamp"],
        kind="stable",
    ).reset_index(drop=True)
    result.attrs = {
        "schema_version": 1,
        "dataset": dataset,
        "timezone": "Asia/Taipei",
        "volume_unit": manifest["volume_unit"],
        "closed_dates": manifest["closed_dates"],
        "no_trade_dates": [p["date"] for p in partitions if p["status"] == "no_trades"],
        "price_adjustment": "none",
        "completeness": "regular_ohlcv_verified",
        "after_hours_validation": "schema_only",
    }
    return result
