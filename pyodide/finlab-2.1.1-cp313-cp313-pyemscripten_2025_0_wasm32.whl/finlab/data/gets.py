"""Batch transport plus ``data.gets()`` wrapper."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

    from .progress import ProgressEvent, ProgressMode

from .get import (
    _fetch_many,
)

logger = logging.getLogger(__name__)

__all__ = [
    "gets",
]


# ---------------------------------------------------------------------------
# data.gets() — batch entry point
# ---------------------------------------------------------------------------


def gets(
    *datasets: str,
    force_download: bool = False,
    lazy: bool = False,
    progress: ProgressMode = "display",
    progress_callback: Callable[[ProgressEvent], None] | None = None,
) -> tuple:
    """Batch-fetch multiple datasets, returning finalized pandas dataframes.

    Uses a single HTTP round-trip for auth/URL signing, downloads datasets
    in parallel, and finalizes the results through the same processing
    path used by :func:`data.get`.

    Args:
        *datasets: One or more dataset names (e.g. ``'price:收盤價'``).
        force_download: Bypass cache and re-download from cloud.
        lazy: Return lazy computation wrappers after fetching datasets.
        progress: ``'display'``, ``'event'``, or ``'silent'``.
        progress_callback: Receives structured progress events in event mode.

    Returns:
        ``tuple[FinlabDataFrame, ...]`` — one per input dataset, same order.
        When ``lazy=True``, returns ``tuple[LazyWide, ...]``.

    Examples:
        >>> from finlab import data
        >>> close, vol = data.gets('price:收盤價', 'price:成交股數')
        >>> position = (close > close.average(20)) & (vol > vol.average(20))
    """
    from .intraday import is_intraday

    if any(is_intraday(dataset) for dataset in datasets):
        raise ValueError("Use data.get() with explicit start/end for intraday datasets")
    if progress == "display" and progress_callback is None:
        frames = _fetch_many(list(datasets), force_download, show_progress=True)
    else:
        frames = _fetch_many(
            list(datasets),
            force_download,
            progress=progress,
            progress_callback=progress_callback,
        )
    if lazy:
        return tuple(frame.lazy() for frame in frames)
    return frames
