"""Validate optional index-label descriptions without inferring completeness."""

from __future__ import annotations

import datetime as dt
import re


def _date(value: object) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise ValueError("Invalid date label")
    return dt.date.fromisoformat(value).isoformat()


def data_period(value: object) -> dict | None:
    """A descriptor is a property of the loaded object, not the current period.

    Future index labels can be valid (early monthly releases aligned to a later
    date). They never certify future source reads or completeness.
    """
    try:
        if (
            not isinstance(value, dict)
            or type(value.get("version")) is not int
            or value["version"] != 1
            or value.get("basis") != "index_label"
            or value.get("completeness") != "unknown"
        ):
            return None
        label = (
            _date(value["label_date"]) if value.get("label_date") is not None else None
        )
        kind, period = value.get("kind"), value.get("value")
        if kind not in {"session", "weekly_snapshot", "month", "unknown"}:
            return None
        if period is not None:
            if label is None:
                return None
            if kind in {"session", "weekly_snapshot"}:
                if _date(period) != label:
                    return None
            elif kind == "month":
                if not isinstance(period, str) or not re.fullmatch(
                    r"\d{4}-\d{2}", period
                ):
                    return None
                _date(period + "-01")
            else:
                return None
        return {
            "version": 1,
            "basis": "index_label",
            "label_date": label,
            "kind": kind,
            "value": period,
            "completeness": "unknown",
        }
    except (ValueError, TypeError, KeyError, OverflowError):
        return None
