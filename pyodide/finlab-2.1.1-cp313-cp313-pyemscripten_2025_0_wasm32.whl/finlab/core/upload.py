from __future__ import annotations

import json
import warnings
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping

STRATEGY_NAME_ENV = "FINLAB_STRATEGY_NAME"
FORCED_STRATEGY_NAME_ENV = "FINLAB_FORCED_STRATEGY_NAME"
DEFAULT_STRATEGY_NAME = "未命名"
HTTP_OK = 200


UPLOAD_SKIPPED = "skipped"
UPLOAD_PENDING = "pending"
UPLOAD_SUCCESS = "success"
UPLOAD_ERROR = "error"

_NAME_OVERRIDE_MESSAGES = {
    FORCED_STRATEGY_NAME_ENV: (
        "Cloud run uploads the report to the deployed strategy {resolved!r}; "
        "sim(name={name!r}) is ignored. "
        "雲端執行時報告一律寫入部署策略 {resolved!r}，sim(name={name!r}) 不會生效。"
    ),
    STRATEGY_NAME_ENV: (
        "FINLAB_STRATEGY_NAME={resolved!r} overrides sim(name={name!r}); "
        "the report is uploaded to {resolved!r}. "
        "環境變數 FINLAB_STRATEGY_NAME={resolved!r} 覆蓋了 sim(name={name!r})，"
        "報告會上傳到 {resolved!r}。"
    ),
}


class StrategyUploadWarning(UserWarning):
    """A strategy report upload did not do what the caller likely expects."""


def resolve_upload_name(name: str | None, environ: Mapping[str, str]) -> str:
    """Return the report name an upload writes to.

    Cloud runs set ``FINLAB_FORCED_STRATEGY_NAME`` to the deployed strategy id
    and FinLab Studio sets ``FINLAB_STRATEGY_NAME``; both override
    ``sim(name=...)``. Warn when that silently discards an explicit name,
    otherwise the report appears to land under a name it never reaches.
    Resolving an already resolved name returns it unchanged without warning.
    """
    override_env = next(
        (
            env
            for env in (FORCED_STRATEGY_NAME_ENV, STRATEGY_NAME_ENV)
            if env in environ
        ),
        None,
    )
    if override_env is None:
        return name or DEFAULT_STRATEGY_NAME

    override = environ[override_env]
    if override and name not in (None, DEFAULT_STRATEGY_NAME, override):
        warnings.warn(
            _NAME_OVERRIDE_MESSAGES[override_env].format(resolved=override, name=name),
            StrategyUploadWarning,
            stacklevel=2,
        )
    return override or DEFAULT_STRATEGY_NAME


def interpret_legacy_upload_response(
    status_code: int, text: str
) -> dict[str, str] | None:
    """Return an error payload when ``write_database`` rejected the upload."""
    if status_code != HTTP_OK:
        return {"status": "error", "message": text.strip() or f"HTTP {status_code}"}
    try:
        body = json.loads(text)
    except ValueError:
        return {"status": "error", "message": "cannot parse json object"}
    if isinstance(body, dict) and body.get("status") == "error":
        return {"status": "error", "message": str(body.get("message", "error"))}
    return None


def post_legacy_upload_pyodide_no_cors(url: str, payload: dict[str, Any]) -> bool:
    """Fire a legacy upload POST from Pyodide without browser CORS response access."""
    try:
        import js
        from pyodide.ffi import to_js
    except ImportError:
        return False

    js_payload = to_js(payload, dict_converter=js.Object.fromEntries)
    body = js.URLSearchParams.new(js_payload)
    options = to_js(
        {
            "method": "POST",
            "body": body,
            "mode": "no-cors",
        },
        dict_converter=js.Object.fromEntries,
    )
    js.fetch(url, options)
    return True
