"""Asset identifier columns of ``Report.trades`` and their wire format.

In memory, trades carry three identifier columns:

- ``stock_id``: the asset code only, e.g. ``"2330"``.
- ``name``: the asset name, e.g. ``"台積電"`` (empty when unknown).
- ``symbol``: the display label ``"2330 台積電"``, kept for compatibility.

Serialized trades (dashboard HTML, uploads, cloud payloads) keep the legacy
shape, where ``stock_id`` holds the ``"代號 名稱"`` label and there is no
``name`` column, because the website and Studio read the display name from
``stock_id``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pandas as pd

_LABEL_SEPARATOR = " "


def split_symbol_labels(labels: pd.Series) -> tuple[pd.Series, pd.Series]:
    """Split ``"代號 名稱"`` labels into (codes, names); names default to ``""``."""
    parts = labels.astype(str).str.split(_LABEL_SEPARATOR, n=1)
    return parts.str[0], parts.str[1].fillna("")


def to_wire_trades(trades: pd.DataFrame) -> pd.DataFrame:
    """Return trades in the legacy serialized shape (``stock_id`` = label)."""
    if "symbol" not in trades.columns:
        return trades
    wire = trades.drop(columns="name", errors="ignore")
    if "stock_id" in wire.columns:
        wire = wire.assign(stock_id=wire["symbol"])
    return wire


def from_wire_trades(trades: pd.DataFrame) -> pd.DataFrame:
    """Rebuild code-only ``stock_id`` and ``name`` from serialized trades.

    Very old payloads only have the ``stock_id`` label; ``symbol`` is filled
    from it.
    """
    label_column = "symbol" if "symbol" in trades.columns else "stock_id"
    if label_column not in trades.columns:
        return trades
    labels = trades[label_column]
    codes, names = split_symbol_labels(labels)
    return trades.assign(symbol=labels, stock_id=codes, name=names)
