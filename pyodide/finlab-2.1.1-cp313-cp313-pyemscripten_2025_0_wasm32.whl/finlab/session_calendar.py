"""Versioned Taiwan sessions; publishing does network I/O, lookups never do."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
from bisect import bisect_left, bisect_right
from dataclasses import dataclass
from typing import Any
from zoneinfo import ZoneInfo

TW = ZoneInfo("Asia/Taipei")
UTC = dt.timezone.utc


class CalendarUnavailable(ValueError):
    """Requested dates are not covered by a verified calendar."""


def aware(value: dt.datetime) -> dt.datetime:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("A timezone-aware datetime is required")
    return value


def canonical(value: dict) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode()


@dataclass(frozen=True)
class UpdateWindow:
    scheduled_date: dt.date
    update_start_at: dt.datetime
    update_end_at: dt.datetime
    execution_session: dt.date

    def contains(self, now: dt.datetime) -> bool:
        return self.update_start_at <= aware(now) < self.update_end_at

    def as_dict(self) -> dict[str, str]:
        return {key: value.isoformat() for key, value in vars(self).items()}


class SessionCalendar:
    """One parsed snapshot, O(log N) searches and O(1) membership tests."""

    def __init__(self, payload: dict) -> None:
        if payload.get("schema_version") != 1 or payload.get("market") != "tw":
            raise CalendarUnavailable("Unsupported calendar schema or market")
        body = {
            k: v
            for k, v in payload.items()
            if k not in {"version", "checked_at", "refresh_after", "expires_at"}
        }
        if hashlib.sha256(canonical(body)).hexdigest() != payload.get("version"):
            raise CalendarUnavailable("Calendar version does not match its content")
        self.version = payload["version"]
        self.valid_from = dt.date.fromisoformat(payload["valid_from"])
        self.valid_through = dt.date.fromisoformat(payload["valid_through"])
        self.expires_at = aware(dt.datetime.fromisoformat(payload["expires_at"]))
        self.checked_at = aware(dt.datetime.fromisoformat(payload["checked_at"]))
        self.sessions = tuple(dt.date.fromisoformat(s) for s in payload["sessions"])
        if (
            not self.sessions
            or self.sessions != tuple(sorted(set(self.sessions)))
            or self.sessions[0] < self.valid_from
            or self.sessions[-1] > self.valid_through
        ):
            raise CalendarUnavailable("Invalid session sequence")
        self._session_set = frozenset(self.sessions)
        self.open_time = dt.time.fromisoformat(payload["open_time"])
        self.close_time = dt.time.fromisoformat(payload["close_time"])
        self.update_start_time = dt.time.fromisoformat(payload["update_start_time"])

    def require_usable(self, now: dt.datetime) -> None:
        """Past expires_at a snapshot stays usable while it lists future sessions.

        Announced holidays rarely change, and a stale snapshot only misses an
        unscheduled closure until the next refresh. A snapshot checked after
        ``now`` (clock skew) or without a session after today is rejected.
        """
        now = aware(now)
        if now < self.checked_at:
            raise CalendarUnavailable("Calendar was checked after the current time")
        if self.sessions[-1] <= now.astimezone(TW).date():
            raise CalendarUnavailable("Calendar lists no future sessions")

    def _covered(self, day: dt.date) -> None:
        if not self.valid_from <= day <= self.valid_through:
            raise CalendarUnavailable(f"{day} is outside the published calendar")

    def is_session(self, day: dt.date) -> bool:
        self._covered(day)
        return day in self._session_set

    def previous_session(self, day: dt.date, *, inclusive: bool = True) -> dt.date:
        self._covered(day)
        index = (bisect_right if inclusive else bisect_left)(self.sessions, day) - 1
        if index < 0:
            raise CalendarUnavailable("Previous session is outside calendar coverage")
        return self.sessions[index]

    def next_session(self, day: dt.date) -> dt.date:
        self._covered(day)
        index = bisect_right(self.sessions, day)
        if index == len(self.sessions):
            raise CalendarUnavailable("Next session is outside calendar coverage")
        return self.sessions[index]

    def open_at(self, session: dt.date) -> dt.datetime:
        if not self.is_session(session):
            raise CalendarUnavailable(f"{session} is not a trading session")
        return dt.datetime.combine(session, self.open_time, TW)

    def close_at(self, session: dt.date) -> dt.datetime:
        if not self.is_session(session):
            raise CalendarUnavailable(f"{session} is not a trading session")
        return dt.datetime.combine(session, self.close_time, TW)

    def next_open(self, now: dt.datetime) -> dt.datetime:
        local = aware(now).astimezone(TW)
        if self.is_session(local.date()) and local < self.open_at(local.date()):
            return self.open_at(local.date())
        return self.open_at(self.next_session(local.date()))

    def window(self, scheduled_date: dt.date) -> UpdateWindow:
        """Daily resample boundary; does not change signal sampling dates."""
        last = self.previous_session(scheduled_date)
        execution = self.next_session(scheduled_date)
        return UpdateWindow(
            scheduled_date,
            dt.datetime.combine(last, self.update_start_time, TW),
            self.open_at(execution),
            execution,
        )

    def count_sessions(self, start: dt.date, end: dt.date) -> int:
        """Count trading dates in (start, end]; start is never counted."""
        self._covered(start)
        self._covered(end)
        if end < start:
            raise ValueError("end must not precede start")
        return bisect_right(self.sessions, end) - bisect_right(self.sessions, start)

    def position_progress(
        self, start: dt.date, current: dt.date, end: dt.date
    ) -> dict[str, Any]:
        """Date-based progress: sessions in (a, b] / sessions in (a, c].

        A trading date counts when reached, independent of its time of day.
        Weekend dates are not snapped. Zero-session ranges have no meaningful
        percentage and return None. This is not a data-readiness indicator.
        """
        total = self.count_sessions(start, end)
        current = max(start, min(current, end))
        elapsed = self.count_sessions(start, current)
        return {
            "elapsed_sessions": elapsed,
            "total_sessions": total,
            "remaining_sessions": total - elapsed,
            "progress": elapsed / total if total else None,
            "calendar_version": self.version,
        }
