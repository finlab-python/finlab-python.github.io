"""Finlab exception hierarchy."""

__all__ = [
    "AuthError",
    "BacktestError",
    "BrokerError",
    "ConfigError",
    "DataError",
    "DatasetNotFoundError",
    "FinlabError",
    "LoginError",
    "PortfolioError",
]


class FinlabError(Exception):
    """Base exception for all finlab errors."""


class DataError(FinlabError):
    """Data fetching, caching, or transformation failures."""


class DatasetNotFoundError(DataError, RuntimeError):
    """``data.get()`` asked for a dataset key that does not exist.

    Subclasses ``RuntimeError`` because missing datasets used to raise a bare
    ``RuntimeError``; existing ``except RuntimeError`` handlers keep working.
    """

    def __init__(
        self, dataset: str, message: str, suggestions: tuple[str, ...] = ()
    ) -> None:
        super().__init__(message)
        self.dataset = dataset
        self.suggestions = suggestions


class BacktestError(FinlabError):
    """Invalid backtest config or simulation failures."""


class BrokerError(FinlabError):
    """Broker connection, order submission, or execution failures."""


class AuthError(FinlabError):
    """Authentication or authorization failures."""


class LoginError(AuthError, RuntimeError):
    """Interactive login did not complete (cancelled, rejected or timed out).

    Subclasses ``RuntimeError`` so callers that already catch login failures
    from ``finlab.get_token()`` keep working.
    """


class PortfolioError(FinlabError):
    """Portfolio construction or rebalancing failures."""


class ConfigError(FinlabError):
    """Invalid configuration or missing required settings."""
