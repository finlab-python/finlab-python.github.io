"""Factor metric computation: IC, correlation, NDCG, and precision-at-rank."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import numpy as np
import pandas as pd
from tqdm import tqdm

from finlab.dataframe import FinlabDataFrame

if TYPE_CHECKING:
    from collections.abc import Callable

try:
    from sklearn.metrics import ndcg_score
except ImportError:
    ndcg_score = None


CorrelationMethod = Literal["pearson", "spearman"]

# ``DataFrame.unstack()`` yields a (column, index) MultiIndex, so the date is
# always the last level whatever the index is named.
_UNSTACKED_DATE_LEVEL = -1


def corr(df: pd.DataFrame) -> float:
    """Pearson correlation between the first two columns of *df*."""
    return df.corr().iloc[0, 1]


def spearman_corr(df: pd.DataFrame) -> float:
    """Spearman rank correlation between the first two columns of *df*."""
    return df.corr(method="spearman").iloc[0, 1]


_IC_SCORERS: dict[str, Callable[[pd.DataFrame], float]] = {
    "pearson": corr,
    "spearman": spearman_corr,
}


def ndcg_k(k: int) -> Callable[[pd.DataFrame], float]:
    """Return an NDCG scorer truncated at rank *k*."""

    def ndcg(df: pd.DataFrame) -> float:
        s1 = np.reshape(df.iloc[:, 0].rank().values, (-1, len(df)))
        s2 = np.reshape(df.iloc[:, 1].rank().values, (-1, len(df)))
        if ndcg_score is None:
            raise ImportError(
                "sklearn is not installed, ndcg_score will not be available"
            )
        return ndcg_score(s1, s2, k=k)

    return ndcg


ndcg20: Callable[[pd.DataFrame], float] = ndcg_k(20)
ndcg50: Callable[[pd.DataFrame], float] = ndcg_k(50)


def precision_at_rank(k: float) -> Callable[[pd.DataFrame], float]:
    """Return a precision scorer that evaluates the top ``1 - k`` quantile."""

    def ret(df: pd.DataFrame) -> float:
        y_true = df.iloc[:, 0]
        y_score = df.iloc[:, 1]
        if not (0 <= k <= 1):
            raise ValueError("k must be between 0 and 1")
        selected = y_score.rank(pct=True) > k
        return y_true.rank(pct=True)[selected.values].mean()

    return ret


def calc_metric(
    factor: pd.DataFrame | dict[str, pd.DataFrame],
    adj_close: pd.DataFrame,
    days: list[int] | None = None,
    func: Callable[[pd.DataFrame], float] = corr,
) -> pd.DataFrame:
    """Compute a cross-sectional metric between *factor* and forward returns.

    Args:
        factor: Single factor DataFrame or dict of named factor DataFrames.
        adj_close: Adjusted close prices.
        days: Forward-return horizons (default ``[10, 20, 60, 120]``).
        func: Scoring callable applied per date group (default :func:`corr`).

    Returns:
        DataFrame with one column per ``(factor_name, horizon)`` pair.
    """
    if days is None:
        days = [10, 20, 60, 120]

    if isinstance(factor, pd.DataFrame):
        factor = {"factor": factor}

    for fname, f in factor.items():
        factor[fname] = FinlabDataFrame(f).index_str_to_date()

    ics: dict[str, pd.DataFrame] = {}

    total = len(days) * len(factor)
    with tqdm(total=total, desc="Processing") as pbar:
        for d in days:
            ret = adj_close.shift(-d - 1) / adj_close.shift(-1) - 1

            for fname, f in factor.items():
                inter_col = f.columns.intersection(adj_close.columns)
                inter_index = f.index.intersection(adj_close.index)

                f_subset = f.reindex(index=inter_index, columns=inter_col)
                ret_subset = ret.reindex(index=inter_index, columns=inter_col)

                funstack = f_subset.unstack()
                ret_unstack = ret_subset.unstack()

                ics[f"{fname}_{d}"] = (
                    pd.DataFrame(
                        {
                            "ret": ret_unstack.values,
                            "f": funstack.values,
                        },
                        index=funstack.index,
                    )
                    .dropna()
                    .groupby(level=_UNSTACKED_DATE_LEVEL)
                    .apply(func)
                )
                pbar.update(1)

    return pd.concat(ics, axis=1)


def ic(
    factor: pd.DataFrame | dict[str, pd.DataFrame],
    adj_close: pd.DataFrame,
    days: list[int] | None = None,
    method: CorrelationMethod = "pearson",
) -> pd.DataFrame:
    """Per-date IC between *factor* and forward returns.

    Args:
        factor: Single factor DataFrame or dict of named factor DataFrames.
        adj_close: Adjusted close prices.
        days: Forward-return horizons (default ``[10, 20, 60, 120]``).
        method: ``"pearson"`` (default, unchanged) or ``"spearman"`` for rank IC.

    Returns:
        DataFrame with one column per ``(factor_name, horizon)`` pair.
    """
    if method not in _IC_SCORERS:
        raise ValueError(f"method must be one of {sorted(_IC_SCORERS)}, got {method!r}")
    return calc_metric(factor, adj_close, days=days, func=_IC_SCORERS[method])


def calc_ic(
    features: pd.DataFrame, labels: pd.Series, rank: bool = False
) -> pd.DataFrame:
    """Compute per-date IC between *features* and *labels*.

    Args:
        features: MultiIndex DataFrame (date, stock) with factor columns.
        labels: MultiIndex Series with the same index.
        rank: If ``True``, compute Spearman rank IC (features and labels are
            both ranked per date); otherwise Pearson IC.

    Returns:
        DataFrame of IC values per date and factor. The Pearson result starts
        at the first date where every factor that has any IC has one; factors
        with no IC at all stay as all-NaN columns.
    """
    label_column = "__label__"
    method: CorrelationMethod = "spearman" if rank else "pearson"
    joined = features.assign(**{label_column: labels.reindex(features.index)})
    ret = joined.groupby(level=0).apply(
        lambda g: g.drop(columns=label_column).corrwith(g[label_column], method=method)
    )
    if rank:
        return ret
    return _from_first_complete_date(ret)


def _from_first_complete_date(ic_values: pd.DataFrame) -> pd.DataFrame:
    """Drop leading dates until every factor that ever has an IC has one."""
    populated = ic_values.loc[:, ic_values.notna().any()]
    if populated.empty:
        return ic_values
    complete = populated.notna().all(axis=1)
    has_any = populated.notna().any(axis=1)
    start = complete.idxmax() if complete.any() else has_any.idxmax()
    return ic_values.loc[start:]
