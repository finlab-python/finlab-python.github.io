"""Candlestick / OHLCV chart functions."""

from __future__ import annotations

import ast
from typing import Any

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from finlab import data
from finlab.compat import param_alias
from finlab.plot._core import IndicatorSpec, color_generator

__all__ = [
    "plot_candles",
    "plot_tw_stock_candles",
]


def _str_to_indicator(s: str, df: pd.DataFrame) -> pd.DataFrame | pd.Series:
    import talib
    from talib import abstract

    params: dict[str, Any] = {}
    if "(" in s:
        param_str = s.rsplit("(", maxsplit=1)[-1].rstrip(")")
        for pair in param_str.split(","):
            if "=" not in pair:
                continue
            key, value = pair.split("=", 1)
            params[key.strip()] = ast.literal_eval(value.strip())
    s = s.split("(", maxsplit=1)[0]

    func = getattr(abstract, s)
    real_func = getattr(talib, s)

    abstract_input = next(iter(func.input_names.values()))
    if isinstance(abstract_input, str):
        abstract_input = [abstract_input]

    pos_paras = [df[k] for k in abstract_input]

    ret = real_func(*pos_paras, **params)

    if isinstance(ret, np.ndarray):
        ret = pd.Series(ret, index=df.index)

    if isinstance(ret, pd.Series):
        return ret.to_frame(s)
    return ret


def _sequence_to_dict(seq: list | tuple) -> dict[str | int, Any]:
    """Convert a list/tuple indicator spec into a dict keyed by name or index."""
    result: dict[str | int, Any] = {}
    ivalue = 0
    for item in seq:
        if isinstance(item, str):
            result[item] = item
        else:
            result[ivalue] = item
            ivalue += 1
    return result


def _dict_to_df(mapping: dict[str, Any], symbol: str, df: pd.DataFrame) -> pd.DataFrame:
    """Evaluate each entry in a dict indicator spec and concatenate into one DataFrame."""
    dfs: list[pd.DataFrame] = []
    for name, n in mapping.items():
        nn = _evaluate_to_df(n, symbol, df)
        if len(nn.columns) == 1:
            nn.columns = [name]
        dfs.append(nn)
    return pd.concat(dfs, axis=1)


def _evaluate_to_df(node: IndicatorSpec, symbol: str, df: pd.DataFrame) -> pd.DataFrame:
    if callable(node):
        node = node(df)

    if isinstance(node, str):
        node = _str_to_indicator(node, df)

    if isinstance(node, pd.Series):
        return node.to_frame("0")

    if isinstance(node, np.ndarray):
        return pd.Series(node, df.index).to_frame("0")

    if isinstance(node, pd.DataFrame):
        if symbol in node.columns:
            return pd.DataFrame({"0": node[symbol]})
        return node

    if isinstance(node, (list, tuple)):
        node = _sequence_to_dict(node)

    if isinstance(node, dict):
        return _dict_to_df(node, symbol, df)

    raise ValueError(f"Unsupported indicator type: {type(node).__name__}")


def _format_indicators(
    indicators: IndicatorSpec | list[IndicatorSpec],
    symbol: str,
    stock_df: pd.DataFrame,
) -> list[pd.DataFrame]:
    if not isinstance(indicators, list):
        indicators = [indicators]

    return [_evaluate_to_df(i, symbol, stock_df) for i in indicators]


def _default_overlay() -> dict[str, Any]:
    """Return default overlay indicators (Bollinger Bands)."""
    upperband, middleband, lowerband = data.indicator("BBANDS")
    return {
        "upperband": upperband,
        "middleband": middleband,
        "lowerband": lowerband,
    }


def _default_technical() -> list[dict[str, Any]]:
    """Return default technical indicators (Stochastic)."""
    k, d = data.indicator("STOCH")
    return [{"K": k, "D": d}]


def _truncate_indicators(
    indicators: list[pd.DataFrame],
    recent_days: int,
    resample: str,
    target_index: pd.Index,
) -> list[pd.DataFrame]:
    """Truncate indicator DataFrames to recent_days and optionally resample."""
    result: list[pd.DataFrame] = []
    for ind_df in indicators:
        truncated = ind_df.iloc[-abs(recent_days) :]
        if resample != "D":
            truncated = truncated.reindex(target_index, method="ffill")
        result.append(truncated)
    return result


def _build_fig_titles(
    technical_func: list[dict[str, Any]] | dict[str, Any],
) -> list[str]:
    """Build subplot title strings from technical function specs."""
    titles = [""]
    if isinstance(technical_func, list):
        titles.extend(",".join(t) for t in technical_func)
    elif isinstance(technical_func, dict):
        titles.append(",".join(technical_func))
    return titles


def _hide_holidays(fig: go.Figure, index_value: pd.Index) -> None:
    """Hide non-trading-day gaps on the x-axis for daily data."""
    dt_all = pd.date_range(start=index_value[0], end=index_value[-1])
    dt_obs = {d_.strftime("%Y-%m-%d") for d_ in pd.to_datetime(index_value)}
    dt_breaks = [d_ for d_ in dt_all.strftime("%Y-%m-%d").tolist() if d_ not in dt_obs]
    fig.update_xaxes(rangebreaks=[{"values": dt_breaks}])


@param_alias("stock_id", "symbol")
def plot_candles(
    symbol: str,
    close: pd.Series,
    open_: pd.Series,
    high: pd.Series,
    low: pd.Series,
    volume: pd.Series,
    recent_days: int = 250,
    resample: str = "D",
    overlay_func: dict[str, Any] | list[dict[str, Any]] | None = None,
    technical_func: list[dict[str, Any]] | dict[str, Any] | None = None,
) -> go.Figure:
    c = color_generator()
    next(c)
    next(c)

    df = pd.DataFrame(
        {
            "close": close.values,
            "open": open_.values,
            "high": high.values,
            "low": low.values,
            "volume": volume.values,
        },
        index=close.index,
    ).iloc[-abs(recent_days) :]

    if resample:
        df = df.resample(resample).agg(
            {
                "close": "last",
                "open": "first",
                "high": "max",
                "low": "min",
                "volume": "sum",
            }
        )

    if overlay_func is None:
        overlay_func = _default_overlay()

    if technical_func is None:
        technical_func = _default_technical()

    overlay_indicator = _format_indicators(overlay_func, symbol, df)

    # merge overlay indicator if it has multiple plots
    if len(overlay_indicator) > 1:
        overlay_indicator = [pd.concat(overlay_indicator, axis=1)]
        overlay_indicator[0].columns = range(len(overlay_indicator[0].columns))

    technical_indicator = _format_indicators(technical_func, symbol, df)

    # truncate recent days
    overlay_indicator = _truncate_indicators(
        overlay_indicator, recent_days, resample, df.index
    )
    technical_indicator = _truncate_indicators(
        technical_indicator, recent_days, resample, df.index
    )

    technical_func_num = len(technical_indicator)
    index_value = close.index

    nrows = 1 + len(technical_indicator)

    fig_titles = _build_fig_titles(technical_func)

    fig = make_subplots(
        rows=nrows,
        specs=[[{"secondary_y": True}]] * nrows,
        shared_xaxes=True,
        vertical_spacing=0.05,
        subplot_titles=fig_titles,
        row_heights=[0.4] + [0.1] * (nrows - 1),
    )

    fig.add_trace(
        go.Bar(
            x=df.index,
            y=df.volume,
            opacity=0.3,
            name="volume",
            marker={"color": "gray", "line_width": 0},
        ),
        row=1,
        col=1,
    )

    fig.add_trace(
        go.Candlestick(
            x=df.index,
            open=df.open,
            high=df.high,
            low=df.low,
            close=df.close,
            increasing_line_color="#ff5084",
            decreasing_line_color="#2bbd91",
            legendgroup="1",
            name="candle",
        ),
        row=1,
        col=1,
        secondary_y=True,
    )

    # overlay plot
    if overlay_indicator:
        fig_overlay = px.line(overlay_indicator[0])
        for o in fig_overlay.data:
            fig.add_trace(
                go.Scatter(
                    x=o["x"],
                    y=o["y"],
                    name=o["name"],
                    line={"color": next(c)},
                    legendgroup="1",
                ),
                row=1,
                col=1,
                secondary_y=True,
            )

    for num, tech_ind in enumerate(technical_indicator):
        fig_tech = px.line(tech_ind)
        for t in fig_tech.data:
            color = next(c)

            fig.add_trace(
                go.Scatter(
                    x=t["x"],
                    y=t["y"],
                    name=t["name"],
                    line={"color": color},
                    legendgroup=str(2 + num),
                ),
                row=2 + num,
                col=1,
            )

    # hide holiday
    if resample == "D":
        _hide_holidays(fig, index_value)

    fig.update_layout(
        height=600 + 100 * technical_func_num,
    )

    fig.update_layout(
        yaxis1={
            "title": "volume",
            "title_font": {"color": "#777"},
            "tickfont": {"color": "#777"},
            "range": [df.volume.min(), df.volume.max() * 2],
        },
        yaxis2={
            "title": "price",
            "title_font": {"color": "#777"},
            "tickfont": {"color": "#777"},
            "showgrid": False,
        },
        hovermode="x unified",
    )

    fig.update_layout(
        **{
            "xaxis1_rangeslider_visible": False,
            "xaxis": {
                "rangeselector": {
                    "buttons": [
                        {
                            "count": 6,
                            "label": "6m",
                            "step": "month",
                            "stepmode": "backward",
                        },
                        {
                            "count": 1,
                            "label": "YTD",
                            "step": "year",
                            "stepmode": "todate",
                        },
                        {
                            "count": 1,
                            "label": "1y",
                            "step": "year",
                            "stepmode": "backward",
                        },
                        {"step": "all"},
                    ]
                },
            },
            f"xaxis{nrows}": {
                "rangeslider": {
                    "visible": True,
                    "thickness": 0.1,
                    "bgcolor": "gainsboro",
                },
                "type": "date",
            },
        }
    )

    fig.update_xaxes(showspikes=True)
    fig.update_yaxes(showspikes=True, spikemode="across")
    fig.update_layout(showlegend=False)
    fig.update_layout(plot_bgcolor="white")
    fig.update_xaxes(showline=True, linecolor="#ddd")
    fig.update_yaxes(showline=True, linecolor="#ddd")
    fig.update_yaxes(title_font={"color": "#777"}, tickfont={"color": "#777"})

    fig.update_layout(
        title={
            "text": f"Candlestick Plot {symbol}",
            "font": {"size": 18, "color": "gray"},
            # Centered so it does not overlap the range selector on the left.
            "x": 0.5,
            "xanchor": "center",
        }
    )

    return fig


@param_alias("stock_id", "symbol")
def plot_tw_stock_candles(
    symbol: str,
    recent_days: int = 400,
    adjust_price: bool = False,
    resample: str = "D",
    overlay_func: dict[str, Any] | list[dict[str, Any]] | None = None,
    technical_func: list[dict[str, Any]] | dict[str, Any] | None = None,
) -> go.Figure:
    """繪製台股技術線圖圖組
    Args:
        symbol (str): 台股股號，ex:`'2330'`。
        recent_days (int):取近n個交易日資料。
        adjust_price (bool):是否使用還原股價計算。
        resample (str): 技術指標價格週期，ex: `D` 代表日線, `W` 代表週線, `M` 代表月線。
        overlay_func (dict):
            K線圖輔助線，預設使用布林通道。
             ```py
             from finlab.data import indicator

             overlay_func={
                          'ema_5':indicator('EMA',timeperiod=5),
                          'ema_10':indicator('EMA',timeperiod=10),
                          'ema_20':indicator('EMA',timeperiod=20),
                          'ema_60':indicator('EMA',timeperiod=60),
                         }
             ```
        technical_func (list):
            技術指標子圖，預設使用KD技術指標單組子圖。

            設定多組技術指標：
            ```py
            from finlab.data import indicator

            k,d = indicator('STOCH')
            rsi = indicator('RSI')
            technical_func = [{'K':k,'D':d},{'RSI':rsi}]
            ```

    Returns:
        (plotly.graph_objects.Figure): 技術線圖

    Examples:
        ```py
        from finlab.plot import plot_tw_stock_candles
        from finlab.data import indicator

        overlay_func={
                      'ema_5':indicator('EMA',timeperiod=5),
                      'ema_10':indicator('EMA',timeperiod=10),
                      'ema_20':indicator('EMA',timeperiod=20),
                      'ema_60':indicator('EMA',timeperiod=60),
                     }
        k,d = indicator('STOCH')
        rsi = indicator('RSI')
        technical_func = [{'K':k,'D':d},{'RSI':rsi}]
        plot_tw_stock_candles(symbol='2330',recent_days=600,adjust_price=False,overlay_func=overlay_func,technical_func=technical_func)
        ```
    """
    if adjust_price:
        close = data.get("etl:adj_close")[symbol]
        open_ = data.get("etl:adj_open")[symbol]
        high = data.get("etl:adj_high")[symbol]
        low = data.get("etl:adj_low")[symbol]
    else:
        close = data.get("price:收盤價")[symbol]
        open_ = data.get("price:開盤價")[symbol]
        high = data.get("price:最高價")[symbol]
        low = data.get("price:最低價")[symbol]

    volume = data.get("price:成交股數")[symbol]

    return plot_candles(
        symbol,
        close,
        open_,
        high,
        low,
        volume,
        recent_days=recent_days,
        resample=resample,
        overlay_func=overlay_func,
        technical_func=technical_func,
    )
