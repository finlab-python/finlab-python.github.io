"""Unit tests for calculate_price_with_extra_bid."""

from __future__ import annotations

from decimal import Decimal

from finlab.markets.us import USMarket
from finlab.online.base_account import Action
from finlab.online.order_executor import calculate_price_with_extra_bid


def test_calculate_price_with_extra_bid_cases() -> None:
    test_data = {
        "test_1": {
            "price": 5.2,
            "extra_bid_pct": 0.06,
            "action": Action.BUY,
            "expected_result": 5.51,
        },
        "test_2": {
            "price": 7.4,
            "extra_bid_pct": 0.02,
            "action": Action.SELL,
            "expected_result": 7.26,
        },
        "test_3": {
            "price": 25.65,
            "extra_bid_pct": 0.1,
            "action": Action.BUY,
            "expected_result": 28.20,
        },
        "test_4": {
            "price": 11.05,
            "extra_bid_pct": 0.1,
            "action": Action.SELL,
            "expected_result": 9.95,
        },
        "test_5": {
            "price": 87.0,
            "extra_bid_pct": 0.04,
            "action": Action.BUY,
            "expected_result": 90.4,
        },
        "test_6": {
            "price": 73.0,
            "extra_bid_pct": 0.06,
            "action": Action.SELL,
            "expected_result": 68.7,
        },
        "test_7": {
            "price": 234.0,
            "extra_bid_pct": 0.08,
            "action": Action.BUY,
            "expected_result": 252.5,
        },
        "test_8": {
            "price": 234.0,
            "extra_bid_pct": 0.08,
            "action": Action.SELL,
            "expected_result": 215.5,
        },
        "test_9": {
            "price": 650.0,
            "extra_bid_pct": 0.05,
            "action": Action.BUY,
            "expected_result": 682,
        },
        "test_10": {
            "price": 756.0,
            "extra_bid_pct": 0.055,
            "action": Action.SELL,
            "expected_result": 715,
        },
        "test_11": {
            "price": 1990.0,
            "extra_bid_pct": 0.035,
            "action": Action.BUY,
            "expected_result": 2055,
        },
        "test_12": {
            "price": 1455.0,
            "extra_bid_pct": 0.088,
            "action": Action.SELL,
            "expected_result": 1330,
        },
    }

    for test_case in test_data.values():
        price = test_case["price"]
        extra_bid_pct = test_case["extra_bid_pct"]
        action = test_case["action"]
        expected_result = test_case["expected_result"]

        result = calculate_price_with_extra_bid(
            price,
            extra_bid_pct if action == Action.BUY else -extra_bid_pct,
        )
        assert result == expected_result


def test_extra_bid_and_up_down_limit() -> None:
    action = Action.BUY
    last_close = 68
    now_price = 73
    extra_bid_pct = 0.08
    up_down_limit = calculate_price_with_extra_bid(last_close, 0.1)
    price = calculate_price_with_extra_bid(now_price, extra_bid_pct)

    if (action == Action.BUY and price > up_down_limit) or (
        action == Action.SELL and price < up_down_limit
    ):
        price = up_down_limit

    assert price == 74.8


def test_calculate_price_with_extra_bid_us_market() -> None:
    us = USMarket()
    assert calculate_price_with_extra_bid(157.3, 0.001, us) == 157.45
    assert calculate_price_with_extra_bid(157.3, -0.001, us) == 157.15
    assert calculate_price_with_extra_bid(0.5, 0.001, us) == 0.5005


def test_calculate_price_with_extra_bid_decimal_price() -> None:
    assert calculate_price_with_extra_bid(Decimal("100"), 0.001) == Decimal("100.1")


def test_calculate_price_with_extra_bid_tw_etf() -> None:
    assert calculate_price_with_extra_bid(120.15, 0.002, symbol="006208") == 120.35
    assert calculate_price_with_extra_bid(52.35, 0.0005, symbol="0050") == 52.35
    assert calculate_price_with_extra_bid(21.33, -0.001, symbol="00878") == 21.31
