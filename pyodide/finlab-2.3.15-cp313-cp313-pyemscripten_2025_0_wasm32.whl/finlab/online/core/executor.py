from __future__ import annotations

import copy
import logging
import math
import numbers
from decimal import Decimal
from io import StringIO
from typing import Any

import pandas as pd
import requests

from finlab import data
from finlab.compat import is_typed_strict_mode, resolve_position_entry_symbol
from finlab.online.core.enums import *
from finlab.online.core.position import Position

logger = logging.getLogger(__name__)

SINOTRADE_ALERTING_URLS = (
    "https://www.sinotrade.com.tw/Stock/Stock_3_8_3",
    "https://www.sinotrade.com.tw/Stock/Stock_3_8_1",
)
SINOTRADE_SYMBOL_COLUMN = "股票代碼"


def _fetch_alerting_symbols(url: str, symbols: list[str]) -> list[str]:
    """Return the symbols listed in the Sinotrade alerting table at ``url``."""
    res = requests.get(url)
    # pandas >= 2.1 deprecates literal HTML in read_html; pandas 3 treats it as a path.
    table = pd.read_html(StringIO(res.text))[0]
    listed = table[SINOTRADE_SYMBOL_COLUMN].astype(str)
    return listed[listed.isin(symbols)].tolist()


class OrderExecutor:
    def __init__(
        self, target_position: Position | dict[str, Any], account: Any
    ) -> None:
        """對比實際帳戶與欲部屬的股票部位，進行同步
        Arguments:
            target_position (Position): 想要部屬的股票部位。
            account (Account): 目前支援永豐與富果帳戶，請參考 Account 來實做。
        """

        if isinstance(target_position, dict):
            target_position = Position(target_position)

        self.account = account
        self.target_position = target_position

    def show_alerting_stocks(self) -> None:
        """產生下單部位是否有警示股，以及相關資訊"""

        present_position = self.account.get_position()
        new_orders = (self.target_position - present_position).position

        symbols = [self._symbol(o) for o in new_orders]
        quantity = {self._symbol(o): o["quantity"] for o in new_orders}

        credit_sids = [
            sid
            for url in SINOTRADE_ALERTING_URLS
            for sid in _fetch_alerting_symbols(url, symbols)
        ]

        if not credit_sids:
            print("待下單股票中無處置股或警示股。")
            return

        close = data.get("price:收盤價").ffill().iloc[-1]
        print("=== 處置股/警示股警告 ===")
        print("以下待下單股票在處置股或信用警示名單中：")
        for sid in credit_sids:
            quantity[sid] = float(quantity[sid])
            if quantity[sid] > 0:
                total_amount = quantity[sid] * close[sid] * 1000 * 1.1
                print(
                    f"買入 {sid} {quantity[sid]:>5} 張 - 總價約 {total_amount:>15.2f}"
                )
            else:
                total_amount = quantity[sid] * close[sid] * 1000 * 0.9
                print(
                    f"賣出 {sid} {quantity[sid]:>5} 張 - 總價約 {total_amount:>15.2f}"
                )
        print("請注意：處置股可能有預收款券、分盤交易等限制。")

    def cancel_orders(
        self, buy_only: bool = False, sell_only: bool = False
    ) -> None:
        """刪除所有未實現委託單

        Attributes:
            buy_only (bool): 若設為 True，只取消買單
            sell_only (bool): 若設為 True，只取消賣單
        """
        if buy_only and sell_only:
            raise ValueError(
                "The buy_only and sell_only parameters cannot be set to True at the same time."
            )
        orders = self.account.get_orders()
        for oid, o in orders.items():
            if o.status not in (OrderStatus.NEW, OrderStatus.PARTIALLY_FILLED):
                continue
            if buy_only and o.action == Action.SELL:
                continue
            if sell_only and o.action == Action.BUY:
                continue
            self.account.cancel_order(oid)

    def _validate_execute_args(
        self,
        market_order: bool,
        best_price_limit: bool,
        extra_bid_pct: float,
        buy_only: bool,
        sell_only: bool,
    ) -> None:
        # 在取消舊委託之前檢查，參數不合法時不會撤掉掛單卻沒下新單
        if [market_order, best_price_limit, bool(extra_bid_pct)].count(True) > 1:
            raise ValueError(
                "Only one of 'market_order', 'best_price_limit', or 'extra_bid_pct' can be set."
            )
        if extra_bid_pct < -0.1 or extra_bid_pct > 0.1:
            raise ValueError(
                "The extra_bid_pct parameter is out of the valid range 0 to 0.1"
            )
        if buy_only and sell_only:
            raise ValueError(
                "The buy_only and sell_only parameters cannot be set to True at the same time."
            )
        if best_price_limit and not self.account.support_best_price_limit():
            raise ValueError(
                "這個券商沒有漲跌停價，不支援 best_price_limit；想掛不會立刻成交的單可改用負的 extra_bid_pct（例如 -0.05），要立即成交用 market_order=True"
            )

    @staticmethod
    def _validate_progress(progress: float, progress_precision: int | None) -> None:
        if progress == 1:
            return
        if not (progress >= 0 and progress <= 1):
            raise ValueError("progress should be in the range of 0 to 1")
        if progress_precision is None:
            raise ValueError("progress_precision should be set when progress is not 1")

    def _account_target_position(self) -> Position:
        """目標部位換成帳戶下單用的代號（幣安要去掉計價幣）"""
        target_position = Position.from_list(copy.copy(self.target_position.position))
        if hasattr(self.account, "base_currency"):
            base_currency = self.account.base_currency
            for pp in target_position.position:
                sid = self._symbol(pp)
                if sid[-len(base_currency) :] == base_currency:
                    pp["symbol"] = sid[: -len(base_currency)]
                    pp["stock_id"] = pp["symbol"]
                else:
                    raise ValueError(
                        f"Stock ID {sid} does not end with {base_currency}"
                    )
        return target_position

    @staticmethod
    def _convert_quantity_type(
        quantity: float | Decimal, quantity_type: str
    ) -> Decimal | float | str:
        if quantity_type == "decimal":
            return quantity if isinstance(quantity, Decimal) else Decimal(str(quantity))
        if quantity_type == "float":
            return float(quantity)
        if quantity_type == "string":
            if isinstance(quantity, Decimal):
                return format(quantity, "f")
            return str(quantity)
        raise ValueError(
            "quantity_type should be one of {'decimal', 'float', 'string'}"
        )

    @staticmethod
    def _symbol(payload: dict[str, Any]) -> str:
        return resolve_position_entry_symbol(payload)

    @staticmethod
    def _order_symbol(order: Any) -> str:
        sid = getattr(order, "symbol", None)
        if isinstance(sid, str) and sid:
            return sid
        return order.stock_id

    def _to_order_entries(
        self, order_payloads: list[dict[str, Any]], quantity_type: str = "decimal"
    ) -> list[Any]:
        from finlab.schemas import OrderEntry

        entries = []
        for payload in order_payloads:
            sid = self._symbol(payload)
            quantity = self._convert_quantity_type(payload["quantity"], quantity_type)
            entries.append(
                OrderEntry(
                    symbol=sid,
                    quantity=quantity,
                    order_condition=payload["order_condition"],
                )
            )
        return entries

    def generate_orders(
        self,
        progress: float = 1,
        progress_precision: int | None = 0,
        as_entries: bool | None = None,
        quantity_type: str = "decimal",
        _internal: bool = False,
    ) -> list[dict[str, Any]] | list[Any]:
        """
        Generate orders based on the difference between target position and present position.

        Returns:
        orders (dict): Orders to be executed.
        """

        strict_mode = is_typed_strict_mode()

        if strict_mode and not _internal:
            if as_entries is False:
                raise ValueError(
                    "strict mode requires typed output; use as_entries=True or generate_order_entries()"
                )
            if as_entries is None:
                as_entries = True

        if as_entries is None:
            as_entries = False

        self._validate_progress(progress, progress_precision)
        target_position = self._account_target_position()

        present_position = self.account.get_position()
        # 現沖先買／先賣成交後，多數券商（例如永豐）把部位回報成現股多單／空單；這時目標也用現股比對，避免盤中重跑同步一賣一買
        present_keys = {
            (self._symbol(p), p["order_condition"]) for p in present_position.position
        }
        target_keys = {
            (self._symbol(p), p["order_condition"]) for p in target_position.position
        }
        present_cash_short = {
            self._symbol(p)
            for p in present_position.position
            if p["order_condition"] == OrderCondition.CASH and p["quantity"] < 0
        }
        us_market = None
        day_trading_short_as_cash = set()
        for pp in target_position.position:
            sid = self._symbol(pp)
            if (
                pp["order_condition"] == OrderCondition.DAY_TRADING_LONG
                and (sid, OrderCondition.CASH) in present_keys
                and (sid, OrderCondition.DAY_TRADING_LONG) not in present_keys
                and (sid, OrderCondition.CASH) not in target_keys
            ) or (
                pp["order_condition"] == OrderCondition.DAY_TRADING_SHORT
                and sid in present_cash_short
                and (sid, OrderCondition.DAY_TRADING_SHORT) not in present_keys
                and (sid, OrderCondition.CASH) not in target_keys
            ):
                if pp["order_condition"] == OrderCondition.DAY_TRADING_SHORT:
                    day_trading_short_as_cash.add(sid)
                pp["order_condition"] = OrderCondition.CASH
            # 美股券商（嘉信）下單不分融資，持倉回報成現股；台股融資與現股是不同部位，照舊分開
            elif (
                pp["order_condition"] == OrderCondition.MARGIN_TRADING
                and (sid, OrderCondition.CASH) in present_keys
                and (sid, OrderCondition.MARGIN_TRADING) not in present_keys
                and (sid, OrderCondition.CASH) not in target_keys
            ):
                if us_market is None:
                    from finlab.markets.us import USMarket

                    us_market = isinstance(self.account.get_market(), USMarket)
                if us_market:
                    pp["order_condition"] = OrderCondition.CASH
            # 空單目標預設是現股，券商（例如嘉信）回報成融券時也用融券比對，避免每次同步一賣一買
            elif (
                pp["order_condition"] == OrderCondition.CASH
                and pp["quantity"] < 0
                and (sid, OrderCondition.SHORT_SELLING) in present_keys
                and (sid, OrderCondition.CASH) not in present_keys
                and (sid, OrderCondition.SHORT_SELLING) not in target_keys
            ):
                pp["order_condition"] = OrderCondition.SHORT_SELLING

        orders = target_position - present_position
        # 只成交一部分的現沖先賣，剩下要加賣的仍用現沖先賣送出；回補照現股買進
        for o in orders.position:
            if (
                self._symbol(o) in day_trading_short_as_cash
                and o["order_condition"] == OrderCondition.CASH
                and o["quantity"] < 0
            ):
                o["order_condition"] = OrderCondition.DAY_TRADING_SHORT
        if progress != 1:

            def scale(quantity: float) -> float:
                scaled = round(quantity * progress, progress_precision)
                # 進位後超過剩餘差額（例如差 0.8 張進位成 1 張）時改往零捨去；
                # 容差避免 1.4 - 0.4 = 0.9999999999999999 這類浮點誤差把整張捨掉
                if abs(scaled) - abs(quantity) > 1e-9:
                    unit = 10**progress_precision
                    scaled = math.trunc(quantity * progress * unit) / unit
                return scaled

            orders = Position.from_list(
                [
                    {**o, "quantity": scale(float(o["quantity"]))}
                    for o in orders.position
                ]
            )

        if as_entries:
            return self._to_order_entries(orders.position, quantity_type=quantity_type)

        return orders.position

    def generate_order_entries(
        self,
        progress: float = 1,
        progress_precision: int = 0,
        quantity_type: str = "decimal",
    ) -> list[Any]:
        return self.generate_orders(
            progress=progress,
            progress_precision=progress_precision,
            as_entries=True,
            quantity_type=quantity_type,
        )

    def execute_orders(
        self,
        orders: list[dict[str, Any]],
        market_order: bool = False,
        best_price_limit: bool = False,
        view_only: bool = False,
        extra_bid_pct: float = 0,
        cancel_orders: bool = True,
        buy_only: bool = False,
        sell_only: bool = False,
    ) -> list[dict[str, Any]]:
        """產生委託單，將部位同步成 self.target_position
        預設以該商品最後一筆成交價設定為限價來下單

        Attributes:
            orders (list): 欲下單的部位，通常是由 `self.generate_orders` 產生。
            market_order (bool): 以類市價盡量即刻成交：所有買單掛漲停價，所有賣單掛跌停價
            best_price_limit (bool): 掛芭樂價：所有買單掛跌停價，所有賣單掛漲停價
            view_only (bool): 預設為 False，會實際下單。若設為 True，不會下單，只會回傳欲執行的委託單資料(dict)
            extra_bid_pct (float): 以該百分比值乘以價格進行追價下單，如設定為 0.05 時，將以當前價的 +(-)5% 的限價進買入(賣出)，也就是更有機會可以成交，但是成交價格可能不理想；
                假如設定為 -0.05 時，將以當前價的 -(+)5% 進行買入賣出，也就是限價單將不會立即成交，然而假如成交後，價格比較理想。參數有效範圍為 -0.1 到 0.1 內。
            buy_only (bool): 若設為 True，只下買單
            sell_only (bool): 若設為 True，只下賣單
        """
        self._validate_execute_args(
            market_order, best_price_limit, extra_bid_pct, buy_only, sell_only
        )

        if cancel_orders and not view_only:
            self.cancel_orders()

        stocks = self.account.get_stocks(list({self._symbol(o) for o in orders}))

        pinfo = None
        if hasattr(self.account, "get_price_info"):
            pinfo = self.account.get_price_info()

        market = self.account.get_market() if extra_bid_pct != 0 else None

        executed_orders: list[dict[str, Any]] = []
        # make orders
        for o in orders:
            if o["quantity"] == 0:
                continue

            sid = self._symbol(o)
            action = Action.BUY if o["quantity"] > 0 else Action.SELL

            if buy_only and action == Action.SELL:
                continue

            if sell_only and action == Action.BUY:
                continue

            if sid not in stocks:
                logger.warning(sid + " not in stocks... skipped!")
                continue

            stock = stocks[sid]
            price: float = (
                stock.close
                if isinstance(stock.close, numbers.Number)
                else (stock.bid_price if action == Action.BUY else stock.ask_price)
            )

            if extra_bid_pct != 0:
                price = calculate_price_with_extra_bid(
                    price,
                    extra_bid_pct if action == Action.BUY else -extra_bid_pct,
                    market,
                    sid,
                )

            if pinfo and sid in pinfo:
                limitup = float(pinfo[sid]["漲停價"])
                limitdn = float(pinfo[sid]["跌停價"])
                price = max(price, limitdn)
                price = min(price, limitup)
            else:
                logger.warning("No price info for stock %s", sid)

            if isinstance(price, Decimal):
                price = format(price, "f")

            if best_price_limit:
                price_string = "LOWEST" if action == Action.BUY else "HIGHEST"
            elif market_order:
                price_string = "HIGHEST" if action == Action.BUY else "LOWEST"
            else:
                price_string = str(price)

            extra_bid_text = ""
            if extra_bid_pct > 0:
                extra_bid_text = f"with extra bid {extra_bid_pct * 100}%"

            action_str = "BUY" if action == Action.BUY else "SELL"
            order_condition_str = (
                "CASH"
                if o["order_condition"] == OrderCondition.CASH
                else "MARGIN_TRADING"
                if o["order_condition"] == OrderCondition.MARGIN_TRADING
                else "SHORT_SELLING"
                if o["order_condition"] == OrderCondition.SHORT_SELLING
                else "DAY_TRADING_LONG"
                if o["order_condition"] == OrderCondition.DAY_TRADING_LONG
                else "DAY_TRADING_SHORT"
                if o["order_condition"] == OrderCondition.DAY_TRADING_SHORT
                else "UNKNOWN"
            )
            print(
                f'{action_str:<11} {sid:10} X {round(abs(o["quantity"]), 3):<10} @ {price_string:<11} {extra_bid_text} {order_condition_str}'
            )

            # Record orders that passed all filters (before view_only check)
            executed_orders.append(o)

            quantity = abs(o["quantity"])
            # 先換成股數再拆，避免 0.9999999999999999 張被拆成 1000 股零股單
            board_lot_quantity, odd_lot_quantity = divmod(round(quantity * 1000), 1000)

            if view_only:
                continue

            if self.account.sep_odd_lot_order():
                if odd_lot_quantity != 0:
                    self.account.create_order(
                        action=action,
                        stock_id=sid,
                        quantity=odd_lot_quantity,
                        price=price,
                        market_order=market_order,
                        order_cond=o["order_condition"],
                        odd_lot=True,
                        best_price_limit=best_price_limit,
                    )

                if board_lot_quantity != 0:
                    self.account.create_order(
                        action=action,
                        stock_id=sid,
                        quantity=board_lot_quantity,
                        price=price,
                        market_order=market_order,
                        order_cond=o["order_condition"],
                        best_price_limit=best_price_limit,
                    )
            else:
                self.account.create_order(
                    action=action,
                    stock_id=sid,
                    quantity=quantity,
                    price=price,
                    market_order=market_order,
                    order_cond=o["order_condition"],
                    best_price_limit=best_price_limit,
                )

        return executed_orders

    def create_orders(
        self,
        market_order: bool = False,
        best_price_limit: bool = False,
        view_only: bool = False,
        extra_bid_pct: float = 0,
        progress: float = 1,
        progress_precision: int = 0,
        buy_only: bool = False,
        sell_only: bool = False,
    ) -> list[dict[str, Any]]:
        """產生委託單，將部位同步成 self.target_position
        預設以該商品最後一筆成交價設定為限價來下單

        Attributes:
            market_order (bool): 以類市價盡量即刻成交：所有買單掛漲停價，所有賣單掛跌停價
            best_price_limit (bool): 掛芭樂價：所有買單掛跌停價，所有賣單掛漲停價
            view_only (bool): 預設為 False，會實際下單。若設為 True，不會下單，只會回傳欲執行的委託單資料(dict)
            extra_bid_pct (float): 以該百分比值乘以價格進行追價下單，如設定為 0.05 時，將以當前價的 +(-)5% 的限價進買入(賣出)，也就是更有機會可以成交，但是成交價格可能不理想；
                假如設定為 -0.05 時，將以當前價的 -(+)5% 進行買入賣出，也就是限價單將不會立即成交，然而假如成交後，價格比較理想。參數有效範圍為 -0.1 到 0.1 內。
            progress (float): 進度，預設為 1，即全部下單。若設定為 0.5，則只下一半的單。
            progress_precision (int): 進度的精度，預設為 0，即只下整數張。若設定為 1，則下到 0.1 張。
            buy_only (bool): 若設為 True，只下買單
            sell_only (bool): 若設為 True，只下賣單
        """
        self._validate_execute_args(
            market_order, best_price_limit, extra_bid_pct, buy_only, sell_only
        )
        # 參數或目標部位有錯要在撤單前報，不留下撤了舊單卻沒下新單的帳戶
        self._validate_progress(progress, progress_precision)
        self._account_target_position()
        if not view_only:
            self.cancel_orders()

        orders = self.generate_orders(progress, progress_precision, _internal=True)
        return self.execute_orders(
            orders,
            market_order,
            best_price_limit,
            view_only,
            extra_bid_pct,
            cancel_orders=False,
            buy_only=buy_only,
            sell_only=sell_only,
        )

    def update_order_price(
        self,
        extra_bid_pct: float = 0,
        buy_only: bool = False,
        sell_only: bool = False,
    ) -> None:
        """更新委託單，將委託單的限價調整成當天最後一筆價格。
        （讓沒成交的限價單去追價）
        Attributes:
            extra_bid_pct (float): 以該百分比值乘以價格進行追價下單，如設定為 0.1 時，將以超出(低於)現價之10%價格下單，以漲停(跌停)價為限。參數有效範圍為 0 到 0.1 內
            buy_only (bool): 若設為 True，只更新買單
            sell_only (bool): 若設為 True，只更新賣單
        """
        if extra_bid_pct < -0.1 or extra_bid_pct > 0.1:
            raise ValueError(
                "The extra_bid_pct parameter is out of the valid range 0 to 0.1"
            )
        if buy_only and sell_only:
            raise ValueError(
                "The buy_only and sell_only parameters cannot be set to True at the same time."
            )
        orders = self.account.get_orders()
        sids = {self._order_symbol(o) for _, o in orders.items()}
        stocks = self.account.get_stocks(sids)

        pinfo = None
        if hasattr(self.account, "get_price_info"):
            pinfo = self.account.get_price_info()

        market = self.account.get_market() if extra_bid_pct != 0 else None

        for i, o in orders.items():
            if o.status in (OrderStatus.NEW, OrderStatus.PARTIALLY_FILLED):
                if buy_only and o.action == Action.SELL:
                    continue

                if sell_only and o.action == Action.BUY:
                    continue

                sid = self._order_symbol(o)
                price = stocks[sid].close
                price = calculate_price_with_extra_bid(
                    price,
                    extra_bid_pct if o.action == Action.BUY else -extra_bid_pct,
                    market,
                    sid,
                )

                if pinfo and sid in pinfo:
                    up_limit = float(pinfo[sid]["漲停價"])
                    dn_limit = float(pinfo[sid]["跌停價"])
                    price = max(price, dn_limit)
                    price = min(price, up_limit)
                else:
                    logger.warning("No price info for stock %s", sid)

                # 追價與漲跌停夾價算完才比，原價等於報價時仍照 extra_bid_pct 改價
                if o.price == price:
                    continue

                self.account.update_order(i, price=price)

    def get_order_info(self) -> list[dict[str, Any]]:

        def calc_order_info(oe: OrderExecutor) -> dict[str, list[dict[str, Any]]]:
            target = oe.target_position
            current = oe.account.get_position()
            return {
                "target": target.to_list(),
                "current": current.to_list(),
                "orders": (target - current).to_list(),
            }

        def get_symbols(orders: list[dict[str, Any]]) -> list[tuple[str, str]]:
            return [(self._symbol(o), str(o["order_condition"])) for o in orders]

        def find_symbols(orders: list[dict[str, Any]], symbol: str) -> dict[str, Any]:
            ret = [o for o in orders if self._symbol(o) == symbol]
            if len(ret) == 0:
                return {
                    "quantity": 0,
                    "symbol": symbol[0],
                    "order_condition": symbol[1],
                }
            return ret[0]

        orders = calc_order_info(self)
        symbols = sorted(
            set(get_symbols(orders["target"]) + get_symbols(orders["current"]))
        )
        stocks = self.account.get_stocks(list({s[0] for s in symbols}))

        order_info: list[dict[str, Any]] = []
        for s in symbols:
            pqty = float(find_symbols(orders["current"], s[0])["quantity"])
            tqty = float(find_symbols(orders["target"], s[0])["quantity"])
            order_info.append(
                {
                    "price": stocks[s[0]].close,
                    "current_qty": pqty,
                    "target_qty": tqty,
                    "order_qty": tqty - pqty,
                    "symbol": s[0],
                    "order_condition": s[1],
                }
            )

        return sorted(
            order_info, key=lambda x: x["order_qty"] * x["price"], reverse=True
        )


def calculate_price_with_extra_bid(
    price: float, extra_bid_pct: float, market: Any = None, symbol: str = ""
) -> float:

    if extra_bid_pct == 0:
        return price

    # 幣安以 Decimal 報價，跳動單位依商品而異，下單時由券商調整
    if isinstance(price, Decimal):
        return price * (1 + Decimal(str(extra_bid_pct)))

    from finlab.markets.us import USMarket
    from finlab.online.core.utils import (
        _round_to_etf_tick,
        _round_to_tick,
        _round_to_us_tick,
    )

    result = price * (1 + extra_bid_pct)
    direction = "floor" if extra_bid_pct > 0 else "ceil"
    if isinstance(market, USMarket):
        round_to_tick = _round_to_us_tick
    elif symbol.startswith("00"):
        # 台股 ETF 代號 00 開頭，跳動單位比股票細
        round_to_tick = _round_to_etf_tick
    else:
        round_to_tick = _round_to_tick
    return round_to_tick(result, direction)
