"""WeightAccessor — accessed via ``df.weight.xxx``."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

from finlab.dataframe.sector import resolve_labels, row_groups

if TYPE_CHECKING:
    from collections.abc import Mapping

    from finlab.dataframe.core import FinlabDataFrame
    from finlab.dataframe.sector import SectorBy


def _solve_risk_parity(cov: np.ndarray) -> np.ndarray:
    """Solve for equal risk contribution weights via fixed-point iteration."""
    n = cov.shape[0]
    w = np.ones(n) / n

    for _ in range(200):
        sigma_w = cov @ w
        risk_contrib = w * sigma_w
        if np.any(risk_contrib <= 0):
            return np.ones(n) / n
        target_rc = risk_contrib.sum() / n
        w_new = w * (target_rc / risk_contrib)
        w_new /= w_new.sum()
        if np.max(np.abs(w_new - w)) < 1e-10:
            return w_new
        w = w_new

    return w


def _get_returns(price: pd.DataFrame | None) -> pd.DataFrame:
    """Daily returns that span NaN gaps instead of dropping them."""
    if price is None:
        from finlab import data as finlab_data

        price = finlab_data.get("etl:adj_close")
    return price.ffill().pct_change(fill_method=None)


def _unknown_as_nan(df: pd.DataFrame) -> pd.DataFrame:
    """Cast nullable boolean masks to float so numpy reads unknown as NaN.

    Quarterly masks aligned to daily dates hold ``pd.NA`` before the first
    disclosure, and ``.values.astype(float)`` cannot convert ``pd.NA``.
    """
    nullable = [
        col for col, dtype in df.dtypes.items() if isinstance(dtype, pd.BooleanDtype)
    ]
    return df.astype(dict.fromkeys(nullable, float)) if nullable else df


def _as_exposure_weights(position: pd.DataFrame) -> np.ndarray:
    """Return the weights ``sim()`` would actually hold: ``sum(|w|) <= 1`` per row.

    ``sim()`` rescales every row whose gross weight exceeds 1 back to 1, so a
    boolean selection (``True`` counts as 1) or an un-normalised score becomes
    a fully invested equal/pro-rata portfolio. Exposure-scaling methods must
    start from these explicit weights; otherwise a ``0.5`` scale applied to a
    row summing to 10 still sums to 5 and ``sim()`` restores full exposure.
    Unknown (NaN) weights mean "not held".
    """
    from finlab.backtest.helpers import normalize_position_weights

    return normalize_position_weights(position.to_numpy(), position_limit=1.0)


class WeightAccessor:
    """Portfolio weight methods, accessible as ``df.weight.<method>(...)``."""

    def __init__(self, obj: FinlabDataFrame) -> None:
        self._obj = _unknown_as_nan(obj)

    def _reshape(self, other: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
        from finlab.dataframe.core import FinlabDataFrame

        aligned, position = FinlabDataFrame.reshape(other, self._obj)
        return aligned, _unknown_as_nan(position)

    def _wrap(
        self, arr: np.ndarray, index: pd.Index, columns: pd.Index
    ) -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame

        return FinlabDataFrame(arr, index=index, columns=columns)

    # ------------------------------------------------------------------
    # Constraint methods
    # ------------------------------------------------------------------

    def cap_industry(self, max_weight: float) -> FinlabDataFrame:
        """限制每個產業的最大權重

        對每一列（日期），若某產業的持股總權重超過 max_weight，
        則按比例縮小該產業內的持股權重，並將多餘的權重按比例重新分配給未超限的產業。
        迭代執行直到所有產業皆符合上限。

        輸入會先轉成 ``sim()`` 實際持有的權重（每列 Σ|w| ≤ 1；布林部位視為等權、
        Σ|w| > 1 的列按比例壓回 1）再計算。

        Args:
            max_weight (float): 每個產業的最大權重上限（例如 0.3 表示 30%）。

        Returns:
            (FinlabDataFrame): 調整後的權重。

        Examples:
            ```py
            position = position.weight.cap_industry(0.3)
            ```
        """
        col_cat = self._obj._get_column_categories().values
        unique_ind = np.unique(col_cat)
        ind_cols = {ind: np.where(col_cat == ind)[0] for ind in unique_ind}

        result = _as_exposure_weights(self._obj)

        for i in range(result.shape[0]):
            row = result[i]
            original_total = np.nansum(row)
            if original_total <= 0:
                continue

            frozen: set[str] = set()

            for _ in range(len(unique_ind)):
                changed = False
                for ind, cols in ind_cols.items():
                    if ind in frozen:
                        continue
                    total = np.nansum(row[cols])
                    if total > max_weight + 1e-10:
                        row[cols] *= max_weight / total
                        frozen.add(ind)
                        changed = True

                if not changed:
                    break

                # Summed in ind_cols order: iterating the set would follow
                # PYTHONHASHSEED and change the float sum between processes.
                frozen_total = sum(
                    np.nansum(row[cols])
                    for ind, cols in ind_cols.items()
                    if ind in frozen
                )
                unfrozen_cols = (
                    np.concatenate(
                        [ind_cols[ind] for ind in unique_ind if ind not in frozen]
                    )
                    if len(frozen) < len(unique_ind)
                    else np.array([], dtype=int)
                )
                unfrozen_total = (
                    np.nansum(row[unfrozen_cols]) if len(unfrozen_cols) > 0 else 0.0
                )
                target_unfrozen = original_total - frozen_total

                if unfrozen_total > 1e-10 and target_unfrozen > 0:
                    row[unfrozen_cols] *= target_unfrozen / unfrozen_total

        return self._wrap(result, self._obj.index, self._obj.columns)

    def clip_by_volume(
        self,
        total_fund: float,
        max_participation_ratio: float = 0.1,
        volume: pd.DataFrame | None = None,
        window: int = 20,
    ) -> FinlabDataFrame:
        """依成交量限制個股權重

        根據總資金規模和最大參與率，計算每支股票的最大可持有權重。
        若個股權重超過限制，則裁剪至上限，多餘權重按比例分配給未超限的股票。

        每支股票的最大權重 = (平均日成交金額 × max_participation_ratio) / total_fund

        輸入會先轉成 ``sim()`` 實際持有的權重（每列 Σ|w| ≤ 1；布林部位視為等權、
        Σ|w| > 1 的列按比例壓回 1）再計算。

        Args:
            total_fund (float): 總資金規模（單位：元）。
            max_participation_ratio (float): 佔平均日成交金額的最大比例。預設 0.1（10%）。
            volume (pd.DataFrame | None): 自訂日成交金額 DataFrame。
                若為 None，自動取得 ``price:成交金額``。
            window (int): 計算平均日成交金額的滾動窗口天數。預設 20。

        Returns:
            (FinlabDataFrame): 調整後的權重。

        Examples:
            ```py
            position = position.weight.clip_by_volume(
                total_fund=1e8, max_participation_ratio=0.1
            )
            ```
        """
        from finlab import data as finlab_data

        if volume is None:
            volume = finlab_data.get("price:成交金額")

        adv = volume.rolling(window, min_periods=1).mean()
        adv_aligned, weights = self._reshape(adv)

        max_w = (
            np.nan_to_num(adv_aligned.values * max_participation_ratio, nan=0.0)
            / total_fund
        )
        result = _as_exposure_weights(weights)

        for i in range(result.shape[0]):
            row = result[i]
            caps = max_w[i]
            original_total = np.nansum(row)
            if original_total <= 0:
                continue

            frozen = np.zeros(len(row), dtype=bool)

            for _ in range(len(row)):
                over = (row > caps + 1e-10) & ~frozen
                if not np.any(over):
                    break

                row[over] = caps[over]
                frozen |= over

                frozen_total = np.nansum(row[frozen])
                unfrozen = ~frozen & (row > 0)
                unfrozen_total = np.nansum(row[unfrozen])
                target_unfrozen = original_total - frozen_total

                if unfrozen_total <= 1e-10 or target_unfrozen <= 0:
                    break

                row[unfrozen] *= target_unfrozen / unfrozen_total

        return self._wrap(result, weights.index, weights.columns)

    def limit_turnover(self, max_turnover: float) -> FinlabDataFrame:
        """限制換手率

        當相鄰兩列的權重變動（雙向換手率）超過上限時，
        將新權重與前一列混合，使實際換手率不超過 max_turnover。
        每列以已混合的前一列為基準，依序處理。

        輸入會先轉成 ``sim()`` 實際持有的權重（每列 Σ|w| ≤ 1；布林部位視為等權、
        Σ|w| > 1 的列按比例壓回 1）再計算。

        限制的是相鄰兩列之間的換手。日頻部位搭配 ``sim(resample='M')`` 這類
        定期換股時，先用 ``.rebalance('ME')`` 只留換股日再呼叫，限制的才是
        每次換股之間的換手；否則限制的是每天的換手，每月實際換手不受限。

        Args:
            max_turnover (float): 最大雙向換手率（權重絕對變動加總）。
                例如 0.2 表示最多 20% 的權重可以變動。

        Returns:
            (FinlabDataFrame): 調整後的權重。

        Examples:
            ```py
            position = position.weight.limit_turnover(0.2)
            ```
        """
        result = _as_exposure_weights(self._obj)

        for i in range(1, len(result)):
            delta = result[i] - result[i - 1]
            turnover = np.nansum(np.abs(delta))
            if turnover > max_turnover + 1e-10:
                scale = max_turnover / turnover
                result[i] = result[i - 1] + scale * delta

        return self._wrap(result, self._obj.index, self._obj.columns)

    # ------------------------------------------------------------------
    # Weighting methods
    # ------------------------------------------------------------------

    def by_group(
        self,
        weights: Mapping[str, float],
        by: SectorBy = None,
        default: float = 0.0,
    ) -> FinlabDataFrame:
        """依群組（產業）分配權重

        每列（日期）內，將各群組的持股權重正規化，使群組權重合計等於指定占比。
        指定占比合計小於 1 時，剩餘部分留為現金；
        當日沒有持股的群組，其占比也留為現金（不重新分配給其他群組）。

        Args:
            weights (dict): 群組名 → 目標權重合計，例如 ``{"半導體業": 0.4, "金融保險業": 0.2}``。
                合計不可超過 1。
            by: 自訂分類（dict、pd.Series 或時變 pd.DataFrame），
                格式同 ``df.sector(by=...)``。若為 None，使用預設產業分類。
            default (float): 未列於 weights 的群組所分配的權重合計。預設 0。

        Returns:
            (FinlabDataFrame): 調整後的權重。

        Examples:
            ```py
            selected = roe.sector.rank() > 0.8
            position = selected.weight.by_group({"半導體業": 0.5, "金融保險業": 0.3})
            ```
        """
        if sum(weights.values()) > 1 + 1e-9:
            raise ValueError(
                "weights 合計不可超過 1 / The sum of weights must not exceed 1"
            )

        groups = row_groups(*resolve_labels(self._obj, by))
        arr = np.ascontiguousarray(self._obj.values, dtype=float)
        result = np.zeros(arr.shape)

        for i in range(arr.shape[0]):
            row = arr[i]
            for group, columns in groups(i):
                # Labels come out of an object-dtype array, so narrow to the str keys
                # that ``weights`` is declared with.
                target = weights.get(str(group), default)
                values = row[columns]
                sel = values > 0
                total = values[sel].sum()
                if target > 0 and total > 0:
                    result[i, columns[sel]] = values[sel] / total * target

        return self._wrap(result, self._obj.index, self._obj.columns)

    def inverse_volatility(
        self, window: int = 60, price: pd.DataFrame | None = None
    ) -> FinlabDataFrame:
        """反波動率加權

        非零持股按歷史波動率的倒數分配權重，波動率低的股票獲得較高權重。

        Args:
            window (int): 計算波動率的滾動窗口天數。預設 60。
            price (pd.DataFrame | None): 股價 DataFrame。若為 None，自動取得 ``etl:adj_close``。

        Returns:
            (FinlabDataFrame): 加權後的權重。

        Examples:
            ```py
            position = position.weight.inverse_volatility(window=60)
            ```
        """
        vol = _get_returns(price).rolling(window, min_periods=window).std()
        vol_aligned, pos = self._reshape(vol)

        v = vol_aligned.values.astype(float)
        p = pos.values.astype(float)

        active = (p != 0) & ~np.isnan(p)
        safe_vol = np.where(active & (v > 0), v, np.nan)
        inv_vol = np.where(np.isnan(safe_vol), 0.0, 1.0 / safe_vol)

        row_sums = np.nansum(inv_vol, axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1.0
        original_sums = np.nansum(np.where(active, p, 0.0), axis=1, keepdims=True)

        result = inv_vol / row_sums * original_sums
        result[~active] = p[~active]

        return self._wrap(result, pos.index, pos.columns)

    def risk_parity(
        self, window: int = 60, price: pd.DataFrame | None = None
    ) -> FinlabDataFrame:
        """風險平價加權

        使每個持股對投資組合風險的貢獻相等，使用滾動共變異數矩陣。

        Args:
            window (int): 計算共變異數矩陣的滾動窗口天數。預設 60。
            price (pd.DataFrame | None): 股價 DataFrame。若為 None，自動取得 ``etl:adj_close``。

        Returns:
            (FinlabDataFrame): 風險平價權重。

        Examples:
            ```py
            position = position.weight.risk_parity(window=60)
            ```
        """
        returns = _get_returns(price)
        returns_aligned, pos = self._reshape(returns)

        r_arr = returns_aligned.values.astype(float)
        p_arr = pos.values.astype(float)
        result = p_arr.copy()

        for i in range(window, len(result)):
            active = (p_arr[i] != 0) & ~np.isnan(p_arr[i])
            active_idx = np.where(active)[0]
            n_active = len(active_idx)

            if n_active < 2:
                continue

            sub_ret = r_arr[max(0, i - window) : i, :][:, active_idx]
            mask = ~np.isnan(sub_ret)
            if mask.sum(axis=0).min() < 2:
                continue

            sub_ret = np.nan_to_num(sub_ret)
            cov = np.cov(sub_ret, rowvar=False)
            if cov.ndim < 2:
                continue

            w = _solve_risk_parity(cov)
            original_sum = np.nansum(np.abs(p_arr[i, active_idx]))
            result[i, active_idx] = w * original_sum
            result[i, ~active] = 0.0

        return self._wrap(result, pos.index, pos.columns)

    def correlation(
        self,
        window: int = 60,
        price: pd.DataFrame | None = None,
        diversify: bool = True,
    ) -> FinlabDataFrame:
        """依相關性調整權重

        計算每支股票與其他持股的平均相關係數，據此調整權重。

        - ``diversify=True``：高平均相關性 → 低權重（分散化）。
        - ``diversify=False``：高平均相關性 → 高權重（集中化）。

        Args:
            window (int): 計算相關係數的滾動窗口天數。預設 60。
            price (pd.DataFrame | None): 股價 DataFrame。若為 None，自動取得 ``etl:adj_close``。
            diversify (bool): True 為分散化（反相關加權），False 為集中化。預設 True。

        Returns:
            (FinlabDataFrame): 調整後的權重。

        Examples:
            ```py
            position = position.weight.correlation(diversify=True)
            ```
        """
        returns = _get_returns(price)
        returns_aligned, pos = self._reshape(returns)

        r_arr = returns_aligned.values.astype(float)
        p_arr = pos.values.astype(float)
        result = p_arr.copy()

        for i in range(window, len(result)):
            active = (p_arr[i] != 0) & ~np.isnan(p_arr[i])
            active_idx = np.where(active)[0]
            n_active = len(active_idx)

            if n_active < 2:
                continue

            sub_ret = np.nan_to_num(r_arr[max(0, i - window) : i, :][:, active_idx])
            corr = np.corrcoef(sub_ret, rowvar=False)
            np.fill_diagonal(corr, 0.0)
            avg_corr = np.abs(corr).mean(axis=1)

            if diversify:
                raw = np.where(avg_corr > 1e-10, 1.0 / avg_corr, 1.0)
            else:
                raw = avg_corr

            total = raw.sum()
            if total <= 1e-10:
                continue

            original_sum = np.nansum(np.abs(p_arr[i, active_idx]))
            result[i, active_idx] = raw / total * original_sum
            result[i, ~active] = 0.0

        return self._wrap(result, pos.index, pos.columns)

    # ------------------------------------------------------------------
    # Dynamic scaling methods
    # ------------------------------------------------------------------

    def target_volatility(
        self, target: float, window: int = 20, price: pd.DataFrame | None = None
    ) -> FinlabDataFrame:
        """目標波動率調整

        根據滾動實現波動率縮放持股權重，使投資組合波動率趨近目標值。

        輸入會先轉成 ``sim()`` 實際持有的權重（每列 Σ|w| ≤ 1；布林部位視為等權、
        Σ|w| > 1 的列按比例壓回 1），再乘上縮放因子，因此縮放後的曝險不會被
        ``sim()`` 的正規化抵銷。
        縮放因子大於 1 時列和可能超過 1，``sim()`` 會將其壓回滿倉（不支援槓桿）。

        Args:
            target (float): 目標年化波動率（例如 0.10 表示 10%）。
            window (int): 計算波動率的滾動窗口天數。預設 20。
            price (pd.DataFrame | None): 股價 DataFrame。若為 None，自動取得 ``etl:adj_close``。

        Returns:
            (FinlabDataFrame): 縮放後的權重（每列 Σ|w| ≤ 1 再乘縮放因子）。

        Examples:
            ```py
            position = position.weight.target_volatility(target=0.10)
            ```
        """
        returns = _get_returns(price)
        returns_aligned, pos = self._reshape(returns)

        r = returns_aligned.values.astype(float)
        w = _as_exposure_weights(pos)

        port_ret = (w * np.nan_to_num(r)).sum(axis=1)
        rolling_vol = pd.Series(port_ret).rolling(
            window, min_periods=window
        ).std().values * np.sqrt(252)

        result = w.copy()
        for i in range(1, len(result)):
            if i >= window and rolling_vol[i] > 1e-10:
                scale = target / rolling_vol[i]
                result[i] = w[i] * scale
            elif i < window:
                pass  # keep original weights during warmup
            else:
                result[i] = 0.0

        return self._wrap(result, pos.index, pos.columns)

    def drawdown_control(
        self, max_drawdown: float, price: pd.DataFrame | None = None
    ) -> FinlabDataFrame:
        """回撤控制

        當投資組合回撤超過門檻時，按比例縮小持股權重。
        縮放因子 = max_drawdown / |當前回撤|，使風險暴露隨回撤加深而降低。

        輸入會先轉成 ``sim()`` 實際持有的權重（每列 Σ|w| ≤ 1；布林部位視為等權、
        Σ|w| > 1 的列按比例壓回 1），再乘上縮放因子，因此縮放後的曝險不會被
        ``sim()`` 的正規化抵銷。

        Args:
            max_drawdown (float): 最大可容忍回撤（正數，例如 0.1 表示 10%）。
            price (pd.DataFrame | None): 股價 DataFrame。若為 None，自動取得 ``etl:adj_close``。

        Returns:
            (FinlabDataFrame): 調整後的權重（每列 Σ|w| ≤ 1 再乘縮放因子）。

        Examples:
            ```py
            position = position.weight.drawdown_control(max_drawdown=0.1)
            ```
        """
        returns = _get_returns(price)
        returns_aligned, pos = self._reshape(returns)

        r_arr = returns_aligned.values.astype(float)
        w_orig = _as_exposure_weights(pos)
        result = w_orig.copy()

        cum_value = 1.0
        peak = 1.0

        for i in range(len(result)):
            if i > 0:
                port_ret = np.nansum(result[i - 1] * np.nan_to_num(r_arr[i]))
                cum_value *= 1.0 + port_ret
                peak = max(peak, cum_value)

            dd = cum_value / peak - 1.0  # negative or zero

            if dd < -max_drawdown:
                scale = max_drawdown / abs(dd)
                result[i] = w_orig[i] * scale

        return self._wrap(result, pos.index, pos.columns)
